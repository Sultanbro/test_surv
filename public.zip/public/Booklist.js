"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["Booklist"],{

/***/ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/ScriptLoader.js":
/*!******************************************************************************!*\
  !*** ./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/ScriptLoader.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "create": () => (/* binding */ create),
/* harmony export */   "load": () => (/* binding */ load)
/* harmony export */ });
/* harmony import */ var _Utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Utils */ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/Utils.js");
/**
 * Copyright (c) 2018-present, Ephox, Inc.
 *
 * This source code is licensed under the Apache 2 license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */

var injectScriptTag = function (scriptId, doc, url, callback) {
    var scriptTag = doc.createElement('script');
    scriptTag.referrerPolicy = 'origin';
    scriptTag.type = 'application/javascript';
    scriptTag.id = scriptId;
    scriptTag.addEventListener('load', callback);
    scriptTag.src = url;
    if (doc.head) {
        doc.head.appendChild(scriptTag);
    }
};
var create = function () {
    return {
        listeners: [],
        scriptId: (0,_Utils__WEBPACK_IMPORTED_MODULE_0__.uuid)('tiny-script'),
        scriptLoaded: false
    };
};
var load = function (state, doc, url, callback) {
    if (state.scriptLoaded) {
        callback();
    }
    else {
        state.listeners.push(callback);
        if (!doc.getElementById(state.scriptId)) {
            injectScriptTag(state.scriptId, doc, url, function () {
                state.listeners.forEach(function (fn) { return fn(); });
                state.scriptLoaded = true;
            });
        }
    }
};


/***/ }),

/***/ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/TinyMCE.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/TinyMCE.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getTinymce": () => (/* binding */ getTinymce)
/* harmony export */ });
/**
 * Copyright (c) 2018-present, Ephox, Inc.
 *
 * This source code is licensed under the Apache 2 license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */
var getGlobal = function () { return (typeof window !== 'undefined' ? window : __webpack_require__.g); };
var getTinymce = function () {
    var global = getGlobal();
    return global && global.tinymce ? global.tinymce : null;
};



/***/ }),

/***/ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/Utils.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/Utils.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "bindHandlers": () => (/* binding */ bindHandlers),
/* harmony export */   "bindModelHandlers": () => (/* binding */ bindModelHandlers),
/* harmony export */   "initEditor": () => (/* binding */ initEditor),
/* harmony export */   "isTextarea": () => (/* binding */ isTextarea),
/* harmony export */   "mergePlugins": () => (/* binding */ mergePlugins),
/* harmony export */   "uuid": () => (/* binding */ uuid)
/* harmony export */ });
/**
 * Copyright (c) 2018-present, Ephox, Inc.
 *
 * This source code is licensed under the Apache 2 license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */
var validEvents = [
    'onActivate',
    'onAddUndo',
    'onBeforeAddUndo',
    'onBeforeExecCommand',
    'onBeforeGetContent',
    'onBeforeRenderUI',
    'onBeforeSetContent',
    'onBeforePaste',
    'onBlur',
    'onChange',
    'onClearUndos',
    'onClick',
    'onContextMenu',
    'onCopy',
    'onCut',
    'onDblclick',
    'onDeactivate',
    'onDirty',
    'onDrag',
    'onDragDrop',
    'onDragEnd',
    'onDragGesture',
    'onDragOver',
    'onDrop',
    'onExecCommand',
    'onFocus',
    'onFocusIn',
    'onFocusOut',
    'onGetContent',
    'onHide',
    'onInit',
    'onKeyDown',
    'onKeyPress',
    'onKeyUp',
    'onLoadContent',
    'onMouseDown',
    'onMouseEnter',
    'onMouseLeave',
    'onMouseMove',
    'onMouseOut',
    'onMouseOver',
    'onMouseUp',
    'onNodeChange',
    'onObjectResizeStart',
    'onObjectResized',
    'onObjectSelected',
    'onPaste',
    'onPostProcess',
    'onPostRender',
    'onPreProcess',
    'onProgressState',
    'onRedo',
    'onRemove',
    'onReset',
    'onSaveContent',
    'onSelectionChange',
    'onSetAttrib',
    'onSetContent',
    'onShow',
    'onSubmit',
    'onUndo',
    'onVisualAid'
];
var isValidKey = function (key) { return validEvents.indexOf(key) !== -1; };
var bindHandlers = function (initEvent, listeners, editor) {
    Object.keys(listeners)
        .filter(isValidKey)
        .forEach(function (key) {
        var handler = listeners[key];
        if (typeof handler === 'function') {
            if (key === 'onInit') {
                handler(initEvent, editor);
            }
            else {
                editor.on(key.substring(2), function (e) { return handler(e, editor); });
            }
        }
    });
};
var bindModelHandlers = function (ctx, editor) {
    var modelEvents = ctx.$props.modelEvents ? ctx.$props.modelEvents : null;
    var normalizedEvents = Array.isArray(modelEvents) ? modelEvents.join(' ') : modelEvents;
    var currentContent;
    ctx.$watch('value', function (val, prevVal) {
        if (editor && typeof val === 'string' && val !== currentContent && val !== prevVal) {
            editor.setContent(val);
            currentContent = val;
        }
    });
    editor.on(normalizedEvents ? normalizedEvents : 'change keyup undo redo', function () {
        currentContent = editor.getContent();
        ctx.$emit('input', currentContent);
    });
};
var initEditor = function (initEvent, ctx, editor) {
    var value = ctx.$props.value ? ctx.$props.value : '';
    var initialValue = ctx.$props.initialValue ? ctx.$props.initialValue : '';
    editor.setContent(value || initialValue);
    // checks if the v-model shorthand is used (which sets an v-on:input listener) and then binds either
    // specified the events or defaults to "change keyup" event and emits the editor content on that event
    if (ctx.$listeners.input) {
        bindModelHandlers(ctx, editor);
    }
    bindHandlers(initEvent, ctx.$listeners, editor);
};
var unique = 0;
var uuid = function (prefix) {
    var time = Date.now();
    var random = Math.floor(Math.random() * 1000000000);
    unique++;
    return prefix + '_' + random + unique + String(time);
};
var isTextarea = function (element) {
    return element !== null && element.tagName.toLowerCase() === 'textarea';
};
var normalizePluginArray = function (plugins) {
    if (typeof plugins === 'undefined' || plugins === '') {
        return [];
    }
    return Array.isArray(plugins) ? plugins : plugins.split(' ');
};
var mergePlugins = function (initPlugins, inputPlugins) {
    return normalizePluginArray(initPlugins).concat(normalizePluginArray(inputPlugins));
};


/***/ }),

/***/ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/components/Editor.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/components/Editor.js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Editor": () => (/* binding */ Editor)
/* harmony export */ });
/* harmony import */ var _ScriptLoader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../ScriptLoader */ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/ScriptLoader.js");
/* harmony import */ var _TinyMCE__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../TinyMCE */ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/TinyMCE.js");
/* harmony import */ var _Utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Utils */ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/Utils.js");
/* harmony import */ var _EditorPropTypes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./EditorPropTypes */ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/components/EditorPropTypes.js");
/**
 * Copyright (c) 2018-present, Ephox, Inc.
 *
 * This source code is licensed under the Apache 2 license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};




var scriptState = _ScriptLoader__WEBPACK_IMPORTED_MODULE_0__.create();
var renderInline = function (h, id, tagName) {
    return h(tagName ? tagName : 'div', {
        attrs: { id: id }
    });
};
var renderIframe = function (h, id) {
    return h('textarea', {
        attrs: { id: id },
        style: { visibility: 'hidden' }
    });
};
var initialise = function (ctx) { return function () {
    var finalInit = __assign({}, ctx.$props.init, { readonly: ctx.$props.disabled, selector: "#" + ctx.elementId, plugins: (0,_Utils__WEBPACK_IMPORTED_MODULE_2__.mergePlugins)(ctx.$props.init && ctx.$props.init.plugins, ctx.$props.plugins), toolbar: ctx.$props.toolbar || (ctx.$props.init && ctx.$props.init.toolbar), inline: ctx.inlineEditor, setup: function (editor) {
            ctx.editor = editor;
            editor.on('init', function (e) { return (0,_Utils__WEBPACK_IMPORTED_MODULE_2__.initEditor)(e, ctx, editor); });
            if (ctx.$props.init && typeof ctx.$props.init.setup === 'function') {
                ctx.$props.init.setup(editor);
            }
        } });
    if ((0,_Utils__WEBPACK_IMPORTED_MODULE_2__.isTextarea)(ctx.element)) {
        ctx.element.style.visibility = '';
    }
    (0,_TinyMCE__WEBPACK_IMPORTED_MODULE_1__.getTinymce)().init(finalInit);
}; };
var Editor = {
    props: _EditorPropTypes__WEBPACK_IMPORTED_MODULE_3__.editorProps,
    created: function () {
        this.elementId = this.$props.id || (0,_Utils__WEBPACK_IMPORTED_MODULE_2__.uuid)('tiny-vue');
        this.inlineEditor = (this.$props.init && this.$props.init.inline) || this.$props.inline;
    },
    watch: {
        disabled: function () {
            this.editor.setMode(this.disabled ? 'readonly' : 'design');
        }
    },
    mounted: function () {
        this.element = this.$el;
        if ((0,_TinyMCE__WEBPACK_IMPORTED_MODULE_1__.getTinymce)() !== null) {
            initialise(this)();
        }
        else if (this.element && this.element.ownerDocument) {
            var doc = this.element.ownerDocument;
            var channel = this.$props.cloudChannel ? this.$props.cloudChannel : '5';
            var apiKey = this.$props.apiKey ? this.$props.apiKey : 'no-api-key';
            _ScriptLoader__WEBPACK_IMPORTED_MODULE_0__.load(scriptState, doc, "https://cdn.tiny.cloud/1/" + apiKey + "/tinymce/" + channel + "/tinymce.min.js", initialise(this));
        }
    },
    beforeDestroy: function () {
        if ((0,_TinyMCE__WEBPACK_IMPORTED_MODULE_1__.getTinymce)() !== null) {
            (0,_TinyMCE__WEBPACK_IMPORTED_MODULE_1__.getTinymce)().remove(this.editor);
        }
    },
    render: function (h) {
        return this.inlineEditor ? renderInline(h, this.elementId, this.$props.tagName) : renderIframe(h, this.elementId);
    }
};


/***/ }),

/***/ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/components/EditorPropTypes.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/components/EditorPropTypes.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "editorProps": () => (/* binding */ editorProps)
/* harmony export */ });
/**
 * Copyright (c) 2018-present, Ephox, Inc.
 *
 * This source code is licensed under the Apache 2 license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */
var editorProps = {
    apiKey: String,
    cloudChannel: String,
    id: String,
    init: Object,
    initialValue: String,
    inline: Boolean,
    modelEvents: [String, Array],
    plugins: [String, Array],
    tagName: String,
    toolbar: [String, Array],
    value: String,
    disabled: Boolean
};


/***/ }),

/***/ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/index.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/index.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_Editor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/Editor */ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/components/Editor.js");
/**
 * Copyright (c) 2018-present, Ephox, Inc.
 *
 * This source code is licensed under the Apache 2 license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_components_Editor__WEBPACK_IMPORTED_MODULE_0__.Editor);


/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuedraggable */ "./node_modules/vuedraggable/dist/vuedraggable.common.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuedraggable__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */


var NestedDraggable = {
  name: 'NestedDraggable',
  props: {
    tasks: {
      required: true,
      type: Array
    },
    parent_id: {
      "default": null
    },
    opened: {
      "default": false
    },
    auth_user_id: {
      type: Number
    },
    mode: {
      type: String
    },
    active: {
      "default": 0
    }
  },
  data: function data() {
    return {
      hover: false,
      handle: '.fa-t'
    };
  },
  created: function created() {
    // if(this.mode == 'edit') {
    //   this.handle = '.fa-bars';
    // }
  },
  methods: {
    toggleOpen: function toggleOpen(el) {
      this.showPage(el.id, false, true);
      el.opened = !el.opened;
    },
    showPage: function showPage(id) {
      this.$emit('showPage', id);
    },
    addPage: function addPage(el) {
      this.$emit('addPage', el);
    },
    saveOrder: function saveOrder(event) {
      var _this = this;
      this.axios.post('/kb/page/save-order', {
        id: event.item.id,
        order: event.newIndex,
        // oldIndex
        parent_id: event.to.id
      }).then(function () {
        _this.$toast.success('Очередь сохранена');
      });
    }
  }
};
NestedDraggable.components = {
  Draggable: (vuedraggable__WEBPACK_IMPORTED_MODULE_0___default()),
  NestedDraggable: NestedDraggable
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NestedDraggable);

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested_course.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested_course.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var NestedCourse = {
  name: 'NestedCourse',
  props: {
    tasks: {
      required: true,
      type: Array
    },
    active: {
      "default": 0
    }
  },
  watch: {
    active: function active() {
      if (this.firstActive == 0) this.firstActive = this.active;
    }
  },
  data: function data() {
    return {
      firstActive: 0
    };
  },
  methods: {
    showPage: function showPage(id) {
      var item = null;
      var i = this.tasks.findIndex(function (el) {
        return el.id == id;
      });
      if (i != -1) {
        item = this.tasks[i];
      }
      if (id != this.firstActive) {
        if (item != null && item.item_model == null) return;
      }
      this.$emit('showPage', id);
    }
  }
};
NestedCourse.components = {
  NestedCourse: NestedCourse
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NestedCourse);

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _components_nested__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/nested */ "./resources/js/components/nested.vue");
/* harmony import */ var _components_nested_course__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/nested_course */ "./resources/js/components/nested_course.vue");
/* harmony import */ var _tinymce_tinymce_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tinymce/tinymce-vue */ "./node_modules/@tinymce/tinymce-vue/lib/es2015/main/ts/index.js");
/* harmony import */ var _pages_Questions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/pages/Questions */ "./resources/js/pages/Questions.vue");
/* harmony import */ var _components_ProgressBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/ProgressBar */ "./resources/js/components/ProgressBar.vue");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'PageBooklist',
  components: {
    NestedDraggable: _components_nested__WEBPACK_IMPORTED_MODULE_0__["default"],
    NestedCourse: _components_nested_course__WEBPACK_IMPORTED_MODULE_1__["default"],
    Editor: _tinymce_tinymce_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    Questions: _pages_Questions__WEBPACK_IMPORTED_MODULE_3__["default"],
    ProgressBar: _components_ProgressBar__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  props: {
    trees: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    parent_id: {
      type: Number,
      "default": 0
    },
    auth_user_id: {
      type: Number,
      "default": 0
    },
    parent_name: {
      type: String,
      "default": ''
    },
    show_page_id: {
      type: Number,
      "default": 0
    },
    can_edit: {
      type: Boolean,
      "default": false
    },
    mode: {
      type: String,
      "default": 'read'
    },
    course_page: {
      type: Number,
      "default": 0
    },
    enable_url_manipulation: {
      type: Boolean,
      "default": true
    },
    course_item_id: {
      type: Number,
      "default": 0
    },
    all_stages: {
      type: Number,
      "default": 0
    },
    completed_stages: {
      type: Number,
      "default": 0
    }
  },
  data: function data() {
    return {
      activesbook: null,
      tree: [],
      ids: [],
      // array of books ids

      // misc
      can_save: false,
      // сохранять без тестов
      myprogress: 0,
      id: 0,
      loader: false,
      parent_title: '',
      search: {
        input: '',
        items: []
      },
      editorHeight: window.innerHeight - 128,
      attachment: null,
      breadcrumbs: [],
      // modals
      showImageModal: false,
      showAudioModal: false,
      showPermissionModal: false,
      edit_actives_book: false,
      showSearch: false,
      // courses
      passedTest: false,
      questions_key: 1,
      text_was: '',
      title_was: '',
      item_models: []
    };
  },
  computed: _objectSpread({}, (0,vuex__WEBPACK_IMPORTED_MODULE_5__.mapGetters)(['user'])),
  created: function created() {
    this.getTree();
    this.parent_title = this.parent_name;
    this.id = this.parent_id;
  },
  mounted: function mounted() {
    var _this = this;
    if (!this.course_page) {
      window.addEventListener('beforeunload', function (e) {
        return _this.beforeunloadFn(e);
      });
    }
  },
  methods: {
    toggleMode: function toggleMode() {
      this.clearSearch();
      this.$emit('toggleMode');
    },
    searchCheck: function searchCheck() {
      if (this.search.input.length === 0) {
        this.clearSearch();
      }
    },
    clearSearch: function clearSearch() {
      this.search = {
        input: '',
        items: []
      };
    },
    beforeunloadFn: function beforeunloadFn(e) {
      if (this.text_was != this.activesbook.text || this.title_was != this.activesbook.title) {
        e.returnValue = 'Are you sure you want to leave?';
      }
    },
    nextElement: function nextElement() {
      var _this2 = this;
      this.setSegmentPassed();

      // find next element
      var index2 = this.ids.findIndex(function (el) {
        return el.id == _this2.activesbook.id;
      });
      if (index2 != -1 && this.ids.length - 1 > index2) {
        var el = this.findItem(this.ids[index2 + 1]);
        this.showPage(el.id);
      } else {
        // move to next course item
        this.$parent.after_click_next_element();
      }
      this.scrollToTop();
    },
    scrollToTop: function scrollToTop() {
      document.getElementsByClassName('rp')[0].scrollTo(0, 0);
      if (this.course_item_id != 0) document.getElementsByClassName('rp')[1].scrollTo(0, 0);
    },
    passed: function passed() {
      var _this3 = this;
      this.passedTest = true;

      // find element
      var index = this.ids.findIndex(function (el) {
        return el.id == _this3.activesbook.id;
      });
      if (index != -1 && this.ids.length - 1 > index) {
        var el = this.findItem(this.ids[index + 1]);

        // pass if its not course.  cos there not nextElement button
        if (el.item_model == null && this.course_item_id == 0) {
          this.setSegmentPassed();
        }
      }

      //test
      var i = this.item_models.findIndex(function (im) {
        return im.item_id == _this3.activesbook.id;
      });
      if (i == -1) this.item_models.push({
        item_id: this.activesbook.id,
        status: 1
      });
      this.connectItemModels(this.tree);
    },
    setSegmentPassed: function setSegmentPassed() {
      var _this4 = this;
      var el = null;
      // find element
      var index = this.ids.findIndex(function (el) {
        return el.id == _this4.activesbook.id;
      });
      if (index != -1) {
        el = this.findItem(this.ids[index]);
        // if(el.item_model != null) return;
      }

      // pass
      this.axios.post('/my-courses/pass', {
        id: this.activesbook.id,
        type: 3,
        course_item_id: this.course_item_id,
        questions: this.activesbook.questions,
        all_stages: this.all_stages,
        completed_stages: this.completed_stages + 1
      }).then(function (response) {
        _this4.$emit('changeProgress');
        _this4.$emit('forGenerateCertificate', response.data.item_model);
        if (el != null) el.item_model = {
          status: 1
        };
        _this4.activesbook.item_model = response.data.item_model;
      })["catch"](function (error) {
        alert(error);
      });
    },
    findItem: function findItem(el) {
      if (el.i.length == 1) return this.tree[el.i[0]];
      if (el.i.length == 2) return this.tree[el.i[0]].children[el.i[1]];
      if (el.i.length == 3) return this.tree[el.i[0]].children[el.i[1]].children[el.i[2]];
      if (el.i.length == 4) return this.tree[el.i[0]].children[el.i[1]].children[el.i[2]].children[el.i[3]];
      if (el.i.length == 5) return this.tree[el.i[0]].children[el.i[1]].children[el.i[2]].children[el.i[3]].children[el.i[4]];
      if (el.i.length == 6) return this.tree[el.i[0]].children[el.i[1]].children[el.i[2]].children[el.i[3]].children[el.i[4]].children[el.i[5]];
    },
    getTree: function getTree() {
      var _this5 = this;
      this.axios.post('/kb/tree', {
        id: this.parent_id,
        can_read: this.course_page,
        course_item_id: this.course_item_id
      }).then(function (response) {
        _this5.tree = response.data.trees;
        _this5.item_models = response.data.item_models;
        _this5.can_save = response.data.can_save; // without test

        // set active book
        var urlParams = new URLSearchParams(window.location.search);
        var book_id = urlParams.get('b');
        _this5.breadcrumbs = [{
          id: _this5.id,
          title: _this5.parent_title
        }];

        // create array of books ids
        _this5.ids = [];
        _this5.returnArray(_this5.tree);
        if (_this5.course_page) {
          book_id = _this5.show_page_id;
          if (_this5.show_page_id == 0 || _this5.show_page_id == null) {
            _this5.showPage(_this5.tree[0].id);
          } else {
            // find element
            var index = _this5.ids.findIndex(function (el) {
              return el.id == _this5.show_page_id;
            });
            if (index != -1) {
              var el = _this5.findItem(_this5.ids[index]);
              _this5.showPage(el.id);
            }
          }
        } else {
          // not course page
          var result = null;
          _this5.tree.every(function (obj) {
            result = _this5.deepSearchId(obj, book_id);
            if (result != null) {
              _this5.showPage(book_id, false, true);
              return false;
            }
            return true;
          });
        }

        // passed steps
        _this5.connectItemModels(_this5.tree);
      })["catch"](function (error) {
        alert(error);
      });
    },
    returnArray: function returnArray(items) {
      var _this6 = this;
      var indexes = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
      items.forEach(function (item, i_index) {
        var arr = [].concat(_toConsumableArray(indexes), [i_index]);
        _this6.ids.push({
          id: item.id,
          i: arr
        });
        if (item.children !== undefined) _this6.returnArray(item.children, arr);
      });
    },
    connectItemModels: function connectItemModels(tree) {
      var _this7 = this;
      tree.forEach(function (el) {
        var i = _this7.item_models.findIndex(function (im) {
          return im.item_id == el.id;
        });
        if (i != -1) {
          el.item_model = _this7.item_models[i];
        } else {
          el.item_model = null;
        }
        if (el.children !== undefined) {
          _this7.connectItemModels(el.children);
        }
      });
    },
    searchInput: function searchInput() {
      var _this8 = this;
      if (this.search.input.length <= 2) return null;
      this.axios.post('/kb/search', {
        text: this.search.input
      }).then(function (response) {
        _this8.search.items = response.data.items;
        _this8.emphasizeTexts();
      })["catch"](function (error) {
        alert(error);
      });
    },
    emphasizeTexts: function emphasizeTexts() {
      var _this9 = this;
      this.search.items.forEach(function (item) {
        item.text = item.text.replace(new RegExp(_this9.search.input, 'gi'), '<b>' + _this9.search.input + '</b>');
      });
    },
    saveServer: function saveServer() {
      var _this10 = this;
      if (this.activesbook.questions.length == 0 && !this.can_save) {
        this.$toast.error('Нельзя вносить изменения без тестов');
        return;
      }
      var loader = this.$loading.show();
      this.axios.post('/kb/page/update', {
        text: this.activesbook.text,
        title: this.activesbook.title,
        pass_grade: this.activesbook.pass_grade,
        id: this.activesbook.id
      }).then(function () {
        _this10.text_was = _this10.activesbook.text;
        _this10.title = _this10.activesbook.title;
        _this10.edit_actives_book = false;
        _this10.$toast.info('Сохранено');
        _this10.renameNode(_this10.tree, _this10.activesbook.id, _this10.activesbook.title);
        loader.hide();
      })["catch"](function () {
        loader.hide();
      });
    },
    addPage: function addPage(book) {
      var _this11 = this;
      this.axios.post('/kb/page/create', {
        id: book.id
      }).then(function (_ref) {
        var data = _ref.data;
        return _this11.addPageHandler(data, book.children);
      });
    },
    addPageToTree: function addPageToTree() {
      var _this12 = this;
      this.axios.post('/kb/page/create', {
        id: this.id
      }).then(function (_ref2) {
        var data = _ref2.data;
        return _this12.addPageHandler(data, _this12.tree);
      });
    },
    addPageHandler: function addPageHandler(book, parent) {
      book.created = this.$moment.utc(book.created_at).local().format('DD.MM.YYYY HH:mm');
      book.edited_at = this.$moment.utc(book.updated_at).local().format('DD.MM.YYYY HH:mm');
      book.editor_avatar = this.$laravel.avatar;
      var name = "".concat(this.user.last_name, " ").concat(this.user.name);
      book.author = name;
      book.editor = name;
      this.activesbook = book;
      this.edit_actives_book = true;
      parent.push(this.activesbook);
      this.$toast.info('Добавлена страница');
    },
    deletePage: function deletePage() {
      var _this13 = this;
      if (confirm('Вы уверены?')) {
        this.axios.post('/kb/page/delete', {
          id: this.activesbook.id
        }).then(function () {
          _this13.$toast.success('Удалено');
          _this13.removeNode(_this13.tree, _this13.activesbook.id);
          _this13.activesbook = null;
        });
      }
    },
    deepSearch: function deepSearch(array, item) {
      return array.some(function s(el) {
        return el == item || el instanceof Array && el.some(s);
      });
    },
    deepSearchId: function deepSearchId(obj, targetId) {
      if (obj.id == targetId) {
        return obj;
      }
      var _iterator = _createForOfIteratorHelper(obj.children),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var item = _step.value;
          var check = this.deepSearchId(item, targetId);
          if (check) {
            return check;
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      return null;
    },
    removeNode: function removeNode(arr, id) {
      var _this14 = this;
      arr.forEach(function (it, index) {
        if (it.id === id) {
          arr.splice(index, 1);
        }
        _this14.removeNode(it.children, id);
      });
    },
    renameNode: function renameNode(arr, id, title) {
      var _this15 = this;
      arr.forEach(function (it) {
        if (it.id === id) {
          it.title = title;
        }
        _this15.renameNode(it.children, id, title);
      });
    },
    showPage: function showPage(id) {
      var _this16 = this;
      var refreshTree = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      var expand = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
      this.questions_key++;
      if (this.activesbook != null && (this.text_was != this.activesbook.text || this.title_was != this.activesbook.title)) {
        if (!this.course_page) {
          if (!confirm('У вас на странице остались несохранненные изменения. Точно хотите выйти?')) {
            return;
          }
        }
      }
      if (this.activesbook && this.activesbook.id == id) return '';
      var loader = this.$loading.show();
      this.axios.post('/kb/get', {
        id: id,
        course_item_id: this.course_item_id,
        refresh: refreshTree
      }).then(function (response) {
        loader.hide();

        // @TODO
        _this16.activesbook = response.data.book;
        _this16.questions_key++;
        _this16.text_was = _this16.activesbook.text;
        _this16.title_was = _this16.activesbook.title;
        _this16.breadcrumbs = response.data.breadcrumbs;
        _this16.edit_actives_book = false;
        if (refreshTree) {
          _this16.id = response.data.top_parent.id;
          _this16.parent_title = response.data.top_parent.title;
          _this16.tree = response.data.tree;
          _this16.showSearch = false;
          _this16.search.input = false;
          _this16.search.items = [];
        }

        // for course
        _this16.passedTest = false;
        if (_this16.activesbook != null && _this16.activesbook.questions.length == 0) {
          _this16.passedTest = true;
        }
        if (expand) _this16.expandTree();
        _this16.setTargetBlank();
        if (_this16.enable_url_manipulation) {
          window.history.replaceState({
            id: '100'
          }, 'База знаний', '/kb?s=' + _this16.id + '&b=' + id);
        }
      })["catch"](function () {
        loader.hide();
      });
    },
    expandTree: function expandTree() {
      var _this17 = this;
      var item = null;
      this.breadcrumbs.forEach(function (bc) {
        var s_index = _this17.tree.findIndex(function (t) {
          return t.id == bc.id;
        });
        if (s_index != -1) {
          if (item != null) {
            item = item.children[s_index];
          } else {
            item = _this17.tree[s_index];
          }
          item.opened = true;
        }
      });
    },
    setTargetBlank: function setTargetBlank() {
      this.$nextTick(function () {
        var links = document.querySelectorAll('.bp-text a');
        links.forEach(function (l) {
          return l.setAttribute('target', '_blank');
        });
      });
    },
    editorSave: function editorSave() {},
    changePassGrade: function changePassGrade(grade) {
      this.activesbook.pass_grade = grade;
      var len = this.activesbook.questions.length;
      if (grade > len) this.activesbook.pass_grade = len;
      if (grade < 1) this.activesbook.pass_grade = 1;
    },
    addaudio: function addaudio(url) {
      // where tinymce???
      // eslint-disable-next-line no-undef
      tinymce.activeEditor.insertContent('<audio controls src="' + url + '"></audio>');
    },
    addimage: function addimage(url) {
      // where tinymce???
      // eslint-disable-next-line no-undef
      tinymce.activeEditor.insertContent('<img alt="картинка" src="' + url + '"/>');
    },
    submit_tinymce: function submit_tinymce(blobInfo, success) {
      var _this18 = this;
      this.loader = true;
      var formData = new FormData();
      formData.append('attachment', blobInfo.blob());
      formData.append('id', this.activesbook.id);
      this.axios.post('/upload/images/', formData).then(function (response) {
        success(response.data.location);
        _this18.loader = false;
      })["catch"](function (error) {
        return console.error(error);
      });
    },
    submit: function submit() {
      var _this19 = this;
      this.loader = true;
      var config = {
        onUploadProgress: function onUploadProgress(progressEvent) {
          var progress = _this19.myprogress.progress;
          progress = progressEvent.loaded / progressEvent.total * 100;
          _this19.myprogress = progress;
        }
      };
      var formData = new FormData();
      formData.append('attachment', this.attachment);
      formData.append('id', this.activesbook.id);
      this.axios.post('/upload/images/', formData, config).then(function (response) {
        _this19.addimage(response.data.location);
        if (_this19.myprogress >= 100) {
          _this19.showImageModal = false;
          _this19.loader = false;
          _this19.myprogress = 0;
        }
      })["catch"](function (error) {
        return console.error(error);
      });
    },
    copyLink: function copyLink(book) {
      var Url = this.$refs['mylink' + book.id];
      Url.value = window.location.origin + '/corp_book/' + book.hash;
      Url.select();
      document.execCommand('copy');
      this.$toast.info('Ссылка на страницу скопирована!');
    },
    onAttachmentChange: function onAttachmentChange(e) {
      this.attachment = e.target.files[0];
      this.submit();
    },
    onAttachmentChangeaudio: function onAttachmentChangeaudio(e) {
      this.attachment = e.target.files[0];
      this.submitaudio();
    },
    submitaudio: function submitaudio() {
      var _this20 = this;
      this.loader = true;
      var formData = new FormData();
      formData.append('attachment', this.attachment);
      formData.append('id', this.activesbook.id);
      this.axios.post('/upload/audio/', formData).then(function (response) {
        _this20.addaudio(response.data.location);
        _this20.showAudioModal = false;
        _this20.loader = false;
      })["catch"](function (error) {
        return console.error(error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=style&index=0&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.content {\n    max-height: unset;\n    overflow: unset;\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_booklist_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./booklist.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=style&index=0&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_booklist_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_booklist_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/nested.vue":
/*!********************************************!*\
  !*** ./resources/js/components/nested.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _nested_vue_vue_type_template_id_628e40fc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nested.vue?vue&type=template&id=628e40fc& */ "./resources/js/components/nested.vue?vue&type=template&id=628e40fc&");
/* harmony import */ var _nested_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nested.vue?vue&type=script&lang=js& */ "./resources/js/components/nested.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _nested_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _nested_vue_vue_type_template_id_628e40fc___WEBPACK_IMPORTED_MODULE_0__.render,
  _nested_vue_vue_type_template_id_628e40fc___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/nested.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/nested_course.vue":
/*!***************************************************!*\
  !*** ./resources/js/components/nested_course.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _nested_course_vue_vue_type_template_id_53ebbaa8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nested_course.vue?vue&type=template&id=53ebbaa8& */ "./resources/js/components/nested_course.vue?vue&type=template&id=53ebbaa8&");
/* harmony import */ var _nested_course_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nested_course.vue?vue&type=script&lang=js& */ "./resources/js/components/nested_course.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _nested_course_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _nested_course_vue_vue_type_template_id_53ebbaa8___WEBPACK_IMPORTED_MODULE_0__.render,
  _nested_course_vue_vue_type_template_id_53ebbaa8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/nested_course.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/booklist.vue":
/*!*****************************************!*\
  !*** ./resources/js/pages/booklist.vue ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _booklist_vue_vue_type_template_id_481b29f0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./booklist.vue?vue&type=template&id=481b29f0& */ "./resources/js/pages/booklist.vue?vue&type=template&id=481b29f0&");
/* harmony import */ var _booklist_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./booklist.vue?vue&type=script&lang=js& */ "./resources/js/pages/booklist.vue?vue&type=script&lang=js&");
/* harmony import */ var _booklist_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./booklist.vue?vue&type=style&index=0&lang=css& */ "./resources/js/pages/booklist.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _booklist_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _booklist_vue_vue_type_template_id_481b29f0___WEBPACK_IMPORTED_MODULE_0__.render,
  _booklist_vue_vue_type_template_id_481b29f0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/booklist.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/nested.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/components/nested.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_nested_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./nested.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_nested_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/nested_course.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/components/nested_course.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_nested_course_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./nested_course.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested_course.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_nested_course_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/booklist.vue?vue&type=script&lang=js&":
/*!******************************************************************!*\
  !*** ./resources/js/pages/booklist.vue?vue&type=script&lang=js& ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_booklist_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./booklist.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_booklist_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/booklist.vue?vue&type=style&index=0&lang=css&":
/*!**************************************************************************!*\
  !*** ./resources/js/pages/booklist.vue?vue&type=style&index=0&lang=css& ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_booklist_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./booklist.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=style&index=0&lang=css&");


/***/ }),

/***/ "./resources/js/components/nested.vue?vue&type=template&id=628e40fc&":
/*!***************************************************************************!*\
  !*** ./resources/js/components/nested.vue?vue&type=template&id=628e40fc& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_nested_vue_vue_type_template_id_628e40fc___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_nested_vue_vue_type_template_id_628e40fc___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_nested_vue_vue_type_template_id_628e40fc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./nested.vue?vue&type=template&id=628e40fc& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested.vue?vue&type=template&id=628e40fc&");


/***/ }),

/***/ "./resources/js/components/nested_course.vue?vue&type=template&id=53ebbaa8&":
/*!**********************************************************************************!*\
  !*** ./resources/js/components/nested_course.vue?vue&type=template&id=53ebbaa8& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_nested_course_vue_vue_type_template_id_53ebbaa8___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_nested_course_vue_vue_type_template_id_53ebbaa8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_nested_course_vue_vue_type_template_id_53ebbaa8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./nested_course.vue?vue&type=template&id=53ebbaa8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested_course.vue?vue&type=template&id=53ebbaa8&");


/***/ }),

/***/ "./resources/js/pages/booklist.vue?vue&type=template&id=481b29f0&":
/*!************************************************************************!*\
  !*** ./resources/js/pages/booklist.vue?vue&type=template&id=481b29f0& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_booklist_vue_vue_type_template_id_481b29f0___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_booklist_vue_vue_type_template_id_481b29f0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_booklist_vue_vue_type_template_id_481b29f0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./booklist.vue?vue&type=template&id=481b29f0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=template&id=481b29f0&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested.vue?vue&type=template&id=628e40fc&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested.vue?vue&type=template&id=628e40fc& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "Draggable",
    {
      staticClass: "dragArea",
      attrs: {
        id: _vm.parent_id,
        tag: "ul",
        handle: ".fa-bars",
        list: _vm.tasks,
        group: { name: "g1" },
      },
      on: { end: _vm.saveOrder },
    },
    [
      _vm._l(_vm.tasks, function (el) {
        return [
          _c(
            "li",
            {
              key: el.id,
              staticClass: "chapter",
              class: {
                opened: _vm.opened,
                active: _vm.active == el.id,
              },
              attrs: { id: el.id },
            },
            [
              _c("div", { staticClass: "d-flex" }, [
                _c("div", { staticClass: "handles" }, [
                  _vm.mode == "edit"
                    ? _c("i", { staticClass: "fa fa-bars mover" })
                    : _c("i", { staticClass: "fa fa-circle mover" }),
                  _vm._v(" "),
                  _c("div", { staticClass: "shower" }, [
                    el.children.length > 0 && el.opened
                      ? _c("i", { staticClass: "fa fa-chevron-down pointer" })
                      : el.children.length > 0
                      ? _c("i", { staticClass: "fa fa-chevron-right pointer" })
                      : _c("i", { staticClass: "fa fa-circle pointer" }),
                  ]),
                ]),
                _vm._v(" "),
                _c(
                  "p",
                  {
                    staticClass: "mb-0",
                    on: {
                      click: function ($event) {
                        $event.stopPropagation()
                        return _vm.toggleOpen(el)
                      },
                    },
                  },
                  [_vm._v("\n\t\t\t\t\t" + _vm._s(el.title) + "\n\t\t\t\t")]
                ),
                _vm._v(" "),
                _vm.mode == "edit"
                  ? _c("div", { staticClass: "chapter-btns" }, [
                      _c("i", {
                        staticClass: "fa fa-plus mr-1",
                        on: {
                          click: function ($event) {
                            $event.stopPropagation()
                            return _vm.addPage(el)
                          },
                        },
                      }),
                    ])
                  : _vm._e(),
              ]),
              _vm._v(" "),
              _c("NestedDraggable", {
                attrs: {
                  tasks: el.children,
                  parent_id: el.id,
                  active: _vm.active,
                  auth_user_id: _vm.auth_user_id,
                  opened: el.opened,
                  mode: _vm.mode,
                },
                on: { showPage: _vm.showPage, addPage: _vm.addPage },
              }),
            ],
            1
          ),
        ]
      }),
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested_course.vue?vue&type=template&id=53ebbaa8&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/nested_course.vue?vue&type=template&id=53ebbaa8& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "ul",
    { staticClass: "dragArea" },
    _vm._l(_vm.tasks, function (el) {
      return _c(
        "li",
        {
          key: el.id,
          staticClass: "chapter opened",
          class: {
            pass: el.item_model !== null,
            active: _vm.active == el.id,
            disabled: el.item_model === null && _vm.firstActive != el.id,
          },
          attrs: { id: el.id },
        },
        [
          _c("div", { staticClass: "d-flex titles" }, [
            _c("div", { staticClass: "handles d-flex aic" }, [
              _c("div", [
                el.item_model != null
                  ? _c("i", { staticClass: "fa fa-check-double pointer" })
                  : _vm.firstActive == el.id
                  ? _c("i", { staticClass: "fa fa-unlock pointer" })
                  : _c("i", { staticClass: "fa fa-lock pointer" }),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "p",
              {
                staticClass: "mb-0",
                on: {
                  click: function ($event) {
                    return _vm.showPage(el.id)
                  },
                },
              },
              [_vm._v("\n\t\t\t\t" + _vm._s(el.title) + "\n\t\t\t")]
            ),
          ]),
          _vm._v(" "),
          _c("NestedCourse", {
            attrs: { tasks: el.children, active: _vm.active },
            on: { showPage: _vm.showPage },
          }),
        ],
        1
      )
    }),
    0
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=template&id=481b29f0&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/booklist.vue?vue&type=template&id=481b29f0& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "d-flex" },
    [
      _c("aside", { staticClass: "lp", attrs: { id: "left-panel" } }, [
        _vm.can_edit
          ? _c("div", { staticClass: "form-search-kb" }, [
              _c("i", { staticClass: "fa fa-search" }),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.search.input,
                    expression: "search.input",
                  },
                ],
                staticClass: "form-control",
                attrs: { type: "text", placeholder: "Искать в базе..." },
                domProps: { value: _vm.search.input },
                on: {
                  input: [
                    function ($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.search, "input", $event.target.value)
                    },
                    _vm.searchInput,
                  ],
                  blur: _vm.searchCheck,
                },
              }),
              _vm._v(" "),
              _vm.search.input.length
                ? _c(
                    "i",
                    {
                      staticClass: "search-clear",
                      on: { click: _vm.clearSearch },
                    },
                    [_vm._v("x")]
                  )
                : _vm._e(),
            ])
          : _vm._e(),
        _vm._v(" "),
        !_vm.course_page
          ? _c(
              "div",
              {
                staticClass: "btn btn-grey mb-3",
                on: {
                  click: function ($event) {
                    return _vm.$emit("back")
                  },
                },
              },
              [
                _c("i", { staticClass: "fa fa-arrow-left" }),
                _vm._v(" "),
                _c("span", [_vm._v("Вернуться к разделам")]),
              ]
            )
          : _vm._e(),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "kb-wrap noscrollbar" },
          [
            !_vm.course_page &&
            !_vm.search.items.length &&
            !_vm.search.input.length
              ? _c("div", { staticClass: "chapter opened mb-3" }, [
                  _c("div", { staticClass: "d-flex" }, [
                    _c("span", { staticClass: "font-16 font-bold" }, [
                      _vm._v(_vm._s(_vm.parent_title)),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "chapter-btns" }, [
                      _vm.mode == "edit"
                        ? _c("i", {
                            staticClass: "fa fa-plus",
                            on: { click: _vm.addPageToTree },
                          })
                        : _vm._e(),
                    ]),
                  ]),
                ])
              : _vm._e(),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "search-content" },
              [
                _vm.search.items.length
                  ? _vm._l(_vm.search.items, function (item) {
                      return _c(
                        "div",
                        {
                          key: item.id,
                          staticClass: "search-item",
                          on: {
                            click: function ($event) {
                              return _vm.showPage(item.id, true)
                            },
                          },
                        },
                        [
                          item.book
                            ? _c("p", { staticClass: "search-item-book" }, [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t" +
                                    _vm._s(item.book.title) +
                                    "\n\t\t\t\t\t\t"
                                ),
                              ])
                            : _vm._e(),
                          _vm._v(" "),
                          _c("p", { staticClass: "search-item-title" }, [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t" +
                                _vm._s(item.title) +
                                "\n\t\t\t\t\t\t"
                            ),
                          ]),
                          _vm._v(" "),
                          _c("div", {
                            staticClass: "search-item-text",
                            domProps: { innerHTML: _vm._s(item.text) },
                          }),
                        ]
                      )
                    })
                  : _vm.search.input.length <= 2 &&
                    _vm.search.input.length !== 0
                  ? _c("div", { staticClass: "text-muted" }, [
                      _vm._v("\n\t\t\t\t\tВведите минимум 3 символа\n\t\t\t\t"),
                    ])
                  : _vm.search.input.length > 2
                  ? _c("div", { staticClass: "text-muted" }, [
                      _vm._v("\n\t\t\t\t\tНичего не найдено\n\t\t\t\t"),
                    ])
                  : _vm._e(),
              ],
              2
            ),
            _vm._v(" "),
            !_vm.search.items.length && !_vm.search.input.length
              ? [
                  _vm.course_page
                    ? _c("NestedCourse", {
                        attrs: {
                          tasks: _vm.tree,
                          active:
                            _vm.activesbook != null ? _vm.activesbook.id : 0,
                        },
                        on: { showPage: _vm.showPage },
                      })
                    : _c("NestedDraggable", {
                        attrs: {
                          active:
                            _vm.activesbook != null ? _vm.activesbook.id : 0,
                          tasks: _vm.tree,
                          mode: _vm.mode,
                          auth_user_id: _vm.auth_user_id,
                          opened: true,
                          parent_id: _vm.id,
                        },
                        on: { showPage: _vm.showPage, addPage: _vm.addPage },
                      }),
                ]
              : _vm._e(),
          ],
          2
        ),
      ]),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "rp",
          staticStyle: {
            flex: "1 1 0%",
            "padding-bottom": "0px",
            height: "100vh",
            "overflow-y": "auto",
          },
        },
        [
          _c("div", { staticClass: "hat" }, [
            !_vm.course_page
              ? _c(
                  "div",
                  { staticClass: "d-flex jsutify-content-between hat-top" },
                  [
                    _c(
                      "div",
                      { staticClass: "bc" },
                      [
                        _c(
                          "a",
                          {
                            attrs: { href: "#" },
                            on: {
                              click: function ($event) {
                                return _vm.$emit("back")
                              },
                            },
                          },
                          [_vm._v("База знаний")]
                        ),
                        _vm._v(" "),
                        _vm._l(_vm.breadcrumbs, function (bc, bc_index) {
                          return [
                            _c("i", {
                              key: bc_index,
                              staticClass: "fa fa-chevron-right",
                            }),
                            _vm._v(" "),
                            _c(
                              "a",
                              {
                                key: "a" + bc_index,
                                attrs: { href: "#" },
                                on: {
                                  click: function ($event) {
                                    return _vm.showPage(bc.id)
                                  },
                                },
                              },
                              [_vm._v(_vm._s(bc.title))]
                            ),
                          ]
                        }),
                      ],
                      2
                    ),
                    _vm._v(" "),
                    _vm.can_edit
                      ? _c("div", { staticClass: "mode_changer" }, [
                          _c("i", {
                            staticClass: "fa fa-pen",
                            class: { active: _vm.mode == "edit" },
                            on: { click: _vm.toggleMode },
                          }),
                        ])
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.can_edit
                      ? _c("div", { staticClass: "control-btns" }, [
                          _vm.activesbook != null
                            ? _c(
                                "div",
                                {
                                  staticClass: "d-flex justify-content-end",
                                  attrs: { asd: _vm.auth_user_id },
                                },
                                [
                                  _c("input", {
                                    ref: "mylink" + _vm.activesbook.id,
                                    staticClass: "hider",
                                    attrs: { type: "text" },
                                  }),
                                  _vm._v(" "),
                                  _vm.activesbook != null &&
                                  _vm.activesbook.parent_id == null
                                    ? _c(
                                        "button",
                                        {
                                          staticClass:
                                            "form-control btn-action btn-medium ml-2",
                                          on: {
                                            click: function ($event) {
                                              _vm.showPermissionModal = true
                                            },
                                          },
                                        },
                                        [_c("i", { staticClass: "fa fa-cog" })]
                                      )
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.edit_actives_book
                                    ? [
                                        _c(
                                          "button",
                                          {
                                            staticClass:
                                              "form-control btn-action btn-medium ml-2",
                                            on: {
                                              click: function ($event) {
                                                _vm.showImageModal = true
                                              },
                                            },
                                          },
                                          [
                                            _c("i", {
                                              staticClass: "far fa-image",
                                            }),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "button",
                                          {
                                            staticClass:
                                              "form-control btn-action btn-medium ml-2",
                                            on: {
                                              click: function ($event) {
                                                _vm.showAudioModal = true
                                              },
                                            },
                                          },
                                          [
                                            _c("i", {
                                              staticClass: "fas fa-volume-up",
                                            }),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "button",
                                          {
                                            staticClass:
                                              "form-control btn-delete btn-medium ml-2",
                                            on: { click: _vm.deletePage },
                                          },
                                          [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\tУдалить\n\t\t\t\t\t\t\t"
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "button",
                                          {
                                            staticClass:
                                              "form-control btn-save btn-medium ml-2",
                                            on: { click: _vm.saveServer },
                                          },
                                          [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\tСохранить\n\t\t\t\t\t\t\t"
                                            ),
                                          ]
                                        ),
                                      ]
                                    : [
                                        _c(
                                          "button",
                                          {
                                            staticClass:
                                              "form-control btn-action btn-medium ml-2",
                                            attrs: {
                                              title: "Поделиться ссылкой",
                                            },
                                            on: {
                                              click: function ($event) {
                                                return _vm.copyLink(
                                                  _vm.activesbook
                                                )
                                              },
                                            },
                                          },
                                          [
                                            _c("i", {
                                              staticClass: "fa fa-clone",
                                            }),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _vm.mode == "edit"
                                          ? _c(
                                              "button",
                                              {
                                                staticClass:
                                                  "form-control btn-danger btn-medium ml-2",
                                                on: { click: _vm.deletePage },
                                              },
                                              [
                                                _c("i", {
                                                  staticClass: "fa fa-trash",
                                                }),
                                              ]
                                            )
                                          : _vm._e(),
                                        _vm._v(" "),
                                        _vm.mode == "edit"
                                          ? _c(
                                              "button",
                                              {
                                                staticClass:
                                                  "form-control btn-save btn-medium ml-2",
                                                on: {
                                                  click: function ($event) {
                                                    _vm.edit_actives_book = true
                                                  },
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n\t\t\t\t\t\t\t\tРедактировать\n\t\t\t\t\t\t\t"
                                                ),
                                              ]
                                            )
                                          : _vm._e(),
                                      ],
                                ],
                                2
                              )
                            : _vm._e(),
                        ])
                      : _vm._e(),
                  ]
                )
              : _vm._e(),
            _vm._v(" "),
            _c(
              "div",
              [
                _vm.activesbook != null
                  ? [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.activesbook.title,
                            expression: "activesbook.title",
                          },
                        ],
                        staticClass: "article_title px-4 py-3",
                        attrs: { type: "text" },
                        domProps: { value: _vm.activesbook.title },
                        on: {
                          input: function ($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.activesbook,
                              "title",
                              $event.target.value
                            )
                          },
                        },
                      }),
                    ]
                  : _vm._e(),
              ],
              2
            ),
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "content mt-3" },
            [
              _vm.activesbook != null && _vm.edit_actives_book
                ? [
                    _c("Editor", {
                      attrs: {
                        "api-key":
                          "mve9w0n1tjerlwenki27p4wjid4oqux1xp0yu0zmapbnaafd",
                        init: {
                          images_upload_url: "/upload/images/",
                          automatic_uploads: true,
                          height: _vm.editorHeight,
                          setup: function (editor) {
                            editor.on("init change", function () {
                              editor.uploadImages()
                            })
                          },
                          images_upload_handler: _vm.submit_tinymce,
                          //paste_data_images: false,
                          resize: true,
                          autosave_ask_before_unload: true,
                          powerpaste_allow_local_images: true,
                          browser_spellcheck: true,
                          contextmenu: true,
                          spellchecker_whitelist: ["Ephox", "Moxiecode"],
                          language: "ru",
                          convert_urls: false,
                          relative_urls: false,
                          language_url: "/static/langs/ru.js",
                          content_css: "/static/css/mycontent.css",
                          fontsize_formats:
                            "8pt 10pt 12pt 13pt 14pt 15pt 16pt 17pt 18pt 20pt 22pt 24pt 26pt 28pt 30pt 36pt",
                          lineheight_formats:
                            "8pt 9pt 10pt 11pt 12pt 14pt 16pt 18pt 20pt 22pt 24pt 26pt 36pt",
                          plugins: [
                            " advlist anchor autolink codesample colorpicker fullscreen help image imagetools ",
                            " lists link media noneditable  preview",
                            " searchreplace table template textcolor  visualblocks wordcount ",
                          ],
                          menubar: false, //'file edit view insert format tools table help',
                          toolbar:
                            "styleselect  | bold italic underline strikethrough | table | fontselect fontsizeselect formatselect | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | forecolor backcolor removeformat | fullscreen  preview |  media  link | undo redo",
                          toolbar_sticky: true,
                          content_style:
                            ".lineheight20px { line-height: 20px; }" +
                            ".lineheight22px { line-height: 22px; }" +
                            ".lineheight24px { line-height: 24px; }" +
                            ".lineheight26px { line-height: 26px; }" +
                            ".lineheight28px { line-height: 28px; }" +
                            ".lineheight30px { line-height: 30px; }" +
                            ".lineheight32px { line-height: 32px; }" +
                            ".lineheight34px { line-height: 34px; }" +
                            ".lineheight36px { line-height: 36px; }" +
                            ".lineheight38px { line-height: 38px; }" +
                            ".lineheight40px { line-height: 40px; }" +
                            "body { padding: 20px;max-width: 960px;margin: 0 auto; }" +
                            ".tablerow1 { background-color: #D3D3D3; }",
                          formats: {
                            lineheight20px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight20px",
                            },
                            lineheight22px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight22px",
                            },
                            lineheight24px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight24px",
                            },
                            lineheight26px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight26px",
                            },
                            lineheight28px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight20px",
                            },
                            lineheight30px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight30px",
                            },
                            lineheight32px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight32px",
                            },
                            lineheight34px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight34px",
                            },
                            lineheight36px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight36px",
                            },
                            lineheight38px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight38px",
                            },
                            lineheight40px: {
                              selector:
                                "span,p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img",
                              classes: "lineheight40px",
                            },
                          },
                          style_formats: [
                            {
                              title: "lineheight20px",
                              format: "lineheight20px",
                            },
                            {
                              title: "lineheight22px",
                              format: "lineheight22px",
                            },
                            {
                              title: "lineheight24px",
                              format: "lineheight24px",
                            },
                            {
                              title: "lineheight26px",
                              format: "lineheight26px",
                            },
                            {
                              title: "lineheight28px",
                              format: "lineheight28px",
                            },
                            {
                              title: "lineheight30px",
                              format: "lineheight30px",
                            },
                            {
                              title: "lineheight32px",
                              format: "lineheight32px",
                            },
                            {
                              title: "lineheight34px",
                              format: "lineheight34px",
                            },
                            {
                              title: "lineheight36px",
                              format: "lineheight36px",
                            },
                            {
                              title: "lineheight38px",
                              format: "lineheight38px",
                            },
                            {
                              title: "lineheight40px",
                              format: "lineheight40px",
                            },
                          ],
                          content_css: [
                            "//fonts.googleapis.com/css?family=Lato:300,300i,400,400i",
                          ],
                        },
                      },
                      on: { onKeyUp: _vm.editorSave, onChange: _vm.editorSave },
                      model: {
                        value: _vm.activesbook.text,
                        callback: function ($$v) {
                          _vm.$set(_vm.activesbook, "text", $$v)
                        },
                        expression: "activesbook.text",
                      },
                    }),
                    _vm._v(" "),
                    _c("Questions", {
                      key: _vm.questions_key,
                      attrs: {
                        id: _vm.activesbook.id,
                        course_item_id: _vm.course_item_id,
                        questions: _vm.activesbook.questions,
                        type: "kb",
                        mode: _vm.mode,
                        count_points: true,
                        pass_grade: _vm.activesbook.pass_grade,
                      },
                      on: {
                        passed: _vm.passed,
                        changePassGrade: _vm.changePassGrade,
                      },
                    }),
                  ]
                : _vm._e(),
              _vm._v(" "),
              _vm.activesbook != null && !_vm.edit_actives_book
                ? [
                    _c(
                      "div",
                      { staticClass: "book_page" },
                      [
                        _c(
                          "div",
                          { staticClass: "author mb-5 d-flex aic justify-end" },
                          [
                            _c("img", {
                              attrs: {
                                src: _vm.activesbook.editor_avatar,
                                alt: "avatar icon",
                              },
                            }),
                            _vm._v(" "),
                            _c("div", { staticClass: "text" }, [
                              _c("div", { staticClass: "edited" }, [
                                _c("p", { staticClass: "author-time" }, [
                                  _c("span", [_vm._v("Cоздан:")]),
                                  _vm._v(
                                    " " +
                                      _vm._s(_vm.activesbook.created) +
                                      "\n\t\t\t\t\t\t\t\t"
                                  ),
                                ]),
                                _vm._v(" "),
                                _c("i", { staticClass: "fa fa-chevron-right" }),
                                _vm._v(" "),
                                _c("p", { staticClass: "author-author" }, [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t\t\t" +
                                      _vm._s(_vm.activesbook.author) +
                                      "\n\t\t\t\t\t\t\t\t"
                                  ),
                                ]),
                              ]),
                              _vm._v(" "),
                              _c("div", { staticClass: "edited" }, [
                                _c("p", { staticClass: "author-time" }, [
                                  _c("span", [_vm._v("Изменен:")]),
                                  _vm._v(
                                    " " +
                                      _vm._s(_vm.activesbook.edited_at) +
                                      "\n\t\t\t\t\t\t\t\t"
                                  ),
                                ]),
                                _vm._v(" "),
                                _c("i", { staticClass: "fa fa-chevron-right" }),
                                _vm._v(" "),
                                _c("p", { staticClass: "author-author" }, [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t\t\t" +
                                      _vm._s(_vm.activesbook.editor) +
                                      "\n\t\t\t\t\t\t\t\t"
                                  ),
                                ]),
                              ]),
                            ]),
                          ]
                        ),
                        _vm._v(" "),
                        _c("div", {
                          staticClass: "bp-text",
                          domProps: { innerHTML: _vm._s(_vm.activesbook.text) },
                        }),
                        _vm._v(" "),
                        _c("Questions", {
                          key: _vm.questions_key,
                          attrs: {
                            id: _vm.activesbook.id,
                            questions: _vm.activesbook.questions,
                            type: "kb",
                            mode: _vm.mode,
                            count_points: true,
                            pass: _vm.activesbook.item_model !== null,
                            pass_grade: _vm.activesbook.pass_grade,
                            course_item_id: _vm.course_item_id,
                          },
                          on: {
                            passed: _vm.passed,
                            changePassGrade: _vm.changePassGrade,
                            nextElement: _vm.nextElement,
                          },
                        }),
                        _vm._v(" "),
                        _c("div", { staticClass: "pb-5" }),
                        _vm._v(" "),
                        _vm.course_page && _vm.activesbook.questions.length == 0
                          ? _c(
                              "button",
                              {
                                staticClass: "next-btn btn btn-primary",
                                on: {
                                  click: function ($event) {
                                    return _vm.nextElement()
                                  },
                                },
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\tПродолжить курс\n\t\t\t\t\t\t"
                                ),
                                _c("i", {
                                  staticClass: "fa fa-angle-double-right ml-2",
                                }),
                              ]
                            )
                          : _vm._e(),
                      ],
                      1
                    ),
                  ]
                : _vm._e(),
            ],
            2
          ),
        ]
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: { title: "Загрузить изображение" },
          model: {
            value: _vm.showImageModal,
            callback: function ($$v) {
              _vm.showImageModal = $$v
            },
            expression: "showImageModal",
          },
        },
        [
          _c(
            "form",
            {
              staticStyle: { "max-width": "300px", margin: "0 auto" },
              attrs: {
                action: "/upload/images/",
                enctype: "multipart/form-data",
                method: "post",
              },
              on: {
                submit: function ($event) {
                  $event.preventDefault()
                  return _vm.submit.apply(null, arguments)
                },
              },
            },
            [
              _c("div", { staticClass: "form-group" }, [
                _c("div", { staticClass: "custom-file" }, [
                  _c("input", {
                    staticClass: "custom-file-input",
                    attrs: {
                      id: "customFile",
                      type: "file",
                      accept: "image/*",
                    },
                    on: { change: _vm.onAttachmentChange },
                  }),
                  _vm._v(" "),
                  _c(
                    "label",
                    {
                      staticClass: "custom-file-label",
                      attrs: { for: "customFile" },
                    },
                    [_vm._v("Выберите файл")]
                  ),
                ]),
              ]),
            ]
          ),
          _vm._v(" "),
          _c("ProgressBar", {
            attrs: { percentage: _vm.myprogress, label: "Загрузка" },
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: { title: "Загрузить аудио" },
          model: {
            value: _vm.showAudioModal,
            callback: function ($$v) {
              _vm.showAudioModal = $$v
            },
            expression: "showAudioModal",
          },
        },
        [
          _c(
            "form",
            {
              staticStyle: { "max-width": "300px", margin: "0 auto" },
              attrs: {
                action: "/upload/audio/",
                enctype: "multipart/form-data",
                method: "post",
              },
              on: {
                submit: function ($event) {
                  $event.preventDefault()
                  return _vm.submit.apply(null, arguments)
                },
              },
            },
            [
              _c("div", { staticClass: "form-group" }, [
                _c("div", { staticClass: "custom-file" }, [
                  _c("input", {
                    staticClass: "custom-file-input",
                    attrs: {
                      id: "customFile",
                      type: "file",
                      accept: "audio/mp3",
                    },
                    on: { change: _vm.onAttachmentChangeaudio },
                  }),
                  _vm._v(" "),
                  _c(
                    "label",
                    {
                      staticClass: "custom-file-label",
                      attrs: { for: "customFile" },
                    },
                    [_vm._v("Выберите файл")]
                  ),
                ]),
              ]),
            ]
          ),
        ]
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: { title: "Настройка доступа к разделу" },
          model: {
            value: _vm.showPermissionModal,
            callback: function ($$v) {
              _vm.showPermissionModal = $$v
            },
            expression: "showPermissionModal",
          },
        },
        [
          _vm.activesbook != null
            ? _c("div", [
                _vm._v("\n\t\t\t" + _vm._s(_vm.activesbook.title) + "\n\t\t"),
              ])
            : _vm._e(),
          _vm._v("\n\t\tПока не сделано\n\t"),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);