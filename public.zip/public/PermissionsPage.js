"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["PermissionsPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/PermissionItem.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/PermissionItem.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/no-mutating-props */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  props: {
    item: {
      type: Object,
      "default": null
    },
    groups: {
      type: Array,
      "default": null
    },
    users: {
      type: Array,
      "default": null
    },
    roles: {
      type: Array,
      "default": null
    }
  },
  data: function data() {
    return {
      local_groups: [],
      local_roles: []
    };
  },
  watch: {
    item: {
      deep: true,
      handler: function handler() {
        this.$emit('updated');
      }
    }
  },
  created: function created() {
    this.local_groups = this.groups;
    this.local_roles = this.roles;
    if (this.item.groups_all) {
      this.local_groups = [];
      this.item.groups.splice(0, this.item.groups.length + 1);
      this.item.groups.push({
        id: 0,
        name: 'Все отделы'
      });
      this.item.groups_all = true;
    }
  },
  methods: {
    onSelect: function onSelect(selectedOption) {
      if (selectedOption.id == 0) {
        this.selectAll();
        //this.$refs.group_select.close();
      }
    },
    selectAll: function selectAll() {
      this.local_groups = [];
      // this.item.groups.splice(0,this.item.groups.length + 1)
      // this.item.groups.push({
      //     id: 0,
      //     name: 'Все отделы'
      // });
      this.item.groups_all = true;
    },
    onRemove: function onRemove(removedOption) {
      if (removedOption.id == 0) {
        this.local_groups = this.groups;
        this.item.groups_all = false;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_PermissionItem_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/PermissionItem.vue */ "./resources/js/components/PermissionItem.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'PagePermissions',
  components: {
    PermissionItem: _components_PermissionItem_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      role: null,
      searchText: '',
      users: [],
      // all select
      groups: [],
      // all select
      items: [],
      roles: [],
      values: [],
      pages: [],
      permissions: [],
      showRoles: false,
      isBp: window.location.hostname.split('.')[0] === 'bp',
      ignoreRules: ['news_view', 'structure_view']
    };
  },
  computed: {
    filteredPages: function filteredPages() {
      return this.isBp ? this.pages : this.pages.filter(function (p) {
        return p.key !== 'faq';
      });
    },
    filteredItems: function filteredItems() {
      if (!this.searchText) return this.items;
      var lowerText = this.searchText.toLowerCase();
      return this.items.filter(function (el) {
        if (el.targets) {
          var inTarget = el.targets.findIndex(function (target) {
            return target.name.toLowerCase().indexOf(lowerText) > -1;
          });
          if (inTarget > -1) return true;
        }
        if (el.groups) {
          var inGroups = el.groups.findIndex(function (target) {
            return target.name.toLowerCase().indexOf(lowerText) > -1;
          });
          if (inGroups > -1) return true;
        }
        if (el.roles) {
          var inRoles = el.roles.findIndex(function (target) {
            return target.name.toLowerCase().indexOf(lowerText) > -1;
          });
          if (inRoles > -1) return true;
        }
        return false;
      });
    }
  },
  created: function created() {
    this.fetchData();
  },
  mounted: function mounted() {},
  methods: {
    filteredPageChildren: function filteredPageChildren(index) {
      return this.isBp ? this.pages[index].children : this.pages[index].children.filter(function (c) {
        return c.key !== 'top' && c.key !== 'hr';
      });
    },
    fetchData: function fetchData() {
      var _this = this;
      var loader = this.$loading.show();
      this.axios.get('/permissions/get', {}).then(function (response) {
        var _response$data;
        if (!((_response$data = response.data) !== null && _response$data !== void 0 && _response$data.roles)) _this.$toast.error('Не удалось загрузить данные');
        _this.users = response.data.users || [];
        _this.roles = response.data.roles || [];
        _this.groups = response.data.groups || [];
        _this.pages = response.data.pages || [];
        _this.items = response.data.items || [];
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    addItem: function addItem() {
      this.searchText = '';
      this.items.unshift({
        id: 0,
        /* eslint-disable-next-line camelcase */
        groups_all: false,
        targets: [],
        roles: [],
        groups: []
      });
    },
    deleteItem: function deleteItem(i) {
      var _this2 = this;
      if (!confirm('Вы точно хотите удалить доступ этой цели?')) {
        return false;
      }
      if (this.filteredItems[i].id == 0) {
        var index = this.items.findIndex(function (it) {
          return it.id == _this2.filteredItems[i].id;
        });
        if (index != -1) this.items.splice(index, 1);
        return false;
      }
      var loader = this.$loading.show();
      this.axios.post('/permissions/delete-target', {
        id: this.filteredItems[i].id
      }).then(function () {
        var index = _this2.items.findIndex(function (it) {
          return it.id == _this2.filteredItems[i].id;
        });
        if (index != -1) _this2.items.splice(index, 1);
        loader.hide();
        _this2.$toast.success('Доступ удален!');
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    updateItem: function updateItem(i) {
      var _this3 = this;
      var loader = this.$loading.show();
      this.axios.post('/permissions/update-target', {
        item: this.filteredItems[i]
      }).then(function (response) {
        var index = _this3.items.findIndex(function (it) {
          return it.id == _this3.filteredItems[i].id;
        });
        if (index != -1) _this3.items.id = response.data.id;
        loader.hide();
        _this3.$toast.success('Цели сохранены!');
      })["catch"](function (error) {
        var _error$response, _error$response$data;
        loader.hide();
        if (((_error$response = error.response) === null || _error$response === void 0 ? void 0 : (_error$response$data = _error$response.data) === null || _error$response$data === void 0 ? void 0 : _error$response$data.error) === 'Duplicate entry for unique key.') {
          _this3.$toast.success('Внесите изменения перед сохранением');
        } else {
          alert(error);
        }
      });
    },
    back: function back() {
      this.showRoles = false;
      this.role = null;
    },
    editRole: function editRole(i) {
      this.showEditRole = true;
      var role = this.roles[i];
      this.role = role;
      this.showRoles = false;
    },
    showRolesPage: function showRolesPage() {
      this.role = null;
      this.showRoles = true;
    },
    addRole: function addRole() {
      this.role = {
        name: 'Test',
        id: null,
        perms: {}
      };
    },
    updateRole: function updateRole() {
      var _this4 = this;
      var loader = this.$loading.show();
      this.permissions = [];
      Object.keys(this.role.perms).forEach(function (key) {
        if (_this4.role.perms[key]) _this4.permissions.push(key);
      });
      this.axios.post('/permissions/update-role', {
        role: this.role,
        permissions: this.permissions
      }).then(function (response) {
        if (_this4.role.id == null) {
          _this4.roles.push({
            id: response.data.id,
            name: response.data.name,
            perms: _this4.role.perms,
            permissions: []
          });
        }
        _this4.role = null;
        loader.hide();
        _this4.$toast.success('Роль сохранена!');
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    deleteRole: function deleteRole(i) {
      var _this5 = this;
      if (!confirm('Вы уверены удалить роль?')) {
        return false;
      }
      if (this.roles[i].id == null) {
        this.roles.splice(i, 1);
        return false;
      }
      var loader = this.$loading.show();
      this.axios.post('/permissions/delete-role', {
        role: this.roles[i]
      }).then(function () {
        loader.hide();
        _this5.roles.splice(i, 1);
        _this5.$toast.success('Роль удалена!');
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    checkParent: function checkParent(i, ability) {
      var _this6 = this;
      var page = this.pages[i];
      var checked = this.role.perms[page.key + '_' + ability];
      if (ability == 'edit') {
        this.role.perms[page.key + '_view'] = checked;
        page.children.forEach(function (c) {
          _this6.role.perms[c.key + '_view'] = checked;
          _this6.role.perms[c.key + '_edit'] = checked;
        });
      } else {
        page.children.forEach(function (c) {
          _this6.role.perms[c.key + '_view'] = checked;
        });
      }
    },
    checkChild: function checkChild(i, ability) {
      var page = this.pages[i];
      var checked = this.role.perms[page.key + '_' + ability];
      if (ability == 'edit') {
        this.role.perms[page.key + '_view'] = checked;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".permissions .img-info {\n  vertical-align: middle;\n}\n.custom-table-permissions {\n  table-layout: fixed;\n}\n.custom-table-permissions thead tr th:last-child, .custom-table-permissions thead tr td:last-child {\n  width: 100px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Permissions_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Permissions.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Permissions_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Permissions_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/PermissionItem.vue":
/*!****************************************************!*\
  !*** ./resources/js/components/PermissionItem.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _PermissionItem_vue_vue_type_template_id_2cdde0a6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PermissionItem.vue?vue&type=template&id=2cdde0a6& */ "./resources/js/components/PermissionItem.vue?vue&type=template&id=2cdde0a6&");
/* harmony import */ var _PermissionItem_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PermissionItem.vue?vue&type=script&lang=js& */ "./resources/js/components/PermissionItem.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PermissionItem_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PermissionItem_vue_vue_type_template_id_2cdde0a6___WEBPACK_IMPORTED_MODULE_0__.render,
  _PermissionItem_vue_vue_type_template_id_2cdde0a6___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/PermissionItem.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Permissions.vue":
/*!********************************************!*\
  !*** ./resources/js/pages/Permissions.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Permissions_vue_vue_type_template_id_7e089b8b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Permissions.vue?vue&type=template&id=7e089b8b& */ "./resources/js/pages/Permissions.vue?vue&type=template&id=7e089b8b&");
/* harmony import */ var _Permissions_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Permissions.vue?vue&type=script&lang=js& */ "./resources/js/pages/Permissions.vue?vue&type=script&lang=js&");
/* harmony import */ var _Permissions_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Permissions.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/Permissions.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Permissions_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Permissions_vue_vue_type_template_id_7e089b8b___WEBPACK_IMPORTED_MODULE_0__.render,
  _Permissions_vue_vue_type_template_id_7e089b8b___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Permissions.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/PermissionItem.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/components/PermissionItem.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermissionItem_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./PermissionItem.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/PermissionItem.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermissionItem_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Permissions.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/pages/Permissions.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Permissions_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Permissions.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Permissions_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Permissions.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************!*\
  !*** ./resources/js/pages/Permissions.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Permissions_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Permissions.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/PermissionItem.vue?vue&type=template&id=2cdde0a6&":
/*!***********************************************************************************!*\
  !*** ./resources/js/components/PermissionItem.vue?vue&type=template&id=2cdde0a6& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PermissionItem_vue_vue_type_template_id_2cdde0a6___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PermissionItem_vue_vue_type_template_id_2cdde0a6___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_PermissionItem_vue_vue_type_template_id_2cdde0a6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./PermissionItem.vue?vue&type=template&id=2cdde0a6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/PermissionItem.vue?vue&type=template&id=2cdde0a6&");


/***/ }),

/***/ "./resources/js/pages/Permissions.vue?vue&type=template&id=7e089b8b&":
/*!***************************************************************************!*\
  !*** ./resources/js/pages/Permissions.vue?vue&type=template&id=7e089b8b& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Permissions_vue_vue_type_template_id_7e089b8b___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Permissions_vue_vue_type_template_id_7e089b8b___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Permissions_vue_vue_type_template_id_7e089b8b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Permissions.vue?vue&type=template&id=7e089b8b& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=template&id=7e089b8b&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/PermissionItem.vue?vue&type=template&id=2cdde0a6&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/PermissionItem.vue?vue&type=template&id=2cdde0a6& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-tr",
    [
      _c(
        "b-td",
        { staticClass: "person" },
        [
          _c("superselect", {
            staticClass: "w-full single",
            attrs: { values: _vm.item.targets },
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-td",
        { staticClass: "role" },
        [
          _c("multiselect", {
            ref: "role_select",
            attrs: {
              options: _vm.local_roles,
              multiple: true,
              "preserve-search": true,
              "hide-selected": true,
              placeholder: "Выберите",
              label: "name",
              "track-by": "name",
            },
            model: {
              value: _vm.item.roles,
              callback: function ($$v) {
                _vm.$set(_vm.item, "roles", $$v)
              },
              expression: "item.roles",
            },
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-td",
        { staticClass: "groups" },
        [
          _c("multiselect", {
            ref: "group_select",
            attrs: {
              options: _vm.local_groups,
              multiple: true,
              "close-on-select": false,
              "clear-on-select": false,
              "preserve-search": true,
              "hide-selected": true,
              placeholder: "Выберите",
              label: "name",
              "track-by": "name",
            },
            on: { select: _vm.onSelect, remove: _vm.onRemove },
            model: {
              value: _vm.item.groups,
              callback: function ($$v) {
                _vm.$set(_vm.item, "groups", $$v)
              },
              expression: "item.groups",
            },
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c("b-td", { staticClass: "actions" }, [
        _c("div", { staticClass: "d-flex align-items-center" }, [
          _c(
            "button",
            {
              staticClass: "btn btn-success btn-icon",
              on: {
                click: function ($event) {
                  return _vm.$emit("updateItem")
                },
              },
            },
            [_c("i", { staticClass: "fa fa-save" })]
          ),
          _vm._v(" "),
          _c(
            "button",
            {
              staticClass: "btn btn-danger btn-icon",
              on: {
                click: function ($event) {
                  return _vm.$emit("deleteItem")
                },
              },
            },
            [_c("i", { staticClass: "fa fa-times" })]
          ),
        ]),
      ]),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=template&id=7e089b8b&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Permissions.vue?vue&type=template&id=7e089b8b& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "p-3 permissions" },
    [
      _c("h4", { staticClass: "title d-flex" }, [
        _c("div", [
          _vm._v("\n\t\t\tНастройка доступов\n\t\t\t"),
          _vm.role != null ? _c("span", [_vm._v(": Роли")]) : _vm._e(),
        ]),
      ]),
      _vm._v(" "),
      _c(
        "b-form-group",
        { staticClass: "add-grade" },
        [
          _vm.role == null
            ? _c("b-form-input", {
                attrs: { type: "text", placeholder: "Поиск..." },
                model: {
                  value: _vm.searchText,
                  callback: function ($$v) {
                    _vm.searchText = $$v
                  },
                  expression: "searchText",
                },
              })
            : _vm._e(),
          _vm._v(" "),
          _vm.role == null
            ? _c(
                "button",
                {
                  staticClass: "btn btn-success ml-4",
                  on: { click: _vm.addItem },
                },
                [_vm._v("\n\t\t\tДобавить\n\t\t")]
              )
            : _vm._e(),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "section",
        [
          _c(
            "b-row",
            [
              _c("b-col", { attrs: { cols: "12", md: "9" } }, [
                _vm.role == null
                  ? _c(
                      "div",
                      { staticClass: "table-container" },
                      [
                        _c(
                          "b-table-simple",
                          {
                            staticClass:
                              "table-bordered custom-table-permissions",
                          },
                          [
                            _c(
                              "b-thead",
                              [
                                _c(
                                  "b-tr",
                                  [
                                    _c("b-th"),
                                    _vm._v(" "),
                                    _c("b-th", [_vm._v("Роль")]),
                                    _vm._v(" "),
                                    _c("b-th", [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t\tОтделы\n\t\t\t\t\t\t\t\t\t"
                                      ),
                                      _c("i", {
                                        directives: [
                                          {
                                            name: "b-popover",
                                            rawName:
                                              "v-b-popover.hover.right.html",
                                            value:
                                              "Выберите только те отделы, которые будет видеть сотрудник(-и)",
                                            expression:
                                              "'Выберите только те отделы, которые будет видеть сотрудник(-и)'",
                                            modifiers: {
                                              hover: true,
                                              right: true,
                                              html: true,
                                            },
                                          },
                                        ],
                                        staticClass: "fa fa-info-circle ml-2",
                                        attrs: { title: "Доступ к отделам" },
                                      }),
                                    ]),
                                    _vm._v(" "),
                                    _c("b-th"),
                                  ],
                                  1
                                ),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-tbody",
                              _vm._l(_vm.filteredItems, function (item, i) {
                                return _c("PermissionItem", {
                                  key: item.id,
                                  attrs: {
                                    item: item,
                                    groups: _vm.groups,
                                    users: _vm.users,
                                    roles: _vm.roles,
                                  },
                                  on: {
                                    deleteItem: function ($event) {
                                      return _vm.deleteItem(i)
                                    },
                                    updateItem: function ($event) {
                                      return _vm.updateItem(i)
                                    },
                                  },
                                })
                              }),
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                _vm.role
                  ? _c("div", { staticClass: "edit-role" }, [
                      _c("div", { staticClass: "d-flex mb-3" }, [
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-primary mr-2",
                            on: { click: _vm.back },
                          },
                          [_vm._v("\n\t\t\t\t\t\t\tНазад\n\t\t\t\t\t\t")]
                        ),
                      ]),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.role.name,
                            expression: "role.name",
                          },
                        ],
                        staticClass: "role-title form-control mb-3",
                        attrs: { type: "text" },
                        domProps: { value: _vm.role.name },
                        on: {
                          input: function ($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.role, "name", $event.target.value)
                          },
                        },
                      }),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "pages table-container" },
                        [
                          _c("div", { staticClass: "item d-flex contrast" }, [
                            _c("div", { staticClass: "name mr-3" }, [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t\tСтраница\n\t\t\t\t\t\t\t"
                              ),
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "check d-flex" }, [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t\tПросмотр\n\t\t\t\t\t\t\t"
                              ),
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "check d-flex" }, [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t\tРедактирование\n\t\t\t\t\t\t\t"
                              ),
                            ]),
                          ]),
                          _vm._v(" "),
                          _vm._l(_vm.filteredPages, function (page, index) {
                            return [
                              _c(
                                "div",
                                { key: index, staticClass: "item d-flex" },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass: "name mr-3",
                                      on: {
                                        click: function ($event) {
                                          page.opened = !page.opened
                                        },
                                      },
                                    },
                                    [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t\t" +
                                          _vm._s(page.name) +
                                          "\n\t\t\t\t\t\t\t\t\t"
                                      ),
                                      page.opened && page.children.length > 0
                                        ? _c("i", {
                                            staticClass: "fa fa-chevron-up",
                                          })
                                        : _vm._e(),
                                      _vm._v(" "),
                                      !page.opened && page.children.length > 0
                                        ? _c("i", {
                                            staticClass: "fa fa-chevron-down",
                                          })
                                        : _vm._e(),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c("div", { staticClass: "check d-flex" }, [
                                    !_vm.ignoreRules.includes(
                                      page.key + "_view"
                                    )
                                      ? _c(
                                          "label",
                                          { staticClass: "mb-0 pointer" },
                                          [
                                            _c("input", {
                                              directives: [
                                                {
                                                  name: "model",
                                                  rawName: "v-model",
                                                  value:
                                                    _vm.role.perms[
                                                      page.key + "_view"
                                                    ],
                                                  expression:
                                                    "role.perms[page.key + '_view']",
                                                },
                                              ],
                                              staticClass: "pointer",
                                              attrs: { type: "checkbox" },
                                              domProps: {
                                                checked: Array.isArray(
                                                  _vm.role.perms[
                                                    page.key + "_view"
                                                  ]
                                                )
                                                  ? _vm._i(
                                                      _vm.role.perms[
                                                        page.key + "_view"
                                                      ],
                                                      null
                                                    ) > -1
                                                  : _vm.role.perms[
                                                      page.key + "_view"
                                                    ],
                                              },
                                              on: {
                                                change: [
                                                  function ($event) {
                                                    var $$a =
                                                        _vm.role.perms[
                                                          page.key + "_view"
                                                        ],
                                                      $$el = $event.target,
                                                      $$c = $$el.checked
                                                        ? true
                                                        : false
                                                    if (Array.isArray($$a)) {
                                                      var $$v = null,
                                                        $$i = _vm._i($$a, $$v)
                                                      if ($$el.checked) {
                                                        $$i < 0 &&
                                                          _vm.$set(
                                                            _vm.role.perms,
                                                            page.key + "_view",
                                                            $$a.concat([$$v])
                                                          )
                                                      } else {
                                                        $$i > -1 &&
                                                          _vm.$set(
                                                            _vm.role.perms,
                                                            page.key + "_view",
                                                            $$a
                                                              .slice(0, $$i)
                                                              .concat(
                                                                $$a.slice(
                                                                  $$i + 1
                                                                )
                                                              )
                                                          )
                                                      }
                                                    } else {
                                                      _vm.$set(
                                                        _vm.role.perms,
                                                        page.key + "_view",
                                                        $$c
                                                      )
                                                    }
                                                  },
                                                  function ($event) {
                                                    return _vm.checkParent(
                                                      index,
                                                      "view"
                                                    )
                                                  },
                                                ],
                                              },
                                            }),
                                          ]
                                        )
                                      : _vm._e(),
                                  ]),
                                  _vm._v(" "),
                                  _c("div", { staticClass: "check d-flex" }, [
                                    !_vm.ignoreRules.includes(
                                      page.key + "_edit"
                                    )
                                      ? _c(
                                          "label",
                                          { staticClass: "mb-0 pointer" },
                                          [
                                            _c("input", {
                                              directives: [
                                                {
                                                  name: "model",
                                                  rawName: "v-model",
                                                  value:
                                                    _vm.role.perms[
                                                      page.key + "_edit"
                                                    ],
                                                  expression:
                                                    "role.perms[page.key + '_edit']",
                                                },
                                              ],
                                              staticClass: "pointer",
                                              attrs: { type: "checkbox" },
                                              domProps: {
                                                checked: Array.isArray(
                                                  _vm.role.perms[
                                                    page.key + "_edit"
                                                  ]
                                                )
                                                  ? _vm._i(
                                                      _vm.role.perms[
                                                        page.key + "_edit"
                                                      ],
                                                      null
                                                    ) > -1
                                                  : _vm.role.perms[
                                                      page.key + "_edit"
                                                    ],
                                              },
                                              on: {
                                                change: [
                                                  function ($event) {
                                                    var $$a =
                                                        _vm.role.perms[
                                                          page.key + "_edit"
                                                        ],
                                                      $$el = $event.target,
                                                      $$c = $$el.checked
                                                        ? true
                                                        : false
                                                    if (Array.isArray($$a)) {
                                                      var $$v = null,
                                                        $$i = _vm._i($$a, $$v)
                                                      if ($$el.checked) {
                                                        $$i < 0 &&
                                                          _vm.$set(
                                                            _vm.role.perms,
                                                            page.key + "_edit",
                                                            $$a.concat([$$v])
                                                          )
                                                      } else {
                                                        $$i > -1 &&
                                                          _vm.$set(
                                                            _vm.role.perms,
                                                            page.key + "_edit",
                                                            $$a
                                                              .slice(0, $$i)
                                                              .concat(
                                                                $$a.slice(
                                                                  $$i + 1
                                                                )
                                                              )
                                                          )
                                                      }
                                                    } else {
                                                      _vm.$set(
                                                        _vm.role.perms,
                                                        page.key + "_edit",
                                                        $$c
                                                      )
                                                    }
                                                  },
                                                  function ($event) {
                                                    return _vm.checkParent(
                                                      index,
                                                      "edit"
                                                    )
                                                  },
                                                ],
                                              },
                                            }),
                                          ]
                                        )
                                      : _vm._e(),
                                  ]),
                                ]
                              ),
                              _vm._v(" "),
                              page.children.length > 0
                                ? [
                                    page.opened
                                      ? _vm._l(
                                          _vm.filteredPageChildren(index),
                                          function (children) {
                                            return _c(
                                              "div",
                                              {
                                                key: children.key,
                                                staticClass:
                                                  "item d-flex child",
                                              },
                                              [
                                                _c(
                                                  "div",
                                                  { staticClass: "name mr-3" },
                                                  [
                                                    _vm._v(
                                                      "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                        _vm._s(children.name) +
                                                        "\n\t\t\t\t\t\t\t\t\t\t"
                                                    ),
                                                  ]
                                                ),
                                                _vm._v(" "),
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass: "check d-flex",
                                                  },
                                                  [
                                                    !_vm.ignoreRules.includes(
                                                      children.key + "_view"
                                                    )
                                                      ? _c(
                                                          "label",
                                                          {
                                                            staticClass:
                                                              "mb-0 pointer",
                                                          },
                                                          [
                                                            _c("input", {
                                                              directives: [
                                                                {
                                                                  name: "model",
                                                                  rawName:
                                                                    "v-model",
                                                                  value:
                                                                    _vm.role
                                                                      .perms[
                                                                      children.key +
                                                                        "_view"
                                                                    ],
                                                                  expression:
                                                                    "role.perms[children.key + '_view']",
                                                                },
                                                              ],
                                                              staticClass:
                                                                "pointer",
                                                              attrs: {
                                                                type: "checkbox",
                                                              },
                                                              domProps: {
                                                                checked:
                                                                  Array.isArray(
                                                                    _vm.role
                                                                      .perms[
                                                                      children.key +
                                                                        "_view"
                                                                    ]
                                                                  )
                                                                    ? _vm._i(
                                                                        _vm.role
                                                                          .perms[
                                                                          children.key +
                                                                            "_view"
                                                                        ],
                                                                        null
                                                                      ) > -1
                                                                    : _vm.role
                                                                        .perms[
                                                                        children.key +
                                                                          "_view"
                                                                      ],
                                                              },
                                                              on: {
                                                                change: [
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    var $$a =
                                                                        _vm.role
                                                                          .perms[
                                                                          children.key +
                                                                            "_view"
                                                                        ],
                                                                      $$el =
                                                                        $event.target,
                                                                      $$c =
                                                                        $$el.checked
                                                                          ? true
                                                                          : false
                                                                    if (
                                                                      Array.isArray(
                                                                        $$a
                                                                      )
                                                                    ) {
                                                                      var $$v =
                                                                          null,
                                                                        $$i =
                                                                          _vm._i(
                                                                            $$a,
                                                                            $$v
                                                                          )
                                                                      if (
                                                                        $$el.checked
                                                                      ) {
                                                                        $$i <
                                                                          0 &&
                                                                          _vm.$set(
                                                                            _vm
                                                                              .role
                                                                              .perms,
                                                                            children.key +
                                                                              "_view",
                                                                            $$a.concat(
                                                                              [
                                                                                $$v,
                                                                              ]
                                                                            )
                                                                          )
                                                                      } else {
                                                                        $$i >
                                                                          -1 &&
                                                                          _vm.$set(
                                                                            _vm
                                                                              .role
                                                                              .perms,
                                                                            children.key +
                                                                              "_view",
                                                                            $$a
                                                                              .slice(
                                                                                0,
                                                                                $$i
                                                                              )
                                                                              .concat(
                                                                                $$a.slice(
                                                                                  $$i +
                                                                                    1
                                                                                )
                                                                              )
                                                                          )
                                                                      }
                                                                    } else {
                                                                      _vm.$set(
                                                                        _vm.role
                                                                          .perms,
                                                                        children.key +
                                                                          "_view",
                                                                        $$c
                                                                      )
                                                                    }
                                                                  },
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    return _vm.checkChild(
                                                                      index,
                                                                      "view"
                                                                    )
                                                                  },
                                                                ],
                                                              },
                                                            }),
                                                          ]
                                                        )
                                                      : _vm._e(),
                                                  ]
                                                ),
                                                _vm._v(" "),
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass: "check d-flex",
                                                  },
                                                  [
                                                    !_vm.ignoreRules.includes(
                                                      children.key + "_edit"
                                                    )
                                                      ? _c(
                                                          "label",
                                                          {
                                                            staticClass:
                                                              "mb-0 pointer",
                                                          },
                                                          [
                                                            _c("input", {
                                                              directives: [
                                                                {
                                                                  name: "model",
                                                                  rawName:
                                                                    "v-model",
                                                                  value:
                                                                    _vm.role
                                                                      .perms[
                                                                      children.key +
                                                                        "_edit"
                                                                    ],
                                                                  expression:
                                                                    "role.perms[children.key + '_edit']",
                                                                },
                                                              ],
                                                              staticClass:
                                                                "pointer",
                                                              attrs: {
                                                                type: "checkbox",
                                                              },
                                                              domProps: {
                                                                checked:
                                                                  Array.isArray(
                                                                    _vm.role
                                                                      .perms[
                                                                      children.key +
                                                                        "_edit"
                                                                    ]
                                                                  )
                                                                    ? _vm._i(
                                                                        _vm.role
                                                                          .perms[
                                                                          children.key +
                                                                            "_edit"
                                                                        ],
                                                                        null
                                                                      ) > -1
                                                                    : _vm.role
                                                                        .perms[
                                                                        children.key +
                                                                          "_edit"
                                                                      ],
                                                              },
                                                              on: {
                                                                change: [
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    var $$a =
                                                                        _vm.role
                                                                          .perms[
                                                                          children.key +
                                                                            "_edit"
                                                                        ],
                                                                      $$el =
                                                                        $event.target,
                                                                      $$c =
                                                                        $$el.checked
                                                                          ? true
                                                                          : false
                                                                    if (
                                                                      Array.isArray(
                                                                        $$a
                                                                      )
                                                                    ) {
                                                                      var $$v =
                                                                          null,
                                                                        $$i =
                                                                          _vm._i(
                                                                            $$a,
                                                                            $$v
                                                                          )
                                                                      if (
                                                                        $$el.checked
                                                                      ) {
                                                                        $$i <
                                                                          0 &&
                                                                          _vm.$set(
                                                                            _vm
                                                                              .role
                                                                              .perms,
                                                                            children.key +
                                                                              "_edit",
                                                                            $$a.concat(
                                                                              [
                                                                                $$v,
                                                                              ]
                                                                            )
                                                                          )
                                                                      } else {
                                                                        $$i >
                                                                          -1 &&
                                                                          _vm.$set(
                                                                            _vm
                                                                              .role
                                                                              .perms,
                                                                            children.key +
                                                                              "_edit",
                                                                            $$a
                                                                              .slice(
                                                                                0,
                                                                                $$i
                                                                              )
                                                                              .concat(
                                                                                $$a.slice(
                                                                                  $$i +
                                                                                    1
                                                                                )
                                                                              )
                                                                          )
                                                                      }
                                                                    } else {
                                                                      _vm.$set(
                                                                        _vm.role
                                                                          .perms,
                                                                        children.key +
                                                                          "_edit",
                                                                        $$c
                                                                      )
                                                                    }
                                                                  },
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    return _vm.checkChild(
                                                                      index,
                                                                      "edit"
                                                                    )
                                                                  },
                                                                ],
                                                              },
                                                            }),
                                                          ]
                                                        )
                                                      : _vm._e(),
                                                  ]
                                                ),
                                              ]
                                            )
                                          }
                                        )
                                      : _vm._e(),
                                  ]
                                : _vm._e(),
                            ]
                          }),
                        ],
                        2
                      ),
                      _vm._v(" "),
                      _c("div", { staticClass: "mt-3" }, [
                        _c(
                          "button",
                          {
                            staticClass: "btn btn-success",
                            on: { click: _vm.updateRole },
                          },
                          [_vm._v("\n\t\t\t\t\t\t\tСохранить\n\t\t\t\t\t\t")]
                        ),
                      ]),
                    ])
                  : _vm._e(),
              ]),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "12", md: "3" } }, [
                _c("div", { staticClass: "roles-list" }, [
                  _c("div", { staticClass: "roles" }, [
                    _c("div", { staticClass: "contrast role-title" }, [
                      _c("b", [_vm._v("Список ролей")]),
                      _vm._v(" "),
                      _c("img", {
                        directives: [
                          {
                            name: "b-popover",
                            rawName: "v-b-popover.hover.bottom",
                            value:
                              "В Роли указывается что доступно для просмотра и Редактирования",
                            expression:
                              "'В Роли указывается что доступно для просмотра и Редактирования'",
                            modifiers: { hover: true, bottom: true },
                          },
                        ],
                        staticClass: "img-info",
                        attrs: { src: "/images/dist/profit-info.svg" },
                      }),
                    ]),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "role-body" },
                      _vm._l(_vm.roles, function (item, i) {
                        return _c("div", { key: i, staticClass: "role-item" }, [
                          _c(
                            "div",
                            {
                              staticClass: "name",
                              on: {
                                click: function ($event) {
                                  return _vm.editRole(i)
                                },
                              },
                            },
                            [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t\t\t" +
                                  _vm._s(item.name) +
                                  "\n\t\t\t\t\t\t\t\t"
                              ),
                            ]
                          ),
                          _vm._v(" "),
                          _c("div", { staticClass: "actions" }, [
                            _c(
                              "span",
                              {
                                staticClass: "btn btn-primary btn-sm btn-icon",
                                on: {
                                  click: function ($event) {
                                    return _vm.editRole(i)
                                  },
                                },
                              },
                              [_c("i", { staticClass: "far fa-edit" })]
                            ),
                            _vm._v(" "),
                            _c(
                              "span",
                              {
                                staticClass: "btn btn-danger btn-sm btn-icon",
                                on: {
                                  click: function ($event) {
                                    return _vm.deleteRole(i)
                                  },
                                },
                              },
                              [_c("i", { staticClass: "fa fa-times" })]
                            ),
                          ]),
                        ])
                      }),
                      0
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "role-footer" }, [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-success",
                          on: { click: _vm.addRole },
                        },
                        [
                          _vm._v(
                            "\n\t\t\t\t\t\t\t\tДобавить роль\n\t\t\t\t\t\t\t"
                          ),
                        ]
                      ),
                    ]),
                  ]),
                ]),
              ]),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);