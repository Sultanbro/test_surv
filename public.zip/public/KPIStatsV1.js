"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["KPIStatsV1"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Stats.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Stats.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jw-vue-pagination */ "./node_modules/jw-vue-pagination/lib/JwPagination.js");
/* harmony import */ var jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pages_kpi_SuperFilter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/pages/kpi/SuperFilter */ "./resources/js/pages/kpi/SuperFilter.vue");
/* harmony import */ var _pages_kpi_StatsTable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/pages/kpi/StatsTable */ "./resources/js/pages/kpi/StatsTable.vue");
/* harmony import */ var _pages_kpi_StatsTableBonus__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/pages/kpi/StatsTableBonus */ "./resources/js/pages/kpi/StatsTableBonus.vue");
/* harmony import */ var _pages_kpi_StatsTableQuartal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/pages/kpi/StatsTableQuartal */ "./resources/js/pages/kpi/StatsTableQuartal.vue");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */


 // filter like bitrix




// import {formatDate} from './kpis.js';

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KPIStats',
  components: {
    JwPagination: (jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0___default()),
    SuperFilter: _pages_kpi_SuperFilter__WEBPACK_IMPORTED_MODULE_1__["default"],
    StatsTable: _pages_kpi_StatsTable__WEBPACK_IMPORTED_MODULE_2__["default"],
    StatsTableBonus: _pages_kpi_StatsTableBonus__WEBPACK_IMPORTED_MODULE_3__["default"],
    StatsTableQuartal: _pages_kpi_StatsTableQuartal__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  props: {},
  data: function data() {
    return {
      searchText: new URL(location.href).searchParams.get('target') ? new URL(location.href).searchParams.get('target') : '',
      s_type_main: 1,
      month: new Date().getMonth(),
      active: 1,
      paginationKey: 1,
      pageSize: 20,
      items: [],
      page_items: [],
      groups: {},
      date: null,
      activities: [],
      bonus_groups: [],
      quartal_users: [],
      quartal_groups: []
    };
  },
  watch: {
    pageSize: {
      handler: function handler(val) {
        if (val < 1) {
          val = 1;
          return;
        }
        if (val > 100) {
          val = 100;
          return;
        }
        this.paginationKey++;
      }
    }
  },
  created: function created() {
    this.fetchData([]);
    this.page_items = this.items.slice(0, this.pageSize);
  },
  mounted: function mounted() {
    var _this = this;
    this.$watch('$refs.child.searchText', function (new_value) {
      return _this.searchText = new_value;
    });
  },
  methods: {
    onChangePage: function onChangePage(page_items) {
      this.page_items = page_items;
    },
    fetchData: function fetchData(filters) {
      var _this2 = this;
      var loader = this.$loading.show();
      this.s_type_main = filters.data_from ? filters.data_from.s_type : 1;
      this.month = filters.data_from ? filters.data_from.month : new Date().getMonth();
      if (this.s_type_main == 1) {
        this.axios.post('/statistics/kpi', {
          filters: filters
        }).then(function (response) {
          // items
          _this2.items = response.data.items;
          _this2.activities = response.data.activities;
          _this2.groups = response.data.groups;

          // paginate
          _this2.page_items = _this2.items.slice(0, _this2.pageSize);
          _this2.date = filters.data_from != undefined ? new Date(filters.data_from.year, filters.data_from.month, 1).toISOString().substr(0, 10) : new Date().toISOString().substr(0, 10);
          loader.hide();
        })["catch"](function (error) {
          loader.hide();
          alert(error);
        });
      } else if (this.s_type_main == 2) {
        this.axios.get('/statistics/bonuses').then(function (response) {
          _this2.bonus_groups = response.data;
          loader.hide();
        })["catch"](function (error) {
          loader.hide();
          alert(error);
        });
      } else if (this.s_type_main == 3) {
        this.axios.get('/statistics/quartal-premiums').then(function (response) {
          //this.quartal_items = response.data;
          _this2.quartal_users = response.data[0].map(function (res) {
            return _objectSpread(_objectSpread({}, res), {}, {
              expanded: false
            });
          });
          _this2.quartal_groups = response.data[1].map(function (res) {
            return _objectSpread(_objectSpread({}, res), {}, {
              expanded: false
            });
          });
          loader.hide();
        })["catch"](function (error) {
          loader.hide();
          alert(error);
        });
      } else {
        loader.hide();
        alert('error!');
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _pages_kpi_KpiItems__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/pages/kpi/KpiItems */ "./resources/js/pages/kpi/KpiItems.vue");
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./kpis.js */ "./resources/js/pages/kpi/kpis.js");
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_kpis_js__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable vue/no-mutating-props */

/* eslint-disable-next-line camelcase */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'StatsTable',
  components: {
    KpiItems: _pages_kpi_KpiItems__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    searchText: {
      type: String,
      "default": ''
    },
    items: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activities: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    groups: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    editable: {
      type: Boolean,
      "default": false
    },
    date: {
      type: Object,
      "default": null
    }
  },
  data: function data() {
    return {
      showFields: [],
      fields: []
    };
  },
  watch: {
    showFields: {
      handler: function handler(val) {
        /* eslint-disable-next-line camelcase */
        localStorage.kpi_show_fields = JSON.stringify(val);
        this.prepareFields();
      },
      deep: true
    }
  },
  created: function created() {
    this.prepareFields();
    this.countAvg();
  },
  mounted: function mounted() {},
  methods: {
    expand: function expand(w) {
      this.items[w].expanded = !this.items[w].expanded;
    },
    prepareFields: function prepareFields() {
      var _this = this;
      var visibleFields = [];

      /* eslint-disable-next-line camelcase */
      _kpis_js__WEBPACK_IMPORTED_MODULE_1__.kpi_fields.forEach(function (field) {
        if (_this.showFields[field.key] != undefined && _this.showFields[field.key]) {
          visibleFields.push(field);
        }
      });

      /* eslint-disable-next-line camelcase */
      this.fields = _kpis_js__WEBPACK_IMPORTED_MODULE_1__.kpi_fields;
    },
    countAvg: function countAvg() {
      this.items.forEach(function (kpi) {
        var kpiSum = 0;
        var kpiCount = 0;
        kpi.users.forEach(function (user) {
          var count = 0;
          var sum = 0;
          var avg = 0;
          user.items.forEach(function (item) {
            sum += Number(item.percent);
            count++;
          });

          /**
          * count avg of user items
          */
          avg = count > 0 ? Number(sum / count).toFixed(2) : 0;
          user.avg = avg;

          // all kpi sum
          kpiSum += Number(avg);
          kpiCount++;
        });

        /**
        * count avg completed percent of kpi by users
        */
        kpi.avg = kpiCount > 0 ? Number(Number(kpiSum / kpiCount * 100).toFixed(2)) : 0;
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".child-table[data-v-a20ceafa] {\n  width: 100%;\n}\n.profile-salary-info .table td[data-v-a20ceafa], .profile-salary-info .table th[data-v-a20ceafa], .profile-salary-info .table thead th[data-v-a20ceafa] {\n  vertical-align: middle;\n  min-width: 42px;\n  font-size: 13px;\n  padding: 5px 12px;\n  text-align: center;\n}\n.profile-salary-info .j-table .table-inner[data-v-a20ceafa] {\n  background: #e9eef3;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTable_vue_vue_type_style_index_0_id_a20ceafa_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTable_vue_vue_type_style_index_0_id_a20ceafa_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTable_vue_vue_type_style_index_0_id_a20ceafa_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/pages/kpi/Stats.vue":
/*!******************************************!*\
  !*** ./resources/js/pages/kpi/Stats.vue ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Stats_vue_vue_type_template_id_a304658a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Stats.vue?vue&type=template&id=a304658a& */ "./resources/js/pages/kpi/Stats.vue?vue&type=template&id=a304658a&");
/* harmony import */ var _Stats_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Stats.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/Stats.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Stats_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Stats_vue_vue_type_template_id_a304658a___WEBPACK_IMPORTED_MODULE_0__.render,
  _Stats_vue_vue_type_template_id_a304658a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/Stats.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTable.vue":
/*!***********************************************!*\
  !*** ./resources/js/pages/kpi/StatsTable.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StatsTable_vue_vue_type_template_id_a20ceafa_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatsTable.vue?vue&type=template&id=a20ceafa&scoped=true& */ "./resources/js/pages/kpi/StatsTable.vue?vue&type=template&id=a20ceafa&scoped=true&");
/* harmony import */ var _StatsTable_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatsTable.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/StatsTable.vue?vue&type=script&lang=js&");
/* harmony import */ var _StatsTable_vue_vue_type_style_index_0_id_a20ceafa_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss& */ "./resources/js/pages/kpi/StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _StatsTable_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StatsTable_vue_vue_type_template_id_a20ceafa_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _StatsTable_vue_vue_type_template_id_a20ceafa_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "a20ceafa",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/StatsTable.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/Stats.vue?vue&type=script&lang=js&":
/*!*******************************************************************!*\
  !*** ./resources/js/pages/kpi/Stats.vue?vue&type=script&lang=js& ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Stats_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Stats.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Stats.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Stats_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTable.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTable.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTable_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTable.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTable_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss& ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTable_vue_vue_type_style_index_0_id_a20ceafa_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=style&index=0&id=a20ceafa&scoped=true&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/kpi/Stats.vue?vue&type=template&id=a304658a&":
/*!*************************************************************************!*\
  !*** ./resources/js/pages/kpi/Stats.vue?vue&type=template&id=a304658a& ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Stats_vue_vue_type_template_id_a304658a___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Stats_vue_vue_type_template_id_a304658a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Stats_vue_vue_type_template_id_a304658a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Stats.vue?vue&type=template&id=a304658a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Stats.vue?vue&type=template&id=a304658a&");


/***/ }),

/***/ "./resources/js/pages/kpi/StatsTable.vue?vue&type=template&id=a20ceafa&scoped=true&":
/*!******************************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTable.vue?vue&type=template&id=a20ceafa&scoped=true& ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTable_vue_vue_type_template_id_a20ceafa_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTable_vue_vue_type_template_id_a20ceafa_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTable_vue_vue_type_template_id_a20ceafa_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTable.vue?vue&type=template&id=a20ceafa&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=template&id=a20ceafa&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Stats.vue?vue&type=template&id=a304658a&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Stats.vue?vue&type=template&id=a304658a& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "stats px-3 py-1" },
    [
      _c("div", { staticClass: "d-flex my-4 jcsb aifs" }, [
        _c(
          "div",
          { staticClass: "d-flex aic mr-2" },
          [
            _c("div", { staticClass: "d-flex aic mr-2" }, [
              _c("span", [_vm._v("Показывать:")]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.pageSize,
                    expression: "pageSize",
                  },
                ],
                staticClass: "form-control ml-2 input-sm",
                attrs: { type: "number", min: "1", max: "100" },
                domProps: { value: _vm.pageSize },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.pageSize = $event.target.value
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("SuperFilter", {
              ref: "child",
              attrs: { groups: _vm.groups },
              on: { apply: _vm.fetchData },
            }),
            _vm._v(" "),
            _vm.items
              ? _c("span", { staticClass: "ml-2" }, [
                  _vm._v(
                    "\n\t\t\t\tНайдено: " +
                      _vm._s(_vm.items.length) +
                      "\n\t\t\t"
                  ),
                ])
              : _c("span", { staticClass: "ml-2" }, [
                  _vm._v("\n\t\t\t\tНайдено: 0\n\t\t\t"),
                ]),
          ],
          1
        ),
      ]),
      _vm._v(" "),
      _vm.s_type_main == 1
        ? _c("StatsTable", {
            attrs: {
              activities: _vm.activities,
              groups: _vm.groups,
              items: _vm.page_items,
              editable: true,
              "search-text": _vm.searchText,
              date: _vm.date,
            },
          })
        : _vm._e(),
      _vm._v(" "),
      _vm.s_type_main == 2
        ? _c("StatsTableBonus", {
            key: _vm.bonus_groups,
            attrs: {
              groups: _vm.bonus_groups,
              group_names: _vm.groups,
              month: _vm.month,
            },
          })
        : _vm._e(),
      _vm._v(" "),
      _vm.s_type_main == 3
        ? _c("StatsTableQuartal", {
            key: _vm.quartal_users,
            attrs: {
              users: _vm.quartal_users,
              groups: _vm.quartal_groups,
              "search-text": _vm.searchText,
            },
          })
        : _vm._e(),
      _vm._v(" "),
      _vm.s_type_main == 1
        ? _c("JwPagination", {
            key: _vm.paginationKey,
            staticClass: "mt-3",
            attrs: {
              items: _vm.items,
              labels: {
                first: "<<",
                last: ">>",
                previous: "<",
                next: ">",
              },
              "page-size": +_vm.pageSize,
            },
            on: { changePage: _vm.onChangePage },
          })
        : _vm._e(),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=template&id=a20ceafa&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTable.vue?vue&type=template&id=a20ceafa&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "t-stats" }, [
    _c("table", { staticClass: "j-table" }, [
      _c("thead", [
        _c("tr", { staticClass: "table-heading" }, [
          _c("th", { staticClass: "first-column" }),
          _vm._v(" "),
          _c("th", { staticClass: "w" }, [_vm._v("\n\t\t\t\t\tKPI\n\t\t\t\t")]),
          _vm._v(" "),
          _vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tСредний %\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          !_vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tНижний порог отсчета\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          !_vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tВерхний порог отсчета\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          !_vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tПри выполнении на 80-99%\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          !_vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tПри выполнении на 100%\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          !_vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tЗаработано\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          _vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tСредний %\n\t\t\t\t"),
              ])
            : _vm._e(),
        ]),
      ]),
      _vm._v(" "),
      _c(
        "tbody",
        [
          _vm._l(_vm.items.slice().reverse(), function (wrap_item, w) {
            return [
              _vm.searchText.length == 0 ||
              (wrap_item.target &&
                wrap_item.target.name.includes(_vm.searchText))
                ? [
                    _c("tr", { key: w, staticClass: "main-row" }, [
                      _c(
                        "td",
                        {
                          staticClass: "pointer p-2 text-center",
                          on: {
                            click: function ($event) {
                              wrap_item.expanded = !wrap_item.expanded
                            },
                          },
                        },
                        [
                          _c(
                            "div",
                            {
                              staticClass:
                                "d-flex align-items-center justify-content-center px-2",
                            },
                            [
                              _c("span", { staticClass: "mr-2" }, [
                                _vm._v(_vm._s(w + 1)),
                              ]),
                              _vm._v(" "),
                              wrap_item.expanded
                                ? _c("i", { staticClass: "fa fa-minus mt-1" })
                                : _c("i", { staticClass: "fa fa-plus mt-1" }),
                            ]
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c("td", { staticClass: "p-4" }, [
                        wrap_item.target != null
                          ? _c("span", [_vm._v(_vm._s(wrap_item.target.name))])
                          : _c("span", [_vm._v("---")]),
                      ]),
                      _vm._v(" "),
                      _vm.editable
                        ? _c("td", { staticClass: "p-4" }, [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t" +
                                _vm._s(wrap_item.avg) +
                                "%\n\t\t\t\t\t\t"
                            ),
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      !_vm.editable
                        ? _c("td", { staticClass: "p-4" }, [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t" +
                                _vm._s(wrap_item.lower_limit) +
                                "%\n\t\t\t\t\t\t"
                            ),
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      !_vm.editable
                        ? _c("td", { staticClass: "p-4" }, [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t" +
                                _vm._s(wrap_item.upper_limit) +
                                "%\n\t\t\t\t\t\t"
                            ),
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      !_vm.editable
                        ? _c("td", { staticClass: "p-4" }, [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t" +
                                _vm._s(
                                  wrap_item.users.length > 0 &&
                                    wrap_item.users[0].full_time == 1
                                    ? wrap_item.completed_80
                                    : wrap_item.completed_80 / 2
                                ) +
                                "\n\t\t\t\t\t\t"
                            ),
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      !_vm.editable
                        ? _c("td", { staticClass: "p-4" }, [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t" +
                                _vm._s(
                                  wrap_item.users.length > 0 &&
                                    wrap_item.users[0].full_time == 1
                                    ? wrap_item.completed_100
                                    : wrap_item.completed_100 / 2
                                ) +
                                "\n\t\t\t\t\t\t"
                            ),
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      !_vm.editable
                        ? _c("td", { staticClass: "p-4" }, [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t" +
                                _vm._s(wrap_item.my_sum) +
                                "\n\t\t\t\t\t\t"
                            ),
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.editable ? _c("td") : _vm._e(),
                    ]),
                    _vm._v(" "),
                    wrap_item.users != undefined && wrap_item.users.length > 0
                      ? [
                          _c(
                            "tr",
                            {
                              key: w + "a",
                              staticClass: "collapsable",
                              class: {
                                active: wrap_item.expanded || !_vm.editable,
                              },
                            },
                            [
                              _c(
                                "td",
                                { attrs: { colspan: _vm.editable ? 4 : 7 } },
                                [
                                  _c(
                                    "div",
                                    { staticClass: "table__wrapper w-100" },
                                    [
                                      _c(
                                        "table",
                                        { staticClass: "child-table" },
                                        [
                                          _vm._l(
                                            wrap_item.users,
                                            function (user, i) {
                                              return [
                                                _vm.editable
                                                  ? _c(
                                                      "tr",
                                                      {
                                                        key: i,
                                                        staticClass:
                                                          "child-row",
                                                      },
                                                      [
                                                        _c(
                                                          "td",
                                                          {
                                                            staticClass:
                                                              "pointer p-2 text-center",
                                                            on: {
                                                              click: function (
                                                                $event
                                                              ) {
                                                                user.expanded =
                                                                  !user.expanded
                                                              },
                                                            },
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "d-flex align-center justify-content-center px-2",
                                                              },
                                                              [
                                                                _c(
                                                                  "span",
                                                                  {
                                                                    staticClass:
                                                                      "mr-2 bg-transparent",
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      _vm._s(
                                                                        i + 1
                                                                      )
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                user.expanded
                                                                  ? _c("i", {
                                                                      staticClass:
                                                                        "fa fa-minus mt-1",
                                                                    })
                                                                  : _c("i", {
                                                                      staticClass:
                                                                        "fa fa-plus mt-1",
                                                                    }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "td",
                                                          {
                                                            staticClass: "p-4",
                                                          },
                                                          [
                                                            _vm._v(
                                                              "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                _vm._s(
                                                                  user.name
                                                                ) +
                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        user.items !== undefined
                                                          ? _vm._l(
                                                              user.items,
                                                              function (
                                                                kpi_item,
                                                                index
                                                              ) {
                                                                return _c(
                                                                  "td",
                                                                  {
                                                                    key: index,
                                                                    staticClass:
                                                                      "px-2",
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                        _vm._s(
                                                                          kpi_item.name
                                                                        ) +
                                                                        " "
                                                                    ),
                                                                    _c("b", [
                                                                      _vm._v(
                                                                        _vm._s(
                                                                          kpi_item.percent
                                                                        ) + "%"
                                                                      ),
                                                                    ]),
                                                                  ]
                                                                )
                                                              }
                                                            )
                                                          : _vm._e(),
                                                      ],
                                                      2
                                                    )
                                                  : _vm._e(),
                                                _vm._v(" "),
                                                user.items !== undefined
                                                  ? [
                                                      _c(
                                                        "tr",
                                                        {
                                                          key: i + "a",
                                                          staticClass:
                                                            "collapsable",
                                                          class: {
                                                            active:
                                                              user.expanded,
                                                          },
                                                        },
                                                        [
                                                          _c(
                                                            "td",
                                                            {
                                                              attrs: {
                                                                colspan:
                                                                  _vm.fields
                                                                    .length + 2,
                                                              },
                                                            },
                                                            [
                                                              _c(
                                                                "div",
                                                                {
                                                                  staticClass:
                                                                    "table__wrapper__second w-100",
                                                                },
                                                                [
                                                                  _c(
                                                                    "KpiItems",
                                                                    {
                                                                      attrs: {
                                                                        my_sum:
                                                                          user.full_time ==
                                                                          1
                                                                            ? wrap_item.completed_100
                                                                            : wrap_item.completed_100 /
                                                                              2,
                                                                        kpi_id:
                                                                          user.id,
                                                                        items:
                                                                          user.items,
                                                                        expanded:
                                                                          user.expanded,
                                                                        activities:
                                                                          _vm.activities,
                                                                        groups:
                                                                          _vm.groups,
                                                                        completed_80:
                                                                          wrap_item.completed_80,
                                                                        completed_100:
                                                                          wrap_item.completed_100,
                                                                        lower_limit:
                                                                          wrap_item.lower_limit,
                                                                        upper_limit:
                                                                          wrap_item.upper_limit,
                                                                        editable:
                                                                          _vm.editable,
                                                                        kpi_page: false,
                                                                        date: _vm.date,
                                                                      },
                                                                      on: {
                                                                        getSum:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            wrap_item.my_sum =
                                                                              $event
                                                                          },
                                                                        recalced:
                                                                          _vm.countAvg,
                                                                      },
                                                                    }
                                                                  ),
                                                                ],
                                                                1
                                                              ),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                    ]
                                                  : _vm._e(),
                                              ]
                                            }
                                          ),
                                        ],
                                        2
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      : _vm._e(),
                  ]
                : _vm._e(),
            ]
          }),
        ],
        2
      ),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);