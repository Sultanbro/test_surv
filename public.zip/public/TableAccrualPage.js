(self["webpackChunk"] = self["webpackChunk"] || []).push([["TableAccrualPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _pages_kpi_KpiItemsV2_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/pages/kpi/KpiItemsV2.vue */ "./resources/js/pages/kpi/KpiItemsV2.vue");
/* harmony import */ var _ui_ProfileTabs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ui/ProfileTabs */ "./resources/js/components/ui/ProfileTabs.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KpiContent',
  components: {
    KpiItemsV2: _pages_kpi_KpiItemsV2_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    ProfileTabs: _ui_ProfileTabs__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  props: {
    items: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    groups: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activities: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    fields: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    editable: {
      type: Boolean,
      "default": false
    }
  },
  methods: {
    countAvg: function countAvg() {
      this.items.forEach(function (kpi) {
        var kpiSum = 0;
        var kpiCount = 0;
        kpi.users.forEach(function (user) {
          var count = 0;
          var sum = 0;
          var avg = 0;
          user.items.forEach(function (item) {
            sum += Number(item.percent);
            count++;
          });

          /**
           * count avg of user items
           */
          avg = count > 0 ? Number(sum / count).toFixed(2) : 0;
          user.avg = avg;

          // all kpi sum
          kpiSum += Number(avg);
          kpiCount++;
        });

        /**
         * count avg completed percent of kpi by users
         */
        kpi.avg = kpiCount > 0 ? Number(Number(kpiSum / kpiCount * 100).toFixed(2)) : 0;
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_Portal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/Portal */ "./resources/js/stores/Portal.js");
/* harmony import */ var _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/ui/Sidebar */ "./resources/js/components/ui/Sidebar.vue");
/* harmony import */ var _composables_yearOptions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../composables/yearOptions */ "./resources/js/composables/yearOptions.js");
/* harmony import */ var _pages_kpi_kpis_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/pages/kpi/kpis.js */ "./resources/js/pages/kpi/kpis.js");
/* harmony import */ var _pages_kpi_kpis_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pages_kpi_kpis_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_Profile_Popups_KpiContent_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/pages/Profile/Popups/KpiContent.vue */ "./resources/js/pages/Profile/Popups/KpiContent.vue");
/* harmony import */ var _composables_salaryCellType__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/composables/salaryCellType */ "./resources/js/composables/salaryCellType.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */



 // сайдбар table

// import KpiItemsV2 from '@/pages/kpi/KpiItemsV2'



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TableAccrual',
  components: {
    Sidebar: _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_1__["default"],
    // KpiItemsV2,
    KpiContent: _pages_Profile_Popups_KpiContent_vue__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  props: {
    groupss: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activeuserid: {
      type: String,
      "default": ''
    },
    activeuserpos: {
      type: Number,
      "default": 0
    },
    can_edit: Boolean,
    is_admin: Boolean
  },
  data: function data() {
    var now = new Date();
    return {
      data: {},
      groups: [],
      accruals: [],
      bonus_history: [],
      selectedGroup: null,
      user_types: 0,
      users_count: 0,
      openSidebar: false,
      show_user: 1,
      sidebarTitle: '',
      sidebarContent: {},
      sidebarHistory: [],
      numClicks: 0,
      total_resources: 0,
      allTotalFired: 0,
      // sum of pay for all fired users
      group_fired: 0,
      // sum of payment for fired users in group
      group_total: 0,
      // sum of payment for  users in group
      items: [],
      fields: [],
      errors: [],
      auth_token: '',
      profile_link: '',
      selectedCell: null,
      special_fields: false,
      editPremiumSidebar: false,
      avans: {
        sum: null,
        comment: '',
        require: '',
        visible: false
      },
      bonus: {
        sum: null,
        comment: '',
        require: '',
        visible: false
      },
      dayInfoText: '',
      hasPermission: false,
      total: 0,
      allTotal: 0,
      dateInfo: {
        currentMonth: null,
        currentYear: now.getFullYear(),
        month: 0,
        year: 0,
        monthEnd: 0,
        workDays: 0,
        weekDays: 0,
        daysInMonth: 0
      },
      editedField: {
        name: '',
        type: 'kpi'
      },
      commentEdit: '',
      amountEdit: 0,
      editPremiunWindow: false,
      showBeforeApprove: false,
      dataLoaded: false,
      currentGroup: null,
      maxScrollWidth: 0,
      scrollLeft: 0,
      defaultScrollValue: 0,
      dayPercentage: now.getDate() / 31 * 100,
      delay: 700,
      clicks: 0,
      timer: null,
      kpiSidebarUserId: 0,
      kpiSidebar: false,
      kpiFields: _pages_kpi_kpis_js__WEBPACK_IMPORTED_MODULE_3__.kpi_fields,
      kpiItems: [],
      // stats:

      isAvansSidebar: false,
      avans_history: [],
      isFineSidebar: false,
      fine_history: [],
      isTaxesSidebar: false,
      taxes_history: []
    };
  },
  computed: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_6__.mapState)(_stores_Portal__WEBPACK_IMPORTED_MODULE_0__.usePortalStore, ['portal'])), {}, {
    years: function years() {
      if (!this.portal.created_at) return [new Date().getFullYear()];
      return (0,_composables_yearOptions__WEBPACK_IMPORTED_MODULE_2__.useYearOptions)(new Date(this.portal.created_at).getFullYear());
    },
    showAccruals: function showAccruals() {
      return this.activeuserid && [5, 18, 84, 157].includes(Number(this.activeuserid));
    },
    showTotals: function showTotals() {
      return this.activeuserid && [5, 18, 84, 157].includes(Number(this.activeuserid));
    },
    actualFOT: function actualFOT() {
      if (!this.items || !this.items[0]) return 0;
      return (parseInt(this.items[0].kpi) || 0) + (parseInt(this.items[0].bonus) || 0) + (parseInt(this.items[0].total) || 0);
    },
    date: function date() {
      return this.$moment("".concat(this.dateInfo.currentYear, "-").concat(this.dateInfo.currentMonth, "-1"), 'YYYY-MMMM-D').format('YYYY-MM-DD');
    }
  }),
  watch: {
    scrollLeft: function scrollLeft(value) {
      var container = document.querySelector('.table-responsive');
      container.scrollLeft = value;
    },
    user_types: function user_types() {
      this.fetchData();
    },
    show_user: function show_user() {
      this.fetchData();
    },
    selectedGroup: function selectedGroup() {
      this.fetchData();
    },
    groupss: function groupss() {
      this.init();
    }
  },
  created: function created() {
    if (this.groupss) {
      this.init();
    }
  },
  methods: {
    init: function init() {
      this.dateInfo.currentMonth = this.dateInfo.currentMonth ? this.dateInfo.currentMonth : this.$moment().format('MMMM');
      var currentMonth = this.$moment("".concat(this.dateInfo.currentYear, "-").concat(this.dateInfo.currentMonth), 'YYYY-MMMM');

      //Расчет выходных дней
      this.dateInfo.monthEnd = currentMonth.endOf('month'); //Конец месяца
      this.dateInfo.weekDays = currentMonth.weekdayCalc(this.dateInfo.monthEnd, [6]); //Колличество выходных
      this.dateInfo.daysInMonth = currentMonth.daysInMonth(); //Колличество дней в месяце
      this.dateInfo.workDays = this.dateInfo.daysInMonth - this.dateInfo.weekDays; //Колличество рабочих дней

      this.groups = this.groupss;
      this.selectedGroup = this.groups[0];
    },
    //Установка выбранного года
    setYear: function setYear() {
      this.dateInfo.currentYear = this.dateInfo.currentYear ? this.dateInfo.currentYear : this.$moment().format('YYYY');
    },
    //Установка выбранного месяца
    setMonth: function setMonth() {
      var year = this.dateInfo.currentYear;
      this.dateInfo.currentMonth = this.dateInfo.currentMonth ? this.dateInfo.currentMonth : this.$moment().format('MMMM');
      this.dateInfo.month = this.dateInfo.month ? this.dateInfo.month : this.$moment().format('M');
      this.dateInfo.year = year;
      this.dateInfo.date = "".concat(this.dateInfo.currentMonth, " ").concat(year);
      var currentMonth = this.$moment("".concat(this.dateInfo.currentYear, "-").concat(this.dateInfo.currentMonth), 'YYYY-MMMM');
      //Расчет выходных дней
      this.dateInfo.monthEnd = currentMonth.endOf('month'); //Конец месяца
      this.dateInfo.weekDays = currentMonth.weekdayCalc(this.dateInfo.monthEnd, [6]); //Колличество выходных
      this.dateInfo.daysInMonth = currentMonth.daysInMonth(); //Колличество дней в месяце
      this.dateInfo.workDays = this.dateInfo.daysInMonth - this.dateInfo.weekDays; //Колличество рабочих дней
    },
    //Установка заголовока таблицы
    setFields: function setFields() {
      var fields = [];
      fields = [{
        key: 'name',
        stickyColumn: true,
        label: 'Имя',
        variant: 'primary',
        sortable: true,
        "class": 'text-left px-3 t-name',
        editable: false
      }, {
        key: 'kpi',
        label: 'KPI',
        sortable: true,
        editable: false,
        stickyColumn: true
      }, {
        key: 'bonus',
        label: 'Бонусы',
        sortable: true,
        editable: false,
        stickyColumn: true
      }, {
        key: 'total',
        label: 'Оклад',
        sortable: true,
        editable: false,
        stickyColumn: true
      }, {
        key: 'fines',
        label: 'Штрафы',
        sortable: true,
        editable: false,
        stickyColumn: true
      }, {
        key: 'avans',
        label: 'Авансы',
        sortable: true,
        editable: false,
        stickyColumn: true
      }, {
        key: 'taxes',
        label: 'Налоги',
        sortable: true,
        editable: false,
        stickyColumn: true
      }, {
        key: 'final',
        label: 'К выдаче',
        sortable: true,
        editable: false,
        stickyColumn: true
      }];
      var days = this.dateInfo.daysInMonth;
      for (var i = 1; i <= days; i++) {
        var dayName = this.$moment("".concat(i, " ").concat(this.dateInfo.date), 'D MMMM YYYY').locale('en').format('ddd');
        var field = {
          key: "".concat(i),
          label: "".concat(i),
          sortable: true,
          editable: true,
          weekend: dayName === 'Sat' || dayName === 'Sun'
        };
        fields.push(field);
      }
      this.fields = fields;
    },
    //Загрузка данных для таблицы
    fetchData: function fetchData() {
      var _this = this;
      if (this.selectedGroup == null) return '';
      var loader = this.$loading.show();
      this.dateInfo.month = this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M');
      this.axios.post('/timetracking/salaries', {
        month: this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M'),
        year: this.dateInfo.currentYear,
        group_id: this.selectedGroup.id,
        user_types: this.user_types
      }).then(function (response) {
        var data = response.data;
        if (data.error && data.error == 'access') {
          console.error(data.error);
          _this.hasPermission = false;
          loader.hide();
          return;
        }
        _this.hasPermission = true;
        _this.data = data;
        _this.group_fired = data.group_fired;
        _this.allTotal = data.all_total;
        _this.allTotalFired = data.all_total_fired;
        _this.group_total = data.group_total;
        _this.total_resources = data.total_resources;
        _this.users_count = data.users.length;
        _this.groups = data.groups;
        _this.accruals = data.accruals;
        _this.auth_token = data.auth_token;
        if (data.currentGroup) {
          _this.selectedGroup.salary_approved = data.currentGroup.salary_approved;
          _this.selectedGroup.salary_approved_by = data.currentGroup.salary_approved_by;
          _this.selectedGroup.salary_approved_date = data.currentGroup.salary_approved_date;
        }
        _this.setYear();
        _this.setMonth();
        _this.setFields();
        _this.loadItems();
        _this.dataLoaded = true;
        loader.hide();
      })["catch"](function (error) {
        _this.$toast.error('Ошибка');
        console.error(error);
      });
    },
    // get salaries total for all group
    getTotals: function getTotals() {
      var loader = this.$loading.show();
      var currentMonth = this.$moment("".concat(this.dateInfo.currentYear, "-").concat(this.dateInfo.currentMonth), 'YYYY-MMMM');
      this.axios.post('/timetracking/salaries/get-total', {
        month: currentMonth.format('M'),
        year: this.dateInfo.currentYear
      }).then(function () {
        loader.hide();
      })["catch"](function (e) {
        console.error(e);
        loader.hide();
      });
    },
    toggleTab: function toggleTab(type) {
      if (type == 'avans') {
        this.bonus.visible = false;
        this.avans.visible = !this.avans.visible;
      } else {
        this.avans.visible = false;
        this.bonus.visible = !this.bonus.visible;
      }
    },
    //Добавление загруженных данных в таблицу
    loadItems: function loadItems() {
      var _this2 = this;
      var hasMoney = 0;
      var items = [];
      var daySalariesSum = [];
      items.push({
        name: 'Общая сумма'
      });
      var total_final = 0; // К выдаче сумма
      var total_kpi = 0; // Кpi total
      var total_bonus = 0; // Bonus total
      var total_fines = 0; // fines total
      var total_avanses = 0; // Avans total
      var total_taxes = 0; // Taxes total
      var total_total = 0; // Начислено total

      this.data.users.forEach(function (item) {
        var daySalaries = [];
        var daySalariesOnly = [];
        var personalTotal = 0;
        var personalFinal = 0;
        var personalAvanses = 0;
        var personalFines = 0;
        var personalBonuses = 0;
        var personalTaxes = 0;
        item.dayType = [];
        item.salaries.forEach(function (tt) {
          var salary = 0;
          var total = 0;
          if (item.earnings[tt.day] !== null) {
            salary = Number(item.earnings[tt.day]);
            total = salary;
          }

          // salary earned to total
          if (Number(salary) != 0) personalTotal += parseInt(salary);
          if (tt.paid !== null) {
            personalAvanses += parseInt(tt.paid, 0);
          }
          if (item.bonuses[tt.day] !== null) {
            personalBonuses += Number(item.bonuses[tt.day]);
            total += Number(item.bonuses[tt.day]);
          }
          if (item.awards[tt.day] !== null) {
            personalBonuses += Number(item.awards[tt.day]);
            total += Number(item.awards[tt.day]);
          }
          if (item.test_bonus[tt.day] !== null) {
            personalBonuses += Number(item.test_bonus[tt.day]);
            total += Number(item.test_bonus[tt.day]);
          }
          if (item.fine[tt.day] !== null) {
            var fine_for_day = 0;
            item.fine[tt.day].forEach(function (el) {
              Object.values(el).forEach(function (fine_sum) {
                return fine_for_day += Number(fine_sum);
              });
            });
            total -= Number(fine_for_day);
          }
          daySalaries[tt.day] = Number(total) != 0 ? Number(total).toFixed(0) : '';
          daySalariesOnly[tt.day] = Number(salary) != 0 ? Number(salary).toFixed(0) : '';
          var isFine = item.fine[tt.day] && item.fine[tt.day].length ? _composables_salaryCellType__WEBPACK_IMPORTED_MODULE_5__["default"].FINE : 0;
          var isTraining = item.trainings[tt.day] ? _composables_salaryCellType__WEBPACK_IMPORTED_MODULE_5__["default"].TRAINING : 0;
          var isBonus = item.bonuses[tt.day] || item.awards[tt.day] || item.test_bonus[tt.day] ? _composables_salaryCellType__WEBPACK_IMPORTED_MODULE_5__["default"].BONUS : 0;
          var isAvans = item.avanses[tt.day] ? _composables_salaryCellType__WEBPACK_IMPORTED_MODULE_5__["default"].AVANS : 0;
          item.dayType[tt.day] = isFine | isTraining | isBonus | isAvans;
        });
        item.taxes.forEach(function (t) {
          personalTaxes = personalTaxes + t.amount;
        });
        var personalKpi = Number(item.kpi);
        if (item.edited_kpi) {
          personalKpi = item.edited_kpi.amount;
        }
        if (item.edited_bonus) {
          personalBonuses = item.edited_bonus.amount;
        }
        personalFines = Number(item.fines_total);
        personalFinal = personalTotal - personalAvanses + personalBonuses - personalFines + personalKpi - personalTaxes;
        if (item.edited_salary) {
          personalFinal = item.edited_salary.amount;
        }
        daySalaries.bonus = Number(personalBonuses).toFixed(0);
        daySalaries.avans = Number(personalAvanses).toFixed(0);
        daySalaries.fines = Number(personalFines).toFixed(0);
        daySalaries.total = Number(personalTotal).toFixed(0);
        daySalaries.taxes = Number(personalTaxes).toFixed(0);
        daySalaries["final"] = Number(personalFinal).toFixed(0);
        total_final += Number(personalFinal) >= 0 ? Number(personalFinal) : 0;
        total_total += Number(personalFinal) >= 0 ? Number(personalTotal) : 0;
        total_kpi += Number(personalFinal) >= 0 ? Number(item.kpi) : 0;
        total_fines += Number(personalFinal) >= 0 ? Number(personalFines) : 0;
        total_bonus += Number(personalFinal) >= 0 ? Number(personalBonuses) : 0;
        total_taxes += Number(personalFinal) >= 0 ? Number(personalTaxes) : 0;
        total_avanses += Number(personalFinal) >= 0 ? Number(personalAvanses) : 0;
        daySalaries.forEach(function (amount, day) {
          if (isNaN(amount) || isNaN(Number(amount))) {
            amount = 0;
          }
          if (typeof daySalariesSum[day] === 'undefined') {
            daySalariesSum[day] = 0;
          }
          daySalariesSum[day] = parseInt(daySalariesSum[day]) + Number(amount);
          if (daySalariesSum[day] > 0) {
            hasMoney = 1;
          }
        });
        var obj = _objectSpread({
          kpi: item.kpi,
          fine: item.fine,
          user_id: item.id,
          hours: item.hours,
          awards: item.awards,
          name: "".concat(item.name, " ").concat(item.last_name),
          avanses: item.avanses,
          bonuses: item.bonuses,
          user_type: item.user_type,
          trainings: item.trainings,
          history: item.track_history,
          edited_kpi: item.edited_kpi,
          test_bonus: item.test_bonus,
          hourly_pays: item.hourly_pays,
          edited_bonus: item.edited_bonus,
          edited_salary: item.edited_salary,
          dayType: item.dayType,
          salaries: daySalariesOnly
        }, daySalaries);
        if (_this2.show_user == 0) {
          items.push(obj);
        } else if (hasMoney > 0) {
          // show if has salary records
          items.push(obj);
          hasMoney = 0;
        }
      });
      var total = 0;
      if (this.user_types != '2') {
        // стажеры
        daySalariesSum.forEach(function (sum) {
          total = total + parseInt(sum);
        });
      }
      total_bonus = Number(total_bonus).toFixed(0);
      items[0] = _objectSpread({
        name: 'Общая сумма',
        "final": total_final,
        kpi: total_kpi,
        bonus: total_bonus,
        avans: total_avanses,
        fines: total_fines,
        taxes: total_taxes,
        total: total_total
      }, daySalariesSum);
      this.total = total_final;
      this.items = items;
    },
    // окно редактирования kpi бонус  к выдаче на месяц
    showEditPremiumWindow: function showEditPremiumWindow(type, data) {
      if (data.index == 0) return false;
      data.type = type;
      this.editedField = data;
      this.editedField.name = data.item.name;
      this.editPremiunWindow = true;
    },
    // сайдбар kpi бонус  к выдаче на месяц
    showEditPremiumSidebar: function showEditPremiumSidebar(type, data) {
      if (data.index == 0) {
        return false;
      }
      data.type = type;
      this.fetchBonusHistory(data.item.user_id);
      this.editedField = data;
      this.editPremiumSidebar = true;
      this.sidebarTitle = data.item.name + ' : ' + type;
    },
    // история бонусов для showEditPremiumSidebar
    fetchBonusHistory: function fetchBonusHistory(user_id) {
      var _this3 = this;
      var currentMonth = this.$moment("".concat(this.dateInfo.currentYear, "-").concat(this.dateInfo.currentMonth), 'YYYY-MMMM');
      this.axios.post('/timetracking/salaries/bonuses', {
        user_id: user_id,
        date: currentMonth.startOf('month').format('YYYY-MM-DD')
      }).then(function (response) {
        _this3.bonus_history = response.data;
      });
    },
    showAvansSidebar: function showAvansSidebar(cellData) {
      var _this4 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var currentMonth, loader, _yield$_this4$axios$p, data;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(cellData.index === 0)) {
                  _context.next = 2;
                  break;
                }
                return _context.abrupt("return", false);
              case 2:
                currentMonth = _this4.$moment("".concat(_this4.dateInfo.currentYear, "-").concat(_this4.dateInfo.currentMonth), 'YYYY-MMMM');
                _this4.avans_history = [];
                loader = _this4.$loading.show();
                _context.next = 7;
                return _this4.axios.post('/timetracking/salaries/advances', {
                  user_id: cellData.item.user_id,
                  date: currentMonth.startOf('month').format('YYYY-MM-DD')
                });
              case 7:
                _yield$_this4$axios$p = _context.sent;
                data = _yield$_this4$axios$p.data;
                _this4.avans_history = data;
                _this4.editedField = cellData;
                _this4.sidebarTitle = cellData.item.name + ' : Авансы';
                _this4.isAvansSidebar = true;
                loader.hide();
              case 14:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    showFineSidebar: function showFineSidebar(cellData) {
      var _this5 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var currentMonth, loader, _yield$_this5$axios$p, data;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(cellData.index === 0)) {
                  _context2.next = 2;
                  break;
                }
                return _context2.abrupt("return", false);
              case 2:
                currentMonth = _this5.$moment("".concat(_this5.dateInfo.currentYear, "-").concat(_this5.dateInfo.currentMonth), 'YYYY-MMMM');
                _this5.fine_history = [];
                loader = _this5.$loading.show();
                _context2.next = 7;
                return _this5.axios.post('/timetracking/salaries/fines', {
                  user_id: cellData.item.user_id,
                  date: currentMonth.startOf('month').format('YYYY-MM-DD')
                });
              case 7:
                _yield$_this5$axios$p = _context2.sent;
                data = _yield$_this5$axios$p.data;
                _this5.fine_history = data;
                _this5.editedField = cellData;
                _this5.sidebarTitle = cellData.item.name + ' : "Депремирования"';
                _this5.isFineSidebar = true;
                loader.hide();
              case 14:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    showTaxesSidebar: function showTaxesSidebar(cellData) {
      var _this6 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var currentMonth, loader, _yield$_this6$axios$p, data;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!(cellData.index === 0)) {
                  _context3.next = 2;
                  break;
                }
                return _context3.abrupt("return", false);
              case 2:
                currentMonth = _this6.$moment("".concat(_this6.dateInfo.currentYear, "-").concat(_this6.dateInfo.currentMonth), 'YYYY-MMMM');
                _this6.texes_history = [];
                loader = _this6.$loading.show();
                _context3.next = 7;
                return _this6.axios.post('/timetracking/salaries/taxes', {
                  user_id: cellData.item.user_id,
                  date: currentMonth.startOf('month').format('YYYY-MM-DD')
                });
              case 7:
                _yield$_this6$axios$p = _context3.sent;
                data = _yield$_this6$axios$p.data;
                _this6.texes_history = data;
                _this6.editedField = cellData;
                _this6.sidebarTitle = cellData.item.name + ' : Налоги';
                _this6.isTaxesSidebar = true;
                loader.hide();
              case 14:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    editPremium: function editPremium() {
      var _this7 = this;
      var currentMonth = this.$moment("".concat(this.dateInfo.currentYear, "-").concat(this.dateInfo.currentMonth), 'YYYY-MMMM');
      if (this.commentEdit < 3) {
        this.errors = ['Комментарии обязательны!'];
        return '';
      }
      this.axios.post('/timetracking/salaries/edit-premium', {
        date: currentMonth.startOf('month').format('YYYY-MM-DD'),
        user_id: this.editedField.item.user_id,
        amount: this.amountEdit,
        comment: this.commentEdit,
        type: this.editedField.type
      }).then(function () {
        if (_this7.editedField.type == 'kpi') {
          _this7.items[_this7.editedField.index].kpi = _this7.amountEdit;
        }
        if (_this7.editedField.type == 'bonus') {
          _this7.items[_this7.editedField.index].bonus = _this7.amountEdit;
        }
        _this7.commentEdit = '';
        _this7.amountEdit = 0;
        _this7.$toast.success('Сохранено');
        _this7.editedField = {
          name: '',
          type: 'kpi'
        };
        _this7.editPremiunWindow = false;
      })["catch"](function (error) {
        _this7.$toast.error('Не сохранилось');
        console.error(error);
      });
    },
    // утверждено к выдаче
    approveSalary: function approveSalary() {
      var _this8 = this;
      this.axios.post('/timetracking/salaries/approve-salary', {
        group_id: this.selectedGroup.id,
        month: this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M'),
        year: this.dateInfo.currentYear
      }).then(function () {
        _this8.$toast.success('Сохранено');
        _this8.showBeforeApprove = false;
        _this8.selectedGroup.salary_approved = 1;
      })["catch"](function (error) {
        _this8.$toast.error('Не получилось');
        console.error(error);
      });
    },
    updateSalary: function updateSalary(type) {
      var _this9 = this;
      if (this.selectedCell.index == 0) return '';
      var comment, amount;
      if (type == 'avans') {
        if (this.avans.comment.length < 3) {
          this.avans.require = 'Комментарии обязательны!';
          return this.$toast.error('Комментарии обязательны!');
        }
        if (this.avans.sum == 0 || this.avans.sum == null) {
          this.avans.require = 'Напишите сумму аванса!';
          return this.$toast.error('Напишите сумму аванса!');
        }
        comment = this.avans.comment;
        amount = this.avans.sum;
      }
      if (type == 'bonus') {
        if (this.bonus.comment.length < 3) {
          this.bonus.require = 'Комментарии обязательны!';
          return this.$toast.error('Комментарии обязательны!');
        }
        if (this.bonus.sum == 0 || this.bonus.sum == null) {
          this.bonus.require = 'Напишите сумму бонуса!';
          return this.$toast.error('Напишите сумму бонуса!');
        }
        comment = this.bonus.comment;
        amount = this.bonus.sum;
      }
      this.axios.post('/timetracking/salaries/update', {
        month: this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M'),
        year: this.dateInfo.currentYear,
        day: this.selectedCell.field.key,
        user_id: this.selectedCell.item.user_id,
        amount: amount,
        comment: comment,
        type: type
      }).then(function (response) {
        if (type == 'avans') {
          _this9.$toast.success('Аванс успешно сохранен');
          _this9.selectedCell.item.avanses[_this9.selectedCell.field.key] = _this9.avans.sum;
          _this9.avans.sum = 0;
          _this9.avans.comment = '';
          _this9.avans.require = '';
          _this9.avans.visible = false;
        }
        if (type == 'bonus') {
          _this9.$toast.success('Бонус успешно сохранен');
          _this9.selectedCell.item.bonuses[_this9.selectedCell.field.key] = _this9.bonus.sum;
          _this9.bonus.sum = 0;
          _this9.bonus.comment = '';
          _this9.bonus.require = '';
          _this9.bonus.visible = false;
        }
        _this9.sidebarHistory.unshift(response.data);
        _this9.items[_this9.selectedCell.index].history.unshift(response.data);
      })["catch"](function (error) {
        _this9.$toast.error('Не сохранилось');
        console.error(error);
      });
    },
    // excel
    exportData: function exportData() {
      var link = '/timetracking/salaries/export';
      link += '?group_id=' + this.selectedGroup.id;
      link += '&month=' + this.dateInfo.month;
      link += '&year=' + this.dateInfo.year;
      link += '&user_types=' + this.user_types;
      window.location.href = link;
    },
    detectClick: function detectClick(data) {
      this.selectedCell = data;
      this.openDay(data);
    },
    toggleVisible: function toggleVisible() {
      this.special_fields = !this.special_fields;
    },
    defineClickNumber: function defineClickNumber(type, data) {
      var _this10 = this;
      //var self = this
      this.clicks++;
      if (this.clicks === 1) {
        this.timer = setTimeout(function () {
          if (type === 'kpi') {
            _this10.fetchKPIStatistics(data.item.user_id);
          } else {
            _this10.showEditPremiumSidebar(type, data);
          }
          _this10.clicks = 0;
        }, 350);
      } else {
        clearTimeout(this.timer);
        if (this.can_edit) {
          this.showEditPremiumWindow(type, data);
        } else {
          if (type === 'kpi') {
            this.fetchKPIStatistics(data.item.user_id);
          } else {
            this.showEditPremiumSidebar(type, data);
          }
        }
        this.clicks = 0;
      }
    },
    openDay: function openDay(data) {
      var _data$item$history;
      this.openSidebar = true;
      this.sidebarContent = data;
      if (this.hasPermission) {
        this.profile_link = '<a href="https://test.jobtron.org/login-as-employee/' + data.item.user_id + '?auth=' + this.auth_token + '" target="_blank">';
        this.profile_link += '<i class="fa fa-link pointer ml-2 mr-2"></i></a>';
      } else {
        this.profile_link = '';
      }
      this.sidebarTitle = "".concat(data.item.name, " - ").concat(data.field.key, " ").concat(this.dateInfo.currentMonth, " ");
      this.sidebarHistory = (_data$item$history = data.item.history) === null || _data$item$history === void 0 ? void 0 : _data$item$history.filter(function (x) {
        return parseInt(x.day) === parseInt(data.field.key);
      });
    },
    // Дичайший костыль, переделать при первой возможности
    getUserGroups: function getUserGroups(userId) {
      return this.groups.reduce(function (result, group) {
        if (!group.users) return result;
        var users = JSON.parse(group.users);
        if (~users.indexOf(userId) && !~result.indexOf(group.id)) result.push(group.id);
        return result;
      }, [this.selectedGroup.id]);
    },
    fetchKPIStatistics: function fetchKPIStatistics(userId) {
      var _this11 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        var loader, _yield$_this11$axios$, userData, groups;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                if (userId) {
                  _context5.next = 2;
                  break;
                }
                return _context5.abrupt("return");
              case 2:
                if (_this11.is_admin) {
                  _context5.next = 4;
                  break;
                }
                return _context5.abrupt("return");
              case 4:
                _this11.kpiSidebarUserId = userId;
                _this11.kpiItems = [];
                loader = _this11.$loading.show();
                _context5.prev = 7;
                _context5.next = 10;
                return _this11.axios.post("/statistics/kpi/groups-and-users/".concat(userId), {
                  filters: {
                    data_from: {
                      year: _this11.dateInfo.currentYear,
                      month: _this11.$moment(_this11.dateInfo.currentMonth, 'MMMM').format('M')
                    }
                  },
                  type: 1
                });
              case 10:
                _yield$_this11$axios$ = _context5.sent;
                userData = _yield$_this11$axios$.data;
                if (!userData.message) {
                  _this11.kpiItems.push((0,_pages_kpi_kpis_js__WEBPACK_IMPORTED_MODULE_3__.parseKPI)(userData.kpi));
                }
                groups = _this11.getUserGroups(userId);
                _context5.next = 16;
                return Promise.all(groups.map( /*#__PURE__*/function () {
                  var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4(groupId) {
                    var _yield$_this11$axios$2, groupData;
                    return _regeneratorRuntime().wrap(function _callee4$(_context4) {
                      while (1) {
                        switch (_context4.prev = _context4.next) {
                          case 0:
                            _context4.next = 2;
                            return _this11.axios.post("/statistics/kpi/groups-and-users/".concat(groupId), {
                              filters: {
                                data_from: {
                                  year: _this11.dateInfo.currentYear,
                                  month: _this11.$moment(_this11.dateInfo.currentMonth, 'MMMM').format('M')
                                }
                              },
                              type: 2
                            });
                          case 2:
                            _yield$_this11$axios$2 = _context4.sent;
                            groupData = _yield$_this11$axios$2.data;
                            if (!groupData.message) {
                              groupData.kpi.users = groupData.kpi.users.filter(function (user) {
                                return user.id === userId;
                              });
                              _this11.kpiItems.push((0,_pages_kpi_kpis_js__WEBPACK_IMPORTED_MODULE_3__.parseKPI)(groupData.kpi));
                            }
                          case 5:
                          case "end":
                            return _context4.stop();
                        }
                      }
                    }, _callee4);
                  }));
                  return function (_x) {
                    return _ref.apply(this, arguments);
                  };
                }()));
              case 16:
                _this11.kpiSidebar = true;
                _context5.next = 23;
                break;
              case 19:
                _context5.prev = 19;
                _context5.t0 = _context5["catch"](7);
                console.error(_context5.t0);
                _this11.$toast.error('Ну удалось получить статистику');
              case 23:
                loader.hide();
              case 24:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, null, [[7, 19]]);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./kpis.js */ "./resources/js/pages/kpi/kpis.js");
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_kpis_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helpers.js */ "./resources/js/pages/kpi/helpers.js");
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_helpers_js__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable vue/no-mutating-props */
/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KpiItemsV2',
  props: {
    my_sum: {
      type: Number,
      "default": 0
    },
    kpi_id: {
      type: Number,
      "default": 0
    },
    expanded: {
      type: Boolean,
      "default": false
    },
    items: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activities: {
      type: Object,
      "default": function _default() {
        return {};
      }
    },
    groups: {
      type: Object,
      "default": function _default() {
        return {};
      }
    },
    completed_80: {
      type: Number,
      "default": 0
    },
    completed_100: {
      type: Number,
      "default": 0
    },
    lower_limit: {
      type: Number,
      "default": 80
    },
    upper_limit: {
      type: Number,
      "default": 100
    },
    editable: {
      type: Boolean,
      "default": false
    },
    kpi_page: {
      type: Boolean,
      "default": false
    },
    allow_overfulfillment: {
      type: Boolean,
      "default": false
    },
    date: {
      type: Object,
      "default": null
    }
  },
  data: function data() {
    return {
      active: 1,
      methods: _helpers_js__WEBPACK_IMPORTED_MODULE_1__.methods,
      sources: _helpers_js__WEBPACK_IMPORTED_MODULE_1__.sources,
      refreshItemsKey: 1,
      source_key: 1,
      show_description: false
    };
  },
  computed: {},
  watch: {
    items: {
      handler: function handler() {
        this.recalc();
        this.getSum();
      },
      deep: true
    },
    lower_limit: {
      handler: function handler() {
        this.recalc();
      }
    },
    upper_limit: {
      handler: function handler() {
        this.recalc();
      }
    },
    completed_80: {
      handler: function handler() {
        this.recalc();
      }
    },
    completed_100: {
      handler: function handler() {
        this.recalc();
      }
    }
  },
  created: function created() {
    this.fillSelectOptions();
    this.defineSourcesAndGroups('with_sources_and_group_id');
    this.recalc();
    this.getSum();
    if (!this.editable) {
      this.items.forEach(function (el) {
        return el.expanded = true;
      });
    }
  },
  mounted: function mounted() {},
  methods: {
    toggle: function toggle() {
      this.show_description = false;
    },
    showDescription: function showDescription() {
      this.show_description = !this.show_description;
    },
    recalc: function recalc() {
      var _this = this;
      this.items.forEach(function (el) {
        // if(
        //     [1,3,5].includes(el.method)
        //     && !this.kpi_page
        //     && el.common != 1
        //     && el.source == 1
        //     && el.activity != null
        //     && el.activity.view != 7
        // ) {
        //     el.plan = el.daily_plan * numberize(el.workdays);
        // }
        el.percent = (0,_kpis_js__WEBPACK_IMPORTED_MODULE_0__.calcCompleted)(el);
        el.sum = (0,_kpis_js__WEBPACK_IMPORTED_MODULE_0__.calcSum)(el, {
          lower_limit: _this.lower_limit,
          upper_limit: _this.upper_limit,
          completed_80: _this.completed_80,
          completed_100: _this.completed_100,
          allow_overfulfillment: _this.allow_overfulfillment
        }, _this.kpi_page ? 1 : el.percent / 100.0);
      });
    },
    deleteItem: function deleteItem(i) {
      this.items[i].deleted = true;
      if (this.kpi_id == 0) this.items.splice(i, 1);
      this.refreshItemsKey++;
    },
    restoreItem: function restoreItem(i) {
      this.items[i].deleted = false;
      this.refreshItemsKey++;
    },
    addItem: function addItem() {
      this.items.push((0,_kpis_js__WEBPACK_IMPORTED_MODULE_0__.newKpiItem)());
    },
    getActivity: function getActivity(id) {
      return this.activities.find(function (el) {
        return el.id == id;
      });
    },
    fillSelectOptions: function fillSelectOptions() {},
    groupBy: function groupBy(xs, key) {
      return xs.reduce(function (rv, x) {
        (rv[x[key]] = rv[x[key]] || []).push(x);
        return rv;
      }, {});
    },
    defineSourcesAndGroups: function defineSourcesAndGroups() {
      var _this2 = this;
      this.items.forEach(function (el) {
        el.source = 0;
        el.group_id = 0;
        if (el.activity_id != 0) {
          var i = _this2.activities.findIndex(function (a) {
            return a.id == el.activity_id;
          });
          if (i != -1) {
            el.source = _this2.activities[i].source;
            if (el.source == 1) el.group_id = _this2.activities[i].group_id;
          }
        }
      });
    },
    grouped_activities: function grouped_activities(source, group_id) {
      if (source == 1) {
        return this.activities.filter(function (el) {
          return el.source == source && el.group_id == group_id;
        });
      } else {
        group_id = 0;
        return this.activities.filter(function (el) {
          return el.source == source;
        });
      }
    },
    isCell: function isCell(activity_id) {
      var i = this.activities.findIndex(function (el) {
        return el.id == activity_id;
      });
      return i != -1 && this.activities[i].view == 7;
    },
    updateStat: function updateStat(i) {
      var _this3 = this;
      var loader = this.$loading.show();
      var item = this.items[i];
      var date = this.date != null ? this.date : this.$moment(Date.now()).format('YYYY-MM-DD');
      var value = [1, 3, 5].includes(item.method) ? item.fact : item.avg;
      this.axios.post('/statistics/update-stat', {
        user_id: this.kpi_id,
        kpi_item_id: item.id,
        activity_id: item.activity_id,
        value: value,
        date: date
      }).then(function () {
        _this3.$toast.success('Изменено');
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    getSum: function getSum() {
      var sum = 0;
      this.items.forEach(function (item) {
        sum += item.sum;
      });
      this.$emit('getSum', sum);
    }
  }
});

/***/ }),

/***/ "./resources/js/composables/salaryCellType.js":
/*!****************************************************!*\
  !*** ./resources/js/composables/salaryCellType.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  FINE: 1,
  TRAINING: 2,
  BONUS: 4,
  AVANS: 8
});

/***/ }),

/***/ "./resources/js/pages/kpi/helpers.js":
/*!*******************************************!*\
  !*** ./resources/js/pages/kpi/helpers.js ***!
  \*******************************************/
/***/ ((module) => {

function findModel() {
  var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
  var text = '';
  if (type == 1) text = "App\\User";
  if (type == 2) text = 'App\\ProfileGroup';
  if (type == 3) text = 'App\\Position';
  return text;
}
function groupBy(xs, key) {
  return xs.reduce(function (rv, x) {
    (rv[x[key]] = rv[x[key]] || []).push(x);
    return rv;
  }, {});
}

// sources of activities
var sources = {
  0: 'без источника',
  1: 'вкладка "Аналитика"'
};

// sources of activities OLD "Адиль сказал пока убрать все, кроме Аналитики"
// let sources = {
// 	0: 'без источника',
// 	1: 'вкладка "Аналитика"',
// 	2: 'из битрикса',
// 	3: 'из амосрм',
// 	4: 'другие',
// 	5: 'вкладка "Табель"',
// 	6: 'вкладка "HR"',
// }

// kpi methods
var methods = {
  1: 'сумма',
  2: 'сред значение',
  3: 'сумма не более',
  4: 'среднее не более',
  5: 'сумма не менее',
  6: 'среднее не менее'
};

// views of activities
var views = {
  0: 'по умолчанию',
  1: 'коллекция',
  2: 'контроль качества',
  3: 'рентабельность',
  4: 'текучка',
  5: 'кол-во сотрудников',
  6: 'конверсия'
};

// eslint-disable-next-line no-undef
module.exports = {
  findModel: findModel,
  groupBy: groupBy,
  sources: sources,
  methods: methods,
  views: views
};

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=style&index=0&lang=scss&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=style&index=0&lang=scss& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".fz-09 {\n  font-size: 0.9rem;\n}\n.TableAccrual-kpi {\n  font-size: 10px;\n}\n.table-accrual .b-table-sticky-header {\n  height: 100% !important;\n}\n.ddf div {\n  display: flex;\n}\n.ddf .custom-control {\n  margin-right: 15px;\n}\n.ddf-br {\n  padding-left: 20px;\n  border-left: 1px solid #ddd;\n}\n.form-control.normal:disabled, .form-control.normal {\n  padding: 0 2px;\n  font-size: 11px;\n  opacity: 1;\n  background: transparent;\n  text-align: center;\n  height: 100%;\n  font-weight: 500;\n  border: none;\n  border-radius: 0;\n  width: 100%;\n  font-family: \"Open Sans\";\n}\ninput[type=number]::-webkit-outer-spin-button,\ninput[type=number]::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n.fz12 {\n  line-height: 1.4em;\n  font-size: 12px;\n  margin-bottom: 0;\n}\n.fz14 {\n  font-size: 14px;\n  line-height: 1.4em;\n  padding: 10px 0;\n}\n.ssssssssss .ui-sidebar__body * {\n  color: #333;\n}\nhr {\n  margin: 2px !important;\n}\n.color-red {\n  color: red;\n}\n.bg-bluish {\n  background: #a1bdd6;\n}\n.btn.activex {\n  background: red;\n}\n.progresso {\n  height: 20px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  padding-left: 10px;\n  color: white !important;\n  line-height: 20px;\n  background: #007bff;\n  transition: width linear 0.5s;\n}\n.my-table.salar .cell-border {\n  position: absolute;\n  right: -47px;\n  bottom: -23px;\n  z-index: 2;\n}\n.accrual-table .b-table {\n  table-layout: fixed;\n}\n.accrual-table .cell-border {\n  border-left-color: red !important;\n}\n.accrual-table th,\n.accrual-table td {\n  width: 72px;\n  padding: 0 !important;\n}\n.accrual-table th > div,\n.accrual-table td > div {\n  padding: 0 15px;\n  height: 40px;\n  min-width: 50px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.accrual-table th:first-child > div,\n.accrual-table td:first-child > div {\n  justify-content: space-between;\n}\n.accrual-table th:nth-child(1),\n.accrual-table td:nth-child(1) {\n  width: 290px;\n  left: 0 !important;\n}\n.accrual-table th:nth-child(1) div,\n.accrual-table td:nth-child(1) div {\n  width: 288px;\n  white-space: normal;\n}\n.accrual-table th:nth-child(2),\n.accrual-table td:nth-child(2) {\n  left: 290px !important;\n}\n.accrual-table th:nth-child(3),\n.accrual-table td:nth-child(3) {\n  left: 362px !important;\n}\n.accrual-table th:nth-child(4),\n.accrual-table td:nth-child(4) {\n  left: 434px !important;\n}\n.accrual-table th:nth-child(5),\n.accrual-table td:nth-child(5) {\n  left: 506px !important;\n}\n.accrual-table th:nth-child(6),\n.accrual-table td:nth-child(6) {\n  left: 578px !important;\n}\n.accrual-table th:nth-child(7),\n.accrual-table td:nth-child(7) {\n  left: 650px !important;\n}\n.accrual-table th:nth-child(8),\n.accrual-table td:nth-child(8) {\n  width: 98px;\n  left: 722px !important;\n}\n.accrual-table th:nth-child(2) div, .accrual-table th:nth-child(3) div, .accrual-table th:nth-child(4) div, .accrual-table th:nth-child(5) div, .accrual-table th:nth-child(6) div, .accrual-table th:nth-child(7) div,\n.accrual-table td:nth-child(2) div,\n.accrual-table td:nth-child(3) div,\n.accrual-table td:nth-child(4) div,\n.accrual-table td:nth-child(5) div,\n.accrual-table td:nth-child(6) div,\n.accrual-table td:nth-child(7) div {\n  width: 70px;\n}\n.accrual-table.hide-special th:nth-child(2), .accrual-table.hide-special th:nth-child(3), .accrual-table.hide-special th:nth-child(4), .accrual-table.hide-special th:nth-child(5), .accrual-table.hide-special th:nth-child(6), .accrual-table.hide-special th:nth-child(7),\n.accrual-table.hide-special td:nth-child(2),\n.accrual-table.hide-special td:nth-child(3),\n.accrual-table.hide-special td:nth-child(4),\n.accrual-table.hide-special td:nth-child(5),\n.accrual-table.hide-special td:nth-child(6),\n.accrual-table.hide-special td:nth-child(7) {\n  display: none;\n}\n.accrual-table.hide-special th:nth-child(8),\n.accrual-table.hide-special td:nth-child(8) {\n  left: 290px !important;\n}\n.accrual-table td:nth-child(2), .accrual-table td:nth-child(3), .accrual-table td:nth-child(4), .accrual-table td:nth-child(5), .accrual-table td:nth-child(6), .accrual-table td:nth-child(7) {\n  background: #DDE9FF !important;\n  border-color: #b4bed2 !important;\n}\n.accrual-table td:nth-child(2) div, .accrual-table td:nth-child(3) div, .accrual-table td:nth-child(4) div, .accrual-table td:nth-child(5) div, .accrual-table td:nth-child(6) div, .accrual-table td:nth-child(7) div {\n  font-size: 13px;\n  text-align: center;\n}\n.accrual-table td:nth-child(8) {\n  background: #8bab00 !important;\n  border-color: #627800 !important;\n  color: #fff;\n}\n.group-select .vs__dropdown-toggle {\n  padding: 5px 3px 6px;\n  margin: 0;\n  border: 1px solid #d3d7db;\n}\n.group-select .ddf div {\n  display: flex;\n}\n.group-select .ddf .custom-control {\n  margin-right: 15px;\n}\n.group-select .form-control.normal:disabled, .group-select .form-control.normal {\n  padding: 0 2px;\n  font-size: 11px;\n  opacity: 1;\n  background: transparent;\n  text-align: center;\n  height: 100%;\n  font-weight: 500;\n  border: none;\n  border-radius: 0;\n  width: 100%;\n  font-family: \"Open Sans\";\n}\n.group-select input[type=number]::-webkit-outer-spin-button,\n.group-select input[type=number]::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n.group-select .fz12 {\n  line-height: 1.4em;\n  font-size: 12px;\n  margin-bottom: 0;\n}\n.group-select .fz14 {\n  font-size: 14px;\n  line-height: 1.4em;\n  padding: 10px 0;\n}\n.group-select .ssssssssss .ui-sidebar__body * {\n  color: #333;\n}\n.group-select hr {\n  margin: 2px !important;\n}\n.group-select .color-red {\n  color: red;\n}\n.group-select .bg-bluish {\n  background: #a1bdd6;\n}\n.group-select .btn.activex {\n  background: red;\n}\n.group-select .progresso {\n  height: 20px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  padding-left: 10px;\n  color: white !important;\n  line-height: 20px;\n  background: #007bff;\n  transition: width linear 0.5s;\n}\n.group-select .my-table.salar .cell-border {\n  position: absolute;\n  right: -47px;\n  bottom: -23px;\n  z-index: 2;\n}\n.group-select .accrual-table th, .group-select .accrual-table td {\n  padding: 0 !important;\n}\n.group-select .accrual-table th > div, .group-select .accrual-table td > div {\n  padding: 0 15px;\n  height: 40px;\n  min-width: 50px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.group-select .accrual-table th:first-child > div, .group-select .accrual-table td:first-child > div {\n  justify-content: space-between;\n}\n.group-select .accrual-table .cell-border {\n  border-left-color: red !important;\n}\n.group-select .accrual-table th:nth-child(1),\n.group-select .accrual-table td:nth-child(1) {\n  left: 0 !important;\n}\n.group-select .accrual-table th:nth-child(1) div,\n.group-select .accrual-table td:nth-child(1) div {\n  width: 288px;\n  white-space: normal;\n}\n.group-select .accrual-table th:nth-child(2),\n.group-select .accrual-table td:nth-child(2) {\n  left: 289px !important;\n}\n.group-select .accrual-table th:nth-child(3),\n.group-select .accrual-table td:nth-child(3) {\n  left: 360px !important;\n}\n.group-select .accrual-table th:nth-child(4),\n.group-select .accrual-table td:nth-child(4) {\n  left: 431px !important;\n}\n.group-select .accrual-table th:nth-child(5),\n.group-select .accrual-table td:nth-child(5) {\n  left: 502px !important;\n}\n.group-select .accrual-table th:nth-child(6),\n.group-select .accrual-table td:nth-child(6) {\n  left: 573px !important;\n}\n.group-select .accrual-table th:nth-child(7),\n.group-select .accrual-table td:nth-child(7) {\n  left: 644px !important;\n}\n.group-select .accrual-table th:nth-child(2) div, .group-select .accrual-table th:nth-child(3) div, .group-select .accrual-table th:nth-child(4) div, .group-select .accrual-table th:nth-child(5) div, .group-select .accrual-table th:nth-child(6) div,\n.group-select .accrual-table td:nth-child(2) div,\n.group-select .accrual-table td:nth-child(3) div,\n.group-select .accrual-table td:nth-child(4) div,\n.group-select .accrual-table td:nth-child(5) div,\n.group-select .accrual-table td:nth-child(6) div {\n  width: 70px;\n}\n.group-select .accrual-table td:nth-child(2), .group-select .accrual-table td:nth-child(3), .group-select .accrual-table td:nth-child(4), .group-select .accrual-table td:nth-child(5), .group-select .accrual-table td:nth-child(6) {\n  background: #DDE9FF !important;\n  outline-color: #c1cee5 !important;\n}\n.group-select .accrual-table td:nth-child(2) div, .group-select .accrual-table td:nth-child(3) div, .group-select .accrual-table td:nth-child(4) div, .group-select .accrual-table td:nth-child(5) div, .group-select .accrual-table td:nth-child(6) div {\n  font-size: 13px;\n  text-align: center;\n}\n.group-select .accrual-table td:nth-child(7) {\n  background: #8bab00 !important;\n  outline-color: #627800 !important;\n  color: #fff;\n}\n.group-select .group-select .vs__dropdown-toggle {\n  padding: 5px 3px 6px;\n  margin: 0;\n  border: 1px solid #d3d7db;\n}\n.group-select .selector {\n  position: relative;\n}\n.group-select .selector p {\n  font-size: 13px;\n}\n.group-select .selector img {\n  position: absolute;\n  right: 0;\n  top: 3px;\n  z-index: 5;\n  height: 16px;\n}\n.group-select .approved-text {\n  text-align: right;\n}\n.group-select .approved-text span {\n  font-size: 11px;\n}\n.fz-08 {\n  font-size: 0.8rem;\n}\n.AvansHistoryItem {\n  padding: 4px 0;\n  line-height: 1.3;\n}\n.AvansHistoryItem-text {\n  font-size: 0.95em;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableAccrual_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableAccrual.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableAccrual_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableAccrual_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/pages/Profile/Popups/KpiContent.vue":
/*!**********************************************************!*\
  !*** ./resources/js/pages/Profile/Popups/KpiContent.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _KpiContent_vue_vue_type_template_id_3ab1c344___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./KpiContent.vue?vue&type=template&id=3ab1c344& */ "./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=template&id=3ab1c344&");
/* harmony import */ var _KpiContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./KpiContent.vue?vue&type=script&lang=js& */ "./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _KpiContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _KpiContent_vue_vue_type_template_id_3ab1c344___WEBPACK_IMPORTED_MODULE_0__.render,
  _KpiContent_vue_vue_type_template_id_3ab1c344___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Profile/Popups/KpiContent.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/TableAccrual.vue":
/*!*********************************************!*\
  !*** ./resources/js/pages/TableAccrual.vue ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TableAccrual_vue_vue_type_template_id_1b3a80ec___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TableAccrual.vue?vue&type=template&id=1b3a80ec& */ "./resources/js/pages/TableAccrual.vue?vue&type=template&id=1b3a80ec&");
/* harmony import */ var _TableAccrual_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TableAccrual.vue?vue&type=script&lang=js& */ "./resources/js/pages/TableAccrual.vue?vue&type=script&lang=js&");
/* harmony import */ var _TableAccrual_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TableAccrual.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/TableAccrual.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TableAccrual_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TableAccrual_vue_vue_type_template_id_1b3a80ec___WEBPACK_IMPORTED_MODULE_0__.render,
  _TableAccrual_vue_vue_type_template_id_1b3a80ec___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/TableAccrual.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/KpiItemsV2.vue":
/*!***********************************************!*\
  !*** ./resources/js/pages/kpi/KpiItemsV2.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./KpiItemsV2.vue?vue&type=template&id=2775d5ac& */ "./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac&");
/* harmony import */ var _KpiItemsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./KpiItemsV2.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _KpiItemsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__.render,
  _KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/KpiItemsV2.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiContent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/TableAccrual.vue?vue&type=script&lang=js&":
/*!**********************************************************************!*\
  !*** ./resources/js/pages/TableAccrual.vue?vue&type=script&lang=js& ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableAccrual_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableAccrual.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableAccrual_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItemsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiItemsV2.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItemsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/TableAccrual.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************!*\
  !*** ./resources/js/pages/TableAccrual.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableAccrual_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableAccrual.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=template&id=3ab1c344&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=template&id=3ab1c344& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiContent_vue_vue_type_template_id_3ab1c344___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiContent_vue_vue_type_template_id_3ab1c344___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiContent_vue_vue_type_template_id_3ab1c344___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiContent.vue?vue&type=template&id=3ab1c344& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=template&id=3ab1c344&");


/***/ }),

/***/ "./resources/js/pages/TableAccrual.vue?vue&type=template&id=1b3a80ec&":
/*!****************************************************************************!*\
  !*** ./resources/js/pages/TableAccrual.vue?vue&type=template&id=1b3a80ec& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableAccrual_vue_vue_type_template_id_1b3a80ec___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableAccrual_vue_vue_type_template_id_1b3a80ec___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableAccrual_vue_vue_type_template_id_1b3a80ec___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableAccrual.vue?vue&type=template&id=1b3a80ec& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=template&id=1b3a80ec&");


/***/ }),

/***/ "./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac&":
/*!******************************************************************************!*\
  !*** ./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiItemsV2.vue?vue&type=template&id=2775d5ac& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=template&id=3ab1c344&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Profile/Popups/KpiContent.vue?vue&type=template&id=3ab1c344& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "kpi__content" },
    [
      _c("ProfileTabs", {
        attrs: {
          tabs: _vm.items
            .slice()
            .reverse()
            .map(function (kpi) {
              return (kpi.target && kpi.target.name) || "---"
            }),
        },
        scopedSlots: _vm._u(
          [
            _vm._l(_vm.items.slice().reverse(), function (wrap_item, w) {
              return {
                key: "tab(" + w + ")",
                fn: function () {
                  return [
                    _c(
                      "div",
                      {
                        key: w,
                        staticClass: "tab__content-item",
                        class: { "is-active": w == 0 },
                        attrs: { "data-content": w },
                      },
                      [
                        _c("div", { staticClass: "kpi__kaspi" }, [
                          _c("div", { staticClass: "kpi__kaspi-wrapper" }, [
                            _c("div", { staticClass: "kpi__kaspi-left" }, [
                              _c("table", [
                                _c("tr", [
                                  _c("td", { staticClass: "blue" }, [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\t\t\tВыполнение KPI от 80-99%\n\t\t\t\t\t\t\t\t\t"
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(
                                      _vm._s(
                                        wrap_item.users.length > 0 &&
                                          wrap_item.users[0].full_time == 1
                                          ? wrap_item.completed_80
                                          : wrap_item.completed_80 / 2
                                      )
                                    ),
                                  ]),
                                ]),
                                _vm._v(" "),
                                _c("tr", [
                                  _c("td", { staticClass: "blue" }, [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\t\t\tВыполнение KPI на 100%\n\t\t\t\t\t\t\t\t\t"
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(
                                      _vm._s(
                                        wrap_item.users.length > 0 &&
                                          wrap_item.users[0].full_time == 1
                                          ? wrap_item.completed_100
                                          : wrap_item.completed_100 / 2
                                      )
                                    ),
                                  ]),
                                ]),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("div", { staticClass: "kpi__kaspi-right" }, [
                              _c("table", [
                                _c("thead", [
                                  _c("tr", [
                                    _c("th", [
                                      _vm._v(
                                        "Нижний порог отсечения премии, %"
                                      ),
                                    ]),
                                    _vm._v(" "),
                                    _c("th", [
                                      _vm._v(
                                        "Верхний порог отсечения премии, %"
                                      ),
                                    ]),
                                  ]),
                                ]),
                                _vm._v(" "),
                                _c("tr", [
                                  _c("td", [
                                    _vm._v(_vm._s(wrap_item.lower_limit)),
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(_vm._s(wrap_item.upper_limit)),
                                  ]),
                                ]),
                              ]),
                            ]),
                          ]),
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "kpi__activities" }, [
                          _c(
                            "div",
                            { staticClass: "kpi__title popup__content-title" },
                            [_vm._v("\n\t\t\t\t\t\tАктивности KPI\n\t\t\t\t\t")]
                          ),
                          _vm._v(" "),
                          _c(
                            "table",
                            { staticClass: "kpi__activities-table" },
                            [
                              wrap_item.users != undefined &&
                              wrap_item.users.length > 0
                                ? [
                                    _c(
                                      "tr",
                                      {
                                        key: w + "a",
                                        staticClass: "collapsable",
                                        class: {
                                          active:
                                            wrap_item.expanded || !_vm.editable,
                                        },
                                      },
                                      [
                                        _c(
                                          "td",
                                          {
                                            staticClass:
                                              "kpi__activities-outer",
                                            attrs: {
                                              colspan: _vm.editable ? 3 : 7,
                                            },
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "table__wrapper" },
                                              [
                                                _c(
                                                  "table",
                                                  {
                                                    staticClass: "child-table",
                                                  },
                                                  [
                                                    _vm._l(
                                                      wrap_item.users,
                                                      function (user, i) {
                                                        return [
                                                          _vm.editable
                                                            ? _c(
                                                                "tr",
                                                                {
                                                                  key: i,
                                                                  staticClass:
                                                                    "child-row",
                                                                },
                                                                [
                                                                  _c(
                                                                    "td",
                                                                    {
                                                                      staticClass:
                                                                        "pointer px-2",
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            user.expanded =
                                                                              !user.expanded
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "span",
                                                                        {
                                                                          staticClass:
                                                                            "ml-2 bg-transparent",
                                                                        },
                                                                        [
                                                                          _vm._v(
                                                                            _vm._s(
                                                                              i +
                                                                                1
                                                                            )
                                                                          ),
                                                                        ]
                                                                      ),
                                                                    ]
                                                                  ),
                                                                  _vm._v(" "),
                                                                  _c(
                                                                    "td",
                                                                    {
                                                                      staticClass:
                                                                        "px-2 py-1",
                                                                    },
                                                                    [
                                                                      _vm._v(
                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                          _vm._s(
                                                                            user.name
                                                                          ) +
                                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                      ),
                                                                    ]
                                                                  ),
                                                                  _vm._v(" "),
                                                                  user.items !==
                                                                  undefined
                                                                    ? _vm._l(
                                                                        user.items,
                                                                        function (
                                                                          kpi_item
                                                                        ) {
                                                                          return _c(
                                                                            "td",
                                                                            {
                                                                              key: kpi_item,
                                                                              staticClass:
                                                                                "px-2",
                                                                            },
                                                                            [
                                                                              _vm._v(
                                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                  _vm._s(
                                                                                    kpi_item.name
                                                                                  ) +
                                                                                  " "
                                                                              ),
                                                                              _c(
                                                                                "b",
                                                                                [
                                                                                  _vm._v(
                                                                                    _vm._s(
                                                                                      kpi_item.percent
                                                                                    ) +
                                                                                      "%"
                                                                                  ),
                                                                                ]
                                                                              ),
                                                                            ]
                                                                          )
                                                                        }
                                                                      )
                                                                    : _vm._e(),
                                                                ],
                                                                2
                                                              )
                                                            : _vm._e(),
                                                          _vm._v(" "),
                                                          user.items !==
                                                          undefined
                                                            ? [
                                                                _c(
                                                                  "tr",
                                                                  {
                                                                    key:
                                                                      i + "a",
                                                                    staticClass:
                                                                      "collapsable",
                                                                    class: {
                                                                      active: true,
                                                                    },
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "td",
                                                                      {
                                                                        staticClass:
                                                                          "kpi__activities-outer",
                                                                        attrs: {
                                                                          colspan:
                                                                            _vm
                                                                              .fields
                                                                              .length +
                                                                            2,
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "div",
                                                                          {
                                                                            staticClass:
                                                                              "table__wrapper__second",
                                                                          },
                                                                          [
                                                                            _c(
                                                                              "KpiItemsV2",
                                                                              {
                                                                                attrs:
                                                                                  {
                                                                                    my_sum:
                                                                                      user.full_time ==
                                                                                      1
                                                                                        ? wrap_item.completed_100
                                                                                        : wrap_item.completed_100 /
                                                                                          2,
                                                                                    kpi_id:
                                                                                      user.id,
                                                                                    items:
                                                                                      user.items,
                                                                                    expanded: true,
                                                                                    activities:
                                                                                      _vm.activities,
                                                                                    groups:
                                                                                      _vm.groups,
                                                                                    completed_80:
                                                                                      wrap_item.completed_80,
                                                                                    completed_100:
                                                                                      wrap_item.completed_100,
                                                                                    lower_limit:
                                                                                      wrap_item.lower_limit,
                                                                                    upper_limit:
                                                                                      wrap_item.upper_limit,
                                                                                    editable: false,
                                                                                    kpi_page: false,
                                                                                    date: "date",
                                                                                  },
                                                                                on: {
                                                                                  getSum:
                                                                                    function (
                                                                                      $event
                                                                                    ) {
                                                                                      wrap_item.my_sum =
                                                                                        $event
                                                                                    },
                                                                                  recalced:
                                                                                    _vm.countAvg,
                                                                                },
                                                                              }
                                                                            ),
                                                                          ],
                                                                          1
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            : _vm._e(),
                                                        ]
                                                      }
                                                    ),
                                                  ],
                                                  2
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                : _vm._e(),
                            ],
                            2
                          ),
                          _vm._v(" "),
                          _c("div", { staticClass: "kpi__activities-tip" }, [
                            _vm._v(
                              "\n\t\t\t\t\t\t* сумма премии за выполнение показателей начнет меняться после достижения 80% от целевого значения на месяц\n\t\t\t\t\t"
                            ),
                          ]),
                        ]),
                      ]
                    ),
                  ]
                },
                proxy: true,
              }
            }),
          ],
          null,
          true
        ),
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=template&id=1b3a80ec&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableAccrual.vue?vue&type=template&id=1b3a80ec& ***!
  \*******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.groupss
    ? _c(
        "div",
        [
          _c("div", { staticClass: "mb-0" }, [
            _c("div", { staticClass: "row mb-4" }, [
              _c(
                "div",
                { staticClass: "col-3" },
                [
                  _c("v-select", {
                    staticClass: "group-select",
                    attrs: { options: _vm.groups, label: "name" },
                    scopedSlots: _vm._u(
                      [
                        {
                          key: "option",
                          fn: function (ref) {
                            var name = ref.name
                            var salary_approved = ref.salary_approved
                            var id = ref.id
                            return [
                              _c("div", { staticClass: "selector" }, [
                                _c("p", { staticStyle: { margin: "0" } }, [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t\t" + _vm._s(name) + " : "
                                  ),
                                  _vm.showAccruals
                                    ? _c("span", [
                                        _vm._v(_vm._s(_vm.accruals[id])),
                                      ])
                                    : _vm._e(),
                                ]),
                                _vm._v(" "),
                                salary_approved
                                  ? _c("img", {
                                      attrs: {
                                        src: "/images/double-check.png",
                                        alt: "",
                                      },
                                    })
                                  : _vm._e(),
                              ]),
                            ]
                          },
                        },
                      ],
                      null,
                      false,
                      3636241817
                    ),
                    model: {
                      value: _vm.selectedGroup,
                      callback: function ($$v) {
                        _vm.selectedGroup = $$v
                      },
                      expression: "selectedGroup",
                    },
                  }),
                ],
                1
              ),
              _vm._v(" "),
              _c("div", { staticClass: "col-2" }, [
                _c(
                  "select",
                  {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.dateInfo.currentMonth,
                        expression: "dateInfo.currentMonth",
                      },
                    ],
                    staticClass: "form-control",
                    on: {
                      change: [
                        function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.$set(
                            _vm.dateInfo,
                            "currentMonth",
                            $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          )
                        },
                        function ($event) {
                          return _vm.fetchData()
                        },
                      ],
                    },
                  },
                  _vm._l(_vm.$moment.months(), function (month) {
                    return _c(
                      "option",
                      { key: month, domProps: { value: month } },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(month) + "\n\t\t\t\t\t"
                        ),
                      ]
                    )
                  }),
                  0
                ),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-2" }, [
                _c(
                  "select",
                  {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.dateInfo.currentYear,
                        expression: "dateInfo.currentYear",
                      },
                    ],
                    staticClass: "form-control",
                    on: {
                      change: [
                        function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.$set(
                            _vm.dateInfo,
                            "currentYear",
                            $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          )
                        },
                        function ($event) {
                          return _vm.fetchData()
                        },
                      ],
                    },
                  },
                  _vm._l(_vm.years, function (year) {
                    return _c(
                      "option",
                      { key: year, domProps: { value: year } },
                      [_vm._v("\n\t\t\t\t\t\t" + _vm._s(year) + "\n\t\t\t\t\t")]
                    )
                  }),
                  0
                ),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-2  align-items-start" }, [
                _c(
                  "a",
                  {
                    staticClass: "btn btn-primary mr-1 rounded text-white",
                    on: {
                      click: function ($event) {
                        return _vm.fetchData()
                      },
                    },
                  },
                  [_c("i", { staticClass: "fa fa-redo-alt" })]
                ),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-2" }),
            ]),
            _vm._v(" "),
            _c("hr"),
            _vm._v(" "),
            _vm.hasPermission
              ? _c("div", { staticClass: "row my-2" }, [
                  _c("div", { staticClass: "col-6" }, [
                    _c("div", [
                      _c("p", { staticClass: "mb-0 fz-08 text-black" }, [
                        _c("b", [
                          _vm._v("Итого действующие ФОТ\n\t\t\t\t\t\t\t"),
                          _c("i", {
                            directives: [
                              {
                                name: "b-popover",
                                rawName: "v-b-popover.hover.right.html",
                                value:
                                  "<b>ФОТ</b>- Фонд оплаты труда<br>Сумма без вычета расходов (Штрафы и авансы)<br>ФОТ = Начисления (Отработанные + Стажировочные) + Бонусы + KPI",
                                expression:
                                  "'<b>ФОТ</b>- Фонд оплаты труда<br>Сумма без вычета расходов (Штрафы и авансы)<br>ФОТ = Начисления (Отработанные + Стажировочные) + Бонусы + KPI'",
                                modifiers: {
                                  hover: true,
                                  right: true,
                                  html: true,
                                },
                              },
                            ],
                            staticClass: "fa fa-info-circle",
                            attrs: { title: "ФОТ" },
                          }),
                          _vm._v("\n\t\t\t\t\t\t\t:"),
                        ]),
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(_vm.actualFOT) +
                            " тг.\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("p", { staticClass: "mb-0 fz-08 text-black" }, [
                        _c("b", [_vm._v("Итого уволенные ФОТ:")]),
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(_vm.group_fired) +
                            " тг.\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _vm.showTotals
                        ? _c(
                            "p",
                            { staticClass: "fz-08 text-black mr-1 mb-0" },
                            [
                              _c("b", [_vm._v("Итого все ФОТ (Действующие):")]),
                              _vm._v(
                                "\n\t\t\t\t\t\t" +
                                  _vm._s(_vm.allTotal) +
                                  "тг.\n\t\t\t\t\t"
                              ),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.showTotals
                        ? _c(
                            "p",
                            { staticClass: "fz-08 text-black mr-1 mb-0" },
                            [
                              _c("b", [_vm._v("Итого все ФОТ (Уволенные):")]),
                              _vm._v(
                                "\n\t\t\t\t\t\t" +
                                  _vm._s(_vm.allTotalFired) +
                                  "тг.\n\t\t\t\t\t"
                              ),
                            ]
                          )
                        : _vm._e(),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "col-6 text-right" },
                    [
                      _vm.can_edit
                        ? _c(
                            "a",
                            {
                              staticClass:
                                "btn btn-success rounded text-white mr-1",
                              on: {
                                click: function ($event) {
                                  return _vm.exportData()
                                },
                              },
                            },
                            [_c("i", { staticClass: "far fa-file-excel" })]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "a",
                        {
                          staticClass: "btn btn-info rounded text-white mr-1",
                          on: {
                            click: function ($event) {
                              return _vm.toggleVisible()
                            },
                          },
                        },
                        [_c("i", { staticClass: "fa fa-eye" })]
                      ),
                      _vm._v(" "),
                      _vm.selectedGroup.salary_approved == 0 && _vm.can_edit
                        ? _c(
                            "b-button",
                            {
                              staticClass: "rounded mb-3 ml-3",
                              staticStyle: { float: "right" },
                              attrs: { variant: "info" },
                              on: {
                                click: function ($event) {
                                  _vm.showBeforeApprove = true
                                },
                              },
                            },
                            [
                              _vm._v(
                                "\n\t\t\t\t\tПроверено и готово к выдаче\n\t\t\t\t"
                              ),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.selectedGroup.salary_approved == 1
                        ? _c("div", { staticClass: "approved-text" }, [
                            _vm._m(0),
                            _vm._v(" "),
                            _c("p", [
                              _vm._v(
                                _vm._s(_vm.selectedGroup.salary_approved_by)
                              ),
                            ]),
                            _vm._v(" "),
                            _c("small", [
                              _vm._v(
                                _vm._s(_vm.selectedGroup.salary_approved_date)
                              ),
                            ]),
                          ])
                        : _vm._e(),
                    ],
                    1
                  ),
                ])
              : _vm._e(),
            _vm._v(" "),
            _c("hr"),
            _vm._v(" "),
            _c("div", { staticClass: "row mt-4" }, [
              _c("div", { staticClass: "col-12 col-md-9" }, [
                _c(
                  "div",
                  { staticClass: "d-flex" },
                  [
                    _c(
                      "b-form-group",
                      { staticClass: "mr-3" },
                      [
                        _c(
                          "b-form-select",
                          {
                            model: {
                              value: _vm.user_types,
                              callback: function ($$v) {
                                _vm.user_types = $$v
                              },
                              expression: "user_types",
                            },
                          },
                          [
                            _c(
                              "b-form-select-option",
                              { attrs: { value: "0" } },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t\tДействующие\n\t\t\t\t\t\t\t"
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-form-select-option",
                              { attrs: { value: "1" } },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t\tУволенные\n\t\t\t\t\t\t\t"
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-form-select-option",
                              { attrs: { value: "2" } },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t\tСтажеры\n\t\t\t\t\t\t\t"
                                ),
                              ]
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-group",
                      [
                        _c(
                          "b-form-select",
                          {
                            model: {
                              value: _vm.show_user,
                              callback: function ($$v) {
                                _vm.show_user = $$v
                              },
                              expression: "show_user",
                            },
                          },
                          [
                            _c(
                              "b-form-select-option",
                              { attrs: { value: "0" } },
                              [_vm._v("\n\t\t\t\t\t\t\t\tВсе\n\t\t\t\t\t\t\t")]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-form-select-option",
                              { attrs: { value: "1" } },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t\tЕсть начисления\n\t\t\t\t\t\t\t"
                                ),
                              ]
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-12 col-md-3" }, [
                _c("p", { staticClass: "text-right fz-09 text-black" }, [
                  _c("span", [_vm._v("Сотрудники:")]),
                  _vm._v(" "),
                  _c("b", [
                    _vm._v(
                      _vm._s(_vm.users_count) +
                        " | " +
                        _vm._s(_vm.total_resources)
                    ),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _vm.hasPermission
              ? _c(
                  "div",
                  { staticClass: "table-container table-accrual" },
                  [
                    _c("b-table", {
                      staticClass: "text-nowrap text-right salar accrual-table",
                      class: { "hide-special": _vm.special_fields },
                      attrs: {
                        responsive: "",
                        small: true,
                        bordered: true,
                        items: _vm.items,
                        fields: _vm.fields,
                        "show-empty": "",
                        "empty-text": "Нет данных",
                      },
                      scopedSlots: _vm._u(
                        [
                          {
                            key: "cell(name)",
                            fn: function (nameData) {
                              return [
                                _c(
                                  "div",
                                  { staticClass: "badge_table" },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t" +
                                        _vm._s(nameData.value) +
                                        "\n\t\t\t\t\t\t"
                                    ),
                                    nameData.index !== 0 && nameData.value
                                      ? _c(
                                          "b-badge",
                                          {
                                            staticClass: "mr-2",
                                            attrs: {
                                              pill: "",
                                              variant: "success",
                                            },
                                          },
                                          [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t" +
                                                _vm._s(
                                                  nameData.item.user_type
                                                ) +
                                                "\n\t\t\t\t\t\t"
                                            ),
                                          ]
                                        )
                                      : _vm._e(),
                                    _vm._v(" "),
                                    nameData.index == 0
                                      ? _c("i", {
                                          directives: [
                                            {
                                              name: "b-popover",
                                              rawName:
                                                "v-b-popover.hover.right.html",
                                              value:
                                                "В суммах этого ряда не учитываются Сотрудники, у которых <b>К выдаче</b> меньше 0",
                                              expression:
                                                "'В суммах этого ряда не учитываются Сотрудники, у которых <b>К выдаче</b> меньше 0'",
                                              modifiers: {
                                                hover: true,
                                                right: true,
                                                html: true,
                                              },
                                            },
                                          ],
                                          staticClass: "fa fa-info-circle",
                                          attrs: { title: "Заметка" },
                                        })
                                      : _vm._e(),
                                  ],
                                  1
                                ),
                              ]
                            },
                          },
                          {
                            key: "cell(bonus)",
                            fn: function (bonusData) {
                              return [
                                _c(
                                  "div",
                                  {
                                    staticClass: "pointer",
                                    on: {
                                      click: function ($event) {
                                        return _vm.defineClickNumber(
                                          "bonus",
                                          bonusData
                                        )
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t" +
                                        _vm._s(bonusData.value) +
                                        "\n\t\t\t\t\t\t"
                                    ),
                                    bonusData.item.edited_bonus !== null &&
                                    bonusData.index != 0
                                      ? _c("div", {
                                          staticClass: "cell-border",
                                        })
                                      : _vm._e(),
                                  ]
                                ),
                              ]
                            },
                          },
                          {
                            key: "cell(kpi)",
                            fn: function (kpiData) {
                              return [
                                _c(
                                  "div",
                                  {
                                    staticClass: "pointer",
                                    on: {
                                      click: function ($event) {
                                        return _vm.defineClickNumber(
                                          "kpi",
                                          kpiData
                                        )
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t" +
                                        _vm._s(kpiData.value) +
                                        "\n\t\t\t\t\t\t"
                                    ),
                                    kpiData.item.edited_kpi !== null &&
                                    kpiData.index != 0
                                      ? _c("div", {
                                          staticClass: "cell-border",
                                        })
                                      : _vm._e(),
                                  ]
                                ),
                              ]
                            },
                          },
                          {
                            key: "cell(total)",
                            fn: function (totalData) {
                              return [
                                _c("div", [_vm._v(_vm._s(totalData.value))]),
                              ]
                            },
                          },
                          {
                            key: "cell(fines)",
                            fn: function (finesData) {
                              return [
                                _c(
                                  "div",
                                  {
                                    staticClass: "pointer",
                                    on: {
                                      click: function ($event) {
                                        return _vm.showFineSidebar(finesData)
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t" +
                                        _vm._s(finesData.value) +
                                        "\n\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                              ]
                            },
                          },
                          {
                            key: "cell(avans)",
                            fn: function (avansData) {
                              return [
                                _c(
                                  "div",
                                  {
                                    staticClass: "pointer",
                                    on: {
                                      click: function ($event) {
                                        return _vm.showAvansSidebar(avansData)
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t" +
                                        _vm._s(avansData.value) +
                                        "\n\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                              ]
                            },
                          },
                          {
                            key: "cell(taxes)",
                            fn: function (taxesData) {
                              return [
                                _c(
                                  "div",
                                  {
                                    staticClass: "pointer",
                                    on: {
                                      click: function ($event) {
                                        return _vm.showTaxesSidebar(taxesData)
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t" +
                                        _vm._s(taxesData.value) +
                                        "\n\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                              ]
                            },
                          },
                          {
                            key: "cell(final)",
                            fn: function (finalData) {
                              return [
                                _vm.user_types == "1"
                                  ? _c(
                                      "div",
                                      {
                                        staticClass: "pointer",
                                        on: {
                                          click: function ($event) {
                                            return _vm.defineClickNumber(
                                              "final",
                                              finalData
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t" +
                                            _vm._s(finalData.value) +
                                            "\n\t\t\t\t\t\t"
                                        ),
                                        finalData.item.edited_salary !== null &&
                                        finalData.index != 0
                                          ? _c("div", {
                                              staticClass: "cell-border",
                                            })
                                          : _vm._e(),
                                      ]
                                    )
                                  : _c("div", [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t" +
                                          _vm._s(finalData.value) +
                                          "\n\t\t\t\t\t"
                                      ),
                                    ]),
                              ]
                            },
                          },
                          {
                            key: "cell()",
                            fn: function (cellData) {
                              return [
                                _c(
                                  "div",
                                  {
                                    class: [
                                      {
                                        SalaryCell:
                                          cellData.item.dayType &&
                                          cellData.item.dayType[
                                            cellData.field.key
                                          ],
                                      },
                                      cellData.item.dayType
                                        ? "SalaryCell" +
                                          (cellData.field.weekend
                                            ? "-weekend"
                                            : "") +
                                          "-" +
                                          (cellData.item.dayType[
                                            cellData.field.key
                                          ] || "0")
                                        : "",
                                    ],
                                    on: {
                                      click: function ($event) {
                                        return _vm.detectClick(cellData)
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t" +
                                        _vm._s(cellData.value) +
                                        "\n\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                              ]
                            },
                          },
                        ],
                        null,
                        false,
                        797313534
                      ),
                    }),
                  ],
                  1
                )
              : _c("div", [
                  _c("p", [_vm._v("У вас нет доступа к этой группе")]),
                ]),
          ]),
          _vm._v(" "),
          _vm.kpiSidebar
            ? _c(
                "Sidebar",
                {
                  attrs: {
                    width: "80vw",
                    title: "KPI Статистика",
                    open: _vm.kpiSidebar,
                  },
                  on: {
                    close: function ($event) {
                      _vm.kpiSidebar = false
                    },
                  },
                },
                [
                  _c(
                    "div",
                    { staticClass: "px-2 pt-5" },
                    [
                      _c("KpiContent", {
                        staticClass: "px-4 TableAccrual-kpi",
                        attrs: {
                          items: _vm.kpiItems,
                          groups: _vm.groups,
                          fields: _vm.kpiFields,
                        },
                      }),
                    ],
                    1
                  ),
                ]
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.editPremiumSidebar
            ? _c(
                "Sidebar",
                {
                  attrs: {
                    title: _vm.sidebarTitle,
                    width: "400px",
                    open: _vm.editPremiumSidebar,
                  },
                  on: {
                    close: function ($event) {
                      _vm.editPremiumSidebar = false
                    },
                  },
                },
                [
                  _c("div", { staticClass: "px-2" }, [
                    _c("div", [
                      _vm.editedField.item.edited_kpi !== null
                        ? _c("div", [
                            _c("p", { staticClass: "mt-3" }, [
                              _c("b", [_vm._v("Kpi  ")]),
                              _vm._v(" "),
                              _c("i", {
                                directives: [
                                  {
                                    name: "b-popover",
                                    rawName: "v-b-popover.hover.right.html",
                                    value: "Сумма KPI утвержденная к выдаче",
                                    expression:
                                      "'Сумма KPI утвержденная к выдаче'",
                                    modifiers: {
                                      hover: true,
                                      right: true,
                                      html: true,
                                    },
                                  },
                                ],
                                staticClass: "fa fa-info-circle",
                                attrs: { title: "Kpi на этот месяц" },
                              }),
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("b", [_vm._v("Автор:")]),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v(
                                  _vm._s(_vm.editedField.item.edited_kpi.user)
                                ),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("b", [_vm._v("Изменено на:")]),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v(
                                  _vm._s(_vm.editedField.item.edited_kpi.amount)
                                ),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("b", [_vm._v("Комментарии:")]),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v(
                                  _vm._s(
                                    _vm.editedField.item.edited_kpi.comment
                                  )
                                ),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("hr"),
                          ])
                        : _vm._e(),
                    ]),
                    _vm._v(" "),
                    _c("div", [
                      _vm.editedField.item.edited_bonus !== null
                        ? _c("div", [
                            _c("p", { staticClass: "mt-3" }, [
                              _c("b", [_vm._v("Бонусы")]),
                              _vm._v(" "),
                              _c("i", {
                                directives: [
                                  {
                                    name: "b-popover",
                                    rawName: "v-b-popover.hover.right.html",
                                    value:
                                      "Сумма Бонусов, утвержденная к выдаче",
                                    expression:
                                      "'Сумма Бонусов, утвержденная к выдаче'",
                                    modifiers: {
                                      hover: true,
                                      right: true,
                                      html: true,
                                    },
                                  },
                                ],
                                staticClass: "fa fa-info-circle",
                                attrs: { title: "Бонусы на этот месяц" },
                              }),
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("b", [_vm._v("Автор:")]),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v(
                                  _vm._s(_vm.editedField.item.edited_bonus.user)
                                ),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("b", [_vm._v("Изменено на:")]),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v(
                                  _vm._s(
                                    _vm.editedField.item.edited_bonus.amount
                                  )
                                ),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("b", [_vm._v("Комментарии:")]),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v(
                                  _vm._s(
                                    _vm.editedField.item.edited_bonus.comment
                                  )
                                ),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("hr"),
                          ])
                        : _vm._e(),
                    ]),
                    _vm._v(" "),
                    _c("div", [
                      _vm.editedField.item.edited_salary !== null
                        ? _c("div", [
                            _c("p", { staticClass: "mt-3" }, [
                              _c("b", [_vm._v("К выдаче")]),
                              _vm._v(" "),
                              _c("i", {
                                directives: [
                                  {
                                    name: "b-popover",
                                    rawName: "v-b-popover.hover.right.html",
                                    value:
                                      "Окончательная суммма утвержденная к выдаче",
                                    expression:
                                      "'Окончательная суммма утвержденная к выдаче'",
                                    modifiers: {
                                      hover: true,
                                      right: true,
                                      html: true,
                                    },
                                  },
                                ],
                                staticClass: "fa fa-info-circle",
                                attrs: { title: "К выдаче на этот месяц" },
                              }),
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("b", [_vm._v("Автор:")]),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v(
                                  _vm._s(
                                    _vm.editedField.item.edited_salary.user
                                  )
                                ),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("b", [_vm._v("Изменено на:")]),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v(
                                  _vm._s(
                                    _vm.editedField.item.edited_salary.amount
                                  )
                                ),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("b", [_vm._v("Комментарии:")]),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v(
                                  _vm._s(
                                    _vm.editedField.item.edited_salary.comment
                                  )
                                ),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("hr"),
                          ])
                        : _vm._e(),
                    ]),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "mt-3" },
                      [
                        _c("p", { staticClass: "mt-3" }, [
                          _c("b", [_vm._v("Бонусы локальные")]),
                        ]),
                        _vm._v(" "),
                        _vm._l(
                          Object.keys(_vm.editedField.item.bonuses),
                          function (item, index) {
                            return _c("div", { key: index }, [
                              _vm.editedField.item.bonuses[item] != null
                                ? _c("p", { staticClass: "fz12" }, [
                                    _c("b", { staticClass: "text-black" }, [
                                      _vm._v(_vm._s(item) + ":"),
                                    ]),
                                    _vm._v(
                                      "\n\t\t\t\t\t\t" +
                                        _vm._s(
                                          _vm.editedField.item.bonuses[item]
                                        ) +
                                        "\n\t\t\t\t\t"
                                    ),
                                  ])
                                : _vm._e(),
                            ])
                          }
                        ),
                        _vm._v(" "),
                        _c("hr"),
                        _vm._v(" "),
                        _c("p", { staticClass: "mt-3" }, [
                          _c("b", [_vm._v("Бонусы за активности")]),
                        ]),
                        _vm._v(" "),
                        _vm._l(
                          Object.keys(_vm.editedField.item.awards),
                          function (item, index) {
                            return _c("div", { key: index }, [
                              _vm.editedField.item.awards[item] != null
                                ? _c("p", { staticClass: "fz12" }, [
                                    _c("b", { staticClass: "text-black" }, [
                                      _vm._v(_vm._s(item) + ":"),
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(
                                          _vm.editedField.item.awards[item]
                                        ) +
                                        "\n\t\t\t\t\t"
                                    ),
                                  ])
                                : _vm._e(),
                            ])
                          }
                        ),
                        _vm._v(" "),
                        _c("p", { staticClass: "mt-3" }, [
                          _c("b", [_vm._v("Бонусы за обучение")]),
                        ]),
                        _vm._v(" "),
                        _vm._l(
                          Object.keys(_vm.editedField.item.test_bonus),
                          function (item, index) {
                            return _c("div", { key: index }, [
                              _vm.editedField.item.test_bonus[item] != null
                                ? _c("p", { staticClass: "fz12" }, [
                                    _c("b", { staticClass: "text-black" }, [
                                      _vm._v(_vm._s(item) + ":"),
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(
                                          _vm.editedField.item.test_bonus[item]
                                        ) +
                                        "\n\t\t\t\t\t"
                                    ),
                                  ])
                                : _vm._e(),
                            ])
                          }
                        ),
                        _vm._v(" "),
                        _c("hr"),
                        _vm._v(" "),
                        _c("p", { staticClass: "mt-3" }, [
                          _c("b", [_vm._v("Авансы ")]),
                        ]),
                        _vm._v(" "),
                        _vm._l(
                          Object.keys(_vm.editedField.item.avanses),
                          function (item, index) {
                            return _c("div", { key: index }, [
                              _vm.editedField.item.avanses[item] != null
                                ? _c("p", { staticClass: "fz12" }, [
                                    _c("b", { staticClass: "text-black" }, [
                                      _vm._v(_vm._s(item) + ":"),
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(
                                          _vm.editedField.item.avanses[item]
                                        ) +
                                        "\n\t\t\t\t\t"
                                    ),
                                  ])
                                : _vm._e(),
                            ])
                          }
                        ),
                        _vm._v(" "),
                        _c("hr"),
                        _vm._v(" "),
                        _c("p", { staticClass: "mt-3" }, [
                          _c("b", [
                            _vm._v(
                              "История " + _vm._s(_vm.bonus_history.length)
                            ),
                          ]),
                        ]),
                        _vm._v(" "),
                        _vm._l(_vm.bonus_history, function (item, index) {
                          return _c(
                            "div",
                            { key: index, staticClass: "mb-3" },
                            [
                              _c("p", { staticClass: "fz12" }, [
                                _c("b", { staticClass: "text-black" }, [
                                  _vm._v("Дата:"),
                                ]),
                                _vm._v(
                                  " " +
                                    _vm._s(
                                      new Date(item.created_at)
                                        .addHours(6)
                                        .toLocaleString("ru-RU")
                                    ) +
                                    "\n\t\t\t\t\t"
                                ),
                              ]),
                              _vm._v(" "),
                              _c("p", { staticClass: "fz12" }, [
                                _c("b", { staticClass: "text-black" }, [
                                  _vm._v("Автор:"),
                                ]),
                                _vm._v(" " + _vm._s(item.author) + " "),
                                _c("br"),
                              ]),
                              _vm._v(" "),
                              _c("p", {
                                staticClass: "fz14 mb-0",
                                domProps: {
                                  innerHTML: _vm._s(item.description),
                                },
                              }),
                              _vm._v(" "),
                              _c("br"),
                              _vm._v(" "),
                              _c("hr"),
                            ]
                          )
                        }),
                      ],
                      2
                    ),
                  ]),
                ]
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.openSidebar
            ? _c(
                "Sidebar",
                {
                  attrs: {
                    width: "400px",
                    title: _vm.sidebarTitle,
                    open: _vm.openSidebar,
                    link: _vm.profile_link,
                  },
                  on: {
                    close: function ($event) {
                      _vm.openSidebar = false
                    },
                  },
                },
                [
                  _c("div", { staticClass: "px-2" }, [
                    _vm.sidebarContent.item !== undefined
                      ? _c(
                          "div",
                          { staticClass: "mb-2" },
                          [
                            _vm.sidebarContent.item.hours !== undefined
                              ? _c("p", { staticClass: "text-black" }, [
                                  _c("b", [_vm._v("Отработано:")]),
                                  _vm._v(
                                    "  " +
                                      _vm._s(
                                        _vm.sidebarContent.item.hours[
                                          _vm.sidebarContent.field.key
                                        ]
                                      ) +
                                      "\n\t\t\t\t"
                                  ),
                                ])
                              : _vm._e(),
                            _vm._v(" "),
                            _vm.sidebarContent.item.hourly_pays !== undefined
                              ? _c("p", { staticClass: "text-black" }, [
                                  _c("b", [_vm._v("Оплата за час:")]),
                                  _vm._v(
                                    "  " +
                                      _vm._s(
                                        _vm.sidebarContent.item.hourly_pays[
                                          _vm.sidebarContent.field.key
                                        ]
                                      ) +
                                      "\n\t\t\t\t"
                                  ),
                                ])
                              : _vm._e(),
                            _vm._v(" "),
                            _c("p", { staticClass: "text-black mb-0" }, [
                              _c("b", [_vm._v("Начис:")]),
                              _vm._v(
                                "  " +
                                  _vm._s(
                                    _vm.sidebarContent.item.salaries[
                                      _vm.sidebarContent.field.key
                                    ]
                                  ) +
                                  "\n\t\t\t\t"
                              ),
                            ]),
                            _vm._v(" "),
                            _vm.selectedCell.field.editable
                              ? [
                                  _vm.sidebarContent.item.avanses !== undefined
                                    ? _c(
                                        "p",
                                        { staticClass: "text-black mb-0" },
                                        [
                                          _c("b", [_vm._v("Аванс:")]),
                                          _vm._v(
                                            "\n\t\t\t\t\t\t" +
                                              _vm._s(
                                                _vm.sidebarContent.item.avanses[
                                                  _vm.sidebarContent.field.key
                                                ]
                                              ) +
                                              "\n\t\t\t\t\t"
                                          ),
                                        ]
                                      )
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.sidebarContent.item.bonuses !== undefined
                                    ? _c("p", { staticClass: "text-black" }, [
                                        _c("b", [_vm._v("Бонус:")]),
                                        _vm._v(
                                          "\n\t\t\t\t\t\t" +
                                            _vm._s(
                                              _vm.sidebarContent.item.bonuses[
                                                _vm.sidebarContent.field.key
                                              ]
                                            ) +
                                            "\n\t\t\t\t\t"
                                        ),
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.sidebarContent.item.awards !== undefined
                                    ? _c("p", { staticClass: "text-black" }, [
                                        _c("b", [_vm._v("Бонус (авто):")]),
                                        _vm._v(
                                          "\n\t\t\t\t\t\t" +
                                            _vm._s(
                                              _vm.sidebarContent.item.awards[
                                                _vm.sidebarContent.field.key
                                              ]
                                            ) +
                                            "\n\t\t\t\t\t"
                                        ),
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.sidebarContent.item.test_bonus !==
                                  undefined
                                    ? _c("p", { staticClass: "text-black" }, [
                                        _c("b", [_vm._v("Бонус (тесты):")]),
                                        _vm._v(
                                          "\n\t\t\t\t\t\t" +
                                            _vm._s(
                                              _vm.sidebarContent.item
                                                .test_bonus[
                                                _vm.sidebarContent.field.key
                                              ]
                                            ) +
                                            "\n\t\t\t\t\t"
                                        ),
                                      ])
                                    : _vm._e(),
                                ]
                              : _vm._e(),
                          ],
                          2
                        )
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.can_edit
                      ? _c("div", { staticClass: "mb-2" }, [
                          _c("div", { staticClass: "d-flex row" }, [
                            _vm.user_types == "0" || _vm.user_types == "1"
                              ? _c(
                                  "div",
                                  { staticClass: "col-6" },
                                  [
                                    _c(
                                      "b-button",
                                      {
                                        staticClass:
                                          "rounded btn-primary w-full d-block",
                                        class: { activex: _vm.avans.visible },
                                        on: {
                                          click: function ($event) {
                                            return _vm.toggleTab("avans")
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\tВыдать аванс\n\t\t\t\t\t\t"
                                        ),
                                      ]
                                    ),
                                  ],
                                  1
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            _c(
                              "div",
                              { staticClass: "col-6" },
                              [
                                _c(
                                  "b-button",
                                  {
                                    staticClass:
                                      "rounded btn-primary w-full d-block",
                                    class: { activex: _vm.bonus.visible },
                                    on: {
                                      click: function ($event) {
                                        return _vm.toggleTab("bonus")
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\tВыдать бонус\n\t\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                              ],
                              1
                            ),
                          ]),
                        ])
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.avans.visible
                      ? _c(
                          "div",
                          { staticClass: "mb-4 bg-bluish p-3" },
                          [
                            _c("label", [_vm._v("Сумма аванса")]),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.avans.sum,
                                  expression: "avans.sum",
                                },
                              ],
                              staticClass:
                                "form-control form-control-sm mr-2 mb-2",
                              attrs: {
                                placeholder: "Cумма аванса",
                                required: true,
                                type: "number",
                              },
                              domProps: { value: _vm.avans.sum },
                              on: {
                                input: function ($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.avans,
                                    "sum",
                                    $event.target.value
                                  )
                                },
                              },
                            }),
                            _vm._v(" "),
                            _c("label", [
                              _vm._v("Комментарии "),
                              _c("span", { staticClass: "color-red" }, [
                                _vm._v("*"),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.avans.comment,
                                  expression: "avans.comment",
                                },
                              ],
                              staticClass:
                                "form-control form-control-sm mr-2 mb-2",
                              attrs: {
                                placeholder: "Причина выдачи...",
                                required: true,
                                type: "text",
                              },
                              domProps: { value: _vm.avans.comment },
                              on: {
                                input: function ($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.avans,
                                    "comment",
                                    $event.target.value
                                  )
                                },
                              },
                            }),
                            _vm._v(" "),
                            _c("p", [
                              _c("span", { staticClass: "color-red" }, [
                                _vm._v(_vm._s(_vm.avans.require)),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c(
                              "b-button",
                              {
                                staticClass: "rounded btn-primary",
                                attrs: { variant: "primary" },
                                on: {
                                  click: function ($event) {
                                    return _vm.updateSalary("avans")
                                  },
                                },
                              },
                              [_vm._v("\n\t\t\t\t\tВыдать аванс\n\t\t\t\t")]
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.bonus.visible
                      ? _c(
                          "div",
                          { staticClass: "mb-4 bg-bluish p-3" },
                          [
                            _c("label", [_vm._v("Сумма бонуса")]),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.bonus.sum,
                                  expression: "bonus.sum",
                                },
                              ],
                              staticClass:
                                "form-control form-control-sm mr-2 mb-2",
                              attrs: {
                                placeholder: "Cумма бонуса",
                                required: true,
                                type: "number",
                              },
                              domProps: { value: _vm.bonus.sum },
                              on: {
                                input: function ($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.bonus,
                                    "sum",
                                    $event.target.value
                                  )
                                },
                              },
                            }),
                            _vm._v(" "),
                            _c("label", [
                              _vm._v("Комментарии "),
                              _c("span", { staticClass: "color-red" }, [
                                _vm._v("*"),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.bonus.comment,
                                  expression: "bonus.comment",
                                },
                              ],
                              staticClass:
                                "form-control form-control-sm mr-2 mb-2",
                              attrs: {
                                placeholder: "Причина выдачи...",
                                required: true,
                                type: "text",
                              },
                              domProps: { value: _vm.bonus.comment },
                              on: {
                                input: function ($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(
                                    _vm.bonus,
                                    "comment",
                                    $event.target.value
                                  )
                                },
                              },
                            }),
                            _vm._v(" "),
                            _c("p", [
                              _c("span", { staticClass: "color-red" }, [
                                _vm._v(_vm._s(_vm.avans.require)),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c(
                              "b-button",
                              {
                                staticClass: "rounded btn-primary",
                                attrs: { variant: "primary" },
                                on: {
                                  click: function ($event) {
                                    return _vm.updateSalary("bonus")
                                  },
                                },
                              },
                              [_vm._v("\n\t\t\t\t\tВыдать бонус\n\t\t\t\t")]
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.selectedCell.item.fine[_vm.sidebarContent.field.key]
                      .length > 0
                      ? _c(
                          "div",
                          { staticClass: "mb-4" },
                          [
                            _c("p", [_c("b", [_vm._v("Штрафы")])]),
                            _vm._v(" "),
                            _vm._l(
                              _vm.selectedCell.item.fine[
                                _vm.sidebarContent.field.key
                              ],
                              function (fine, fineIndex) {
                                return _c(
                                  "div",
                                  { key: fineIndex },
                                  _vm._l(fine, function (value, name) {
                                    return _c(
                                      "p",
                                      { key: name, staticClass: "mb-0 mt-0" },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t" +
                                            _vm._s(name) +
                                            ": " +
                                            _vm._s(value) +
                                            "\n\t\t\t\t\t"
                                        ),
                                      ]
                                    )
                                  }),
                                  0
                                )
                              }
                            ),
                          ],
                          2
                        )
                      : _vm._e(),
                    _vm._v(" "),
                    _c(
                      "div",
                      [
                        _c("p", { staticClass: "text-black" }, [
                          _c("b", [_vm._v("История")]),
                        ]),
                        _vm._v(" "),
                        _vm.sidebarHistory && _vm.sidebarHistory.length > 0
                          ? [
                              _c(
                                "div",
                                { staticClass: "history" },
                                _vm._l(
                                  _vm.sidebarHistory,
                                  function (item, index) {
                                    return _c(
                                      "div",
                                      { key: index, staticClass: "mb-3" },
                                      [
                                        _c("p", { staticClass: "fz12" }, [
                                          _c(
                                            "b",
                                            { staticClass: "text-black" },
                                            [_vm._v("Дата:")]
                                          ),
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                new Date(item.created_at)
                                                  .addHours(6)
                                                  .toLocaleString("ru-RU")
                                              ) +
                                              "\n\t\t\t\t\t\t\t"
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("p", { staticClass: "fz12" }, [
                                          _c(
                                            "b",
                                            { staticClass: "text-black" },
                                            [_vm._v("Автор:")]
                                          ),
                                          _vm._v(
                                            " " + _vm._s(item.author) + " "
                                          ),
                                          _c("br"),
                                        ]),
                                        _vm._v(" "),
                                        _c("p", {
                                          staticClass: "fz14 mb-0",
                                          domProps: {
                                            innerHTML: _vm._s(item.description),
                                          },
                                        }),
                                        _c("br"),
                                        _vm._v(" "),
                                        _c("hr"),
                                      ]
                                    )
                                  }
                                ),
                                0
                              ),
                            ]
                          : [
                              _c("p", [
                                _vm._v("История изменения отсутствует"),
                              ]),
                            ],
                      ],
                      2
                    ),
                  ]),
                ]
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.isAvansSidebar
            ? _c(
                "Sidebar",
                {
                  attrs: {
                    title: _vm.sidebarTitle,
                    width: "400px",
                    open: _vm.isAvansSidebar,
                  },
                  on: {
                    close: function ($event) {
                      _vm.isAvansSidebar = false
                    },
                  },
                },
                [
                  _c(
                    "div",
                    { staticClass: "px-2" },
                    _vm._l(_vm.avans_history, function (avansItem) {
                      return _c(
                        "div",
                        { key: avansItem.id, staticClass: "AvansHistoryItem" },
                        [
                          _c("div", { staticClass: "AvansHistoryItem-date" }, [
                            _c("b", [
                              _vm._v(
                                _vm._s(
                                  _vm
                                    .$moment(avansItem.date)
                                    .format("DD.MM.YYYY")
                                )
                              ),
                            ]),
                            _vm._v(
                              " " + _vm._s(avansItem.author) + "\n\t\t\t\t"
                            ),
                          ]),
                          _vm._v(" "),
                          _c("div", {
                            staticClass: "AvansHistoryItem-text",
                            domProps: {
                              innerHTML: _vm._s(avansItem.description),
                            },
                          }),
                          _vm._v(" "),
                          _c("hr"),
                        ]
                      )
                    }),
                    0
                  ),
                ]
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.isFineSidebar
            ? _c(
                "Sidebar",
                {
                  attrs: {
                    title: _vm.sidebarTitle,
                    width: "400px",
                    open: _vm.isFineSidebar,
                  },
                  on: {
                    close: function ($event) {
                      _vm.isFineSidebar = false
                    },
                  },
                },
                [
                  _c(
                    "div",
                    { staticClass: "px-2" },
                    [
                      _vm._l(_vm.fine_history, function (fineItem, fineIndex) {
                        return [
                          fineItem.pivot.status === 1
                            ? _c(
                                "div",
                                {
                                  key: fineIndex,
                                  staticClass: "AvansHistoryItem",
                                },
                                [
                                  _c(
                                    "div",
                                    { staticClass: "AvansHistoryItem-date" },
                                    [
                                      _c("b", [
                                        _vm._v(
                                          _vm._s(
                                            _vm
                                              .$moment(fineItem.pivot.day)
                                              .format("DD.MM.YYYY")
                                          )
                                        ),
                                      ]),
                                      _vm._v(
                                        " " +
                                          _vm._s(fineItem.penalty_amount) +
                                          "\n\t\t\t\t\t"
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c("div", {
                                    staticClass: "AvansHistoryItem-text",
                                    domProps: {
                                      innerHTML: _vm._s(fineItem.name),
                                    },
                                  }),
                                  _vm._v(" "),
                                  _c("hr"),
                                ]
                              )
                            : _vm._e(),
                        ]
                      }),
                    ],
                    2
                  ),
                ]
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.isTaxesSidebar
            ? _c(
                "Sidebar",
                {
                  attrs: {
                    title: _vm.sidebarTitle,
                    width: "400px",
                    open: _vm.isTaxesSidebar,
                  },
                  on: {
                    close: function ($event) {
                      _vm.isTaxesSidebar = false
                    },
                  },
                },
                [
                  _c(
                    "div",
                    { staticClass: "px-2" },
                    _vm._l(_vm.texes_history, function (taxItem, taxIndex) {
                      return _c(
                        "div",
                        { key: taxIndex, staticClass: "AvansHistoryItem" },
                        [
                          _c("div", { staticClass: "AvansHistoryItem-date" }, [
                            _c("b", [
                              _vm._v(
                                _vm._s(
                                  _vm
                                    .$moment(taxItem.pivot.created_at)
                                    .format("DD.MM.YYYY")
                                )
                              ),
                            ]),
                            _vm._v(
                              " " +
                                _vm._s(taxItem.pivot.value) +
                                _vm._s(taxItem.is_percent ? "%" : "") +
                                "\n\t\t\t\t"
                            ),
                          ]),
                          _vm._v(" "),
                          _c("div", {
                            staticClass: "AvansHistoryItem-text",
                            domProps: { innerHTML: _vm._s(taxItem.name) },
                          }),
                          _vm._v(" "),
                          _c("hr"),
                        ]
                      )
                    }),
                    0
                  ),
                ]
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                "ok-text": "Да",
                "cancel-text": "Нет",
                title: _vm.editedField.name + ": " + _vm.editedField.type,
                size: "md",
              },
              on: { ok: _vm.editPremium },
              model: {
                value: _vm.editPremiunWindow,
                callback: function ($$v) {
                  _vm.editPremiunWindow = $$v
                },
                expression: "editPremiunWindow",
              },
            },
            [
              _c("b-form-input", {
                staticClass: "mb-2",
                attrs: { type: "number", placeholder: "Сумма", required: true },
                model: {
                  value: _vm.amountEdit,
                  callback: function ($$v) {
                    _vm.amountEdit = $$v
                  },
                  expression: "amountEdit",
                },
              }),
              _vm._v(" "),
              _c("b-form-input", {
                staticClass: "mb-2",
                attrs: {
                  type: "text",
                  placeholder: "Комментарий",
                  required: true,
                },
                model: {
                  value: _vm.commentEdit,
                  callback: function ($$v) {
                    _vm.commentEdit = $$v
                  },
                  expression: "commentEdit",
                },
              }),
              _vm._v(" "),
              _vm._l(_vm.errors, function (error) {
                return _c(
                  "b-alert",
                  { key: error, attrs: { show: "", variant: "danger" } },
                  [_vm._v("\n\t\t\t" + _vm._s(error) + "\n\t\t")]
                )
              }),
            ],
            2
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                "ok-text": "Да",
                "cancel-text": "Нет",
                title: "Утверждение зарплаты",
                size: "md",
              },
              on: { ok: _vm.approveSalary },
              model: {
                value: _vm.showBeforeApprove,
                callback: function ($$v) {
                  _vm.showBeforeApprove = $$v
                },
                expression: "showBeforeApprove",
              },
            },
            [
              _c("p", [
                _vm._v(
                  "Вы подтверждаете, что вы проверили начисления и уверены, в том что они верные?"
                ),
              ]),
            ]
          ),
        ],
        1
      )
    : _vm._e()
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", { staticClass: "text-success" }, [
      _c("img", {
        staticStyle: { width: "20px" },
        attrs: { src: "/images/double-check.png" },
      }),
      _vm._v(" Начисления утверждены\n\t\t\t\t\t"),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "kpi-item" },
    [
      _c("table", { staticClass: "table table-inner" }, [
        _c("thead", [
          _c("tr", [
            _c("th"),
            _vm._v(" "),
            _c("th", [_vm._v("Наименование активности")]),
            _vm._v(" "),
            _c("th", [_vm._v("Вид плана")]),
            _vm._v(" "),
            _vm.kpi_page
              ? _c("th", [
                  _vm._v("\n\t\t\t\t\tПоказатели "),
                  _c("i", {
                    staticClass: "fa fa-info-circle",
                    on: {
                      click: function ($event) {
                        return _vm.showDescription()
                      },
                    },
                  }),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.kpi_page
              ? _c("th", [_vm._v("\n\t\t\t\t\tЕд. изм.\n\t\t\t\t")])
              : _vm._e(),
            _vm._v(" "),
            _c("th", [_vm._v("Целевое значение на месяц")]),
            _vm._v(" "),
            _c("th", [_vm._v("Удельный вес, %")]),
            _vm._v(" "),
            !_vm.kpi_page
              ? _c("th", [_vm._v("\n\t\t\t\t\tФакт\n\t\t\t\t")])
              : _vm._e(),
            _vm._v(" "),
            !_vm.kpi_page
              ? _c("th", [_vm._v("\n\t\t\t\t\t% выполнения\n\t\t\t\t")])
              : _vm._e(),
            _vm._v(" "),
            _c("th", [_vm._v("Сумма премии при выполнении плана, KZT")]),
            _vm._v(" "),
            _c("th", [_vm._v("Заработано")]),
            _vm._v(" "),
            _vm.kpi_page ? _c("th") : _vm._e(),
          ]),
        ]),
        _vm._v(" "),
        _c(
          "tbody",
          { key: _vm.refreshItemsKey },
          [
            _vm.kpi_page
              ? [
                  _vm._l(_vm.items, function (item, i) {
                    return _c(
                      "tr",
                      {
                        key: i,
                        staticClass: "jt-row",
                        class: {
                          "j-hidden": !_vm.expanded,
                          "j-deleted":
                            item.deleted != undefined && item.deleted,
                        },
                      },
                      [
                        _c("td", { staticClass: "first-column text-center" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t" + _vm._s(i + 1) + "\n\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.name,
                                expression: "item.name",
                              },
                            ],
                            attrs: { type: "text" },
                            domProps: { value: item.name },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "name", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _c(
                            "select",
                            {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: item.method,
                                  expression: "item.method",
                                },
                              ],
                              on: {
                                change: function ($event) {
                                  var $$selectedVal = Array.prototype.filter
                                    .call($event.target.options, function (o) {
                                      return o.selected
                                    })
                                    .map(function (o) {
                                      var val =
                                        "_value" in o ? o._value : o.value
                                      return val
                                    })
                                  _vm.$set(
                                    item,
                                    "method",
                                    $event.target.multiple
                                      ? $$selectedVal
                                      : $$selectedVal[0]
                                  )
                                },
                              },
                            },
                            _vm._l(Object.keys(_vm.methods), function (key) {
                              return _c(
                                "option",
                                { key: key, domProps: { value: key } },
                                [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t\t" +
                                      _vm._s(_vm.methods[key]) +
                                      "\n\t\t\t\t\t\t\t"
                                  ),
                                ]
                              )
                            }),
                            0
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center no-hover" }, [
                          _c("div", { staticClass: "d-flex" }, [
                            _c(
                              "select",
                              {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: item.source,
                                    expression: "item.source",
                                  },
                                ],
                                on: {
                                  change: [
                                    function ($event) {
                                      var $$selectedVal = Array.prototype.filter
                                        .call(
                                          $event.target.options,
                                          function (o) {
                                            return o.selected
                                          }
                                        )
                                        .map(function (o) {
                                          var val =
                                            "_value" in o ? o._value : o.value
                                          return val
                                        })
                                      _vm.$set(
                                        item,
                                        "source",
                                        $event.target.multiple
                                          ? $$selectedVal
                                          : $$selectedVal[0]
                                      )
                                    },
                                    function ($event) {
                                      ++_vm.source_key
                                    },
                                  ],
                                },
                              },
                              _vm._l(Object.keys(_vm.sources), function (key) {
                                return _c(
                                  "option",
                                  { key: key, domProps: { value: key } },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\t\t" +
                                        _vm._s(_vm.sources[key]) +
                                        "\n\t\t\t\t\t\t\t\t"
                                    ),
                                  ]
                                )
                              }),
                              0
                            ),
                            _vm._v(" "),
                            item.source == 1
                              ? _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: item.group_id,
                                        expression: "item.group_id",
                                      },
                                    ],
                                    key: "c" + _vm.source_key,
                                    on: {
                                      change: [
                                        function ($event) {
                                          var $$selectedVal =
                                            Array.prototype.filter
                                              .call(
                                                $event.target.options,
                                                function (o) {
                                                  return o.selected
                                                }
                                              )
                                              .map(function (o) {
                                                var val =
                                                  "_value" in o
                                                    ? o._value
                                                    : o.value
                                                return val
                                              })
                                          _vm.$set(
                                            item,
                                            "group_id",
                                            $event.target.multiple
                                              ? $$selectedVal
                                              : $$selectedVal[0]
                                          )
                                        },
                                        function ($event) {
                                          ++_vm.source_key
                                        },
                                      ],
                                    },
                                  },
                                  [
                                    _c(
                                      "option",
                                      { attrs: { value: "0", selected: "" } },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _vm._l(_vm.groups, function (group, id) {
                                      return _c(
                                        "option",
                                        { key: id, domProps: { value: id } },
                                        [
                                          _vm._v(
                                            "\n\t\t\t\t\t\t\t\t\t" +
                                              _vm._s(group) +
                                              "\n\t\t\t\t\t\t\t\t"
                                          ),
                                        ]
                                      )
                                    }),
                                  ],
                                  2
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            _c(
                              "select",
                              {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: item.activity_id,
                                    expression: "item.activity_id",
                                  },
                                ],
                                key: "d" + _vm.source_key,
                                class: { hidden: item.source == 0 },
                                on: {
                                  change: function ($event) {
                                    var $$selectedVal = Array.prototype.filter
                                      .call(
                                        $event.target.options,
                                        function (o) {
                                          return o.selected
                                        }
                                      )
                                      .map(function (o) {
                                        var val =
                                          "_value" in o ? o._value : o.value
                                        return val
                                      })
                                    _vm.$set(
                                      item,
                                      "activity_id",
                                      $event.target.multiple
                                        ? $$selectedVal
                                        : $$selectedVal[0]
                                    )
                                  },
                                },
                              },
                              [
                                _c(
                                  "option",
                                  { attrs: { value: "0", selected: "" } },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _vm._l(
                                  _vm.grouped_activities(
                                    item.source,
                                    item.group_id
                                  ),
                                  function (activity) {
                                    return _c(
                                      "option",
                                      {
                                        key: activity.id,
                                        domProps: { value: activity.id },
                                      },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t" +
                                            _vm._s(activity.name) +
                                            "\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    )
                                  }
                                ),
                              ],
                              2
                            ),
                            _vm._v(" "),
                            item.source == 1 && !_vm.isCell(item.activity_id)
                              ? _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: item.common,
                                        expression: "item.common",
                                      },
                                    ],
                                    on: {
                                      change: function ($event) {
                                        var $$selectedVal =
                                          Array.prototype.filter
                                            .call(
                                              $event.target.options,
                                              function (o) {
                                                return o.selected
                                              }
                                            )
                                            .map(function (o) {
                                              var val =
                                                "_value" in o
                                                  ? o._value
                                                  : o.value
                                              return val
                                            })
                                        _vm.$set(
                                          item,
                                          "common",
                                          $event.target.multiple
                                            ? $$selectedVal
                                            : $$selectedVal[0]
                                        )
                                      },
                                    },
                                  },
                                  [
                                    _c(
                                      "option",
                                      { attrs: { value: "0", selected: "" } },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\tСвой\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c("option", { attrs: { value: "1" } }, [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t\tВсего отдела\n\t\t\t\t\t\t\t\t"
                                      ),
                                    ]),
                                  ]
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            item.source == 1 && _vm.isCell(item.activity_id)
                              ? _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item.cell,
                                      expression: "item.cell",
                                    },
                                  ],
                                  attrs: {
                                    type: "text",
                                    placeholder: "Ячейка: C7",
                                  },
                                  domProps: { value: item.cell },
                                  on: {
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        item,
                                        "cell",
                                        $event.target.value
                                      )
                                    },
                                  },
                                })
                              : _vm._e(),
                          ]),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center w-sm" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.unit,
                                expression: "item.unit",
                              },
                            ],
                            attrs: { type: "text" },
                            domProps: { value: item.unit },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "unit", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.plan,
                                expression: "item.plan",
                              },
                            ],
                            attrs: { type: "number" },
                            domProps: { value: item.plan },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "plan", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.share,
                                expression: "item.share",
                              },
                            ],
                            attrs: { type: "number", min: "0", max: "100" },
                            domProps: { value: item.share },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "share", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t" + _vm._s(item.sum) + "\n\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t" +
                              _vm._s(
                                parseInt(item.sum * (item.percent / 100))
                              ) +
                              "\n\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "no-hover" }, [
                          item.deleted != undefined && item.deleted
                            ? _c("i", {
                                staticClass:
                                  "fa fa-arrow-up mx-3 btn btn-danger btn-icon",
                                on: {
                                  click: function ($event) {
                                    return _vm.restoreItem(i)
                                  },
                                },
                              })
                            : _c("i", {
                                staticClass:
                                  "fa fa-trash mx-3 btn btn-danger btn-icon",
                                on: {
                                  click: function ($event) {
                                    return _vm.deleteItem(i)
                                  },
                                },
                              }),
                        ]),
                      ]
                    )
                  }),
                  _vm._v(" "),
                  _c("tr", [
                    _c(
                      "td",
                      {
                        staticClass: "plus-item",
                        attrs: { colspan: "10" },
                        on: { click: _vm.addItem },
                      },
                      [_vm._m(0)]
                    ),
                  ]),
                ]
              : _vm._l(_vm.items, function (item, i) {
                  return _c(
                    "tr",
                    {
                      key: i,
                      staticClass: "jt-row j-hidden",
                      class: {
                        "j-hidden": !_vm.expanded,
                      },
                    },
                    [
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(i + 1) + "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "px-2" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(
                              item.histories_latest
                                ? item.histories_latest.payload.name
                                : item.name
                            ) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(_vm.methods[item.method]) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _c("b", [
                          _vm._v(
                            _vm._s(
                              item.histories_latest
                                ? item.histories_latest.payload.plan
                                : item.plan
                            ) +
                              " " +
                              _vm._s(
                                item.histories_latest
                                  ? item.histories_latest.payload.unit
                                  : item.unit
                              )
                          ),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(
                              item.histories_latest
                                ? item.histories_latest.payload.share
                                : item.share
                            ) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _vm.editable
                        ? _c("td", { staticClass: "text-center" }, [
                            [1, 3, 5].includes(item.method)
                              ? _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item.fact,
                                      expression: "item.fact",
                                    },
                                  ],
                                  attrs: { type: "number", min: "0" },
                                  domProps: { value: item.fact },
                                  on: {
                                    change: function ($event) {
                                      return _vm.updateStat(i)
                                    },
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        item,
                                        "fact",
                                        $event.target.value
                                      )
                                    },
                                  },
                                })
                              : _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item.avg,
                                      expression: "item.avg",
                                    },
                                  ],
                                  attrs: { type: "number", min: "0" },
                                  domProps: { value: item.avg },
                                  on: {
                                    change: function ($event) {
                                      return _vm.updateStat(i)
                                    },
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(item, "avg", $event.target.value)
                                    },
                                  },
                                }),
                          ])
                        : _c("td", { staticClass: "text-center" }, [
                            [1, 3, 5].includes(item.method)
                              ? _c("div", [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(item.fact) +
                                      "\n\t\t\t\t\t\t"
                                  ),
                                ])
                              : _c("div", [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(Number(item.avg).toFixed(2)) +
                                      "\n\t\t\t\t\t\t"
                                  ),
                                ]),
                          ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(item.percent) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(
                              _vm.my_sum *
                                (parseInt(
                                  item.histories_latest
                                    ? item.histories_latest.payload.share
                                    : item.share
                                ) /
                                  100)
                            ) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(item.sum) + "\n\t\t\t\t\t"
                        ),
                      ]),
                    ]
                  )
                }),
          ],
          2
        ),
      ]),
      _vm._v(" "),
      _c(
        "sidebar",
        {
          attrs: {
            title: "Показатели",
            open: _vm.show_description,
            width: "70%",
          },
          on: {
            close: function ($event) {
              return _vm.toggle()
            },
          },
        },
        [
          _c("p", [
            _vm._v(
              "Тут указывается какой показатель сотрудника нужно смотреть для выявления процента выполнения."
            ),
          ]),
          _vm._v(" "),
          _c("p", [_vm._v("Первый select источник:")]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- без источникa:")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("руководитель сам будет ставить нужный коэффициент"),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- из показателей отдела: ")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("берем данные из подробных таблиц в Аналитике отдела."),
          ]),
          _vm._v(" "),
          _c("p", [_vm._v("Появляются три selectа:")]),
          _vm._v(" "),
          _c("ul", [
            _c("li", [_vm._v("выбираем отдел")]),
            _vm._v(" "),
            _c("li", [_vm._v("выбираем показатель")]),
            _vm._v(" "),
            _c("li", [
              _vm._v("выбор "),
              _c("em", [_vm._v("Свой")]),
              _vm._v(" или "),
              _c("em", [_vm._v("Всего отдела")]),
              _vm._v(
                ". Свой выберет только показатель пользователя, а Всего отдела - какой показатель сделал отдел."
              ),
            ]),
          ]),
          _vm._v(" "),
          _c("p", [
            _vm._v("Если выбрать "),
            _c("em", [_vm._v("ячейка из сводной")]),
            _vm._v(" нужно будет указать название ячейки как в Excel."),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- из битрикса:")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("Если в интеграции настроен "),
            _c("strong", [_vm._v("Битрикс24")]),
            _vm._v(
              ", будем брать оттуда показатели, при условии, что  ID пользователей из битрикса были связаны с Jobtron."
            ),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- из amocrm:")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("Если в интеграции настроен "),
            _c("strong", [_vm._v("Amocrm")]),
            _vm._v(
              ", будем брать оттуда показатели, при условии, что  ID пользователей из amocrm были связаны с Jobtron."
            ),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- другие :")])]),
          _vm._v(" "),
          _c("p", [_vm._v("разные показатели в Jobtron")]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "p-4" }, [
      _c("i", { staticClass: "fa fa-plus mr-2" }),
      _vm._v(" "),
      _c("b", [_vm._v("Добавить активность")]),
    ])
  },
]
render._withStripped = true



/***/ })

}]);