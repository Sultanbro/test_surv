"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["KBPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Glossary.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Glossary.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'GlossaryComponent',
  props: {
    mode: {
      type: String,
      "default": 'read'
    }
  },
  data: function data() {
    return {
      words: [],
      searchText: ''
    };
  },
  computed: {
    filteredWords: function filteredWords() {
      var _this = this;
      return this.words.filter(function (el) {
        return el.word.toLowerCase().indexOf(_this.searchText.toLowerCase()) > -1;
      });
    }
  },
  created: function created() {
    this.fetch();
  },
  methods: {
    fetch: function fetch() {
      var _this2 = this;
      this.axios.get('/glossary/get', {}).then(function (response) {
        _this2.words = response.data;
      })["catch"](function (error) {
        console.error(error);
      });
    },
    save: function save(i) {
      var _this3 = this;
      this.axios.post('/glossary/save', {
        word: this.words[i]
      }).then(function (response) {
        _this3.words[i].id = response.data;
        _this3.$toast.success('Определение сохранено');
      })["catch"](function (error) {
        console.error(error);
      });
    },
    add: function add() {
      this.searchText = '';
      this.words.unshift({
        id: 0,
        word: '',
        definition: ''
      });
    },
    deleteWord: function deleteWord(i) {
      var _this4 = this;
      if (this.words[i].id == 0) this.words.splice(i, 1);
      this.axios.post('/glossary/delete', {
        id: this.words[i].id
      }).then(function () {
        _this4.words.splice(i, 1);
        _this4.$toast.success('Определение удалено');
      })["catch"](function (error) {
        console.error(error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'UISidebar',
  props: {
    title: {
      type: String,
      "default": ''
    },
    open: {
      type: Boolean
    },
    width: {
      type: String,
      "default": ''
    },
    link: {
      type: String,
      "default": ''
    }
  },
  data: function data() {
    return {};
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuedraggable */ "./node_modules/vuedraggable/dist/vuedraggable.common.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuedraggable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Glossary_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Glossary.vue */ "./resources/js/components/Glossary.vue");
/* harmony import */ var _components_ui_SimpleSidebar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/ui/SimpleSidebar */ "./resources/js/components/ui/SimpleSidebar.vue");
/* harmony import */ var _components_SuperSelect__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/SuperSelect */ "./resources/js/components/SuperSelect.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */



var Booklist = function Booklist() {
  return __webpack_require__.e(/*! import() | Booklist */ "Booklist").then(__webpack_require__.bind(__webpack_require__, /*! @/pages/booklist */ "./resources/js/pages/booklist.vue"));
}; // база знаний разде
 // сайдбар table
 // with User ProfileGroup and Position

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KBPage',
  components: {
    Draggable: (vuedraggable__WEBPACK_IMPORTED_MODULE_0___default()),
    Glossary: _components_Glossary_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    Booklist: Booklist,
    SimpleSidebar: _components_ui_SimpleSidebar__WEBPACK_IMPORTED_MODULE_2__["default"],
    SuperSelect: _components_SuperSelect__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  props: {
    auth_user_id: {
      type: Number,
      "default": 0
    },
    can_edit: {
      type: Boolean,
      "default": false
    }
  },
  data: function data() {
    return {
      books: [],
      mode: 'read',
      archived_books: [],
      trees: [],
      settings: null,
      section: 0,
      activeBook: null,
      showCreate: false,
      show_glossary: false,
      send_notification_after_edit: false,
      show_page_from_kb_everyday: false,
      allow_save_kb_without_test: false,
      showBookSettings: false,
      showArchive: false,
      showSearch: false,
      who_can_read: [],
      who_can_edit: [],
      showEdit: false,
      show_page_id: 0,
      superselectKey: 1,
      section_name: '',
      update_book: null,
      search: {
        input: '',
        items: []
      }
    };
  },
  watch: {
    auth_user_id: function auth_user_id() {
      this.init();
    }
  },
  created: function created() {
    if (this.auth_user_id) {
      this.init();
    }
  },
  methods: {
    searchCheck: function searchCheck() {
      if (this.search.input.length === 0) {
        this.clearSearch();
      }
    },
    clearSearch: function clearSearch() {
      this.search = {
        input: '',
        items: []
      };
    },
    init: function init() {
      this.fetchData();

      // бывор группы
      var urlParams = new URLSearchParams(window.location.search);
      var section = urlParams.get('s');
      if (section) {
        this.selectSection({
          id: section
        });
      }
    },
    fetchData: function fetchData() {
      var _this = this;
      this.axios.get('/kb/get', {}).then(function (response) {
        _this.books = response.data.books;
      })["catch"](function (error) {
        alert(error);
      });
    },
    get_settings: function get_settings() {
      var _this2 = this;
      this.axios.post('/settings/get', {
        type: 'kb'
      }).then(function (response) {
        _this2.send_notification_after_edit = response.data.settings.send_notification_after_edit;
        _this2.show_page_from_kb_everyday = response.data.settings.show_page_from_kb_everyday;
        _this2.allow_save_kb_without_test = response.data.settings.allow_save_kb_without_test;
        _this2.showBookSettings = true;
      })["catch"](function (error) {
        alert(error);
      });
    },
    save_settings: function save_settings() {
      var _this3 = this;
      this.axios.post('/settings/save', {
        type: 'kb',
        send_notification_after_edit: this.send_notification_after_edit,
        show_page_from_kb_everyday: this.show_page_from_kb_everyday,
        allow_save_kb_without_test: this.allow_save_kb_without_test
      }).then(function () {
        _this3.showBookSettings = false;
      })["catch"](function (error) {
        alert(error);
      });
    },
    selectSection: function selectSection(book) {
      var _this4 = this;
      var page_id = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      this.axios.post('kb/tree', {
        id: book.id
      }).then(function (response) {
        if (response.data.error) {
          _this4.$toast.info('Раздел не найден');
        }
        _this4.trees = response.data.trees;
        _this4.activeBook = response.data.book;
        _this4.show_page_id = page_id;
        _this4.showSearch = false;
        _this4.search.input = '';
        _this4.search.items = [];
        // change URL
        var urlParams = new URLSearchParams(window.location.search);
        var b = urlParams.get('b');
        var uri = '/kb?s=' + book.id;
        if (b) uri += '&b=' + b;
        window.history.replaceState({}, 'База знаний', uri);
      })["catch"](function (error) {
        alert(error);
      });
    },
    deleteSection: function deleteSection(i) {
      var _this5 = this;
      if (confirm('Вы уверены что хотите архивировать раздел?')) {
        this.axios.post('/kb/page/delete-section', {
          id: this.books[i].id
        }).then(function () {
          _this5.books.splice(i, 1);
          _this5.$toast.success('Удалено');
        });
      }
    },
    restoreSection: function restoreSection(i) {
      var _this6 = this;
      if (confirm('Вы уверены что хотите восстановить раздел?')) {
        this.axios.post('/kb/page/restore-section', {
          id: this.archived_books[i].id
        }).then(function () {
          _this6.books.push(_this6.archived_books[i]);
          _this6.archived_books.splice(i, 1);
          _this6.$toast.success('Восстановлен');
        });
      }
    },
    back: function back() {
      if (!this.can_edit) {
        this.mode = 'read';
        this.clearSearch();
      }
      this.activeBook = null;
      window.history.replaceState({
        id: '100'
      }, 'База знаний', '/kb');
    },
    searchInput: function searchInput() {
      var _this7 = this;
      if (this.search.input.length <= 2) return null;
      this.axios.post('kb/search', {
        text: this.search.input
      }).then(function (response) {
        _this7.search.items = response.data.items;
        _this7.emphasizeTexts();
      })["catch"](function (error) {
        alert(error);
      });
    },
    emphasizeTexts: function emphasizeTexts() {
      var _this8 = this;
      this.search.items.forEach(function (item) {
        item.text = item.text.replace(new RegExp(_this8.search.input, 'gi'), '<b>' + _this8.search.input + '</b>');
      });
    },
    editAccess: function editAccess(book) {
      var _this9 = this;
      this.showEdit = true;
      this.update_book = book;
      this.axios.post('/kb/page/get-access', {
        id: book.id
      }).then(function (response) {
        _this9.who_can_edit = response.data.who_can_edit;
        _this9.who_can_read = response.data.who_can_read;
        _this9.superselectKey++;
      })["catch"](function (error) {
        alert(error);
      });
    },
    addSection: function addSection() {
      var _this10 = this;
      if (this.section_name.length <= 2) {
        alert('Слишком короткое название!');
        return '';
      }
      var loader = this.$loading.show();
      this.axios.post('/kb/page/add-section', {
        name: this.section_name
      }).then(function (response) {
        _this10.showCreate = false;
        _this10.section_name = '';
        _this10.books.push(response.data);
        _this10.$toast.success('Раздел успешно создан!');
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    getArchivedBooks: function getArchivedBooks() {
      var _this11 = this;
      var loader = this.$loading.show();
      this.axios.get('/kb/get-archived').then(function (response) {
        _this11.archived_books = response.data.books;
        _this11.showArchive = true;
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    updateSection: function updateSection() {
      var _this12 = this;
      if (this.update_book.title.length <= 2) {
        alert('Слишком короткое название!');
        return '';
      }
      var loader = this.$loading.show();
      this.axios.post('/kb/page/update-section', {
        title: this.update_book.title,
        who_can_read: this.who_can_read,
        who_can_edit: this.who_can_edit,
        id: this.update_book.id
      }).then(function () {
        _this12.showEdit = false;
        var index = _this12.books.findIndex(function (b) {
          return b.id == _this12.update_book.id;
        });
        if (index != -1) {
          _this12.books[index].title = _this12.update_book.title;
        }
        _this12.update_book = null;
        _this12.who_can_read = [];
        _this12.who_can_edit = [];
        _this12.$toast.success('Изменения сохранены!');
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    saveOrder: function saveOrder(event) {
      var _this13 = this;
      this.axios.post('/kb/page/save-order', {
        id: event.item.id,
        order: event.newIndex,
        // oldIndex
        parent_id: null
      }).then(function () {
        _this13.$toast.success('Очередь сохранена');
      });
    },
    toggleMode: function toggleMode() {
      this.mode = this.mode == 'read' ? 'edit' : 'read';
      this.clearSearch();
    },
    startChangeOrder: function startChangeOrder() {},
    openGlossary: function openGlossary() {
      this.show_glossary = true;
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".ui-simple-sidebar[data-v-369803ba] {\n  background: rgba(0, 0, 0, 0);\n  width: 100%;\n  height: 100%;\n  left: 0;\n  top: 0;\n  position: fixed;\n  visibility: hidden;\n  transition: 0.3s ease-in-out all;\n  z-index: 101;\n}\n.ui-simple-sidebar-content[data-v-369803ba] {\n  position: absolute;\n  right: -100%;\n  top: 0;\n  border-radius: 12px 0 0 12px;\n  min-height: 450px;\n  background: #fff;\n  z-index: 12;\n  box-shadow: -10px 0px 60px -40px rgba(45, 50, 90, 0.1), 0px 0px 3px 0px rgba(0, 0, 0, 0.05);\n  transition: 0.3s ease-in-out all;\n  overflow: auto;\n}\n.ui-simple-sidebar.is-open[data-v-369803ba] {\n  visibility: visible;\n  background: rgba(0, 0, 0, 0.45);\n}\n.ui-simple-sidebar.is-open .ui-simple-sidebar-content[data-v-369803ba] {\n  right: 60px;\n}\n.ui-simple-sidebar .ui-simple-sidebar-header[data-v-369803ba] {\n  padding: 30px 25px 15px 25px;\n}\n.ui-simple-sidebar .ui-simple-sidebar-header .ui-simple-sidebar-title[data-v-369803ba] {\n  color: #0A1323;\n  font-size: 18px;\n  margin: 0;\n  font-weight: 700;\n}\n.ui-simple-sidebar .ui-simple-sidebar-body[data-v-369803ba] {\n  overflow: auto;\n  max-height: calc(100vh - 135px);\n  min-height: calc(100vh - 135px);\n  padding: 15px 25px 25px 25px;\n}\n.ui-simple-sidebar .ui-simple-sidebar-footer[data-v-369803ba] {\n  min-height: 65px;\n  padding: 15px 25px;\n  border-top: 1px solid #ddd;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".form-search-kb {\n  position: relative;\n  margin-bottom: 10px;\n}\n.form-search-kb .fa-search {\n  position: absolute;\n  top: 10px;\n  left: 10px;\n  color: #bdcadf;\n}\n.form-search-kb input {\n  padding: 0 35px !important;\n}\n.form-search-kb .search-clear {\n  position: absolute;\n  top: 8px;\n  right: 12px;\n  font-style: normal;\n  font-size: 16px;\n  line-height: 1;\n  color: red;\n  cursor: pointer;\n}\n.search-content .search-item {\n  margin-bottom: 10px;\n  border-bottom: 1px solid #ddd;\n  padding: 3px 5px 10px 5px;\n  font-size: 14px;\n  cursor: pointer;\n}\n.search-content .search-item:hover {\n  background-color: #f2f2f2;\n}\n.search-content .search-item-book {\n  color: #1272aa;\n}\n.search-content .search-item-title {\n  font-size: 16px;\n  color: #666;\n  font-weight: 700;\n}\n.search-content .search-item-text {\n  font-size: 12px;\n  color: #999;\n  margin-top: 5px;\n}\n.search-content .search-item b {\n  color: #333;\n  background-color: yellow;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_KBPage_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KBPage.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_KBPage_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_KBPage_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/Glossary.vue":
/*!**********************************************!*\
  !*** ./resources/js/components/Glossary.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Glossary_vue_vue_type_template_id_08772089___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Glossary.vue?vue&type=template&id=08772089& */ "./resources/js/components/Glossary.vue?vue&type=template&id=08772089&");
/* harmony import */ var _Glossary_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Glossary.vue?vue&type=script&lang=js& */ "./resources/js/components/Glossary.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Glossary_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Glossary_vue_vue_type_template_id_08772089___WEBPACK_IMPORTED_MODULE_0__.render,
  _Glossary_vue_vue_type_template_id_08772089___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/Glossary.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue":
/*!******************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& */ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&");
/* harmony import */ var _SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SimpleSidebar.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&");
/* harmony import */ var _SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& */ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "369803ba",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/SimpleSidebar.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/KBPage.vue":
/*!***************************************!*\
  !*** ./resources/js/pages/KBPage.vue ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _KBPage_vue_vue_type_template_id_2827202f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./KBPage.vue?vue&type=template&id=2827202f& */ "./resources/js/pages/KBPage.vue?vue&type=template&id=2827202f&");
/* harmony import */ var _KBPage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./KBPage.vue?vue&type=script&lang=js& */ "./resources/js/pages/KBPage.vue?vue&type=script&lang=js&");
/* harmony import */ var _KBPage_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./KBPage.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/KBPage.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _KBPage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _KBPage_vue_vue_type_template_id_2827202f___WEBPACK_IMPORTED_MODULE_0__.render,
  _KBPage_vue_vue_type_template_id_2827202f___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/KBPage.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/Glossary.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/components/Glossary.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Glossary_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Glossary.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Glossary.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Glossary_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/KBPage.vue?vue&type=script&lang=js&":
/*!****************************************************************!*\
  !*** ./resources/js/pages/KBPage.vue?vue&type=script&lang=js& ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KBPage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KBPage.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KBPage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&":
/*!****************************************************************************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/KBPage.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************!*\
  !*** ./resources/js/pages/KBPage.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_KBPage_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KBPage.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/Glossary.vue?vue&type=template&id=08772089&":
/*!*****************************************************************************!*\
  !*** ./resources/js/components/Glossary.vue?vue&type=template&id=08772089& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Glossary_vue_vue_type_template_id_08772089___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Glossary_vue_vue_type_template_id_08772089___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Glossary_vue_vue_type_template_id_08772089___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Glossary.vue?vue&type=template&id=08772089& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Glossary.vue?vue&type=template&id=08772089&");


/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/KBPage.vue?vue&type=template&id=2827202f&":
/*!**********************************************************************!*\
  !*** ./resources/js/pages/KBPage.vue?vue&type=template&id=2827202f& ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KBPage_vue_vue_type_template_id_2827202f___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KBPage_vue_vue_type_template_id_2827202f___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KBPage_vue_vue_type_template_id_2827202f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KBPage.vue?vue&type=template&id=2827202f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=template&id=2827202f&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Glossary.vue?vue&type=template&id=08772089&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Glossary.vue?vue&type=template&id=08772089& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "glossary" },
    [
      _c("div", { staticClass: "buttons d-flex mb-3" }, [
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.searchText,
              expression: "searchText",
            },
          ],
          staticClass: "search form-control form-control-sm",
          attrs: { type: "text" },
          domProps: { value: _vm.searchText },
          on: {
            input: function ($event) {
              if ($event.target.composing) {
                return
              }
              _vm.searchText = $event.target.value
            },
          },
        }),
        _vm._v(" "),
        _vm.mode == "edit"
          ? _c("button", { staticClass: "btn", on: { click: _vm.add } }, [
              _vm._v("\n\t\t\tДобавить\n\t\t"),
            ])
          : _vm._e(),
      ]),
      _vm._v(" "),
      _vm._l(_vm.filteredWords, function (word, i) {
        return _c("div", { key: i, staticClass: "block" }, [
          _c("div", { staticClass: "word" }, [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: word.word,
                  expression: "word.word",
                },
              ],
              staticClass: "form-control",
              attrs: { type: "text", disabled: _vm.mode == "read" },
              domProps: { value: word.word },
              on: {
                input: function ($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.$set(word, "word", $event.target.value)
                },
              },
            }),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "definition" }, [
            _c("textarea", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: word.definition,
                  expression: "word.definition",
                },
              ],
              staticClass: "form-control",
              attrs: { disabled: _vm.mode == "read" },
              domProps: { value: word.definition },
              on: {
                input: function ($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.$set(word, "definition", $event.target.value)
                },
              },
            }),
          ]),
          _vm._v(" "),
          _vm.mode == "edit"
            ? _c("div", { staticClass: "action d-flex" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-sm",
                    on: {
                      click: function ($event) {
                        return _vm.save(i)
                      },
                    },
                  },
                  [_c("i", { staticClass: "fa fa-save" })]
                ),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-sm ml-2",
                    on: {
                      click: function ($event) {
                        return _vm.deleteWord(i)
                      },
                    },
                  },
                  [_c("i", { staticClass: "fa fa-trash" })]
                ),
              ])
            : _vm._e(),
        ])
      }),
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "ui-simple-sidebar",
      class: [{ "is-open": _vm.open }],
      on: {
        click: function ($event) {
          if ($event.target !== $event.currentTarget) {
            return null
          }
          return _vm.$emit("close")
        },
      },
    },
    [
      _c(
        "div",
        {
          staticClass: "ui-simple-sidebar-content",
          style: "width:" + _vm.width,
        },
        [
          _c("div", { staticClass: "ui-simple-sidebar-header" }, [
            _c("p", { staticClass: "ui-simple-sidebar-title" }, [
              _vm._v("\n\t\t\t\t" + _vm._s(_vm.title) + "\n\t\t\t"),
            ]),
            _vm._v(" "),
            _c("span", { domProps: { innerHTML: _vm._s(_vm.link) } }),
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "ui-simple-sidebar-body" },
            [_vm._t("body")],
            2
          ),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "ui-simple-sidebar-footer" },
            [_vm._t("footer")],
            2
          ),
        ]
      ),
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=template&id=2827202f&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/KBPage.vue?vue&type=template&id=2827202f& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.auth_user_id
    ? _c(
        "div",
        [
          _vm.activeBook === null
            ? _c("div", { staticClass: "kb-sections d-flex" }, [
                _c(
                  "aside",
                  { staticClass: "lp", attrs: { id: "left-panel" } },
                  [
                    _c("div", { staticClass: "form-search-kb" }, [
                      _c("i", { staticClass: "fa fa-search" }),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.search.input,
                            expression: "search.input",
                          },
                        ],
                        staticClass: "form-control",
                        attrs: {
                          type: "text",
                          placeholder: "Искать в базе...",
                        },
                        domProps: { value: _vm.search.input },
                        on: {
                          input: [
                            function ($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(_vm.search, "input", $event.target.value)
                            },
                            _vm.searchInput,
                          ],
                          blur: _vm.searchCheck,
                        },
                      }),
                      _vm._v(" "),
                      _vm.search.input.length
                        ? _c(
                            "i",
                            {
                              staticClass: "search-clear",
                              on: { click: _vm.clearSearch },
                            },
                            [_vm._v("x")]
                          )
                        : _vm._e(),
                    ]),
                    _vm._v(" "),
                    _vm.activeBook === null
                      ? _c(
                          "div",
                          {
                            staticClass: "btn btn-grey mb-3",
                            on: { click: _vm.openGlossary },
                          },
                          [_c("span", [_vm._v("Глоссарий")])]
                        )
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.showArchive
                      ? _c(
                          "div",
                          {
                            staticClass: "btn btn-grey mb-3",
                            on: {
                              click: function ($event) {
                                _vm.showArchive = false
                              },
                            },
                          },
                          [
                            _c("i", { staticClass: "fa fa-arrow-left" }),
                            _vm._v(" "),
                            _c("span", [_vm._v("Выйти из архива")]),
                          ]
                        )
                      : _vm._e(),
                    _vm._v(" "),
                    !_vm.showArchive
                      ? _c(
                          "div",
                          {
                            staticClass: "sections-wrap noscrollbar",
                            class: { expand: _vm.mode == "read" },
                          },
                          [
                            _c(
                              "div",
                              { staticClass: "search-content" },
                              [
                                _vm.search.items.length
                                  ? _vm._l(_vm.search.items, function (item) {
                                      return _c(
                                        "div",
                                        {
                                          key: item.id,
                                          staticClass: "search-item",
                                          on: {
                                            click: function ($event) {
                                              return _vm.selectSection(
                                                item.book,
                                                item.id
                                              )
                                            },
                                          },
                                        },
                                        [
                                          item.book
                                            ? _c(
                                                "p",
                                                {
                                                  staticClass:
                                                    "search-item-book",
                                                },
                                                [
                                                  _vm._v(
                                                    "\n\t\t\t\t\t\t\t\t" +
                                                      _vm._s(item.book.title) +
                                                      "\n\t\t\t\t\t\t\t"
                                                  ),
                                                ]
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          _c(
                                            "p",
                                            {
                                              staticClass: "search-item-title",
                                            },
                                            [
                                              _vm._v(
                                                "\n\t\t\t\t\t\t\t\t" +
                                                  _vm._s(item.title) +
                                                  "\n\t\t\t\t\t\t\t"
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c("div", {
                                            staticClass: "search-item-text",
                                            domProps: {
                                              innerHTML: _vm._s(item.text),
                                            },
                                          }),
                                        ]
                                      )
                                    })
                                  : _vm.search.input.length <= 2 &&
                                    _vm.search.input.length !== 0
                                  ? _c("div", { staticClass: "text-muted" }, [
                                      _vm._v(
                                        "\n\t\t\t\t\t\tВведите минимум 3 символа\n\t\t\t\t\t"
                                      ),
                                    ])
                                  : _vm.search.input.length > 2
                                  ? _c("div", { staticClass: "text-muted" }, [
                                      _vm._v(
                                        "\n\t\t\t\t\t\tНичего не найдено\n\t\t\t\t\t"
                                      ),
                                    ])
                                  : _vm._e(),
                              ],
                              2
                            ),
                            _vm._v(" "),
                            !_vm.search.items.length && !_vm.search.input.length
                              ? _c(
                                  "Draggable",
                                  {
                                    staticClass: "dragArea ml-0",
                                    attrs: {
                                      id: null,
                                      tag: "div",
                                      handle: ".fa-bars",
                                      list: _vm.books,
                                      group: { name: "g1" },
                                    },
                                    on: {
                                      start: _vm.startChangeOrder,
                                      end: _vm.saveOrder,
                                    },
                                  },
                                  [
                                    _vm._l(_vm.books, function (book, b_index) {
                                      return [
                                        _c(
                                          "div",
                                          {
                                            key: book.id,
                                            staticClass:
                                              "section d-flex aic jcsb",
                                            attrs: { id: book.id },
                                            on: {
                                              click: function ($event) {
                                                $event.stopPropagation()
                                                return _vm.selectSection(book)
                                              },
                                            },
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "d-flex aic" },
                                              [
                                                _vm.mode == "edit"
                                                  ? _c("i", {
                                                      staticClass:
                                                        "fa fa-bars mover mr-2",
                                                    })
                                                  : _vm._e(),
                                                _vm._v(" "),
                                                _c("p", [
                                                  _vm._v(_vm._s(book.title)),
                                                ]),
                                              ]
                                            ),
                                            _vm._v(" "),
                                            _vm.mode == "edit"
                                              ? _c(
                                                  "div",
                                                  {
                                                    staticClass: "section-btns",
                                                  },
                                                  [
                                                    _c("i", {
                                                      staticClass:
                                                        "fa fa-trash mr-1",
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          $event.stopPropagation()
                                                          return _vm.deleteSection(
                                                            b_index
                                                          )
                                                        },
                                                      },
                                                    }),
                                                    _vm._v(" "),
                                                    _c("i", {
                                                      staticClass: "fa fa-cog ",
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          $event.stopPropagation()
                                                          return _vm.editAccess(
                                                            book
                                                          )
                                                        },
                                                      },
                                                    }),
                                                  ]
                                                )
                                              : _vm._e(),
                                          ]
                                        ),
                                      ]
                                    }),
                                  ],
                                  2
                                )
                              : _vm._e(),
                          ],
                          1
                        )
                      : _c(
                          "div",
                          { staticClass: "sections-wrap noscrollbar" },
                          [
                            _vm._l(
                              _vm.archived_books,
                              function (book, b_index) {
                                return [
                                  _vm.can_edit
                                    ? _c(
                                        "div",
                                        {
                                          key: b_index,
                                          staticClass:
                                            "section d-flex aic jcsb",
                                          on: {
                                            click: function ($event) {
                                              $event.stopPropagation()
                                              return _vm.selectSection(book)
                                            },
                                          },
                                        },
                                        [
                                          _c("p", [_vm._v(_vm._s(book.title))]),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            { staticClass: "section-btns" },
                                            [
                                              _c("i", {
                                                staticClass:
                                                  "fa fa-trash-restore mr-1",
                                                on: {
                                                  click: function ($event) {
                                                    $event.stopPropagation()
                                                    return _vm.restoreSection(
                                                      b_index
                                                    )
                                                  },
                                                },
                                              }),
                                            ]
                                          ),
                                        ]
                                      )
                                    : _vm._e(),
                                ]
                              }
                            ),
                          ],
                          2
                        ),
                    _vm._v(" "),
                    _vm.mode == "edit"
                      ? _c("div", [
                          !_vm.showArchive
                            ? _c("div", { staticClass: "d-flex jscb" }, [
                                _vm.can_edit
                                  ? _c(
                                      "div",
                                      {
                                        staticClass: "btn btn-grey w-full mr-1",
                                        on: {
                                          click: function ($event) {
                                            _vm.showCreate = true
                                          },
                                        },
                                      },
                                      [
                                        _c("i", { staticClass: "fa fa-plus" }),
                                        _vm._v(" "),
                                        _c("span", [_vm._v("Добавить")]),
                                      ]
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.can_edit
                                  ? _c(
                                      "div",
                                      {
                                        staticClass: "btn btn-grey",
                                        attrs: { title: "Архив" },
                                        on: { click: _vm.getArchivedBooks },
                                      },
                                      [_c("i", { staticClass: "fa fa-box" })]
                                    )
                                  : _vm._e(),
                              ])
                            : _vm._e(),
                        ])
                      : _vm._e(),
                  ]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass: "rp",
                    staticStyle: { flex: "1 1 0%", "padding-bottom": "50px" },
                  },
                  [
                    _c("div", { staticClass: "hat" }, [
                      _c(
                        "div",
                        {
                          staticClass: "d-flex jsutify-content-between hat-top",
                        },
                        [
                          _vm._m(0),
                          _vm._v(" "),
                          _c("div", { staticClass: "control-btns d-flex" }, [
                            _vm.can_edit
                              ? _c(
                                  "div",
                                  { staticClass: "mode_changer mr-2" },
                                  [
                                    _c("i", {
                                      directives: [
                                        {
                                          name: "b-popover",
                                          rawName: "v-b-popover.hover.top",
                                          value:
                                            "Включить редактирование Базы знаний",
                                          expression:
                                            "'Включить редактирование Базы знаний'",
                                          modifiers: { hover: true, top: true },
                                        },
                                      ],
                                      staticClass: "fa fa-pen",
                                      class: { active: _vm.mode == "edit" },
                                      on: { click: _vm.toggleMode },
                                    }),
                                  ]
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            _vm.can_edit
                              ? _c("div", { staticClass: "mode_changer" }, [
                                  _c("i", {
                                    staticClass: "icon-nd-settings",
                                    on: {
                                      click: function ($event) {
                                        return _vm.get_settings()
                                      },
                                    },
                                  }),
                                ])
                              : _vm._e(),
                          ]),
                        ]
                      ),
                      _vm._v(" "),
                      _c("div"),
                    ]),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "content mt-3" },
                      [
                        _vm.show_glossary
                          ? _c("Glossary", { attrs: { mode: _vm.mode } })
                          : _vm._e(),
                      ],
                      1
                    ),
                  ]
                ),
              ])
            : _vm._e(),
          _vm._v(" "),
          _vm.activeBook
            ? _c(
                "div",
                [
                  _c("Booklist", {
                    ref: "booklist",
                    attrs: {
                      trees: _vm.trees,
                      can_edit: _vm.activeBook.access == 2 || _vm.can_edit,
                      parent_name: _vm.activeBook.title,
                      parent_id: _vm.activeBook.id,
                      show_page_id: _vm.show_page_id,
                      course_item_id: 0,
                      mode: _vm.mode,
                      enable_url_manipulation: true,
                      auth_user_id: _vm.auth_user_id,
                    },
                    on: { back: _vm.back, toggleMode: _vm.toggleMode },
                  }),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              staticClass: "modalle",
              attrs: { title: "Новый раздел", size: "md", "hide-footer": "" },
              model: {
                value: _vm.showCreate,
                callback: function ($$v) {
                  _vm.showCreate = $$v
                },
                expression: "showCreate",
              },
            },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.section_name,
                    expression: "section_name",
                  },
                ],
                staticClass: "form-control mb-2",
                attrs: { type: "text", placeholder: "Название раздела..." },
                domProps: { value: _vm.section_name },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.section_name = $event.target.value
                  },
                },
              }),
              _vm._v(" "),
              _c(
                "button",
                {
                  staticClass: "btn btn-primary rounded m-auto",
                  on: { click: _vm.addSection },
                },
                [_c("span", [_vm._v("Сохранить")])]
              ),
            ]
          ),
          _vm._v(" "),
          _c("SimpleSidebar", {
            attrs: {
              title: "Настройки базы знаний",
              open: _vm.showBookSettings,
              width: "400px",
            },
            on: {
              close: function ($event) {
                _vm.showBookSettings = false
              },
            },
            scopedSlots: _vm._u(
              [
                {
                  key: "body",
                  fn: function () {
                    return [
                      _c("label", { staticClass: "d-flex mb-2" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.send_notification_after_edit,
                              expression: "send_notification_after_edit",
                            },
                          ],
                          staticClass: "form- mb-2 mr-2",
                          attrs: { type: "checkbox" },
                          domProps: {
                            checked: Array.isArray(
                              _vm.send_notification_after_edit
                            )
                              ? _vm._i(_vm.send_notification_after_edit, null) >
                                -1
                              : _vm.send_notification_after_edit,
                          },
                          on: {
                            change: function ($event) {
                              var $$a = _vm.send_notification_after_edit,
                                $$el = $event.target,
                                $$c = $$el.checked ? true : false
                              if (Array.isArray($$a)) {
                                var $$v = null,
                                  $$i = _vm._i($$a, $$v)
                                if ($$el.checked) {
                                  $$i < 0 &&
                                    (_vm.send_notification_after_edit =
                                      $$a.concat([$$v]))
                                } else {
                                  $$i > -1 &&
                                    (_vm.send_notification_after_edit = $$a
                                      .slice(0, $$i)
                                      .concat($$a.slice($$i + 1)))
                                }
                              } else {
                                _vm.send_notification_after_edit = $$c
                              }
                            },
                          },
                        }),
                        _vm._v(" "),
                        _c("p", [
                          _vm._v(
                            "Отправлять уведомления сотрудникам об изменениях в базе знаний"
                          ),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c("label", { staticClass: "d-flex mb-2" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.show_page_from_kb_everyday,
                              expression: "show_page_from_kb_everyday",
                            },
                          ],
                          staticClass: "form- mb-2 mr-2",
                          attrs: { type: "checkbox" },
                          domProps: {
                            checked: Array.isArray(
                              _vm.show_page_from_kb_everyday
                            )
                              ? _vm._i(_vm.show_page_from_kb_everyday, null) >
                                -1
                              : _vm.show_page_from_kb_everyday,
                          },
                          on: {
                            change: function ($event) {
                              var $$a = _vm.show_page_from_kb_everyday,
                                $$el = $event.target,
                                $$c = $$el.checked ? true : false
                              if (Array.isArray($$a)) {
                                var $$v = null,
                                  $$i = _vm._i($$a, $$v)
                                if ($$el.checked) {
                                  $$i < 0 &&
                                    (_vm.show_page_from_kb_everyday =
                                      $$a.concat([$$v]))
                                } else {
                                  $$i > -1 &&
                                    (_vm.show_page_from_kb_everyday = $$a
                                      .slice(0, $$i)
                                      .concat($$a.slice($$i + 1)))
                                }
                              } else {
                                _vm.show_page_from_kb_everyday = $$c
                              }
                            },
                          },
                        }),
                        _vm._v(" "),
                        _c("p", [
                          _vm._v(
                            'Показывать одну из страниц базы знаний каждый день, после нажатия на кнопку "начать рабочий день"'
                          ),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c("label", { staticClass: "d-flex mb-2" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.allow_save_kb_without_test,
                              expression: "allow_save_kb_without_test",
                            },
                          ],
                          staticClass: "form- mb-2 mr-2",
                          attrs: { type: "checkbox" },
                          domProps: {
                            checked: Array.isArray(
                              _vm.allow_save_kb_without_test
                            )
                              ? _vm._i(_vm.allow_save_kb_without_test, null) >
                                -1
                              : _vm.allow_save_kb_without_test,
                          },
                          on: {
                            change: function ($event) {
                              var $$a = _vm.allow_save_kb_without_test,
                                $$el = $event.target,
                                $$c = $$el.checked ? true : false
                              if (Array.isArray($$a)) {
                                var $$v = null,
                                  $$i = _vm._i($$a, $$v)
                                if ($$el.checked) {
                                  $$i < 0 &&
                                    (_vm.allow_save_kb_without_test =
                                      $$a.concat([$$v]))
                                } else {
                                  $$i > -1 &&
                                    (_vm.allow_save_kb_without_test = $$a
                                      .slice(0, $$i)
                                      .concat($$a.slice($$i + 1)))
                                }
                              } else {
                                _vm.allow_save_kb_without_test = $$c
                              }
                            },
                          },
                        }),
                        _vm._v(" "),
                        _c("p", [
                          _vm._v(
                            "Разрешить вносить изменения без тестовых вопросов в разделах базы знаний"
                          ),
                        ]),
                      ]),
                    ]
                  },
                  proxy: true,
                },
                {
                  key: "footer",
                  fn: function () {
                    return [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-primary rounded m-auto",
                          on: {
                            click: function ($event) {
                              return _vm.save_settings()
                            },
                          },
                        },
                        [_vm._v("\n\t\t\t\tСохранить\n\t\t\t")]
                      ),
                    ]
                  },
                  proxy: true,
                },
              ],
              null,
              false,
              728017959
            ),
          }),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                title: "Редактирование раздела",
                size: "md",
                "dialog-class": "modallxe",
                "hide-footer": "",
              },
              model: {
                value: _vm.showEdit,
                callback: function ($$v) {
                  _vm.showEdit = $$v
                },
                expression: "showEdit",
              },
            },
            [
              _vm.update_book != null
                ? _c("div", [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.update_book.title,
                          expression: "update_book.title",
                        },
                      ],
                      staticClass: "form-control mb-2",
                      attrs: {
                        type: "text",
                        placeholder: "Название раздела...",
                      },
                      domProps: { value: _vm.update_book.title },
                      on: {
                        input: function ($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.update_book,
                            "title",
                            $event.target.value
                          )
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c(
                      "div",
                      { key: _vm.superselectKey },
                      [
                        _c("p", { staticClass: "mb-2" }, [
                          _vm._v("\n\t\t\t\t\tКто может видеть\n\t\t\t\t"),
                        ]),
                        _vm._v(" "),
                        _c("SuperSelect", {
                          staticClass: "w-full mb-4",
                          attrs: {
                            values: _vm.who_can_read,
                            select_all_btn: true,
                          },
                        }),
                        _vm._v(" "),
                        _c("p", { staticClass: "mb-2" }, [
                          _vm._v(
                            "\n\t\t\t\t\tКто может редактировать\n\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("SuperSelect", {
                          staticClass: "w-full mb-4",
                          attrs: {
                            values: _vm.who_can_edit,
                            select_all_btn: true,
                          },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-primary rounded m-auto",
                        on: { click: _vm.updateSection },
                      },
                      [_c("span", [_vm._v("Сохранить")])]
                    ),
                  ])
                : _vm._e(),
            ]
          ),
        ],
        1
      )
    : _vm._e()
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "bc" }, [
      _c("a", { attrs: { href: "#" } }, [_vm._v("База знаний")]),
    ])
  },
]
render._withStripped = true



/***/ })

}]);