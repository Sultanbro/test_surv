"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["AnalyticsPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @icons */ "./resources/js/components/ui/Icons/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */


var Parser = (__webpack_require__(/*! expr-eval */ "./node_modules/expr-eval/dist/index.mjs").Parser);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'AnalyticStat',
  components: {
    IconDelete: _icons__WEBPACK_IMPORTED_MODULE_0__.IconDelete,
    ChatIconPlus: _icons__WEBPACK_IMPORTED_MODULE_0__.ChatIconPlus
  },
  props: {
    monthInfo: {
      type: Object,
      "default": null
    },
    table: {
      type: Array,
      "default": null
    },
    activeuserid: {
      type: Number,
      "default": null
    },
    group_id: {
      type: Number,
      "default": null
    },
    fields: {
      type: Array,
      "default": null
    },
    activities: {
      type: Array,
      "default": null
    },
    isAdmin: {
      type: Boolean
    }
  },
  data: function data() {
    return {
      active: '1',
      focused_item: null,
      focused_field: null,
      focused_subfield: null,
      editTableMode: false,
      showVariants: false,
      // activites
      showDependy: false,
      //
      coords: null,
      activity_id: null,
      depend_id: null,
      dependencies: [],
      cell_value: null,
      cell_type: null,
      cell_show_value: null,
      cell_comment: null,
      showFormula1_31: false,
      showCommentWindow: false,
      // for remote/ inhouse add hours
      comment: '',
      // for remote/ inhouse add hours
      comment_i: '',
      // for remote/ inhouse add hours
      comment_f: '',
      // for remote/ inhouse add hours
      depender: [],
      formula_1_31: '',
      formula_1_31_decimals: 0,
      cell_types: {
        initial: 'Обычный',
        formula: 'Формула',
        time: 'Часы из табеля',
        stat: 'Показатели',
        avg: 'Среднее',
        sum: 'Сумма',
        salary: 'Начисления',
        remote: 'Отсутствие remote',
        inhouse: 'Отсутствие inhouse'
      },
      items: [{
        'plan': {
          value: 'testplan',
          show_value: 'x',
          context: false,
          type: 'initial'
        }
      }],
      itemy: null,
      letter_cells: []
    };
  },
  created: function created() {
    this.items = this.fixNameValue(this.table);
    this.form();
    this.calcGlobal();
    this.setDependencies();

    //this.fields = this.columns
  },
  mounted: function mounted() {
    document.addEventListener('keyup', this.nextItem);
    // this.listener()
  },

  methods: {
    fixNameValue: function fixNameValue(items) {
      items.forEach(function (item) {
        if (item.name) {
          if (!item.name.value && item.name.show_value) {
            item.name.value = item.name.show_value;
          }
        }
      });
      return items;
    },
    setDependencies: function setDependencies() {
      var arr = [];
      this.items.forEach(function (item, index) {
        if (![0, 1, 2, 3].includes(index)) {
          arr.push({
            'row_id': item['name']['row_id'],
            'name': index + 1,
            'index': item['name']['value']
          });
        }
      });
      this.dependencies = arr;
      var depender = {};
      this.items.forEach(function (item, index) {
        depender[item['name']['row_id']] = index;
      });
      this.depender = depender;
    },
    editMode: function editMode() {
      this.editTableMode = !this.editTableMode;
    },
    listener: function listener() {
      var ignoreClickOnMeElement = document.getElementById('wow-table');
      var self = this;
      document.addEventListener('click', function (event) {
        var isClickInsideElement = ignoreClickOnMeElement.contains(event.target);
        if (!isClickInsideElement) {
          self.hideContextMenu();
        }
      });
    },
    calc: function calc(combinations) {
      var expression = this.getExpression(combinations);
      var result = 0;
      if (expression !== null && expression.length > 0) {
        try {
          result = Parser.evaluate(expression);
        } catch (error) {
          console.error(error);
        }
      }
      return result;
    },
    add_class: function add_class(item, clasxs) {
      var c = item["class"];
      if (clasxs == 'text-center' && c !== null) {
        item["class"] = item["class"].replace('text-left', '');
        item["class"] = item["class"].replace('text-right', '');
      }
      if (clasxs == 'text-left' && c !== null) {
        item["class"] = item["class"].replace('text-center', '');
        item["class"] = item["class"].replace('text-right', '');
      }
      if (clasxs == 'text-right' && c !== null) {
        item["class"] = item["class"].replace('text-left', '');
        item["class"] = item["class"].replace('text-center', '');
      }
      if (clasxs == 'bg-red' && c !== null) {
        item["class"] = item["class"].replace('bg-yellow', '');
        item["class"] = item["class"].replace('bg-green', '');
        item["class"] = item["class"].replace('bg-blue', '');
        item["class"] = item["class"].replace('bg-violet', '');
      }
      if (clasxs == 'bg-yellow' && c !== null) {
        item["class"] = item["class"].replace('bg-red', '');
        item["class"] = item["class"].replace('bg-green', '');
        item["class"] = item["class"].replace('bg-blue', '');
        item["class"] = item["class"].replace('bg-violet', '');
      }
      if (clasxs == 'bg-green' && c !== null) {
        item["class"] = item["class"].replace('bg-yellow', '');
        item["class"] = item["class"].replace('bg-red', '');
        item["class"] = item["class"].replace('bg-blue', '');
        item["class"] = item["class"].replace('bg-violet', '');
      }
      if (clasxs == 'bg-blue' && c !== null) {
        item["class"] = item["class"].replace('bg-yellow', '');
        item["class"] = item["class"].replace('bg-green', '');
        item["class"] = item["class"].replace('bg-red', '');
        item["class"] = item["class"].replace('bg-violet', '');
      }
      if (clasxs == 'bg-violet' && c !== null) {
        item["class"] = item["class"].replace('bg-yellow', '');
        item["class"] = item["class"].replace('bg-green', '');
        item["class"] = item["class"].replace('bg-blue', '');
        item["class"] = item["class"].replace('bg-red', '');
      }
      if (c !== null && c.includes(clasxs)) {
        item["class"] = item["class"].replace(clasxs, '');
      } else {
        item["class"] = item["class"] + ' ' + clasxs;
      }
      if (item.type == 'formula') {
        item.show_value = item.value;
        var combinations = this.combinator(item.value);
        item.formula = this.getExpression(combinations, 'db');
        item.show_value = this.calc(combinations);
      }
      this.editQueryItem(item);
    },
    calcGlobal: function calcGlobal() {
      var _this = this;
      var items = this.formula_searcher();
      items.forEach(function (it) {
        var combinations = _this.combinator(it.value);
        it.formula = _this.getExpression(combinations, 'db');
        it.show_value = Number(Number(_this.calc(combinations).toFixed(it.decimals)));
      });
    },
    getExpression: function getExpression(combinations) {
      var _this2 = this;
      var type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'local';
      var expression = '';
      if (type == 'local') {
        // для vue
        combinations.forEach(function (item) {
          if (item.type == 'formula') {
            var inner_combinations = _this2.combinator(item.value);
            var inner_calc = 0;
            var inner_item = _this2.searcher(item.text);
            inner_calc = _this2.calc(inner_combinations);
            inner_item.show_value = inner_calc;
            expression += inner_calc;
          } else if (item.type == 'action') {
            expression += item.text;
          } else {
            item.value = Number(item.value);
            expression += !isNaN(item.value) ? item.value : 0;
          }
        });
      }
      if (type == 'db') {
        // для хранения формулы в базе
        combinations.forEach(function (item) {
          if (item.type == 'value') expression += item.value;
          if (item.type == 'cell') expression += item.code;
          if (item.type == 'formula') expression += item.code;
          if (item.type == 'action') expression += item.text;
        });
      }
      return expression;
    },
    add_row: function add_row(i_index) {
      var _this3 = this;
      var loader = this.$loading.show();
      this.axios.post('/timetracking/analytics/add-row', {
        group_id: this.group_id,
        date: this.$moment("".concat(this.monthInfo.currentMonth, " ").concat(this.monthInfo.currentYear), 'MMMM YYYY').format('YYYY-MM-DD'),
        after_row_id: this.items[i_index]['name']['row_id']
      }).then(function (response) {
        _this3.$toast.success('Добавлено');
        _this3.items.splice(i_index + 1, 0, response.data);
        //this.setDependencies();
        loader.hide();
      })["catch"](function (error) {
        _this3.$toast.error('Не получилось');
        console.error(error);
        loader.hide();
      });
    },
    deleteRow: function deleteRow(index) {
      var _this4 = this;
      if (!confirm('Вы уверены?')) return;
      var loader = this.$loading.show();
      this.axios.post('/timetracking/analytics/delete-row', {
        group_id: this.group_id,
        date: this.$moment("".concat(this.monthInfo.currentMonth, " ").concat(this.monthInfo.currentYear), 'MMMM YYYY').format('YYYY-MM-DD'),
        item: this.items[index]
      }).then(function () {
        _this4.$toast.success('Удалено');
        // Delete item from items
        _this4.items.splice(index, 1);
        _this4.setDependencies();
        loader.hide();
      })["catch"](function (error) {
        _this4.$toast.error('Не получилось');
        console.error(error);
        loader.hide();
      });
    },
    save_depend: function save_depend() {
      var _this5 = this;
      this.axios.post('/timetracking/analytics/add-depend', {
        id: this.itemy['row_id'],
        depend_id: this.depend_id
      }).then(function () {
        _this5.$toast.success('Обновите, чтобы подтянуть данные!');
        _this5.showDependy = false;
        _this5.depend_id = null;
        _this5.itemy = null;
      })["catch"](function (error) {
        _this5.$toast.error('Не получилось');
        console.error(error);
      });
    },
    removeDependency: function removeDependency(item) {
      var _this6 = this;
      this.axios.post('/timetracking/analytics/dependency/remove', {
        id: item.row_id
      }).then(function () {
        _this6.$toast.success('Обновите, чтобы подтянуть данные!');
      })["catch"](function (error) {
        _this6.$toast.error('Не получилось');
        console.error(error);
      });
    },
    focus: function focus(i, f) {
      if ([1, 2, 3].includes(i) && f == 0) return '';
      if (!(this.focused_item == i && this.focused_field == f)) {
        this.hideContextMenu();
      }

      // indexes
      this.focused_item = i;
      this.focused_field = f;

      // cell value
      var item = this.items[i][this.fields[f].key];
      this.cell_value = item.value;
      this.cell_comment = item.comment;
      this.cell_type = this.cell_types[item.type];
      this.cell_show_value = item.show_value;
      this.coords = item.cell;
    },
    focusName: function focusName(i, f, s) {
      this.hideContextMenu();
      // indexes
      this.focused_item = i;
      this.focused_field = f;

      // cell value
      this.focused_subfield = s;
      var field = s == 2 ? 'plan' : 'name';
      this.cell_value = this.items[i][field].value;
      this.cell_comment = this.items[i][field].comment;
      this.cell_type = this.cell_types[this.items[i][field].type];
      this.coords = this.items[i][field].cell;
    },
    hideContextMenu: function hideContextMenu() {
      this.items.forEach(function (item) {
        Object.values(item).forEach(function (value) {
          value.context = false;
        });
      });
    },
    openContextMenu: function openContextMenu(item, i_index, f_index) {
      if (!this.isAdmin) return;
      this.focus(i_index, f_index);
      this.hideContextMenu();
      item.context = true;
      this.$nextTick(function () {
        var cellName = i_index + '-' + f_index;
        var cell = document.querySelector("[data-an-cell=\"".concat(cellName, "\"]"));
        var context = document.querySelector("[data-an-context=\"".concat(cellName, "\"]"));
        if (!cell) return;
        if (!context) return;
        var parent = cell.closest('.AnalyticStat-tables');
        if (!parent) return;
        var cellRect = cell.getBoundingClientRect();
        var parentRect = parent.getBoundingClientRect();
        var pos = {
          top: cellRect.top - parentRect.top + parseInt(cell.clientHeight / 2),
          left: cellRect.left - parentRect.left + parseInt(cell.clientWidth / 2)
        };

        // корректировка left если уходит за предели предка
        if (pos.left + context.clientWidth > parent.clientWidth) {
          pos.left -= context.clientWidth;
        }
        context.style.top = pos.top + 'px';
        context.style.left = pos.left + 'px';
      });
    },
    editQuery: function editQuery(i_index, f_index) {
      var _this7 = this;
      var item = this.items[i_index][f_index];
      this.axios.post('/timetracking/analytics/edit-stat', {
        date: this.$moment("".concat(this.monthInfo.currentMonth, " ").concat(this.monthInfo.currentYear), 'MMMM YYYY').format('YYYY-MM-DD'),
        column_id: item.column_id,
        row_id: item.row_id,
        value: item.value,
        show_value: item.show_value,
        type: item.type,
        group_id: this.group_id,
        "class": item["class"],
        formula: item.formula,
        comment: this.comment
      }).then(function () {
        _this7.showCommentWindow = false;
        _this7.comment_i = '';
        _this7.comment_f = '';
        _this7.$toast.success('Сохранено');
      })["catch"](function (error) {
        _this7.$toast.error('Не сохранено');
        console.error(error);
      });
    },
    save_cell_time: function save_cell_time() {
      var _this8 = this;
      var loader = this.$loading.show();
      var item = this.item;
      this.axios.post('/timetracking/analytics/save-cell-time', {
        month: this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M'),
        year: this.monthInfo.currentYear,
        column_id: item.column_id,
        row_id: item.row_id,
        group_id: this.group_id,
        "class": item["class"]
      }).then(function () {
        _this8.$toast.success('Обновите чтобы подтянуть данные!');
        _this8.item = null;
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        _this8.$toast.error('Ошибка!');
        alert(error);
      });
    },
    save_cell_sum: function save_cell_sum() {
      var _this9 = this;
      var loader = this.$loading.show();
      var item = this.item;
      this.axios.post('/timetracking/analytics/save-cell-sum', {
        month: this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M'),
        year: this.monthInfo.currentYear,
        column_id: item.column_id,
        row_id: item.row_id,
        group_id: this.group_id,
        "class": item["class"]
      }).then(function (response) {
        _this9.$toast.success('Сумма подтянута!');
        _this9.item.value = response.data;
        _this9.item.show_value = response.data;
        _this9.item = null;
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        _this9.$toast.error('Ошибка!');
        alert(error);
      });
    },
    save_cell_avg: function save_cell_avg() {
      var _this10 = this;
      var loader = this.$loading.show();
      var item = this.item;
      this.axios.post('/timetracking/analytics/save-cell-avg', {
        month: this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M'),
        year: this.monthInfo.currentYear,
        column_id: item.column_id,
        row_id: item.row_id,
        group_id: this.group_id,
        "class": item["class"]
      }).then(function (response) {
        _this10.$toast.success('Среднее за месяц подтянута!');
        _this10.item.value = response.data;
        _this10.item.show_value = response.data;
        _this10.item = null;
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        _this10.$toast.error('Ошибка!');
        alert(error);
      });
    },
    save_cell_activity: function save_cell_activity() {
      var _this11 = this;
      var loader = this.$loading.show();
      var item = this.item;
      this.axios.post('/timetracking/analytics/save-cell-activity', {
        month: this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M'),
        year: this.monthInfo.currentYear,
        column_id: item.column_id,
        row_id: item.row_id,
        value: item.value,
        show_value: item.show_value,
        group_id: this.group_id,
        type: item.type,
        "class": item["class"],
        formula: item.formula,
        activity_id: this.activity_id
      }).then(function () {
        _this11.$toast.success('Обновите чтобы подтянуть данные!');
        _this11.item = null;
        _this11.showVariants = false;
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        _this11.$toast.error('Ошибка!');
        alert(error);
      });
    },
    editQueryItem: function editQueryItem(item) {
      var _this12 = this;
      this.axios.post('/timetracking/analytics/edit-stat', {
        date: this.$moment("".concat(this.monthInfo.currentMonth, " ").concat(this.monthInfo.currentYear), 'MMMM YYYY').format('YYYY-MM-DD'),
        column_id: item.column_id,
        row_id: item.row_id,
        value: item.value,
        show_value: item.show_value,
        type: item.type,
        "class": item["class"],
        formula: item.formula,
        group_id: this.group_id
      }).then(function () {
        _this12.$toast.success('Сохранено');
      })["catch"](function (error) {
        _this12.$toast.error('Не сохранено');
        console.error(error);
      });
    },
    change_type: function change_type(type, i_index, f_index) {
      var item = this.items[i_index][f_index];
      item.type = type;
      if (item.type == 'initial') {
        item.show_value = item.value;
        this.calcGlobal();
        this.editQuery(i_index, f_index);
      }
      if (item.type == 'formula') {
        item.show_value = item.value;
        var combinations = this.combinator(item.value);
        item.formula = this.getExpression(combinations, 'db');
        item.show_value = this.calc(combinations);
        this.calcGlobal();
        this.editQuery(i_index, f_index);
      }
      if (item.type == 'time') {
        this.item = item;
        this.save_cell_time();
      }
      if (item.type == 'sum') {
        this.item = item;
        this.save_cell_sum();
      }
      if (item.type == 'avg') {
        this.item = item;
        this.save_cell_avg();
      }
      if (item.type == 'stat') {
        this.item = item;
        this.showVariants = true;
      }
    },
    selectDepend: function selectDepend(item) {
      this.itemy = item;
      this.showDependy = true;
    },
    add_formula_1_31: function add_formula_1_31(item) {
      this.itemy = item;
      this.showFormula1_31 = true;
    },
    add_inhouse: function add_inhouse(item) {
      var _this13 = this;
      this.itemy = item;
      this.axios.post('/timetracking/analytics/add-remote-inhouse', {
        date: this.$moment("".concat(this.monthInfo.currentMonth, " ").concat(this.monthInfo.currentYear), 'MMMM YYYY').format('YYYY-MM-DD'),
        row_id: this.itemy.row_id,
        type: 'inhouse'
      }).then(function () {
        _this13.$toast.success('Обновите для сохранения');
        _this13.itemy = null;
      })["catch"](function (error) {
        _this13.$toast.error('Не сохранено');
        console.error(error);
      });
    },
    add_remote: function add_remote(item) {
      var _this14 = this;
      this.itemy = item;
      this.axios.post('/timetracking/analytics/add-remote-inhouse', {
        date: this.$moment("".concat(this.monthInfo.currentMonth, " ").concat(this.monthInfo.currentYear), 'MMMM YYYY').format('YYYY-MM-DD'),
        row_id: this.itemy.row_id,
        type: 'remote'
      }).then(function () {
        _this14.$toast.success('Обновите для сохранения');
        _this14.itemy = null;
      })["catch"](function (error) {
        _this14.$toast.error('Не сохранено');
        console.error(error);
      });
    },
    add_salary: function add_salary(item) {
      var _this15 = this;
      this.itemy = item;
      this.axios.post('/timetracking/analytics/add-salary', {
        date: this.$moment("".concat(this.monthInfo.currentMonth, " ").concat(this.monthInfo.currentYear), 'MMMM YYYY').format('YYYY-MM-DD'),
        row_id: this.itemy.row_id
      }).then(function () {
        _this15.$toast.success('Обновите для сохранения');
        _this15.itemy = null;
      })["catch"](function (error) {
        _this15.$toast.error('Не сохранено');
        console.error(error);
      });
    },
    setDecimals: function setDecimals(item) {
      var _this16 = this;
      this.axios.post('/timetracking/analytics/set-decimals', {
        date: this.$moment("".concat(this.monthInfo.currentMonth, " ").concat(this.monthInfo.currentYear), 'MMMM YYYY').format('YYYY-MM-DD'),
        row_id: item.row_id,
        column_id: item.column_id,
        decimals: item.decimals
      }).then(function () {
        _this16.$toast.success('Сохранено!');
        _this16.hideContextMenu();
      })["catch"](function (error) {
        _this16.$toast.error('Не сохранено');
        console.error(error);
      });
    },
    save_formula_1_31: function save_formula_1_31() {
      var _this17 = this;
      // let rows = [];
      var text = this.formula_1_31;
      this.items.forEach(function (item, index) {
        index++;
        text = text.replaceAll('{' + index + '}', '{' + item['name']['row_id'] + '}');
      });
      var regExp = /[a-zA-Z]/g;
      if (regExp.test(text)) {
        /* do something if letters are found in your string */
        this.$toast.error('Вы не правильно ввели формулу');
      } else {
        this.axios.post('/timetracking/analytics/add-formula-1-31', {
          date: this.$moment("".concat(this.monthInfo.currentMonth, " ").concat(this.monthInfo.currentYear), 'MMMM YYYY').format('YYYY-MM-DD'),
          formula: text,
          row_id: this.itemy.row_id,
          decimals: this.formula_1_31_decimals
        }).then(function () {
          _this17.$toast.success('Обновите для сохранения');
          _this17.showFormula1_31 = false;
          _this17.formula_1_31 = '';
          _this17.formula_1_31_decimals = 9;
          _this17.itemy = null;
        })["catch"](function (error) {
          _this17.$toast.error('Не сохранено');
          console.error(error);
        });
      }
    },
    change_stat: function change_stat(i_index, f_index) {
      var item = this.items[i_index][f_index];
      if (item.type == 'initial') {
        item.show_value = item.value;
        this.calcGlobal();
      }
      if (item.type == 'formula') {
        item.show_value = item.value;
        var combinations = this.combinator(item.value);
        item.formula = this.getExpression(combinations, 'db');
        item.show_value = this.calc(combinations);
        this.calcGlobal();
      }
      if (item.type == 'remote' || item.type == 'inhouse') {
        item.show_value = item.value;
        this.showCommentWindow = true;
        this.comment_i = i_index;
        this.comment_f = f_index;
        return '';
      }
      this.editQuery(i_index, f_index);
    },
    saveComment: function saveComment() {
      // for remote/inhouse add hours
      if (this.comment.length > 5) {
        this.editQuery(this.comment_i, this.comment_f);
        this.items[this.comment_i][this.comment_f].comment = this.comment;
        this.showCommentWindow = false;
      } else {
        this.$toast.info('Пожалуйста, напишите подробнее');
      }
    },
    form: function form() {
      this.set_letters(this.fields.length);
    },
    nextItem: function nextItem() {
      // move by arrows
      return '';
      // if (event.keyCode == 38) { // up
      // 	if(this.focused_item !== 0) {
      // 		this.focused_item--
      // 	}
      // 	console.log('up')
      // } else if (event.keyCode == 40) { // down
      // 	if(this.focused_item !== this.items.length - 1) {
      // 		this.focused_item++
      // 	}
      // 	console.log('down')
      // } else if (event.keyCode == 37) { // left
      // 	console.log('left')
      // 	if(this.focused_field !== 0) {
      // 		this.focused_field--
      // 	}
      // } else if (event.keyCode == 39) { // right
      // 	console.log('right')
      // 	if(this.focused_field !== this.fields.length - 1) {
      // 		this.focused_field++
      // 	}
      // }
      // this.focus(this.focused_item, this.focused_field);
    },
    letters: function letters() {
      return ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    },
    set_letters: function set_letters(q) {
      var letters = this.letters();
      this.letter_cells.push('A');
      var fl_pos = 0;
      var sl_pos = -1;
      for (var i = 0; i < q - 1; i++) {
        fl_pos = (i + 1) % letters.length;
        if (fl_pos == 0) sl_pos++;
        if (sl_pos >= 0) {
          this.letter_cells.push(letters[sl_pos] + letters[fl_pos]);
        } else {
          this.letter_cells.push(letters[fl_pos]);
        }
      }
    },
    // get array of expression combinations
    combinator: function combinator(text) {
      if (text === null) return [];
      //let text = "-12+B4+AA10*12.7*AE31/aR7";
      var positions = [];
      text = text.toUpperCase();
      var combinations = text.match(/A?[A-Z][1-9]?[0-9]/gi);
      // eslint-disable-next-line no-useless-escape
      var floats = text.match(/(\*|\/|\+|\-|\s|\(|^){1}[0-9]+\.?[0-9]?/gi); // цифры

      if (combinations === null) combinations = [];
      if (floats === null) floats = [];
      // find multipliers
      var multiply = [];
      for (var i = 0; i < text.length; i++) {
        if (text[i] === '*') {
          multiply.push(i);
          positions.push({
            text: '*',
            index: i,
            type: 'action'
          });
        }
      }

      // find additions
      var addition = [];
      for (var _i = 0; _i < text.length; _i++) {
        if (text[_i] === '+') {
          addition.push(_i);
          positions.push({
            text: '+',
            index: _i,
            type: 'action'
          });
        }
      }

      // find substract
      var substract = [];
      for (var _i2 = 0; _i2 < text.length; _i2++) {
        if (text[_i2] === '-' && _i2 != 0) {
          substract.push(_i2);
          positions.push({
            text: '-',
            index: _i2,
            type: 'action'
          });
        }
      }

      // find dividers
      var divider = [];
      for (var _i3 = 0; _i3 < text.length; _i3++) {
        if (text[_i3] === '/') {
          divider.push(_i3);
          positions.push({
            text: '/',
            index: _i3,
            type: 'action'
          });
        }
      }

      // find parentheses
      var parentheses = [];
      for (var _i4 = 0; _i4 < text.length; _i4++) {
        if (text[_i4] === '(' || text[_i4] === ')') {
          parentheses.push(_i4);
          positions.push({
            text: text[_i4],
            index: _i4,
            type: 'action'
          });
        }
      }

      // cells
      var last_pos = -1;
      for (var _i5 = 0; _i5 < combinations.length; _i5++) {
        // TODO find value of field
        last_pos++;
        var s = this.searcher(combinations[_i5]);
        last_pos = text.indexOf(combinations[_i5], last_pos), positions.push({
          text: combinations[_i5],
          index: last_pos,
          type: s !== undefined && s.type == 'formula' ? 'formula' : 'cell',
          value: s !== undefined ? s.value : 0,
          code: s !== undefined ? '[' + s.column_id + ':' + s.row_id + ']' : 0
        });
      }

      // just numbers in expression
      var last_pos_floats = -1;
      for (var _i6 = 0; _i6 < floats.length; _i6++) {
        last_pos_floats++;
        last_pos_floats = text.indexOf(floats[_i6], last_pos_floats);
        var f_text = floats[_i6];
        if (['*', '/', '+', '-', '('].includes(floats[_i6][0])) {
          last_pos_floats++;
          f_text = f_text.substr(1, f_text.length);
        }
        positions.push({
          text: f_text,
          index: last_pos_floats,
          type: 'value',
          value: Number(f_text)
        });
      }

      // sort array
      positions.sort(function (a, b) {
        if (a.index < b.index) return -1;
        if (a.index > b.index) return 1;
        return 0;
      });
      return positions;
    },
    searcher: function searcher(cell) {
      var res;
      for (var i = 0; i < this.items.length; i++) {
        Object.values(this.items[i]).forEach(function (item) {
          if (item.cell == cell) {
            res = item;
          }
        });
      }
      return res;
    },
    formula_searcher: function formula_searcher() {
      if (this.items) return [];
      var items = [];
      for (var i = 0; i < this.items.length; i++) {
        Object.values(this.items[i]).forEach(function (item) {
          if (item.type == 'formula') {
            items.push(item);
          }
        });
      }
      return items;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'CallBase',
  components: {},
  props: {
    data: {
      type: Array,
      "default": null
    },
    monthInfo: {
      type: Object,
      "default": null
    }
  },
  data: function data() {
    return {
      items: []
    };
  },
  created: function created() {
    this.items = this.data;
    this.calc();
  },
  methods: {
    form: function form() {},
    calc: function calc() {
      var sum = 0;
      for (var i = 1; i < 31; i++) {
        if (this.items.current_credits[i] !== undefined && !isNaN(this.items.current_credits[i])) {
          sum += Number(this.items.current_credits[i]);
        }
      }
      this.items.current_credits['sum'] = sum;

      ///

      sum = 0;
      for (var _i = 1; _i < 31; _i++) {
        if (this.items.current_given[_i] !== undefined && !isNaN(this.items.current_given[_i])) {
          sum += Number(this.items.current_given[_i]);
        }
      }
      this.items.current_given['sum'] = sum;

      //
      sum = 0;
      for (var _i2 = 1; _i2 < 31; _i2++) {
        if (this.items.next_credits[_i2] !== undefined && !isNaN(this.items.next_credits[_i2])) {
          sum += Number(this.items.next_credits[_i2]);
        }
      }
      this.items.next_credits['sum'] = sum;

      //

      sum = 0;
      for (var _i3 = 1; _i3 < 31; _i3++) {
        if (this.items.next_given[_i3] !== undefined && !isNaN(this.items.next_given[_i3])) {
          sum += Number(this.items.next_given[_i3]);
        }
      }
      this.items.next_given['sum'] = sum;

      //

      if (Number(this.items.total) !== 0) {
        this.items.conversion = (Number(this.items.next_credits['sum']) + Number(this.items.current_credits['sum'])) / Number(this.items.total) * 100;
        this.items.conversion = Number(Number(this.items.conversion).toFixed(2)) - 0.01;
        if (this.items.conversion == -0.01) this.items.conversion = 0;
      } else {
        this.items.conversion = 0;
      }
    },
    save: function save() {
      this.calc();
      this.query();
    },
    query: function query() {
      var loader = this.$loading.show();
      this.axios.post('/timetracking/analytics/save-call-base', {
        date: this.$moment("".concat(this.monthInfo.currentMonth, " ").concat(this.monthInfo.currentYear), 'MMMM YYYY').format('YYYY-MM-DD'),
        total: this.items.total,
        conversion: this.items.conversion,
        'current_credits': this.items.current_credits,
        'next_credits': this.items.next_credits,
        'current_given': this.items.current_given,
        'next_given': this.items.next_given
      }).then(function () {
        loader.hide();
      })["catch"](function () {
        return console.error('Error');
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_tables_TableActivityCollection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/tables/TableActivityCollection */ "./resources/js/components/tables/TableActivityCollection.vue");
/* harmony import */ var _components_tables_TableQualityWeekly__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/tables/TableQualityWeekly */ "./resources/js/components/tables/TableQualityWeekly.vue");
/* harmony import */ var _ui_PopupMenu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ui/PopupMenu */ "./resources/js/components/ui/PopupMenu.vue");
/* harmony import */ var _ui_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ui/Button */ "./resources/js/components/ui/Button.vue");
/* harmony import */ var _ui_Switch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ui/Switch */ "./resources/js/components/ui/Switch.vue");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vuedraggable */ "./node_modules/vuedraggable/dist/vuedraggable.common.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(vuedraggable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _stores_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/stores/api */ "./resources/js/stores/api.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */

var TableActivityNew = function TableActivityNew() {
  return __webpack_require__.e(/*! import() | TableActivityNew */ "TableActivityNew").then(__webpack_require__.bind(__webpack_require__, /*! @/components/tables/TableActivityNew */ "./resources/js/components/tables/TableActivityNew.vue"));
};







var API = {
  fetchAnalyticsMonthlyStats: _stores_api__WEBPACK_IMPORTED_MODULE_6__.fetchAnalyticsMonthlyStats,
  createAnalyticsActivity: _stores_api__WEBPACK_IMPORTED_MODULE_6__.createAnalyticsActivity,
  deleteAnalyticsActivity: _stores_api__WEBPACK_IMPORTED_MODULE_6__.deleteAnalyticsActivity,
  updateAnalyticsOrder: _stores_api__WEBPACK_IMPORTED_MODULE_6__.updateAnalyticsOrder,
  getAnalyticsActivityHiddenUsers: _stores_api__WEBPACK_IMPORTED_MODULE_6__.getAnalyticsActivityHiddenUsers
};
function percentMinMax(value, min, max) {
  return (value - min) / (max - min);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'AnalyticsDetailes',
  components: {
    TableActivityNew: TableActivityNew,
    TableActivityCollection: _components_tables_TableActivityCollection__WEBPACK_IMPORTED_MODULE_0__["default"],
    TableQualityWeekly: _components_tables_TableQualityWeekly__WEBPACK_IMPORTED_MODULE_1__["default"],
    PopupMenu: _ui_PopupMenu__WEBPACK_IMPORTED_MODULE_2__["default"],
    JobtronButton: _ui_Button__WEBPACK_IMPORTED_MODULE_3__["default"],
    JobtronSwitch: _ui_Switch__WEBPACK_IMPORTED_MODULE_4__["default"],
    Draggable: (vuedraggable__WEBPACK_IMPORTED_MODULE_5___default())
  },
  props: {
    activities: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    weeks: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activitySelect: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    currentGroup: {
      type: Number,
      "default": 0
    },
    monthInfo: {
      type: Object,
      "default": function _default() {
        return {};
      }
    }
  },
  data: function data() {
    return {
      isPopup: false,
      showOrder: false,
      showActivityModal: false,
      active_sub_tab: 0,
      activity: {
        name: null,
        daily_plan: null,
        plan_unit: null,
        unit: null,
        editable: 1,
        weekdays: 6
      },
      plan_units: {
        minutes: 'Сумма показателей',
        percent: 'Среднее значение',
        less_sum: 'Не более, сумма',
        less_avg: 'Не более, сред. зн.'
      },
      activityStates: this.activities.map(function () {
        return 'month';
      }),
      users: [],
      // year table of activity
      statistics: [],
      // year table of activity,
      yearActivityTable: [],
      yearActivityTableFields: [{
        key: 'name',
        name: 'Сотрудник',
        // order: order++,
        classes: ' b-table-sticky-column text-left t-name wd'
      }].concat(_toConsumableArray(this.$moment.months().map(function (name, index) {
        return {
          key: index + 1,
          name: name,
          classes: 'text-center px-1 month'
        };
      }))),
      activityHiddenUsers: {}
    };
  },
  watch: {
    activities: function activities() {
      this.activityStates = this.activities.map(function () {
        return 'month';
      });
    }
  },
  created: function created() {
    this.init();
  },
  methods: {
    init: function init() {
      var _this = this;
      API.getAnalyticsActivityHiddenUsers(this.currentGroup).then(function (hidden) {
        _this.activityHiddenUsers = hidden;
      });
    },
    showSubTab: function showSubTab(tab) {
      this.active_sub_tab = tab;
    },
    switchToMonthInActivity: function switchToMonthInActivity(index) {
      this.$set(this.activityStates, index, 'month');
    },
    switchToYearInActivity: function switchToYearInActivity(index) {
      this.$set(this.activityStates, index, 'year');
      this.fetchYearTableOfActivity(this.activities[index].id);
    },
    add_activity: function add_activity() {
      this.showActivityModal = true;
    },
    create_activity: function create_activity() {
      var _this2 = this;
      var loader = this.$loading.show();
      API.createAnalyticsActivity({
        month: this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M'),
        year: this.monthInfo.currentYear,
        activity: this.activity,
        group_id: this.currentGroup
      }).then(function (activities) {
        _this2.$toast.success('Активность для группы добавлена!');
        _this2.activity = {
          name: null,
          daily_plan: null,
          plan_unit: null,
          unit: null,
          editable: 1,
          weekdays: 6
        };
        _this2.$emit('updateActivity', activities);
        _this2.showActivityModal = false;
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        _this2.$toast.error('Активность для группы не добавлена!');
        alert(error);
      });
    },
    delete_activity: function delete_activity(act) {
      var _this3 = this;
      if (!confirm('Вы уверены что хотите удалить активность \'' + act.name + '\' ?')) return;
      var loader = this.$loading.show();
      API.deleteAnalyticsActivity({
        id: act.id
      }).then(function () {
        _this3.$toast.success('Удален!');
        _this3.$emit('deleteActivity', act);
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        _this3.$toast.error('Ошибка!');
        alert(error);
      });
    },
    save_order: function save_order() {
      var _this4 = this;
      var loader = this.$loading.show();
      API.updateAnalyticsOrder({
        activities: this.activity_select
      }).then(function () {
        _this4.$toast.success('Порядок сохранен!');
        _this4.showOrder = false;
        _this4.$emit('orderActivity');
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        _this4.$toast.error('Ошибка!');
        alert(error);
      });
    },
    fetchYearTableOfActivity: function fetchYearTableOfActivity(activityId) {
      var _this5 = this;
      var loader = this.$loading.show();
      API.fetchAnalyticsMonthlyStats({
        group_id: this.currentGroup,
        date: {
          year: this.monthInfo.currentYear,
          month: this.monthInfo.month
        },
        activity_id: activityId
      }).then(function (_ref) {
        var data = _ref.data;
        _this5.users = data.users;
        _this5.formYearActivityTable(data.statistics);
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    formYearActivityTable: function formYearActivityTable(stats) {
      var _this6 = this;
      var res = [];
      this.users.forEach(function (user) {
        if (user.deleted_at) return;
        if (stats[user.id] !== undefined) {
          res.push(_objectSpread({
            name: _this6.fullNameOfUser(user)
          }, _this6.normalizeStat(stats[user.id])));
        }
      });
      this.yearActivityTable = res;
      this.yearCalcMinMax();
    },
    normalizeStat: function normalizeStat(obj) {
      var res = {};
      Object.keys(obj).forEach(function (key) {
        res[key] = obj[key] == 0 ? 0 : parseInt(obj[key].total) === parseFloat(obj[key].total) ? parseInt(obj[key].total) : Number(obj[key].total).toFixed(2);
      });
      return res;
    },
    yearCalcMinMax: function yearCalcMinMax() {
      var min = 9999999999;
      var max = 0;
      this.yearActivityTable.forEach(function (row) {
        Object.keys(row).forEach(function (key) {
          if (key === 'name') return;
          var value = parseFloat(row[key]);
          if (value < min) min = value;
          if (value > max) max = value;
        });
      });
      this.yearMin = min;
      this.yearMax = max;
    },
    getCellColor: function getCellColor(value) {
      var perc = percentMinMax(value, this.yearMin, this.yearMax) * 100;
      var r,
        g,
        b = 0;
      if (perc < 50) {
        r = 235;
        g = Math.round(5.1 * perc);
        b = Math.round(113 - 1.13 * perc);
      } else {
        g = 225;
        r = Math.round(510 - 5.1 * perc);
      }
      var h = r * 0x10000 + g * 0x100 + b * 0x1;
      return '#' + ('000000' + h.toString(16)).slice(-6);
    },
    fullNameOfUser: function fullNameOfUser(user) {
      return user.last_name ? user.last_name + ' ' + user.name : user.name;
    },
    onClickPopup: function onClickPopup() {
      this.isPopup = true;
    },
    onClickOutside: function onClickOutside() {
      this.isPopup = false;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/ui/Sidebar */ "./resources/js/components/ui/Sidebar.vue");
/* harmony import */ var _components_imports_ActivityExcelImport__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/imports/ActivityExcelImport */ "./resources/js/components/imports/ActivityExcelImport.vue");
/* harmony import */ var _ui_Cup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ui/Cup */ "./resources/js/components/ui/Cup.vue");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */


 // импорт в активности

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TActivityCollection',
  components: {
    Sidebar: _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_0__["default"],
    JobtronCup: _ui_Cup__WEBPACK_IMPORTED_MODULE_2__["default"],
    ActivityExcelImport: _components_imports_ActivityExcelImport__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  props: {
    month: {
      type: Object,
      "default": null
    },
    activity: {
      type: Object,
      "default": null
    },
    is_admin: Boolean,
    price: {
      type: Number,
      "default": 50
    }
  },
  data: function data() {
    return {
      items: [],
      sorts: {},
      sortField: '',
      sortDir: 'asc',
      fields: [],
      itemsArray: [],
      avgOfAverage: 0,
      showExcelImport: false,
      totalCountDays: 0,
      sum: {},
      percentage: [],
      records: [],
      totalRowName: '',
      accountsNumber: 0,
      tenant: location.hostname.split('.')[0]
    };
  },
  watch: {
    activity: function activity() {
      this.fetchData();
    }
  },
  created: function created() {
    this.fetchData();
  },
  mounted: function mounted() {
    document.getElementById('sticky-' + this.activity.id).style.height = window.innerHeight + 'px';
  },
  methods: {
    setFirstRowAsTotals: function setFirstRowAsTotals() {
      this.totalRowName = 'Сумма сборов';
      this.records.unshift({
        is_date: false,
        name: this.totalRowName
      });
    },
    addCellVariantsArrayToRecords: function addCellVariantsArrayToRecords() {
      var _this = this;
      this.itemsArray.forEach(function (element, key) {
        _this.itemsArray[key]['_cellVariants'] = [];
      });
    },
    updateAvgValuesOfRecords: function updateAvgValuesOfRecords() {
      var _this2 = this;
      this.itemsArray.forEach(function (account, index) {
        _this2.itemsArray[index]['plan'] = account.plan;
      });
    },
    fetchData: function fetchData() {
      var loader = this.$loading.show();
      this.records = this.activity.records || [];
      this.accountsNumber = (this.activity.records || []).length;
      if (this.is_admin) this.setFirstRowAsTotals();
      this.calculateRecordsValues();
      if (this.is_admin) this.calculateTotalsRow();
      if (!this.is_admin) this.setLeaders();
      if (this.is_admin) this.setAvgCell();
      this.items = this.itemsArray;
      this.addCellVariantsArrayToRecords();
      this.setCellVariants();
      loader.hide();
    },
    updateTable: function updateTable(items) {
      var loader = this.$loading.show();
      this.records = items;
      this.calculateRecordsValues();
      if (this.is_admin) this.calculateTotalsRow();
      if (!this.is_admin) this.setLeaders();
      this.updateAvgValuesOfRecords();
      if (this.is_admin) this.setAvgCell();
      this.totalColumn();
      this.items = this.itemsArray;
      this.addCellVariantsArrayToRecords();
      this.setCellVariants();
      loader.hide();
    },
    setLeaders: function setLeaders() {
      var arr = this.itemsArray;

      // let first_item = this.itemsArray[0];
      //this.itemsArray.shift();
      arr.sort(function (a, b) {
        return Number(a.plan) < Number(b.plan) ? 1 : Number(a.plan) > Number(b.plan) ? -1 : 0;
      });
      if (this.itemsArray.length > 3) {
        arr[0].show_cup = 1;
        arr[1].show_cup = 2;
        arr[2].show_cup = 3;
      }

      // this.itemsArray.unshift(first_item);
    },
    totalColumn: function totalColumn() {
      var row0_avg = 0;
      this.itemsArray.forEach(function (account) {
        if (parseFloat(account['plan']) != 0 && account['plan'] != undefined) {
          row0_avg += parseFloat(account['plan']);
        }
      });
      if (this.is_admin) this.itemsArray[0]['plan'] = parseInt(row0_avg);
    },
    setAvgCell: function setAvgCell() {
      this.itemsArray[0]['avg'] = (this.avgOfAverage / this.totalCountDays).toFixed(2);
      this.itemsArray[0]['avg'] = '';
    },
    calculateTotalsRow: function calculateTotalsRow() {
      var total = 0;
      // вот здесь я считаю итоговые суммы минут по всем сотрудникам, и мне их видимо придется сохранить в бд
      for (var key in this.sum) {
        if (this.sum.hasOwnProperty(key)) {
          this.itemsArray[0][key] = parseFloat(this.sum[key]).toFixed(0);
          total += parseFloat(this.sum[key]);
        } else {
          this.itemsArray[0][key] = 0;
        }
      }
      if (this.is_admin) this.itemsArray[0]['plan'] = Math.round(parseFloat(total) * this.price);
    },
    setCellVariants: function setCellVariants() {
      var _this3 = this;
      if (_typeof(this.activity) === 'object') {
        var SPECIAL_VALUE = this.activity.daily_plan;
        var minutes = this.items;
        minutes.forEach(function (account, index) {
          if (index > 0 || !_this3.is_admin) {
            for (var key in account) {
              if (key >= 1 && key <= 31) {
                if (account[key] >= SPECIAL_VALUE && account[key] !== undefined && account[key] !== null) {
                  _this3.items[index]._cellVariants[key] = 'success';
                } else if (account[key] < SPECIAL_VALUE && account[key] !== undefined && account[key] !== null) {
                  _this3.items[index]._cellVariants[key] = 'danger';
                }
              }
            }
          }
        });
      }
    },
    editMode: function editMode(item) {
      if (!this.is_admin) return null;
      this.items.forEach(function (account) {
        account.editable = false;
      });
      item.editable = true;
    },
    updateSettings: function updateSettings(e, data, index, key) {
      data.editable = false;

      //var index = data.index;
      var clearedValue = e.target.value.replace(',', '.');
      var value = parseFloat(clearedValue) || null;
      if (value < 0) {
        this.items[index][key] = 0;
      }
      if (value > 999) {
        this.items[index][key] = 999;
      }
      this.items[index][key] = Number(this.items[index][key]);

      // let settings = [];
      var employee_id = data.id;
      var items = this.items;
      var loader = this.$loading.show();
      // let year = new Date().getFullYear();

      this.updateTable(items);
      this.axios.post('/timetracking/analytics/update-stat', {
        month: this.month.month,
        year: this.month.currentYear,
        group_id: this.activity.group_id,
        employee_id: employee_id,
        id: this.activity.id,
        day: key,
        value: '' + (value || 0)
      }).then(function () {
        loader.hide();
      });
    },
    exportData: function exportData() {
      var link = '/timetracking/analytics/activity/export';
      link += '?month=' + this.$moment("".concat(this.month.currentMonth), 'MMMM YYYY').format('MM');
      link += '&year=' + new Date().getFullYear();
      window.location.href = link;
    },
    calculateRecordsValues: function calculateRecordsValues() {
      var _this4 = this;
      this.sum = {};
      this.itemsArray = [];
      this.totalCountDays = 0;
      this.avgOfAverage = 0;
      this.percentage = [];

      // let row0_avg = 0;
      // let row0_avg_items = 0;

      this.records.forEach(function (account) {
        // let countWorkedDays = 0;
        var cellValues = [];
        if (account.name != _this4.totalRowName) {
          var sumForOne = 0;
          for (var key in account) {
            var value = account[key];
            if (key >= 1 && key <= 31) {
              cellValues[key] = Number(value);
              if (isNaN(_this4.sum[key])) _this4.sum[key] = 0;
              if (isNaN(_this4.percentage[key])) _this4.percentage[key] = 0;
              _this4.sum[key] = _this4.sum[key] + account[key]; // vertical sum

              if (account[key] > 0) {
                _this4.percentage[key] = _this4.percentage[key] + 1;
              }
              if (account[key] > 0) {
                sumForOne += account[key]; // horizontal sum
                // countWorkedDays++;
                _this4.totalCountDays++;
              }
            }
          }
          var plan = sumForOne * _this4.price;
          cellValues['plan_unit'] = _this4.activity.plan_unit;
          cellValues['plan'] = Number.isInteger(plan) ? plan : plan.toFixed(2);
          cellValues['count'] = Number.isInteger(sumForOne) ? sumForOne : sumForOne.toFixed(2);
        }
        _this4.itemsArray.push(_objectSpread({
          name: account.name,
          lastname: account.lastname,
          fullname: account.fullname,
          id: account.id,
          editable: false,
          group: account.group,
          email: account.email,
          show_cup: 0
        }, cellValues));
      });
    },
    toFloat: function toFloat(number) {
      return Number(number).toFixed(2);
    },
    sort: function sort(field) {
      if (this.sorts[field] === undefined) {
        this.sorts[field] = 'asc';
      }
      this.sortField = field;
      this.sortDir = this.sorts[field];
      var item = this.items[0];
      this.items.shift();
      if (this.sorts[field] === 'desc') {
        if (field == 'name') {
          this.items.sort(function (a, b) {
            return a[field] > b[field] ? 1 : -1;
          });
        } else {
          this.items.sort(function (a, b) {
            return Number(a[field]) > Number(b[field]) ? 1 : -1;
          });
        }
        this.sorts[field] = 'asc';
      } else {
        if (field == 'name') {
          this.items.sort(function (a, b) {
            return a[field] < b[field] ? 1 : -1;
          });
        } else {
          this.items.sort(function (a, b) {
            return Number(a[field]) < Number(b[field]) ? 1 : -1;
          });
        }
        this.sorts[field] = 'desc';
      }
      this.items.unshift(item);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TableDecomposition',
  props: {
    month: {
      type: Object,
      "default": function _default() {
        return {};
      }
    },
    decompositions: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    groupId: {
      type: Number,
      required: true
    }
  },
  data: function data() {
    return {
      fields: [],
      itemsArray: [],
      records: [],
      is_weekday: {},
      planner: {
        value: null,
        from: 1,
        to: null,
        index: null
      }
    };
  },
  computed: {
    items: function items() {
      var _this = this;
      return this.records.map(function (item) {
        var cellValues = [];
        var totalPlan = 0;
        var totalFact = 0;
        for (var i = 1; i <= _this.month.daysInMonth; i++) {
          cellValues[i] = item[i] || {
            plan: '',
            fact: ''
          };
          if (!item[i]) continue;
          if (item[i].plan) totalPlan += Number(item[i].plan);
          if (item[i].fact) totalFact += Number(item[i].fact);
        }
        return _objectSpread({
          id: item.id,
          name: item.name,
          editable: false,
          total_plan: totalPlan,
          total_fact: totalFact
        }, cellValues);
      });
    }
  },
  watch: {
    data: function data() {
      this.fetchData();
    }
  },
  created: function created() {
    this.fetchData();
    this.getWeekdays();
    this.planner.to = this.month.daysInMonth;
  },
  methods: {
    getWeekdays: function getWeekdays() {
      for (var i = 1; i <= this.month.daysInMonth; i++) {
        var day = i > 9 ? i : '0' + i;
        var month = Number(this.month.month) > 9 ? this.month.month : '0' + this.month.month;
        var date = new Date(this.month.currentYear + '-' + month + '-' + day);
        if (date.getDay() == 0 || date.getDay() == 6) {
          this.is_weekday[i] = true;
        } else {
          this.is_weekday[i] = false;
        }
      }
    },
    fetchData: function fetchData() {
      var loader = this.$loading.show();
      this.records = this.decompositions;
      loader.hide();
    },
    addRecord: function addRecord() {
      var cells = {
        name: '',
        plan: 0,
        editable: false
      };
      for (var i = 1; i <= this.month.daysInMonth; i++) {
        cells[i] = {
          'plan': '',
          'fact': ''
        };
      }
      this.items.push(cells);
      this.$toast.info('Пункт добавлен');
    },
    updateSettings: function updateSettings(e, data, index) {
      data.editable = false;
      var post_data = {
        group_id: this.groupId,
        id: data.id,
        name: data.name,
        index: index,
        values: this.items[index]
      };
      this.reqSave(post_data);
    },
    reqSave: function reqSave(post_data) {
      var _this2 = this;
      var url = '/timetracking/analytics/decomposition/save';
      var loader = this.$loading.show();
      var year = new Date().getFullYear();
      post_data.date = this.$moment("".concat(this.month.currentMonth, " ").concat(year), 'MMMM YYYY').format('YYYY-MM-DD');
      this.axios.post(url, post_data).then(function (response) {
        if (post_data.id === undefined) {
          _this2.items[post_data.index].id = response.data.id;
        }
      })["catch"](function (error) {
        alert(error);
      });
      loader.hide();
    },
    showModal: function showModal(index) {
      this.planner.index = index;
      this.$refs['change-plan-modal'].show();
    },
    changePlan: function changePlan() {
      if (this.planner.value != null && this.planner.value != '') {
        // Set plans from to
        var start = this.planner.from,
          end = this.planner.to > this.month.daysInMonth ? this.month.daysInMonth : this.planner.to;
        for (var i = start; i <= end; i++) {
          this.items[this.planner.index][i].plan = Number(this.planner.value);
        }

        // POST
        this.reqSave({
          group_id: this.groupId,
          id: this.items[this.planner.index].id,
          name: this.items[this.planner.index].name,
          values: this.items[this.planner.index],
          index: this.planner.index
        });

        // Count total plan
        var total_plan = 0;
        for (var _i = 1; _i <= this.month.daysInMonth; _i++) {
          total_plan += Number(this.items[this.planner.index][_i].plan);
        }
        this.items[this.planner.index].total_plan = total_plan;
        // Reset planner
        this.planner = {
          value: null,
          from: 1,
          to: this.month.daysInMonth,
          index: null
        };
        this.$toast.info('План проставлен');
      }

      // Hide modal
      this.$refs['change-plan-modal'].hide();
    },
    deleteRecord: function deleteRecord(id, index) {
      var _this3 = this;
      if (!confirm('Вы уверены?')) {
        return '';
      }
      if (id != 0) {
        var url = '/timetracking/analytics/decomposition/delete';
        this.axios["delete"](url, {
          headers: {},
          data: {
            id: id
          }
        }).then(function () {
          _this3.$toast.info('Пункт удален');
        })["catch"](function (error) {
          alert(error);
        });
      }
      this.items.splice(index, 1);
    },
    editMode: function editMode(item) {
      this.items.forEach(function (account) {
        account.editable = false;
      });
      item.editable = true;
    },
    toFloat: function toFloat(number) {
      return Number(number).toFixed(2);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ui_Cup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ui/Cup */ "./resources/js/components/ui/Cup.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TableQualityWeekly',
  components: {
    JobtronCup: _ui_Cup__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    monthInfo: {
      type: Object,
      "default": null
    },
    items: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    weeks: {
      type: Array,
      "default": function _default() {
        return [];
      }
    }
  },
  data: function data() {
    return {
      users: [],
      user_ids: {},
      total_avg: 0,
      total_count: 0,
      loader: null
    };
  },
  computed: {
    totalCount: function totalCount() {
      return this.users.reduce(function (result, user) {
        return user.total > 0 ? result + 1 : result;
      }, 0);
    },
    totalAvg: function totalAvg() {
      if (this.totalCount <= 0) return 0;
      return Math.round(this.users.reduce(function (result, user) {
        if (user.total > 0) {
          result += user.total;
        }
        return result;
      }, 0) / this.totalCount * 100) / 100;
    },
    sortedUsers: function sortedUsers() {
      return this.users.slice().sort(function (a, b) {
        return b.total - a.total;
      });
    },
    topUsers: function topUsers() {
      return this.sortedUsers.slice(0, 3).map(function (user) {
        return user.id;
      });
    },
    fields: function fields() {
      var order = 1;
      var fieldsArray = [{
        key: 'total',
        name: 'Итог',
        order: order++,
        klass: ' text-center px-1 t-total'
      }];
      this.weeks.forEach(function (week, weekIndex) {
        week.forEach(function (day, dayIndex) {
          fieldsArray.push({
            key: day,
            name: day,
            order: order++,
            klass: 'text-center px-1',
            type: 'day'
          });
          if (dayIndex + 1 === week.length) {
            fieldsArray.push({
              key: 'avg' + (weekIndex + 1),
              name: 'Ср. ' + (weekIndex + 1),
              order: order++,
              klass: 'text-center px-1 averages',
              type: 'avg'
            });
          }
        });
      });
      return fieldsArray;
    }
  },
  created: function created() {
    this.users = this.items;
    this.setLeaders();
  },
  methods: {
    setLeaders: function setLeaders() {
      this.users.forEach(function (item) {
        item.show_cup = 0;
      });
      var arr = this.users;
      arr.sort(function (a, b) {
        return Number(a.total) < Number(b.total) ? 1 : Number(a.total) > Number(b.total) ? -1 : 0;
      });
      if (this.users.length > 3) {
        arr[0].show_cup = 1;
        arr[1].show_cup = 2;
        arr[2].show_cup = 3;
      }
      var total_avg = 0;
      var total_count = 0;
      arr.forEach(function (el) {
        if (Number(el.total) > 0) {
          total_avg += Number(el.total);
          total_count++;
        }
      });
      total_avg = total_count > 0 ? total_avg / total_count : 0;
      this.total_avg = total_avg;
      this.total_count = total_count;
    } // createUserIdList() {
    //     this.items.forEach((item, index) => {
    //         this.user_ids[item.id] = item.name
    //     })
    // },
    // editMode(item) {
    //     this.records.data.forEach((record, index) => {
    //         record.editable = false
    //     })
    //     item.editable = true
    // },
    // updateWeekValue(item, key) {
    //     let loader = this.$loading.show();
    //     axios.post("/timetracking/quality-control/saveweekly", {
    //             'day': key,
    //             'month': this.monthInfo.month,
    //             'year': this.currentYear,
    //             'total': item.weeks[key],
    //             'user_id': item.id,
    //         })
    //         .then((response) => {
    //             console.log(response)
    //             this.$toast.success('Сохранено');
    //             loader.hide();
    //         }).catch(function(e){
    //             loader.hide()
    //             alert(e)
    //         })
    // },
    // exportData() {
    //     var link = "/timetracking/quality-control/export";
    //     link += "?group_id=" + this.currentGroup;
    //     link += "&month=" + this.monthInfo.month;
    //     link += "&year=" + this.currentYear;
    //     window.location.href = link;
    // },
    // exportAll() {
    //     var link = "/timetracking/quality-control/exportall";
    //     link += "?month=" + this.monthInfo.month;
    //     link += "&year=" + this.currentYear;
    //     window.location.href = link;
    // },
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//

var images = ['', 'first-place.png', 'second-place.png', 'third-place.png'];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'JobtronCup',
  components: {},
  props: {
    place: {
      type: Number,
      "default": 1
    },
    rotate: {
      type: Boolean,
      "default": false
    }
  },
  computed: {
    src: function src() {
      if (this.place < 1 || this.place > 3) return '';
      return '/images/dist/' + images[this.place];
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'JobtronSwitch',
  components: {},
  props: {
    value: {
      type: Boolean
    }
  },
  data: function data() {
    return {
      localValue: this.value
    };
  },
  watch: {
    value: function value() {
      this.localValue = this.value;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_AnalyticStat__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AnalyticStat */ "./resources/js/components/AnalyticStat.vue");
/* harmony import */ var _components_CallBase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/CallBase */ "./resources/js/components/CallBase.vue");
/* harmony import */ var _components_tables_TableDecomposition__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/tables/TableDecomposition */ "./resources/js/components/tables/TableDecomposition.vue");
/* harmony import */ var _components_pages_AnalyticsPage_AnalyticsDetailes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/pages/AnalyticsPage/AnalyticsDetailes */ "./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue");
/* harmony import */ var _composables_yearOptions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../composables/yearOptions */ "./resources/js/composables/yearOptions.js");
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_Portal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/stores/Portal */ "./resources/js/stores/Portal.js");
/* harmony import */ var _stores_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/stores/api */ "./resources/js/stores/api.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */



var TopGauges = function TopGauges() {
  return __webpack_require__.e(/*! import() | TopGauges */ "TopGauges").then(__webpack_require__.bind(__webpack_require__, /*! @/components/TopGauges */ "./resources/js/components/TopGauges.vue"));
}; // TOП спидометры, есть и в аналитике






var API = {
  fetchAnalytics: _stores_api__WEBPACK_IMPORTED_MODULE_6__.fetchAnalytics,
  createAnalyticsGroup: _stores_api__WEBPACK_IMPORTED_MODULE_6__.createAnalyticsGroup,
  archiveAnalyticsGroup: _stores_api__WEBPACK_IMPORTED_MODULE_6__.archiveAnalyticsGroup,
  restoreAnalyticsGroup: _stores_api__WEBPACK_IMPORTED_MODULE_6__.restoreAnalyticsGroup,
  fetchActivitiesV2: _stores_api__WEBPACK_IMPORTED_MODULE_6__.fetchActivitiesV2,
  fetchDecompositionsV2: _stores_api__WEBPACK_IMPORTED_MODULE_6__.fetchDecompositionsV2,
  fetchPerformancesV2: _stores_api__WEBPACK_IMPORTED_MODULE_6__.fetchPerformancesV2,
  fetchFiredInfoV2: _stores_api__WEBPACK_IMPORTED_MODULE_6__.fetchFiredInfoV2,
  fetchAnalyticsGroupsV2: _stores_api__WEBPACK_IMPORTED_MODULE_6__.fetchAnalyticsGroupsV2,
  fetchAnalyticsV2: _stores_api__WEBPACK_IMPORTED_MODULE_6__.fetchAnalyticsV2
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'AnalyticsPage',
  components: {
    AnalyticStat: _components_AnalyticStat__WEBPACK_IMPORTED_MODULE_0__["default"],
    CallBase: _components_CallBase__WEBPACK_IMPORTED_MODULE_1__["default"],
    TableDecomposition: _components_tables_TableDecomposition__WEBPACK_IMPORTED_MODULE_2__["default"],
    TopGauges: TopGauges,
    AnalyticsDetailes: _components_pages_AnalyticsPage_AnalyticsDetailes__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  props: {
    groups: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activeuserid: {
      type: Number,
      "default": 0
    },
    isAdmin: {
      type: Boolean
    }
  },
  data: function data() {
    return {
      data: [],
      ggroups: [],
      active: '1',
      hasPremission: true,
      // доступ
      yearActivityTableFields: [],
      yearMin: 0,
      yearMax: 0,
      currentYear: new Date().getFullYear(),
      monthInfo: {},
      currentGroupId: null,
      loader: null,
      firstEnter: true,
      showArchive: false,
      askey: 1,
      call_bases: [],
      // euras call base unique table
      restore_group: null,
      noan: false,
      // нет аналитики
      dataLoaded: false,
      list: [{
        name: 'John',
        id: 0
      }, {
        name: 'Joao',
        id: 1
      }, {
        name: 'Jean',
        id: 2
      }],
      activities: [],
      weeks: [],
      decompositions: [],
      performances: {
        utility: [],
        rentability: null
      },
      firedInfo: null,
      archived_groups: [],
      columns: [],
      table: null,
      ready: {
        activities: false,
        decompositions: false,
        performances: false,
        fired: false,
        groups: false,
        analytics: false
      }
    };
  },
  computed: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_7__.mapState)(_stores_Portal__WEBPACK_IMPORTED_MODULE_5__.usePortalStore, ['portal'])), {}, {
    years: function years() {
      if (!this.portal.created_at) return [new Date().getFullYear()];
      return (0,_composables_yearOptions__WEBPACK_IMPORTED_MODULE_4__.useYearOptions)(new Date(this.portal.created_at).getFullYear());
    },
    activitiesOptions: function activitiesOptions() {
      return this.activities.map(function (_ref) {
        var name = _ref.name,
          id = _ref.id;
        return {
          id: id,
          name: name
        };
      });
    },
    gauges: function gauges() {
      if (!this.performances.utility.length) return [];
      return [{
        gauges: [].concat(_toConsumableArray(this.performances.utility[0].gauges), [_objectSpread(_objectSpread({}, this.performances.rentability), {}, {
          name: 'Рентабельность'
        })])
      }];
    },
    currentGroup: function currentGroup() {
      var _this = this;
      return this.ggroups.find(function (group) {
        return group.id === _this.currentGroupId;
      });
    }
  }),
  watch: {
    groups: function groups() {
      this.init();
    }
  },
  created: function created() {
    if (this.groups) {
      this.init();
    }
  },
  methods: {
    init: function init() {
      // выбор группы
      // переделать на роуты
      var urlParams = new URLSearchParams(window.location.search);
      var group = parseInt(urlParams.get('group') || 0);
      var active = urlParams.get('active');
      var load = urlParams.get('load');
      var year = parseInt(urlParams.get('year') || 0);
      this.ggroups = this.groups;
      this.currentGroupId = group || this.groups[0].id;
      this.currentYear = year || new Date().getFullYear();
      this.active = active || '1';
      this.setMonth();
      this.setYear();
      this.setActivityYearTableFields();
      var now = new Date();
      this.fetchGroups({
        month: now.getMonth() + 1,
        year: now.getFullYear(),
        group_id: this.currentGroupId
      });
      if (load) this.fetchData();
    },
    /**
     * ACTIVITY YEAR
     */
    setActivityYearTableFields: function setActivityYearTableFields() {
      var fieldsArray = [];
      var order = 1;
      fieldsArray.push({
        key: 'name',
        name: 'Сотрудник',
        order: order++,
        classes: ' b-table-sticky-column text-left t-name wd'
      });
      for (var i = 1; i <= 12; i++) {
        var month = (i.length === 1 ? '0' : '') + i;
        fieldsArray.push({
          key: i,
          name: this.$moment(this.currentYear + '-' + month + '-01').format('MMMM'),
          order: order++,
          classes: 'text-center px-1 month'
        });
      }
      this.yearActivityTableFields = fieldsArray;
    },
    setMonth: function setMonth() {
      this.monthInfo.currentMonth = this.monthInfo.currentMonth ? this.monthInfo.currentMonth : this.$moment().format('MMMM');
      this.monthInfo.month = this.monthInfo.currentMonth ? this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M') : this.$moment().format('M');
      var currentMonth = this.$moment(this.monthInfo.currentMonth, 'MMMM');
      //Расчет выходных дней
      this.monthInfo.monthEnd = currentMonth.endOf('month'); //Конец месяца
      this.monthInfo.weekDays = currentMonth.weekdayCalc(currentMonth.startOf('month').toString(), currentMonth.endOf('month').toString(), [6]); //Колличество выходных
      this.monthInfo.weekDays5 = currentMonth.weekdayCalc(currentMonth.startOf('month').toString(), currentMonth.endOf('month').toString(), [6, 0]); //Колличество выходных
      this.monthInfo.daysInMonth = new Date(this.$moment().format('YYYY'), this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M'), 0).getDate(); //Колличество дней в месяце
      this.monthInfo.workDays = this.monthInfo.daysInMonth - this.monthInfo.weekDays; // Колличество рабочих дней
      this.monthInfo.workDays5 = this.monthInfo.daysInMonth - this.monthInfo.weekDays5; // Колличество рабочих дней
    },
    //Установка выбранного года
    setYear: function setYear() {
      this.currentYear = this.currentYear ? this.currentYear : this.$moment().format('YYYY');
      this.monthInfo.currentYear = this.currentYear;
    },
    onTabChange: function onTabChange(active) {
      this.active = active;
      window.history.replaceState({
        id: '100'
      }, 'Аналитика групп', '/timetracking/an?group=' + this.currentGroupId + '&active=' + this.active);
    },
    fetchActivities: function fetchActivities(request) {
      var _this2 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var _yield$API$fetchActiv, activities, weeks;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;
                _context.next = 3;
                return API.fetchActivitiesV2(request);
              case 3:
                _yield$API$fetchActiv = _context.sent;
                activities = _yield$API$fetchActiv.activities;
                weeks = _yield$API$fetchActiv.weeks;
                _this2.activities = activities;
                _this2.weeks = weeks;
                _this2.ready.activities = true;
                _context.next = 15;
                break;
              case 11:
                _context.prev = 11;
                _context.t0 = _context["catch"](0);
                console.error(_context.t0);
                _this2.$toast('Ошибка при загрузке показателей');
              case 15:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[0, 11]]);
      }))();
    },
    fetchDecompositions: function fetchDecompositions(request) {
      var _this3 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;
                _context2.next = 3;
                return API.fetchDecompositionsV2(request);
              case 3:
                _this3.decompositions = _context2.sent;
                _this3.ready.decompositions = true;
                _context2.next = 11;
                break;
              case 7:
                _context2.prev = 7;
                _context2.t0 = _context2["catch"](0);
                console.error(_context2.t0);
                _this3.$toast('Ошибка при загрузке декомпозиции');
              case 11:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[0, 7]]);
      }))();
    },
    fetchPerformances: function fetchPerformances(request) {
      var _this4 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.prev = 0;
                _context3.next = 3;
                return API.fetchPerformancesV2(request);
              case 3:
                _this4.performances = _context3.sent;
                _this4.ready.performances = true;
                _context3.next = 11;
                break;
              case 7:
                _context3.prev = 7;
                _context3.t0 = _context3["catch"](0);
                console.error(_context3.t0);
                _this4.$toast('Ошибка при загрузке полезности');
              case 11:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, null, [[0, 7]]);
      }))();
    },
    fetchFiredInfo: function fetchFiredInfo(request) {
      var _this5 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.prev = 0;
                _context4.next = 3;
                return API.fetchFiredInfoV2(request);
              case 3:
                _this5.firedInfo = _context4.sent;
                _this5.ready.fired = true;
                _context4.next = 11;
                break;
              case 7:
                _context4.prev = 7;
                _context4.t0 = _context4["catch"](0);
                console.error(_context4.t0);
                _this5.$toast('Ошибка при загрузке информации о уволенных сотрудниках');
              case 11:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, null, [[0, 7]]);
      }))();
    },
    fetchGroups: function fetchGroups(request) {
      var _this6 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        var _yield$API$fetchAnaly, is_active, is_archived;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.prev = 0;
                _context5.next = 3;
                return API.fetchAnalyticsGroupsV2(request);
              case 3:
                _yield$API$fetchAnaly = _context5.sent;
                is_active = _yield$API$fetchAnaly.is_active;
                is_archived = _yield$API$fetchAnaly.is_archived;
                _this6.ggroups = Array.isArray(is_active) ? is_active : Object.values(is_active);
                _this6.archived_groups = Array.isArray(is_archived) ? is_archived : Object.values(is_archived);
                _this6.ready.groups = true;
                _context5.next = 15;
                break;
              case 11:
                _context5.prev = 11;
                _context5.t0 = _context5["catch"](0);
                console.error(_context5.t0);
                _this6.$toast('Ошибка при загрузке информации о отделах');
              case 15:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, null, [[0, 11]]);
      }))();
    },
    fetchAnalytics: function fetchAnalytics(request) {
      var _this7 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        var _yield$API$fetchAnaly2, columns, table;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.prev = 0;
                _context6.next = 3;
                return API.fetchAnalyticsV2(request);
              case 3:
                _yield$API$fetchAnaly2 = _context6.sent;
                columns = _yield$API$fetchAnaly2.columns;
                table = _yield$API$fetchAnaly2.table;
                _this7.columns = Array.isArray(columns) ? columns : Object.values(columns);
                _this7.table = Array.isArray(table) ? table : Object.values(table);
                _this7.ready.analytics = true;
                _context6.next = 15;
                break;
              case 11:
                _context6.prev = 11;
                _context6.t0 = _context6["catch"](0);
                console.error(_context6.t0);
                _this7.$toast('Ошибка при загрузке сводной');
              case 15:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, null, [[0, 11]]);
      }))();
    },
    fetchData: function fetchData() {
      var _this8 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee7() {
        var request, urlParamss, active;
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                // const loader = this.$loading.show()
                _this8.ready = {
                  activities: false,
                  decompositions: false,
                  performances: false,
                  fired: false,
                  groups: false,
                  analytics: false
                };
                _this8.firstEnter = false;
                request = {
                  month: _this8.$moment(_this8.monthInfo.currentMonth, 'MMMM').format('M'),
                  year: _this8.currentYear,
                  group_id: _this8.currentGroupId
                };
                _context7.next = 5;
                return Promise.all([_this8.fetchActivities(request), _this8.fetchDecompositions(request), _this8.fetchPerformances(request), _this8.fetchFiredInfo(request), _this8.fetchAnalytics(request)]);
              case 5:
                try {
                  // const data = await API.fetchAnalytics(request)
                  // if (data.error && data.error == 'access') {
                  // 	this.hasPremission = false
                  // 	loader.hide()
                  // 	return
                  // }
                  // this.hasPremission = true

                  // this.setMonth()
                  // this.setYear()

                  // this.firstEnter = false

                  // const urlParamss = new URLSearchParams(window.location.search)
                  // const active = urlParamss.get('active')
                  // this.active = active ? active : '1'

                  // if(data.error !== undefined) {
                  // 	this.dataLoaded = false
                  // 	this.noan = true
                  // 	this.archived_groups = data.archived_groups
                  // 	this.ggroups = data.groups
                  // }
                  // else {
                  // 	this.dataLoaded = true
                  // 	this.data = data
                  // 	this.noan = false

                  // 	this.call_bases = data.call_bases
                  // 	this.archived_groups = data.archived_groups
                  // 	this.ggroups = data.groups
                  // }

                  _this8.dataLoaded = true;
                  _this8.firstEnter = false;
                  _this8.hasPremission = true;
                  urlParamss = new URLSearchParams(window.location.search);
                  active = urlParamss.get('active');
                  _this8.active = active ? active : '1';
                  _this8.askey++;
                  window.history.replaceState({
                    id: '100'
                  }, 'Аналитика групп', '/timetracking/an?group=' + _this8.currentGroupId + '&active=' + _this8.active);
                  _this8.monthInfo.workDays = _this8.getBusinessDateCount(_this8.monthInfo.month, _this8.monthInfo.currentYear, _this8.currentGroup.workdays);
                } catch (error) {
                  alert(error);
                }
                // loader.hide()
              case 6:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7);
      }))();
    },
    getBusinessDateCount: function getBusinessDateCount(month, year, workdays) {
      month = month - 1;
      var next_month = month + 1 == 12 ? 0 : month + 1;
      var next_year = month + 1 == 12 ? year + 1 : year;
      var start = new Date(year, month, 1);
      var end = new Date(next_year, next_month, 1);
      var days = (end - start) / 86400000;
      var weekends = workdays == 5 ? [0, 6] : [0];
      var business_days = 0;
      for (var i = 1; i <= days; i++) {
        var d = new Date(year, month, i).getDay();
        if (!weekends.includes(d)) business_days++;
      }
      return business_days;
    },
    add_analytics: function add_analytics() {
      var _this9 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee8() {
        var loader;
        return _regeneratorRuntime().wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                loader = _this9.$loading.show();
                _context8.prev = 1;
                _context8.next = 4;
                return API.createAnalyticsGroup({
                  month: _this9.$moment(_this9.monthInfo.currentMonth, 'MMMM').format('M'),
                  year: _this9.currentYear,
                  group_id: _this9.currentGroupId
                });
              case 4:
                _this9.$toast.success('Аналитика для группы добавлена!');
                _this9.fetchData();
                _context8.next = 12;
                break;
              case 8:
                _context8.prev = 8;
                _context8.t0 = _context8["catch"](1);
                _this9.$toast.error('Аналитика для группы не добавлена!');
                console.error(_context8.t0);
              case 12:
                loader.hide();
              case 13:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, null, [[1, 8]]);
      }))();
    },
    restore_analytics: function restore_analytics() {
      var _this10 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee9() {
        var loader, data;
        return _regeneratorRuntime().wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                if (confirm('Вы уверены что хотите восстановить аналитику группы?')) {
                  _context9.next = 2;
                  break;
                }
                return _context9.abrupt("return");
              case 2:
                loader = _this10.$loading.show();
                _context9.prev = 3;
                _context9.next = 6;
                return API.restoreAnalyticsGroup({
                  id: _this10.restore_group
                });
              case 6:
                data = _context9.sent;
                _this10.$toast.success('Восстановлен!');
                _this10.currentGroupId = _this10.restore_group;
                _this10.ggroups = data.groups;
                _this10.fetchData();
                _this10.restore_group = null;
                _this10.showArchive = false;
                _context9.next = 19;
                break;
              case 15:
                _context9.prev = 15;
                _context9.t0 = _context9["catch"](3);
                _this10.$toast.error('Не удалось восстановить аналитику!');
                console.error(_context9.t0);
              case 19:
                loader.hide();
              case 20:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, null, [[3, 15]]);
      }))();
    },
    archive: function archive() {
      var _this11 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee10() {
        var loader;
        return _regeneratorRuntime().wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                if (confirm('Вы уверены что хотите архивировать аналитику группы ?')) {
                  _context10.next = 2;
                  break;
                }
                return _context10.abrupt("return");
              case 2:
                loader = _this11.$loading.show();
                _context10.prev = 3;
                _context10.next = 6;
                return API.archiveAnalyticsGroup({
                  id: _this11.currentGroupId
                });
              case 6:
                _this11.$toast.success('Архивирован!');
                _this11.currentGroupId = _this11.ggroups[0].id;
                _this11.fetchData();
                _context10.next = 15;
                break;
              case 11:
                _context10.prev = 11;
                _context10.t0 = _context10["catch"](3);
                _this11.$toast.error('Не удалось архивировать аналитику!');
                console.error(_context10.t0);
              case 15:
                loader.hide();
              case 16:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10, null, [[3, 11]]);
      }))();
    },
    onUpdateActivity: function onUpdateActivity(activities) {
      this.activities = activities;
      this.fetchData();
    },
    onDeleteActivity: function onDeleteActivity() {
      this.fetchData();
    },
    onOrderActivity: function onOrderActivity() {
      this.fetchData();
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=style&index=0&lang=scss&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=style&index=0&lang=scss& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".AnalyticStat-settings {\n  font-size: 0.8em;\n}\n.AnalyticStat-rowControls {\n  display: flex;\n  flex-flow: row nowrap;\n  align-items: center;\n  justify-content: center;\n  gap: 0.4rem;\n}\n.AnalyticStat-contexts input {\n  width: 50px;\n}\n.z-12 {\n  z-index: 12;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".AnalyticsDetailes-controls {\n  position: relative;\n}\n.AnalyticsDetailes-monthTable {\n  margin-top: -38px;\n}\n.drag_item {\n  display: flex;\n  justify-content: flex-start;\n  align-items: center;\n  gap: 0.5rem;\n  padding: 5px 8px;\n  margin-bottom: 5px;\n  border: 1px solid #eee;\n  transform: translateZ(0px);\n  background: white;\n  border-radius: 5px;\n  cursor: move;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".my-table.m2 tr .badge {\n  opacity: 1;\n}\n.day-minute {\n  padding: 0 !important;\n  text-align: center;\n  vertical-align: middle;\n}\n.day-minute div {\n  font-size: 0.8rem;\n}\n.day-minute.table-success {\n  background-color: #01c601 !important;\n}\n.day-minute.table-danger {\n  background-color: #fd1600 !important;\n}\n.table td, .table th, .table thead th {\n  vertical-align: middle;\n  min-width: 42px;\n  text-align: center;\n}\n.table.b-table.table-sm > thead > tr > [aria-sort]:not(.b-table-sort-icon-left),\n.table.b-table.table-sm > tfoot > tr > [aria-sort]:not(.b-table-sort-icon-left) {\n  background-image: none !important;\n  min-width: 32px;\n}\n.table .stat {\n  background: #d9edff;\n}\n.table {\n  position: relative;\n}\n.b-table-sticky-column {\n  position: sticky;\n  left: 0;\n  z-index: 2;\n}\n.wd {\n  font-size: 0.75rem;\n  width: -moz-max-content;\n  width: max-content;\n  font-weight: 500;\n}\n.table .stat.plan {\n  background: #007bff;\n  color: #fff;\n}\n.cell-input {\n  background: none;\n  border: none;\n  text-align: center;\n  -moz-appearance: textfield;\n  font-size: 0.8rem;\n  font-weight: normal;\n  padding: 0;\n  color: #000;\n  border-radius: 0;\n}\n.cell-input:focus {\n  outline: none;\n}\n.cell-input::-webkit-outer-spin-button, .cell-input::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n.z2233 {\n  z-index: 3 !important;\n}\n.r-to .wd .badge-success {\n  display: none;\n}\n.r-to tr:hover td.wdf {\n  background: #51a5ff;\n}\n.r-to tr:hover td {\n  background: #eaf3ff;\n}\n.lb {\n  border-left: 1px solid #aaa !important;\n}\n.rb {\n  border-right: 1px solid #aaa !important;\n  background: whitesmoke;\n}\n.sticky-h1 {\n  position: sticky;\n  top: 0;\n  z-index: 2;\n  outline: 1px solid #ddd !important;\n}\n.sticky-h2 {\n  position: sticky;\n  top: 39px;\n  z-index: 2;\n  outline: 1px solid #ddd !important;\n}\n.TableActivityCollection .sticky-h1:last-child,\n.TableActivityCollection .sticky-h2:last-child {\n  position: sticky !important;\n  font-size: 12px !important;\n}\n.TableActivityCollection .sticky-h1.b-table-sticky-column,\n.TableActivityCollection .sticky-h2.b-table-sticky-column {\n  z-index: 10 !important;\n}\n.TableActivityCollection thead tr {\n  z-index: 99999 !important;\n}\n.TableActivityCollection-data {\n  width: 76px !important;\n  max-width: 76px !important;\n  padding: 0 !important;\n}\n.TableActivityCollection-data .cell-input {\n  width: 76px !important;\n  border: none !important;\n  background-color: transparent !important;\n}\n.TableActivityCollection-data .cell-input:focus {\n  border: none !important;\n  background-color: transparent !important;\n  box-shadow: none !important;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".TableDecomposition-inputName::-moz-placeholder {\n  font-style: italic;\n}\n.TableDecomposition-inputName::placeholder {\n  font-style: italic;\n}\n.TableDecomposition-inputNumber {\n  display: block;\n  width: calc(100% + 20px);\n  margin: 0 -10px;\n  background: transparent;\n  -moz-appearance: textfield;\n  text-align: center;\n}\n.TableDecomposition-inputNumber::-webkit-outer-spin-button, .TableDecomposition-inputNumber::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n.TableDecomposition-header {\n  font-size: 14px !important;\n  font-weight: 700 !important;\n}\n.TableDecomposition-subhead .TableDecomposition-th {\n  background-color: #dde9ff !important;\n  border-color: #b5c1d7 !important;\n}\n.TableDecomposition-th {\n  padding: 5px !important;\n  font-size: 12px !important;\n}\n.TableDecomposition-td {\n  padding: 5px !important;\n}\n.day-minute {\n  padding: 0 !important;\n  text-align: center;\n  vertical-align: middle;\n}\n.day-minute div {\n  font-size: 0.8rem;\n}\n.day-minute.table-success {\n  background-color: #01c601 !important;\n}\n.day-minute.table-danger {\n  background-color: #fd1600 !important;\n}\n.table td,\n.table th,\n.table thead th {\n  vertical-align: middle;\n  min-width: 42px;\n  text-align: center;\n}\n.table.b-table.table-sm > thead > tr > [aria-sort]:not(.b-table-sort-icon-left),\n.table.b-table.table-sm > tfoot > tr > [aria-sort]:not(.b-table-sort-icon-left) {\n  background-image: none !important;\n  min-width: 32px;\n}\n.table .stat {\n  background: #d9edff;\n}\n.table {\n  position: relative;\n}\n.b-table-sticky-column {\n  position: sticky;\n  left: 0;\n  z-index: 2;\n}\n.wd {\n  font-size: 0.75rem;\n  width: -moz-max-content;\n  width: max-content;\n  font-weight: 500;\n}\n.table .stat.plan {\n  background: #007bff;\n  color: #fff;\n}\n.cell-input {\n  background: none;\n  border: none;\n  text-align: center;\n  -moz-appearance: textfield;\n  font-size: 0.8rem;\n  font-weight: normal;\n  padding: 0;\n  color: #000;\n  border-radius: 0;\n}\n.cell-input:focus {\n  outline: none;\n}\n.cell-input::-webkit-outer-spin-button, .cell-input::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n.w-250 {\n  min-width: 250px;\n}\n.wd .fa {\n  opacity: 0;\n}\n.wd:hover .fa {\n  opacity: 1;\n}\n.day-minute div {\n  font-size: 0.8rem;\n  font-weight: 500;\n}\n.border-r-2 {\n  border-right: 2px solid #b5c1d7 !important;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".table th.averages,\n.table td.averages {\n  background-color: #28a745 !important;\n  color: #fff;\n}\n.table .t-total {\n  background-color: #28a745 !important;\n  color: #fff;\n}\n.table .bg-white {\n  background: white;\n}\n.quality .t-name {\n  min-width: 200px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".JobtronCup {\n  width: 15px;\n  height: 20px;\n}\n.JobtronCup_rotate {\n  animation: rotateCup 2.5s cubic-bezier(0.78, 0, 0.26, 0.79) infinite normal;\n}\n@keyframes rotateCup {\n0% {\n    transform: rotateY(0);\n}\n100% {\n    transform: rotateY(360deg);\n}\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".JobtronSwitch {\n  display: inline-block;\n  position: relative;\n}\n.JobtronSwitch-switch {\n  display: block;\n  width: 48px;\n  height: 30px;\n  background: #8BABD8;\n  border-radius: 20px;\n  cursor: pointer;\n}\n.JobtronSwitch-switch:before {\n  content: \"\";\n  width: 20px;\n  height: 20px;\n  position: absolute;\n  z-index: 3;\n  top: 5px;\n  left: 5px;\n  background-color: #fff;\n  border-radius: 20px;\n  box-shadow: 0px 4px 4px rgba(50, 50, 71, 0.18), 0px 4px 8px rgba(50, 50, 71, 0.16);\n}\n.JobtronSwitch-input {\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  z-index: 5;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  opacity: 0;\n  cursor: pointer;\n}\n.JobtronSwitch-input:checked ~ .JobtronSwitch-switch {\n  background: #3361FF;\n}\n.JobtronSwitch-input:checked ~ .JobtronSwitch-switch:before {\n  left: auto;\n  right: 5px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".AnalyticsPage-gauges {\n  flex: 1;\n}\n.AnalyticsPage-gauges .TopGauges-group,\n.AnalyticsPage-gauges .TopGauges-gauges {\n  flex: 1;\n  justify-content: flex-start !important;\n  align-items: flex-end;\n}\n.AnalyticsPage-gauges .TopGauges-gauges {\n  gap: 1.5rem;\n}\n.AnalyticsPage-gauges .TopGauges-gauge {\n  flex: 0 0 content;\n}\n.AnalyticsPage-gauges .TopGauges-gauge:last-of-type {\n  margin-left: auto;\n}\n.AnalyticsPage-skeletonImg {\n  width: 100px;\n  height: 100px;\n}\n.AnalyticsPage .btn {\n  padding: 0.375rem 0.75rem;\n}\n.AnalyticsPage .btn.btn-sm {\n  padding: 0.15rem 0.5rem;\n}\n.AnalyticsPage .cell-input {\n  padding: 0 !important;\n}\n.mw30 {\n  min-width: 30px;\n}\n.rating {\n  display: inline-block;\n  unicode-bidi: bidi-override;\n  color: #888888;\n  font-size: 25px;\n  height: 25px;\n  width: auto;\n  margin: 0;\n  position: relative;\n  padding: 0;\n}\n.rating-upper {\n  color: #c52b2f;\n  padding: 0;\n  position: absolute;\n  z-index: 1;\n  display: flex;\n  top: 0;\n  left: 0;\n  overflow: hidden;\n}\n.rating-lower {\n  padding: 0;\n  display: flex;\n  z-index: 0;\n}\n.ap-text {\n  margin: 0;\n  display: flex;\n  font-size: 12px;\n  align-items: center;\n}\n.ap-text span {\n  font-size: 16px;\n  font-weight: 700;\n  margin-left: 5px;\n}\n.fz12 {\n  font-size: 12px;\n  margin-bottom: 0;\n  line-height: 20px;\n  color: #000 !important;\n}\n.wrap {\n  background: #f3f7f9;\n  margin-bottom: 15px;\n  padding-top: 15px;\n  border: 1px solid #dde8ee;\n  border-radius: 5px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.bg-bluegrey {\n    background: #e9ecef;\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=style&index=0&lang=scss&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=style&index=0&lang=scss& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticStat_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticStat.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticStat_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticStat_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsDetailes_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsDetailes_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsDetailes_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityCollection_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableActivityCollection.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityCollection_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityCollection_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableDecomposition_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableDecomposition.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableDecomposition_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableDecomposition_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQualityWeekly_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableQualityWeekly.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQualityWeekly_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQualityWeekly_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Cup_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Cup.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Cup_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Cup_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=style&index=0&lang=scss&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=style&index=0&lang=scss& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsPage_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticsPage.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsPage_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsPage_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=style&index=0&lang=css&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=style&index=0&lang=css& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CallBase_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CallBase.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=style&index=0&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CallBase_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CallBase_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/AnalyticStat.vue":
/*!**************************************************!*\
  !*** ./resources/js/components/AnalyticStat.vue ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AnalyticStat_vue_vue_type_template_id_ad882428___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AnalyticStat.vue?vue&type=template&id=ad882428& */ "./resources/js/components/AnalyticStat.vue?vue&type=template&id=ad882428&");
/* harmony import */ var _AnalyticStat_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AnalyticStat.vue?vue&type=script&lang=js& */ "./resources/js/components/AnalyticStat.vue?vue&type=script&lang=js&");
/* harmony import */ var _AnalyticStat_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AnalyticStat.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/AnalyticStat.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AnalyticStat_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AnalyticStat_vue_vue_type_template_id_ad882428___WEBPACK_IMPORTED_MODULE_0__.render,
  _AnalyticStat_vue_vue_type_template_id_ad882428___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/AnalyticStat.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/CallBase.vue":
/*!**********************************************!*\
  !*** ./resources/js/components/CallBase.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _CallBase_vue_vue_type_template_id_90ba278c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CallBase.vue?vue&type=template&id=90ba278c& */ "./resources/js/components/CallBase.vue?vue&type=template&id=90ba278c&");
/* harmony import */ var _CallBase_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CallBase.vue?vue&type=script&lang=js& */ "./resources/js/components/CallBase.vue?vue&type=script&lang=js&");
/* harmony import */ var _CallBase_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CallBase.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/CallBase.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _CallBase_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CallBase_vue_vue_type_template_id_90ba278c___WEBPACK_IMPORTED_MODULE_0__.render,
  _CallBase_vue_vue_type_template_id_90ba278c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/CallBase.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AnalyticsDetailes_vue_vue_type_template_id_5c952445___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AnalyticsDetailes.vue?vue&type=template&id=5c952445& */ "./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=template&id=5c952445&");
/* harmony import */ var _AnalyticsDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AnalyticsDetailes.vue?vue&type=script&lang=js& */ "./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=script&lang=js&");
/* harmony import */ var _AnalyticsDetailes_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AnalyticsDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AnalyticsDetailes_vue_vue_type_template_id_5c952445___WEBPACK_IMPORTED_MODULE_0__.render,
  _AnalyticsDetailes_vue_vue_type_template_id_5c952445___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/tables/TableActivityCollection.vue":
/*!********************************************************************!*\
  !*** ./resources/js/components/tables/TableActivityCollection.vue ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TableActivityCollection_vue_vue_type_template_id_516af23c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TableActivityCollection.vue?vue&type=template&id=516af23c& */ "./resources/js/components/tables/TableActivityCollection.vue?vue&type=template&id=516af23c&");
/* harmony import */ var _TableActivityCollection_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TableActivityCollection.vue?vue&type=script&lang=js& */ "./resources/js/components/tables/TableActivityCollection.vue?vue&type=script&lang=js&");
/* harmony import */ var _TableActivityCollection_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TableActivityCollection.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/tables/TableActivityCollection.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TableActivityCollection_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TableActivityCollection_vue_vue_type_template_id_516af23c___WEBPACK_IMPORTED_MODULE_0__.render,
  _TableActivityCollection_vue_vue_type_template_id_516af23c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/tables/TableActivityCollection.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/tables/TableDecomposition.vue":
/*!***************************************************************!*\
  !*** ./resources/js/components/tables/TableDecomposition.vue ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TableDecomposition_vue_vue_type_template_id_1da121ac___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TableDecomposition.vue?vue&type=template&id=1da121ac& */ "./resources/js/components/tables/TableDecomposition.vue?vue&type=template&id=1da121ac&");
/* harmony import */ var _TableDecomposition_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TableDecomposition.vue?vue&type=script&lang=js& */ "./resources/js/components/tables/TableDecomposition.vue?vue&type=script&lang=js&");
/* harmony import */ var _TableDecomposition_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TableDecomposition.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/tables/TableDecomposition.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TableDecomposition_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TableDecomposition_vue_vue_type_template_id_1da121ac___WEBPACK_IMPORTED_MODULE_0__.render,
  _TableDecomposition_vue_vue_type_template_id_1da121ac___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/tables/TableDecomposition.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/tables/TableQualityWeekly.vue":
/*!***************************************************************!*\
  !*** ./resources/js/components/tables/TableQualityWeekly.vue ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TableQualityWeekly_vue_vue_type_template_id_45440b81___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TableQualityWeekly.vue?vue&type=template&id=45440b81& */ "./resources/js/components/tables/TableQualityWeekly.vue?vue&type=template&id=45440b81&");
/* harmony import */ var _TableQualityWeekly_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TableQualityWeekly.vue?vue&type=script&lang=js& */ "./resources/js/components/tables/TableQualityWeekly.vue?vue&type=script&lang=js&");
/* harmony import */ var _TableQualityWeekly_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TableQualityWeekly.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/tables/TableQualityWeekly.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TableQualityWeekly_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TableQualityWeekly_vue_vue_type_template_id_45440b81___WEBPACK_IMPORTED_MODULE_0__.render,
  _TableQualityWeekly_vue_vue_type_template_id_45440b81___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/tables/TableQualityWeekly.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/Cup.vue":
/*!********************************************!*\
  !*** ./resources/js/components/ui/Cup.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Cup_vue_vue_type_template_id_31e214ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Cup.vue?vue&type=template&id=31e214ae& */ "./resources/js/components/ui/Cup.vue?vue&type=template&id=31e214ae&");
/* harmony import */ var _Cup_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Cup.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/Cup.vue?vue&type=script&lang=js&");
/* harmony import */ var _Cup_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Cup.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/ui/Cup.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Cup_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Cup_vue_vue_type_template_id_31e214ae___WEBPACK_IMPORTED_MODULE_0__.render,
  _Cup_vue_vue_type_template_id_31e214ae___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/Cup.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/Switch.vue":
/*!***********************************************!*\
  !*** ./resources/js/components/ui/Switch.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Switch.vue?vue&type=template&id=40141c18& */ "./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&");
/* harmony import */ var _Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Switch.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&");
/* harmony import */ var _Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Switch.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.render,
  _Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/Switch.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/AnalyticsPage.vue":
/*!**********************************************!*\
  !*** ./resources/js/pages/AnalyticsPage.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AnalyticsPage_vue_vue_type_template_id_aa0b7408___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AnalyticsPage.vue?vue&type=template&id=aa0b7408& */ "./resources/js/pages/AnalyticsPage.vue?vue&type=template&id=aa0b7408&");
/* harmony import */ var _AnalyticsPage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AnalyticsPage.vue?vue&type=script&lang=js& */ "./resources/js/pages/AnalyticsPage.vue?vue&type=script&lang=js&");
/* harmony import */ var _AnalyticsPage_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AnalyticsPage.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/AnalyticsPage.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AnalyticsPage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AnalyticsPage_vue_vue_type_template_id_aa0b7408___WEBPACK_IMPORTED_MODULE_0__.render,
  _AnalyticsPage_vue_vue_type_template_id_aa0b7408___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/AnalyticsPage.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/AnalyticStat.vue?vue&type=script&lang=js&":
/*!***************************************************************************!*\
  !*** ./resources/js/components/AnalyticStat.vue?vue&type=script&lang=js& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticStat_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticStat.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticStat_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/CallBase.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/components/CallBase.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CallBase_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CallBase.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CallBase_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticsDetailes.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/tables/TableActivityCollection.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/components/tables/TableActivityCollection.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityCollection_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableActivityCollection.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityCollection_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/tables/TableDecomposition.vue?vue&type=script&lang=js&":
/*!****************************************************************************************!*\
  !*** ./resources/js/components/tables/TableDecomposition.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableDecomposition_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableDecomposition.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableDecomposition_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/tables/TableQualityWeekly.vue?vue&type=script&lang=js&":
/*!****************************************************************************************!*\
  !*** ./resources/js/components/tables/TableQualityWeekly.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQualityWeekly_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableQualityWeekly.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQualityWeekly_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/Cup.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/components/ui/Cup.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Cup_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Cup.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Cup_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/components/ui/Switch.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/AnalyticsPage.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/pages/AnalyticsPage.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsPage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticsPage.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsPage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/AnalyticStat.vue?vue&type=style&index=0&lang=scss&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/AnalyticStat.vue?vue&type=style&index=0&lang=scss& ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticStat_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticStat.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsDetailes_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/tables/TableActivityCollection.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/components/tables/TableActivityCollection.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityCollection_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableActivityCollection.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/tables/TableDecomposition.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/components/tables/TableDecomposition.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableDecomposition_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableDecomposition.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/tables/TableQualityWeekly.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/components/tables/TableQualityWeekly.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQualityWeekly_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableQualityWeekly.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/ui/Cup.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************!*\
  !*** ./resources/js/components/ui/Cup.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Cup_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Cup.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************!*\
  !*** ./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/AnalyticsPage.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************!*\
  !*** ./resources/js/pages/AnalyticsPage.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsPage_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticsPage.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/CallBase.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************!*\
  !*** ./resources/js/components/CallBase.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CallBase_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CallBase.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=style&index=0&lang=css&");


/***/ }),

/***/ "./resources/js/components/AnalyticStat.vue?vue&type=template&id=ad882428&":
/*!*********************************************************************************!*\
  !*** ./resources/js/components/AnalyticStat.vue?vue&type=template&id=ad882428& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticStat_vue_vue_type_template_id_ad882428___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticStat_vue_vue_type_template_id_ad882428___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticStat_vue_vue_type_template_id_ad882428___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticStat.vue?vue&type=template&id=ad882428& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=template&id=ad882428&");


/***/ }),

/***/ "./resources/js/components/CallBase.vue?vue&type=template&id=90ba278c&":
/*!*****************************************************************************!*\
  !*** ./resources/js/components/CallBase.vue?vue&type=template&id=90ba278c& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CallBase_vue_vue_type_template_id_90ba278c___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CallBase_vue_vue_type_template_id_90ba278c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CallBase_vue_vue_type_template_id_90ba278c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CallBase.vue?vue&type=template&id=90ba278c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=template&id=90ba278c&");


/***/ }),

/***/ "./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=template&id=5c952445&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=template&id=5c952445& ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsDetailes_vue_vue_type_template_id_5c952445___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsDetailes_vue_vue_type_template_id_5c952445___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsDetailes_vue_vue_type_template_id_5c952445___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticsDetailes.vue?vue&type=template&id=5c952445& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=template&id=5c952445&");


/***/ }),

/***/ "./resources/js/components/tables/TableActivityCollection.vue?vue&type=template&id=516af23c&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/components/tables/TableActivityCollection.vue?vue&type=template&id=516af23c& ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityCollection_vue_vue_type_template_id_516af23c___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityCollection_vue_vue_type_template_id_516af23c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityCollection_vue_vue_type_template_id_516af23c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableActivityCollection.vue?vue&type=template&id=516af23c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=template&id=516af23c&");


/***/ }),

/***/ "./resources/js/components/tables/TableDecomposition.vue?vue&type=template&id=1da121ac&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/components/tables/TableDecomposition.vue?vue&type=template&id=1da121ac& ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableDecomposition_vue_vue_type_template_id_1da121ac___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableDecomposition_vue_vue_type_template_id_1da121ac___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableDecomposition_vue_vue_type_template_id_1da121ac___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableDecomposition.vue?vue&type=template&id=1da121ac& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=template&id=1da121ac&");


/***/ }),

/***/ "./resources/js/components/tables/TableQualityWeekly.vue?vue&type=template&id=45440b81&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/components/tables/TableQualityWeekly.vue?vue&type=template&id=45440b81& ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQualityWeekly_vue_vue_type_template_id_45440b81___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQualityWeekly_vue_vue_type_template_id_45440b81___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQualityWeekly_vue_vue_type_template_id_45440b81___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableQualityWeekly.vue?vue&type=template&id=45440b81& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=template&id=45440b81&");


/***/ }),

/***/ "./resources/js/components/ui/Cup.vue?vue&type=template&id=31e214ae&":
/*!***************************************************************************!*\
  !*** ./resources/js/components/ui/Cup.vue?vue&type=template&id=31e214ae& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Cup_vue_vue_type_template_id_31e214ae___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Cup_vue_vue_type_template_id_31e214ae___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Cup_vue_vue_type_template_id_31e214ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Cup.vue?vue&type=template&id=31e214ae& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=template&id=31e214ae&");


/***/ }),

/***/ "./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&":
/*!******************************************************************************!*\
  !*** ./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=template&id=40141c18& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&");


/***/ }),

/***/ "./resources/js/pages/AnalyticsPage.vue?vue&type=template&id=aa0b7408&":
/*!*****************************************************************************!*\
  !*** ./resources/js/pages/AnalyticsPage.vue?vue&type=template&id=aa0b7408& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsPage_vue_vue_type_template_id_aa0b7408___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsPage_vue_vue_type_template_id_aa0b7408___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AnalyticsPage_vue_vue_type_template_id_aa0b7408___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AnalyticsPage.vue?vue&type=template&id=aa0b7408& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=template&id=aa0b7408&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=template&id=ad882428&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/AnalyticStat.vue?vue&type=template&id=ad882428& ***!
  \************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "AnalyticStat z-12 relative" },
    [
      _c("div", { staticClass: "table-header" }, [
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.coords,
              expression: "coords",
            },
          ],
          staticClass: "cell-coords",
          attrs: { type: "text" },
          domProps: { value: _vm.coords },
          on: {
            input: function ($event) {
              if ($event.target.composing) {
                return
              }
              _vm.coords = $event.target.value
            },
          },
        }),
        _vm._v(" "),
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.cell_type,
              expression: "cell_type",
            },
          ],
          staticClass: "cell-type",
          attrs: { type: "text" },
          domProps: { value: _vm.cell_type },
          on: {
            input: function ($event) {
              if ($event.target.composing) {
                return
              }
              _vm.cell_type = $event.target.value
            },
          },
        }),
        _vm._v(" "),
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.cell_show_value,
              expression: "cell_show_value",
            },
          ],
          staticClass: "cell-show-value",
          attrs: { type: "text" },
          domProps: { value: _vm.cell_show_value },
          on: {
            input: function ($event) {
              if ($event.target.composing) {
                return
              }
              _vm.cell_show_value = $event.target.value
            },
          },
        }),
        _vm._v(" "),
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.cell_value,
              expression: "cell_value",
            },
          ],
          staticClass: "cell-value",
          attrs: { type: "text" },
          domProps: { value: _vm.cell_value },
          on: {
            input: function ($event) {
              if ($event.target.composing) {
                return
              }
              _vm.cell_value = $event.target.value
            },
          },
        }),
        _vm._v(" "),
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.cell_comment,
              expression: "cell_comment",
            },
          ],
          staticClass: "cell-comment",
          attrs: { type: "text" },
          domProps: { value: _vm.cell_comment },
          on: {
            input: function ($event) {
              if ($event.target.composing) {
                return
              }
              _vm.cell_comment = $event.target.value
            },
          },
        }),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "AnalyticStat-tables d-flex relative" }, [
        _c(
          "div",
          { staticClass: "relative w551", attrs: { id: "wow-table" } },
          [
            _c(
              "table",
              { staticClass: "as-table left-side" },
              [
                _c(
                  "tr",
                  [
                    _c(
                      "td",
                      { staticClass: "ruler-cells t-cell text-center" },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "AnalyticStat-settings in-cell inner-div ",
                            on: {
                              click: function ($event) {
                                return _vm.editMode()
                              },
                            },
                          },
                          [_c("i", { staticClass: "icon-nd-settings" })]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _vm._l(
                      _vm.letter_cells.slice(1, 4),
                      function (letter, index) {
                        return _c(
                          "td",
                          {
                            key: index,
                            staticClass: "ruler-cells t-cell text-center",
                          },
                          [
                            index == 0
                              ? _c(
                                  "div",
                                  { staticClass: "in-cell inner-div d-flex" },
                                  [
                                    _c("span", { staticClass: "two-letter" }, [
                                      _vm._v("A"),
                                    ]),
                                    _vm._v(" "),
                                    _c("span", { staticClass: "two-letter" }, [
                                      _vm._v("B"),
                                    ]),
                                  ]
                                )
                              : _c(
                                  "div",
                                  { staticClass: "in-cell inner-div" },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t" +
                                        _vm._s(letter) +
                                        "\n\t\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                          ]
                        )
                      }
                    ),
                  ],
                  2
                ),
                _vm._v(" "),
                _vm._l(_vm.items, function (item, i_index) {
                  return _c(
                    "tr",
                    { key: i_index },
                    [
                      _c(
                        "td",
                        { staticClass: "t-cell rownumber ruler-cells" },
                        [
                          _c(
                            "div",
                            {
                              staticClass:
                                "AnalyticStat-rowControls in-cell inner-div text-center",
                            },
                            [
                              _vm.editTableMode && i_index > 3
                                ? _c(
                                    "span",
                                    {
                                      on: {
                                        click: function ($event) {
                                          return _vm.deleteRow(i_index)
                                        },
                                      },
                                    },
                                    [
                                      _c("IconDelete", {
                                        staticClass: "pointer",
                                        attrs: { width: "14", height: "14" },
                                      }),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.editTableMode && i_index > 2
                                ? _c(
                                    "span",
                                    {
                                      on: {
                                        click: function ($event) {
                                          return _vm.add_row(i_index)
                                        },
                                      },
                                    },
                                    [
                                      _c("ChatIconPlus", {
                                        staticClass: "pointer ChatIcon-parent",
                                        attrs: { width: "14", height: "14" },
                                      }),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _c("span", [_vm._v(_vm._s(i_index + 1))]),
                            ]
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _vm._l(_vm.fields.slice(0, 4), function (field, f_index) {
                        return [
                          field.key != "plan"
                            ? _c(
                                "td",
                                {
                                  key: f_index,
                                  staticClass: "t-cell font-bold",
                                  class: item[field.key].class,
                                  on: {
                                    click: function ($event) {
                                      return _vm.focus(i_index, f_index)
                                    },
                                  },
                                },
                                [
                                  field.key == "name" &&
                                  [1, 2, 3].includes(i_index)
                                    ? [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "d-flex justify-content-between",
                                          },
                                          [
                                            _c(
                                              "div",
                                              {
                                                staticClass: "inner-div halfy",
                                                class: {
                                                  focused:
                                                    _vm.focused_item ===
                                                      i_index &&
                                                    _vm.focused_field ===
                                                      f_index &&
                                                    _vm.focused_subfield == 1,
                                                  context:
                                                    item[field.key].context,
                                                  disabled:
                                                    item[field.key].editable ==
                                                    0,
                                                },
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.focusName(
                                                      i_index,
                                                      f_index,
                                                      1
                                                    )
                                                  },
                                                  contextmenu: function (
                                                    $event
                                                  ) {
                                                    $event.preventDefault()
                                                    $event.stopPropagation()
                                                    return _vm.openContextMenu(
                                                      item[field.key],
                                                      i_index,
                                                      f_index
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _c("div", {
                                                  staticClass: "disabled",
                                                }),
                                                _vm._v(" "),
                                                item[field.key].context
                                                  ? _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "contextor",
                                                      },
                                                      [
                                                        _c(
                                                          "ul",
                                                          {
                                                            staticClass:
                                                              "types",
                                                          },
                                                          [
                                                            _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.add_formula_1_31(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\tФормула с 1 по 31\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    )
                                                  : _vm._e(),
                                                _vm._v(" "),
                                                _vm.focused_item === i_index &&
                                                _vm.focused_field === f_index &&
                                                _vm.focused_subfield == 1
                                                  ? _c("input", {
                                                      directives: [
                                                        {
                                                          name: "model",
                                                          rawName: "v-model",
                                                          value:
                                                            item["name"].value,
                                                          expression:
                                                            "item['name'].value",
                                                        },
                                                      ],
                                                      staticClass: "in-cell",
                                                      attrs: { type: "text" },
                                                      domProps: {
                                                        value:
                                                          item["name"].value,
                                                      },
                                                      on: {
                                                        change: function (
                                                          $event
                                                        ) {
                                                          return _vm.change_stat(
                                                            i_index,
                                                            "name"
                                                          )
                                                        },
                                                        input: function (
                                                          $event
                                                        ) {
                                                          if (
                                                            $event.target
                                                              .composing
                                                          ) {
                                                            return
                                                          }
                                                          _vm.$set(
                                                            item["name"],
                                                            "value",
                                                            $event.target.value
                                                          )
                                                        },
                                                      },
                                                    })
                                                  : _c("input", {
                                                      staticClass: "in-cell",
                                                      attrs: { type: "text" },
                                                      domProps: {
                                                        value:
                                                          item["name"]
                                                            .show_value,
                                                      },
                                                    }),
                                                _vm._v(" "),
                                                _vm.focused_item === i_index &&
                                                _vm.focused_field === f_index &&
                                                _vm.focused_subfield == 1
                                                  ? _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "bottom-angle",
                                                      },
                                                      [
                                                        _c("div", {
                                                          staticClass: "angler",
                                                        }),
                                                      ]
                                                    )
                                                  : _vm._e(),
                                                _vm._v(" "),
                                                _c("div", {
                                                  staticClass: "top-angle",
                                                  class: item[field.key].type,
                                                }),
                                              ]
                                            ),
                                            _vm._v(" "),
                                            _c(
                                              "div",
                                              {
                                                staticClass: "inner-div halfy",
                                                class: {
                                                  focused:
                                                    _vm.focused_item ===
                                                      i_index &&
                                                    _vm.focused_field ===
                                                      f_index &&
                                                    _vm.focused_subfield == 2,
                                                  context: item["plan"].context,
                                                  disabled:
                                                    item["plan"].editable == 0,
                                                },
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.focusName(
                                                      i_index,
                                                      f_index,
                                                      2
                                                    )
                                                  },
                                                  contextmenu: function (
                                                    $event
                                                  ) {
                                                    $event.preventDefault()
                                                    $event.stopPropagation()
                                                    return _vm.openContextMenu(
                                                      item["plan"],
                                                      i_index,
                                                      f_index
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _c("div", {
                                                  staticClass: "disabled",
                                                }),
                                                _vm._v(" "),
                                                _vm.focused_item === i_index &&
                                                _vm.focused_field === f_index &&
                                                _vm.focused_subfield == 2
                                                  ? _c("input", {
                                                      directives: [
                                                        {
                                                          name: "model",
                                                          rawName: "v-model",
                                                          value:
                                                            item["plan"].value,
                                                          expression:
                                                            "item['plan'].value",
                                                        },
                                                      ],
                                                      staticClass: "in-cell",
                                                      attrs: { type: "text" },
                                                      domProps: {
                                                        value:
                                                          item["plan"].value,
                                                      },
                                                      on: {
                                                        change: function (
                                                          $event
                                                        ) {
                                                          return _vm.change_stat(
                                                            i_index,
                                                            "plan"
                                                          )
                                                        },
                                                        input: function (
                                                          $event
                                                        ) {
                                                          if (
                                                            $event.target
                                                              .composing
                                                          ) {
                                                            return
                                                          }
                                                          _vm.$set(
                                                            item["plan"],
                                                            "value",
                                                            $event.target.value
                                                          )
                                                        },
                                                      },
                                                    })
                                                  : _c("input", {
                                                      staticClass: "in-cell",
                                                      attrs: { type: "text" },
                                                      domProps: {
                                                        value:
                                                          item["plan"]
                                                            .show_value +
                                                          (i_index == 2
                                                            ? "%"
                                                            : ""),
                                                      },
                                                    }),
                                                _vm._v(" "),
                                                _vm.focused_item === i_index &&
                                                _vm.focused_field === f_index &&
                                                _vm.focused_subfield == 2
                                                  ? _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "bottom-angle",
                                                      },
                                                      [
                                                        _c("div", {
                                                          staticClass: "angler",
                                                        }),
                                                      ]
                                                    )
                                                  : _vm._e(),
                                                _vm._v(" "),
                                                _c("div", {
                                                  staticClass: "top-angle",
                                                  class: item[field.key].type,
                                                }),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    : [
                                        _c(
                                          "div",
                                          {
                                            staticClass: "inner-div",
                                            class: {
                                              focused:
                                                _vm.focused_item === i_index &&
                                                _vm.focused_field === f_index,
                                              context: item[field.key].context,
                                              disabled:
                                                item[field.key].editable == 0,
                                            },
                                            on: {
                                              contextmenu: function ($event) {
                                                $event.preventDefault()
                                                $event.stopPropagation()
                                                return _vm.openContextMenu(
                                                  item[field.key],
                                                  i_index,
                                                  f_index
                                                )
                                              },
                                            },
                                          },
                                          [
                                            _c("div", {
                                              staticClass: "disabled",
                                            }),
                                            _vm._v(" "),
                                            item[field.key].context
                                              ? _c(
                                                  "div",
                                                  { staticClass: "contextor" },
                                                  [
                                                    _vm.activeuserid == 5
                                                      ? _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "fonter d-flex justify-content-between",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.add_class(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ],
                                                                        "font-bold"
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tЖ\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "div",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.add_class(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ],
                                                                        "font-italic"
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tК\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "div",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.add_class(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ],
                                                                        "text-left"
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tЛ\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "div",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.add_class(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ],
                                                                        "text-center"
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tЦ\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "div",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.add_class(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ],
                                                                        "text-right"
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tП\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        )
                                                      : _vm._e(),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "color-choser d-flex justify-content-between",
                                                      },
                                                      [
                                                        _c("div", {
                                                          staticClass: "bg-red",
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.add_class(
                                                                item[field.key],
                                                                "bg-red"
                                                              )
                                                            },
                                                          },
                                                        }),
                                                        _vm._v(" "),
                                                        _c("div", {
                                                          staticClass:
                                                            "bg-yellow",
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.add_class(
                                                                item[field.key],
                                                                "bg-yellow"
                                                              )
                                                            },
                                                          },
                                                        }),
                                                        _vm._v(" "),
                                                        _c("div", {
                                                          staticClass:
                                                            "bg-green",
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.add_class(
                                                                item[field.key],
                                                                "bg-green"
                                                              )
                                                            },
                                                          },
                                                        }),
                                                        _vm._v(" "),
                                                        _c("div", {
                                                          staticClass:
                                                            "bg-blue",
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.add_class(
                                                                item[field.key],
                                                                "bg-blue"
                                                              )
                                                            },
                                                          },
                                                        }),
                                                        _vm._v(" "),
                                                        _c("div", {
                                                          staticClass:
                                                            "bg-violet",
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.add_class(
                                                                item[field.key],
                                                                "bg-violet"
                                                              )
                                                            },
                                                          },
                                                        }),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "ul",
                                                      { staticClass: "types" },
                                                      [
                                                        _vm.activeuserid == 5 ||
                                                        ["sum", "avg"].includes(
                                                          field.key
                                                        )
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.change_type(
                                                                        "initial",
                                                                        i_index,
                                                                        field.key
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tОбычный\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        _vm.activeuserid == 5
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.change_type(
                                                                        "formula",
                                                                        i_index,
                                                                        field.key
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tФормула\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        ["name"].includes(
                                                          field.key
                                                        )
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.change_type(
                                                                        "time",
                                                                        i_index,
                                                                        field.key
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tЧасы из табеля\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        ["name"].includes(
                                                          field.key
                                                        )
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.change_type(
                                                                        "stat",
                                                                        i_index,
                                                                        field.key
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tПоказатели\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        ["avg"].includes(
                                                          field.key
                                                        )
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.change_type(
                                                                        "avg",
                                                                        i_index,
                                                                        field.key
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tСреднее за месяц\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        ["sum"].includes(
                                                          field.key
                                                        )
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.change_type(
                                                                        "sum",
                                                                        i_index,
                                                                        field.key
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tСумма за месяц\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        ["name"].includes(
                                                          field.key
                                                        ) &&
                                                        item[field.key]
                                                          .depend_id === null
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.selectDepend(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tЗависимость от ряда\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : ["name"].includes(
                                                              field.key
                                                            )
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.removeDependency(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tУбрать зависимость\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        ["name"].includes(
                                                          field.key
                                                        )
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.add_formula_1_31(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tФормула с 1 по 31\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        ["name"].includes(
                                                          field.key
                                                        )
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.add_inhouse(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tОтсутствие минут inhouse\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        ["name"].includes(
                                                          field.key
                                                        )
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.add_remote(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tОтсутствие минут remote\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        ["name"].includes(
                                                          field.key
                                                        )
                                                          ? _c(
                                                              "li",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.add_salary(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\tНачисления отдела\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        _c("li", [
                                                          _c(
                                                            "div",
                                                            {
                                                              staticClass:
                                                                "d-flex decimals",
                                                            },
                                                            [
                                                              _c("p", [
                                                                _vm._v(
                                                                  "Дробные"
                                                                ),
                                                              ]),
                                                              _vm._v(" "),
                                                              _c("input", {
                                                                directives: [
                                                                  {
                                                                    name: "model",
                                                                    rawName:
                                                                      "v-model",
                                                                    value:
                                                                      item[
                                                                        field
                                                                          .key
                                                                      ]
                                                                        .decimals,
                                                                    expression:
                                                                      "item[field.key].decimals",
                                                                  },
                                                                ],
                                                                attrs: {
                                                                  type: "number",
                                                                },
                                                                domProps: {
                                                                  value:
                                                                    item[
                                                                      field.key
                                                                    ].decimals,
                                                                },
                                                                on: {
                                                                  change:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.setDecimals(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      )
                                                                    },
                                                                  input:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      if (
                                                                        $event
                                                                          .target
                                                                          .composing
                                                                      ) {
                                                                        return
                                                                      }
                                                                      _vm.$set(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ],
                                                                        "decimals",
                                                                        $event
                                                                          .target
                                                                          .value
                                                                      )
                                                                    },
                                                                },
                                                              }),
                                                            ]
                                                          ),
                                                        ]),
                                                      ]
                                                    ),
                                                  ]
                                                )
                                              : _vm._e(),
                                            _vm._v(" "),
                                            _vm.focused_item === i_index &&
                                            _vm.focused_field === f_index
                                              ? _c("input", {
                                                  directives: [
                                                    {
                                                      name: "model",
                                                      rawName: "v-model",
                                                      value:
                                                        item[field.key].value,
                                                      expression:
                                                        "item[field.key].value",
                                                    },
                                                  ],
                                                  staticClass: "in-cell",
                                                  attrs: { type: "text" },
                                                  domProps: {
                                                    value:
                                                      item[field.key].value,
                                                  },
                                                  on: {
                                                    change: function ($event) {
                                                      return _vm.change_stat(
                                                        i_index,
                                                        field.key
                                                      )
                                                    },
                                                    input: function ($event) {
                                                      if (
                                                        $event.target.composing
                                                      ) {
                                                        return
                                                      }
                                                      _vm.$set(
                                                        item[field.key],
                                                        "value",
                                                        $event.target.value
                                                      )
                                                    },
                                                  },
                                                })
                                              : _c("input", {
                                                  staticClass: "in-cell",
                                                  attrs: { type: "text" },
                                                  domProps: {
                                                    value: item[field.key]
                                                      .show_value
                                                      ? item[field.key]
                                                          .show_value
                                                      : "" +
                                                        (i_index == 2 &&
                                                        field.key == "sum"
                                                          ? "%"
                                                          : ""),
                                                  },
                                                }),
                                            _vm._v(" "),
                                            _vm.focused_item === i_index &&
                                            _vm.focused_field === f_index
                                              ? _c(
                                                  "div",
                                                  {
                                                    staticClass: "bottom-angle",
                                                  },
                                                  [
                                                    _c("div", {
                                                      staticClass: "angler",
                                                    }),
                                                  ]
                                                )
                                              : _vm._e(),
                                            _vm._v(" "),
                                            _c("div", {
                                              staticClass: "top-angle",
                                              class: item[field.key].type,
                                            }),
                                          ]
                                        ),
                                      ],
                                ],
                                2
                              )
                            : _vm._e(),
                        ]
                      }),
                    ],
                    2
                  )
                }),
              ],
              2
            ),
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass: "table-responsive",
            on: { scroll: _vm.hideContextMenu },
          },
          [
            _c(
              "table",
              { staticClass: "as-table" },
              [
                _c(
                  "tr",
                  _vm._l(
                    _vm.letter_cells.slice(4, _vm.letter_cells.length),
                    function (letter, index) {
                      return _c(
                        "td",
                        {
                          key: index,
                          staticClass: "ruler-cells t-cell text-center",
                        },
                        [
                          _c("div", { staticClass: "in-cell inner-div" }, [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t" +
                                _vm._s(letter) +
                                "\n\t\t\t\t\t\t"
                            ),
                          ]),
                        ]
                      )
                    }
                  ),
                  0
                ),
                _vm._v(" "),
                _vm._l(_vm.items, function (item, i_index) {
                  return _c(
                    "tr",
                    { key: i_index },
                    [
                      _vm._l(_vm.fields, function (field, f_index) {
                        return [
                          f_index > 3
                            ? _c(
                                "td",
                                {
                                  key: f_index,
                                  staticClass: "t-cell font-bold",
                                  class: item[field.key].class,
                                  attrs: {
                                    "data-an-cell": i_index + "-" + f_index,
                                  },
                                  on: {
                                    click: function ($event) {
                                      return _vm.focus(i_index, f_index)
                                    },
                                  },
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass: "inner-div",
                                      class: {
                                        focused:
                                          _vm.focused_item === i_index &&
                                          _vm.focused_field === f_index,
                                        context: item[field.key].context,
                                        disabled:
                                          item[field.key].editable == 0 ||
                                          ["stat", "time"].includes(
                                            item[field.key].type
                                          ),
                                        less:
                                          item[field.key].depend_id !== null &&
                                          _vm.items[
                                            _vm.depender[
                                              item[field.key].depend_id
                                            ]
                                          ] !== undefined &&
                                          Number(
                                            _vm.items[
                                              _vm.depender[
                                                item[field.key].depend_id
                                              ]
                                            ][field.key].show_value
                                          ) >
                                            Number(item[field.key].show_value),
                                        more:
                                          item[field.key].depend_id !== null &&
                                          _vm.items[
                                            _vm.depender[
                                              item[field.key].depend_id
                                            ]
                                          ] !== undefined &&
                                          Number(
                                            _vm.items[
                                              _vm.depender[
                                                item[field.key].depend_id
                                              ]
                                            ][field.key].show_value
                                          ) <
                                            Number(item[field.key].show_value),
                                      },
                                      on: {
                                        contextmenu: function ($event) {
                                          $event.preventDefault()
                                          $event.stopPropagation()
                                          return _vm.openContextMenu(
                                            item[field.key],
                                            i_index,
                                            f_index
                                          )
                                        },
                                      },
                                    },
                                    [
                                      _c("div", { staticClass: "disabled" }),
                                      _vm._v(" "),
                                      _vm.focused_item === i_index &&
                                      _vm.focused_field === f_index
                                        ? _c("input", {
                                            directives: [
                                              {
                                                name: "model",
                                                rawName: "v-model",
                                                value: item[field.key].value,
                                                expression:
                                                  "item[field.key].value",
                                              },
                                            ],
                                            staticClass: "in-cell",
                                            attrs: { type: "text" },
                                            domProps: {
                                              value: item[field.key].value,
                                            },
                                            on: {
                                              change: function ($event) {
                                                return _vm.change_stat(
                                                  i_index,
                                                  field.key
                                                )
                                              },
                                              input: function ($event) {
                                                if ($event.target.composing) {
                                                  return
                                                }
                                                _vm.$set(
                                                  item[field.key],
                                                  "value",
                                                  $event.target.value
                                                )
                                              },
                                            },
                                          })
                                        : i_index != 0
                                        ? _c("input", {
                                            staticClass: "in-cell",
                                            attrs: { type: "text" },
                                            domProps: {
                                              value:
                                                Number(
                                                  item[field.key].show_value
                                                ) != 0
                                                  ? Number(
                                                      item[field.key].show_value
                                                    ).toFixed(
                                                      item[field.key].decimals
                                                    ) + item[field.key].sign
                                                  : "",
                                            },
                                          })
                                        : _c("input", {
                                            staticClass: "in-cell",
                                            attrs: { type: "text" },
                                            domProps: {
                                              value: item[field.key].show_value,
                                            },
                                          }),
                                      _vm._v(" "),
                                      _vm.focused_item === i_index &&
                                      _vm.focused_field === f_index
                                        ? _c(
                                            "div",
                                            { staticClass: "bottom-angle" },
                                            [
                                              _c("div", {
                                                staticClass: "angler",
                                              }),
                                            ]
                                          )
                                        : _vm._e(),
                                      _vm._v(" "),
                                      _c("div", {
                                        staticClass: "top-angle",
                                        class: item[field.key].type,
                                      }),
                                    ]
                                  ),
                                ]
                              )
                            : _vm._e(),
                        ]
                      }),
                    ],
                    2
                  )
                }),
              ],
              2
            ),
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "AnalyticStat-contexts" },
          [
            _vm._l(_vm.items, function (item, i_index) {
              return [
                _vm._l(_vm.fields, function (field, f_index) {
                  return [
                    f_index > 3 && item[field.key].context
                      ? _c(
                          "div",
                          {
                            key: i_index + "-" + f_index,
                            staticClass: "contextor",
                            attrs: {
                              "data-an-context": i_index + "-" + f_index,
                            },
                          },
                          [
                            _c("ul", { staticClass: "types" }, [
                              _c("li", [
                                _c("div", { staticClass: "d-flex decimals" }, [
                                  _c("p", [_vm._v("Дробные")]),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: item[field.key].decimals,
                                        expression: "item[field.key].decimals",
                                      },
                                    ],
                                    attrs: { type: "number" },
                                    domProps: {
                                      value: item[field.key].decimals,
                                    },
                                    on: {
                                      change: function ($event) {
                                        return _vm.setDecimals(item[field.key])
                                      },
                                      input: function ($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          item[field.key],
                                          "decimals",
                                          $event.target.value
                                        )
                                      },
                                    },
                                  }),
                                ]),
                              ]),
                              _vm._v(" "),
                              _c(
                                "li",
                                {
                                  on: {
                                    click: function ($event) {
                                      return _vm.change_type(
                                        "initial",
                                        i_index,
                                        field.key
                                      )
                                    },
                                  },
                                },
                                [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t\tОбычный\n\t\t\t\t\t\t\t"
                                  ),
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "li",
                                {
                                  on: {
                                    click: function ($event) {
                                      return _vm.change_type(
                                        "formula",
                                        i_index,
                                        field.key
                                      )
                                    },
                                  },
                                },
                                [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t\tФормула\n\t\t\t\t\t\t\t"
                                  ),
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "li",
                                {
                                  on: {
                                    click: function ($event) {
                                      return _vm.add_formula_1_31(
                                        item[field.key]
                                      )
                                    },
                                  },
                                },
                                [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t\tФормула с 1 по 31\n\t\t\t\t\t\t\t"
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        )
                      : _vm._e(),
                  ]
                }),
              ]
            }),
          ],
          2
        ),
      ]),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          staticClass: "modalle",
          attrs: { title: "Зависимость значений от ряда", size: "md" },
          on: {
            ok: function ($event) {
              return _vm.save_depend()
            },
          },
          model: {
            value: _vm.showDependy,
            callback: function ($$v) {
              _vm.showDependy = $$v
            },
            expression: "showDependy",
          },
        },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-12" }, [
              _vm.itemy !== undefined && _vm.itemy !== null
                ? _c("b", [_vm._v(" " + _vm._s(_vm.itemy.value))])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-5 mt-1" }, [
              _c("p", {}, [_vm._v("\n\t\t\t\t\tРяд\n\t\t\t\t")]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-7" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.depend_id,
                      expression: "depend_id",
                    },
                  ],
                  staticClass: "form-control form-control-sm",
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.depend_id = $event.target.multiple
                        ? $$selectedVal
                        : $$selectedVal[0]
                    },
                  },
                },
                _vm._l(_vm.dependencies, function (dep, key) {
                  return _c(
                    "option",
                    { key: key, domProps: { value: dep.row_id } },
                    [
                      _vm._v(
                        "\n\t\t\t\t\t\t" +
                          _vm._s(dep.index) +
                          " " +
                          _vm._s(dep.name) +
                          "\n\t\t\t\t\t"
                      ),
                    ]
                  )
                }),
                0
              ),
            ]),
          ]),
        ]
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          staticClass: "modalle",
          attrs: { title: "Формула на 31 дней", size: "lg" },
          on: {
            ok: function ($event) {
              return _vm.save_cell_activity()
            },
          },
          model: {
            value: _vm.showVariants,
            callback: function ($$v) {
              _vm.showVariants = $$v
            },
            expression: "showVariants",
          },
        },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-5" }, [
              _c("p", {}, [_vm._v("\n\t\t\t\t\tАктивность\n\t\t\t\t")]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-7" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.activity_id,
                      expression: "activity_id",
                    },
                  ],
                  staticClass: "form-control form-control-sm",
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.activity_id = $event.target.multiple
                        ? $$selectedVal
                        : $$selectedVal[0]
                    },
                  },
                },
                _vm._l(_vm.activities, function (activity, key) {
                  return _c(
                    "option",
                    { key: key, domProps: { value: activity.id } },
                    [
                      _vm._v(
                        "\n\t\t\t\t\t\t" +
                          _vm._s(activity.name) +
                          "\n\t\t\t\t\t"
                      ),
                    ]
                  )
                }),
                0
              ),
            ]),
          ]),
        ]
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          staticClass: "modalle",
          attrs: { title: "Формула на 31 дней", size: "lg" },
          on: {
            ok: function ($event) {
              return _vm.save_formula_1_31()
            },
          },
          model: {
            value: _vm.showFormula1_31,
            callback: function ($$v) {
              _vm.showFormula1_31 = $$v
            },
            expression: "showFormula1_31",
          },
        },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-12" }, [
              _c("p", [
                _vm._v(
                  "Пишите ряд для выбора в фигурных скобках, 5 ряд это - {5}"
                ),
              ]),
              _vm._v(" "),
              _c("p", [_vm._v("Пример формулы: {5} * 12 / 1000")]),
              _vm._v(" "),
              _c("p", [_vm._v("Станет        : E5  * 12 / 1000")]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-12 mb-3" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.formula_1_31,
                    expression: "formula_1_31",
                  },
                ],
                staticClass: "form-control form-control-sm",
                attrs: { type: "text" },
                domProps: { value: _vm.formula_1_31 },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.formula_1_31 = $event.target.value
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-4" }, [
              _vm._v("\n\t\t\t\tКоличество цифр после запятой\n\t\t\t"),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-8" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.formula_1_31_decimals,
                    expression: "formula_1_31_decimals",
                  },
                ],
                staticClass: "form-control form-control-sm",
                attrs: { type: "text" },
                domProps: { value: _vm.formula_1_31_decimals },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.formula_1_31_decimals = $event.target.value
                  },
                },
              }),
            ]),
          ]),
        ]
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          staticClass: "modalle",
          attrs: { title: "Комментарии", size: "lg" },
          on: {
            ok: function ($event) {
              return _vm.saveComment()
            },
          },
          model: {
            value: _vm.showCommentWindow,
            callback: function ($$v) {
              _vm.showCommentWindow = $$v
            },
            expression: "showCommentWindow",
          },
        },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-12" }, [
              _c("p", [_vm._v("По какой причине добавляются минуты?")]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-12" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.comment,
                    expression: "comment",
                  },
                ],
                staticClass: "form-control form-control-sm",
                attrs: { type: "text" },
                domProps: { value: _vm.comment },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.comment = $event.target.value
                  },
                },
              }),
            ]),
          ]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=template&id=90ba278c&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/CallBase.vue?vue&type=template&id=90ba278c& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "mt-5 call-bases" }, [
    _c(
      "table",
      { staticClass: "table b-table table-bordered table-sm table-responsive" },
      [
        _c("tr", [
          _c("th"),
          _vm._v(" "),
          _c("th", [_vm._v("Сумма")]),
          _vm._v(" "),
          _c("th", { attrs: { colspan: "31" } }, [
            _vm._v("\n\t\t\t\t" + _vm._s(_vm.items.current_month) + "\n\t\t\t"),
          ]),
        ]),
        _vm._v(" "),
        _c(
          "tr",
          [
            _c(
              "th",
              {
                staticClass:
                  "table-primary b-table-sticky-column text-left px-2 t-name border-blue",
              },
              [_vm._v("\n\t\t\t\tКол-во базы\n\t\t\t")]
            ),
            _vm._v(" "),
            _c("th", [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.items.total,
                    expression: "items.total",
                  },
                ],
                staticClass: "form-control cell-input",
                attrs: { type: "number" },
                domProps: { value: _vm.items.total },
                on: {
                  change: function ($event) {
                    return _vm.save()
                  },
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.items, "total", $event.target.value)
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _vm._l(31, function (day) {
              return _c("th", { key: day, staticClass: "bg-bluegrey" }, [
                _vm._v("\n\t\t\t\t" + _vm._s(day) + "\n\t\t\t"),
              ])
            }),
          ],
          2
        ),
        _vm._v(" "),
        _c(
          "tr",
          [
            _vm._m(0),
            _vm._v(" "),
            _c("td", [
              _vm._v(_vm._s(Number(_vm.items.current_credits.sum).toFixed(0))),
            ]),
            _vm._v(" "),
            _vm._l(31, function (day) {
              return _c(
                "td",
                { key: day, staticClass: "px-0 day-minute text-center" },
                [
                  _c("div", [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.items.current_credits[day],
                          expression: "items.current_credits[day]",
                        },
                      ],
                      staticClass: "form-control cell-input",
                      attrs: { type: "number" },
                      domProps: { value: _vm.items.current_credits[day] },
                      on: {
                        change: function ($event) {
                          return _vm.save()
                        },
                        input: function ($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.items.current_credits,
                            day,
                            $event.target.value
                          )
                        },
                      },
                    }),
                  ]),
                ]
              )
            }),
          ],
          2
        ),
        _vm._v(" "),
        _c(
          "tr",
          [
            _vm._m(1),
            _vm._v(" "),
            _c("td", [
              _vm._v(_vm._s(Number(_vm.items.current_given.sum).toFixed(0))),
            ]),
            _vm._v(" "),
            _vm._l(31, function (day) {
              return _c(
                "td",
                { key: day, staticClass: "px-0 day-minute text-center" },
                [
                  _c("div", [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.items.current_given[day],
                          expression: "items.current_given[day]",
                        },
                      ],
                      staticClass: "form-control cell-input",
                      attrs: { type: "number" },
                      domProps: { value: _vm.items.current_given[day] },
                      on: {
                        change: function ($event) {
                          return _vm.save()
                        },
                        input: function ($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.items.current_given,
                            day,
                            $event.target.value
                          )
                        },
                      },
                    }),
                  ]),
                ]
              )
            }),
          ],
          2
        ),
        _vm._v(" "),
        _c("tr", [
          _c("th"),
          _vm._v(" "),
          _c("th"),
          _vm._v(" "),
          _c("th", { attrs: { colspan: "31" } }, [
            _vm._v("\n\t\t\t\t" + _vm._s(_vm.items.next_month) + "\n\t\t\t"),
          ]),
        ]),
        _vm._v(" "),
        _c(
          "tr",
          [
            _c(
              "th",
              {
                staticClass:
                  "table-primary b-table-sticky-column text-left px-2 t-name border-blue",
              },
              [_vm._v("\n\t\t\t\tКонверсия в выдачу\n\t\t\t")]
            ),
            _vm._v(" "),
            _c("th", [_vm._v(_vm._s(Number(_vm.items.conversion).toFixed(2)))]),
            _vm._v(" "),
            _vm._l(31, function (day) {
              return _c("th", { key: day, staticClass: "bg-bluegrey" }, [
                _vm._v("\n\t\t\t\t" + _vm._s(day) + "\n\t\t\t"),
              ])
            }),
          ],
          2
        ),
        _vm._v(" "),
        _c(
          "tr",
          [
            _vm._m(2),
            _vm._v(" "),
            _c("td", [
              _vm._v(_vm._s(Number(_vm.items.next_credits.sum).toFixed(0))),
            ]),
            _vm._v(" "),
            _vm._l(31, function (day) {
              return _c(
                "td",
                { key: day, staticClass: "px-0 day-minute text-center" },
                [
                  _c("div", [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.items.next_credits[day],
                          expression: "items.next_credits[day]",
                        },
                      ],
                      staticClass: "form-control cell-input",
                      attrs: { type: "number" },
                      domProps: { value: _vm.items.next_credits[day] },
                      on: {
                        change: function ($event) {
                          return _vm.save()
                        },
                        input: function ($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.items.next_credits,
                            day,
                            $event.target.value
                          )
                        },
                      },
                    }),
                  ]),
                ]
              )
            }),
          ],
          2
        ),
        _vm._v(" "),
        _c(
          "tr",
          [
            _vm._m(3),
            _vm._v(" "),
            _c("td", [
              _vm._v(_vm._s(Number(_vm.items.next_given.sum).toFixed(0))),
            ]),
            _vm._v(" "),
            _vm._l(31, function (day) {
              return _c(
                "td",
                { key: day, staticClass: "px-0 day-minute text-center" },
                [
                  _c("div", [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.items.next_given[day],
                          expression: "items.next_given[day]",
                        },
                      ],
                      staticClass: "form-control cell-input",
                      attrs: { type: "number" },
                      domProps: { value: _vm.items.next_given[day] },
                      on: {
                        change: function ($event) {
                          return _vm.save()
                        },
                        input: function ($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.items.next_given,
                            day,
                            $event.target.value
                          )
                        },
                      },
                    }),
                  ]),
                ]
              )
            }),
          ],
          2
        ),
      ]
    ),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "td",
      {
        staticClass:
          "table-primary b-table-sticky-column text-left px-2 t-name border-blue",
      },
      [
        _c("div", { staticClass: "wd d-flex align-items-center" }, [
          _vm._v("\n\t\t\t\t\tКол-во кредитов\n\t\t\t\t"),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "td",
      {
        staticClass:
          "table-primary b-table-sticky-column text-left px-2 t-name border-blue",
      },
      [
        _c("div", { staticClass: "wd d-flex align-items-center" }, [
          _vm._v("\n\t\t\t\t\tСумма выданных кредитов\n\t\t\t\t"),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "td",
      {
        staticClass:
          "table-primary b-table-sticky-column text-left px-2 t-name border-blue",
      },
      [
        _c("div", { staticClass: "wd d-flex align-items-center" }, [
          _vm._v("\n\t\t\t\t\tКол-во кредитов\n\t\t\t\t"),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "td",
      {
        staticClass:
          "table-primary b-table-sticky-column text-left px-2 t-name border-blue",
      },
      [
        _c("div", { staticClass: "wd d-flex align-items-center" }, [
          _vm._v("\n\t\t\t\t\tСумма выданных кредитов\n\t\t\t\t"),
        ]),
      ]
    )
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=template&id=5c952445&":
/*!*************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/AnalyticsPage/AnalyticsDetailes.vue?vue&type=template&id=5c952445& ***!
  \*************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "AnalyticsDetailes" },
    [
      _c(
        "b-tabs",
        {
          staticClass: "mt-4",
          attrs: { type: "card", "default-active-key": _vm.active_sub_tab },
          on: { change: _vm.showSubTab },
          scopedSlots: _vm._u([
            {
              key: "tabs-end",
              fn: function () {
                return [
                  _c(
                    "div",
                    {
                      directives: [
                        {
                          name: "click-outside",
                          rawName: "v-click-outside",
                          value: _vm.onClickOutside,
                          expression: "onClickOutside",
                        },
                      ],
                      staticClass: "AnalyticsDetailes-controls ml-a",
                    },
                    [
                      _c(
                        "JobtronButton",
                        {
                          staticClass: "ChatIcon-parent",
                          attrs: { fade: "", small: "" },
                          on: { click: _vm.onClickPopup },
                        },
                        [
                          _c("i", {
                            staticClass: "fa fa-bars",
                            staticStyle: { "font-size": "14px" },
                          }),
                        ]
                      ),
                      _vm._v(" "),
                      _vm.isPopup
                        ? _c("PopupMenu", [
                            _c(
                              "div",
                              {
                                staticClass: "PopupMenu-item wsnw",
                                on: {
                                  click: function ($event) {
                                    return _vm.add_activity()
                                  },
                                },
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-plus-square",
                                  staticStyle: { "font-size": "14px" },
                                }),
                                _vm._v(
                                  "\n\t\t\t\t\t\tДобавить таблицу\n\t\t\t\t\t"
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass: "PopupMenu-item wsnw",
                                on: {
                                  click: function ($event) {
                                    _vm.showOrder = true
                                  },
                                },
                              },
                              [
                                _c("i", {
                                  staticClass: "fas fa-sort-amount-down",
                                }),
                                _vm._v("\n\t\t\t\t\t\tСортировать\n\t\t\t\t\t"),
                              ]
                            ),
                          ])
                        : _vm._e(),
                    ],
                    1
                  ),
                ]
              },
              proxy: true,
            },
          ]),
        },
        [
          _vm._v(" "),
          _vm._l(_vm.activities, function (activityItem, index) {
            return _c(
              "b-tab",
              {
                key: index,
                attrs: { title: activityItem.name },
                on: {
                  change: function ($event) {
                    return _vm.showSubTab(index)
                  },
                },
              },
              [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-default rounded mt-4",
                    on: {
                      click: function ($event) {
                        return _vm.switchToMonthInActivity(index)
                      },
                    },
                  },
                  [_vm._v("\n\t\t\t\tМесяц\n\t\t\t")]
                ),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-default rounded mt-4",
                    on: {
                      click: function ($event) {
                        return _vm.switchToYearInActivity(index)
                      },
                    },
                  },
                  [_vm._v("\n\t\t\t\tГод\n\t\t\t")]
                ),
                _vm._v(" "),
                _vm.activityStates[index] !== undefined
                  ? _c("div", { staticClass: "mt-2" }, [
                      _vm.activityStates.at(index) === "month"
                        ? _c(
                            "div",
                            [
                              activityItem.type == "default"
                                ? _c("TableActivityNew", {
                                    key: activityItem.id,
                                    staticClass: "AnalyticsDetailes-monthTable",
                                    attrs: {
                                      month: _vm.monthInfo,
                                      activity: activityItem,
                                      group_id: _vm.currentGroup,
                                      work_days: _vm.monthInfo.workDays,
                                      editable:
                                        activityItem.editable == 1
                                          ? true
                                          : false,
                                      "hidden-users":
                                        _vm.activityHiddenUsers[
                                          activityItem.id
                                        ] || [],
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              activityItem.type == "collection"
                                ? _c("TableActivityCollection", {
                                    key: activityItem.id,
                                    staticClass: "AnalyticsDetailes-monthTable",
                                    attrs: {
                                      month: _vm.monthInfo,
                                      activity: activityItem,
                                      is_admin: true,
                                      price: activityItem.price,
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              activityItem.type == "quality"
                                ? _c("TableQualityWeekly", {
                                    key: activityItem.id,
                                    staticClass: "AnalyticsDetailes-monthTable",
                                    attrs: {
                                      "month-info": _vm.monthInfo,
                                      items: activityItem.records,
                                      weeks: _vm.weeks,
                                      editable:
                                        activityItem.editable == 1
                                          ? true
                                          : false,
                                    },
                                  })
                                : _vm._e(),
                            ],
                            1
                          )
                        : _c("div", [
                            _c(
                              "div",
                              {
                                staticClass: "table-container table-responsive",
                              },
                              [
                                _c(
                                  "table",
                                  { staticClass: "table table-bordered" },
                                  [
                                    _c("thead", [
                                      _c(
                                        "tr",
                                        _vm._l(
                                          _vm.yearActivityTableFields,
                                          function (field, key) {
                                            return _c(
                                              "th",
                                              {
                                                key: key,
                                                class: field.classes,
                                              },
                                              [
                                                _c("div", [
                                                  _vm._v(_vm._s(field.name)),
                                                ]),
                                              ]
                                            )
                                          }
                                        ),
                                        0
                                      ),
                                    ]),
                                    _vm._v(" "),
                                    _c(
                                      "tbody",
                                      _vm._l(
                                        _vm.yearActivityTable,
                                        function (row, indexYear) {
                                          return _c(
                                            "tr",
                                            { key: indexYear },
                                            _vm._l(
                                              _vm.yearActivityTableFields,
                                              function (field, key) {
                                                return _c(
                                                  "td",
                                                  {
                                                    key: key,
                                                    class: field.classes,
                                                    style:
                                                      field.key === "name" ||
                                                      !row[field.key]
                                                        ? ""
                                                        : "background: " +
                                                          _vm.getCellColor(
                                                            row[field.key]
                                                          ) +
                                                          ";",
                                                    attrs: {
                                                      "data-key": field.key,
                                                    },
                                                  },
                                                  [
                                                    _c("div", [
                                                      _vm._v(
                                                        _vm._s(row[field.key])
                                                      ),
                                                    ]),
                                                  ]
                                                )
                                              }
                                            ),
                                            0
                                          )
                                        }
                                      ),
                                      0
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]),
                    ])
                  : _vm._e(),
              ]
            )
          }),
        ],
        2
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: { title: "Порядок активностей", size: "md" },
          on: {
            ok: function ($event) {
              return _vm.save_order()
            },
          },
          model: {
            value: _vm.showOrder,
            callback: function ($$v) {
              _vm.showOrder = $$v
            },
            expression: "showOrder",
          },
        },
        [
          _c(
            "Draggable",
            { attrs: { list: _vm.activitySelect } },
            _vm._l(_vm.activitySelect, function (act) {
              return _c("div", { key: act.id, staticClass: "drag_item" }, [
                _c("i", { staticClass: "fa fa-grip-vertical" }),
                _vm._v(" "),
                _c("span", { staticClass: "AnalyticsSort-title" }, [
                  _vm._v("\n\t\t\t\t\t" + _vm._s(act.name) + "\n\t\t\t\t"),
                ]),
                _vm._v(" "),
                _c("i", {
                  staticClass: "fa fa-trash pointer ml-a",
                  on: {
                    click: function ($event) {
                      return _vm.delete_activity(act)
                    },
                  },
                }),
              ])
            }),
            0
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          staticClass: "modalle",
          attrs: { title: "Добавить активность", size: "lg" },
          on: {
            ok: function ($event) {
              return _vm.create_activity()
            },
          },
          model: {
            value: _vm.showActivityModal,
            callback: function ($$v) {
              _vm.showActivityModal = $$v
            },
            expression: "showActivityModal",
          },
        },
        [
          _c("div", { staticClass: "fz-14" }, [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-6 mb-3" }, [
                _c("p", {}, [
                  _vm._v("\n\t\t\t\t\t\tНазвание активности\n\t\t\t\t\t"),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-6 mb-3" }, [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.activity.name,
                      expression: "activity.name",
                    },
                  ],
                  staticClass: "form-control form-control-sm",
                  attrs: { type: "text" },
                  domProps: { value: _vm.activity.name },
                  on: {
                    input: function ($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.activity, "name", $event.target.value)
                    },
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-6 mb-3" }, [
                _c("p", {}, [_vm._v("\n\t\t\t\t\t\tМетод\n\t\t\t\t\t")]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-6 mb-3" }, [
                _c(
                  "select",
                  {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.activity.plan_unit,
                        expression: "activity.plan_unit",
                      },
                    ],
                    staticClass: "form-control form-control-sm",
                    on: {
                      change: function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.activity,
                          "plan_unit",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                    },
                  },
                  _vm._l(_vm.plan_units, function (value, key) {
                    return _c(
                      "option",
                      { key: key, domProps: { value: key } },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t\t" + _vm._s(value) + "\n\t\t\t\t\t\t"
                        ),
                      ]
                    )
                  }),
                  0
                ),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-6 mb-3" }, [
                _c("p", {}, [
                  _vm._v(
                    "\n\t\t\t\t\t\tПлан (Если сумма, на день)\n\t\t\t\t\t"
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-6 mb-3" }, [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.activity.daily_plan,
                      expression: "activity.daily_plan",
                    },
                  ],
                  staticClass: "form-control form-control-sm",
                  attrs: { type: "number" },
                  domProps: { value: _vm.activity.daily_plan },
                  on: {
                    input: function ($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.activity, "daily_plan", $event.target.value)
                    },
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-6 mb-3" }, [
                _c("p", {}, [
                  _vm._v(
                    "\n\t\t\t\t\t\tКол-во рабочих дней в неделе\n\t\t\t\t\t"
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-6 mb-3" }, [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.activity.weekdays,
                      expression: "activity.weekdays",
                    },
                  ],
                  staticClass: "form-control form-control-sm",
                  attrs: { type: "number", min: "1", max: "7" },
                  domProps: { value: _vm.activity.weekdays },
                  on: {
                    input: function ($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.activity, "weekdays", $event.target.value)
                    },
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-6 mb-3" }, [
                _c("p", {}, [
                  _vm._v(
                    "\n\t\t\t\t\t\tЕд. измерения (Символ в конце показателя)\n\t\t\t\t\t"
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-6 mb-3" }, [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.activity.unit,
                      expression: "activity.unit",
                    },
                  ],
                  staticClass: "form-control form-control-sm",
                  attrs: { type: "text" },
                  domProps: { value: _vm.activity.unit },
                  on: {
                    input: function ($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.activity, "unit", $event.target.value)
                    },
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c(
                "div",
                { staticClass: "col-6 mb-3 d-flex align-items-center" },
                [
                  _c("p", { staticClass: "mb-0" }, [
                    _vm._v("\n\t\t\t\t\t\tРедактируемый\n\t\t\t\t\t"),
                  ]),
                  _vm._v(" "),
                  _c("JobtronSwitch", {
                    staticClass: "ml-4",
                    model: {
                      value: _vm.activity.editable,
                      callback: function ($$v) {
                        _vm.$set(_vm.activity, "editable", $$v)
                      },
                      expression: "activity.editable",
                    },
                  }),
                ],
                1
              ),
            ]),
          ]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=template&id=516af23c&":
/*!******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityCollection.vue?vue&type=template&id=516af23c& ***!
  \******************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "TableActivityCollection mb-3" },
    [
      _c(
        "h4",
        {
          staticClass: "d-flex align-items-center justify-content-between mb-3",
        },
        [
          _c("div", { staticClass: "mr-2" }),
          _vm._v(" "),
          _c("div", [
            _vm.is_admin && _vm.tenant === "bp"
              ? _c("div", [
                  _c(
                    "a",
                    {
                      staticClass: "btn btn-success rounded mr-2 text-white",
                      on: {
                        click: function ($event) {
                          _vm.showExcelImport = !_vm.showExcelImport
                        },
                      },
                    },
                    [
                      _c("i", { staticClass: "fa fa-upload" }),
                      _vm._v("\n\t\t\t\t\t\tИмпорт"),
                    ]
                  ),
                ])
              : _vm._e(),
          ]),
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "table-container" }, [
        _c(
          "table",
          {
            staticClass: "table table-bordered table-responsive r-to",
            attrs: { id: "sticky-" + _vm.activity.id },
          },
          [
            _c("thead", [
              _c(
                "tr",
                [
                  _c(
                    "th",
                    {
                      staticClass:
                        "b-table-sticky-column text-left px-1 t-name bg-white sticky-h1 z2233",
                    },
                    [
                      _c("div", { staticClass: "wd" }, [
                        _vm._v("\n\t\t\t\t\t\t\t\tФИО\n\t\t\t\t\t\t\t\t"),
                        _vm.is_admin
                          ? _c("i", {
                              staticClass: "fa fa-sort ml-2",
                              on: {
                                click: function ($event) {
                                  return _vm.sort("fullname")
                                },
                              },
                            })
                          : _vm._e(),
                      ]),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "th",
                    {
                      staticClass: "text-center px-1 sticky-h1",
                      staticStyle: { "z-index": "5" },
                      attrs: { rowspan: "2" },
                    },
                    [
                      _vm.is_admin
                        ? _c("div", { staticClass: "wd" }, [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t\tИтог к выдаче\n\t\t\t\t\t\t\t\t"
                            ),
                            _vm.is_admin
                              ? _c("i", {
                                  staticClass: "fa fa-sort ml-2",
                                  on: {
                                    click: function ($event) {
                                      return _vm.sort("plan")
                                    },
                                  },
                                })
                              : _vm._e(),
                          ])
                        : _c("div", { staticClass: "wd" }),
                    ]
                  ),
                  _vm._v(" "),
                  _vm.is_admin
                    ? _c(
                        "th",
                        {
                          staticClass: "text-center px-1 sticky-h1",
                          attrs: { rowspan: "2" },
                        },
                        [
                          _c("div", { staticClass: "wd" }, [
                            _vm._v("\n\t\t\t\t\t\t\t\tСборы\n\t\t\t\t\t\t\t\t"),
                            _c("i", {
                              staticClass: "fa fa-sort ml-2",
                              on: {
                                click: function ($event) {
                                  return _vm.sort("count")
                                },
                              },
                            }),
                          ]),
                        ]
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm._l(_vm.month.daysInMonth, function (day) {
                    return _c(
                      "th",
                      {
                        key: day,
                        staticClass: "text-center px-1 sticky-h1",
                        attrs: { colspan: "2" },
                      },
                      [_c("div", [_vm._v(_vm._s(day))])]
                    )
                  }),
                ],
                2
              ),
              _vm._v(" "),
              _c(
                "tr",
                [
                  _c("th", {
                    staticClass: "b-table-sticky-column sticky-h2",
                    staticStyle: { "z-index": "5" },
                  }),
                  _vm._v(" "),
                  _vm._l(_vm.month.daysInMonth, function (day) {
                    return [
                      _c("th", { key: "a" + day, staticClass: "sticky-h2" }, [
                        _vm._v("\n\t\t\t\t\t\t\t\tсборы\n\t\t\t\t\t\t\t"),
                      ]),
                      _vm._v(" "),
                      _c("th", { key: "b" + day, staticClass: "sticky-h2" }, [
                        _vm._v("\n\t\t\t\t\t\t\t\tтенге\n\t\t\t\t\t\t\t"),
                      ]),
                    ]
                  }),
                ],
                2
              ),
            ]),
            _vm._v(" "),
            _c(
              "tbody",
              _vm._l(_vm.items, function (item, index) {
                return _c(
                  "tr",
                  { key: index },
                  [
                    _c(
                      "td",
                      {
                        staticClass:
                          "table-primary b-table-sticky-column text-left px-2 t-name wdf",
                        attrs: { title: item.id + " " + item.email },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "wd d-flex align-items-center" },
                          [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t\t" +
                                _vm._s(item.lastname) +
                                " " +
                                _vm._s(item.name) +
                                "\n\t\t\t\t\t\t\t\t"
                            ),
                            _c("b-badge", { attrs: { variant: "success" } }, [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t\t\tOffice\n\t\t\t\t\t\t\t\t"
                              ),
                            ]),
                            _vm._v(" "),
                            _c("JobtronCup", {
                              attrs: {
                                place:
                                  _vm.sortDir === "asc"
                                    ? index
                                    : _vm.items.length - index,
                                rotate: "",
                              },
                            }),
                          ],
                          1
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(item.plan))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(item.count))]),
                    _vm._v(" "),
                    _vm._l(_vm.month.daysInMonth, function (day) {
                      return [
                        item.editable
                          ? _c(
                              "td",
                              {
                                key: day,
                                staticClass:
                                  "TableActivityCollection-data lb px-0 day-minute text-center Fri",
                                class: "table-" + item._cellVariants[day],
                                attrs: { title: day + ": сборы" },
                              },
                              [
                                _c("div", [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: item[day],
                                        expression: "item[day]",
                                      },
                                    ],
                                    staticClass: "form-control cell-input",
                                    attrs: { type: "number" },
                                    domProps: { value: item[day] },
                                    on: {
                                      change: function ($event) {
                                        return _vm.updateSettings(
                                          $event,
                                          item,
                                          index,
                                          day
                                        )
                                      },
                                      input: function ($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(item, day, $event.target.value)
                                      },
                                    },
                                  }),
                                ]),
                              ]
                            )
                          : _c(
                              "td",
                              {
                                key: day + "a",
                                staticClass:
                                  "TableActivityCollection-data lb px-0 day-minute text-center Fri",
                                class: "table-" + item._cellVariants[day],
                                attrs: { title: day + ": сборы" },
                                on: {
                                  click: function ($event) {
                                    return _vm.editMode(item)
                                  },
                                },
                              },
                              [_c("div", [_vm._v(_vm._s(item[day]))])]
                            ),
                        _vm._v(" "),
                        !isNaN(Number(item[day]) * _vm.price)
                          ? _c(
                              "td",
                              {
                                key: day + "b",
                                staticClass: "TableActivityCollection-data rb",
                                attrs: { title: day + ": тенге" },
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t\t" +
                                    _vm._s(
                                      Number.isInteger(
                                        Number(item[day]) * _vm.price
                                      )
                                        ? Number(item[day]) * _vm.price
                                        : Math.round(
                                            Number(item[day]) * _vm.price
                                          )
                                    ) +
                                    "\n\t\t\t\t\t\t\t"
                                ),
                              ]
                            )
                          : _c("td", {
                              key: day + "c",
                              staticClass: "TableActivityCollection-data rb",
                              attrs: { title: day + ": тенге" },
                            }),
                      ]
                    }),
                  ],
                  2
                )
              }),
              0
            ),
          ]
        ),
      ]),
      _vm._v(" "),
      _vm.showExcelImport
        ? _c(
            "Sidebar",
            {
              attrs: {
                title: "Импорт EXCEL",
                open: _vm.showExcelImport,
                width: "75%",
              },
              on: {
                close: function ($event) {
                  _vm.showExcelImport = false
                },
              },
            },
            [
              _c("ActivityExcelImport", {
                attrs: {
                  group_id: 42,
                  table: "minutes",
                  activity_id: _vm.activity.id,
                },
                on: {
                  close: function ($event) {
                    _vm.showExcelImport = false
                  },
                },
              }),
            ],
            1
          )
        : _vm._e(),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=template&id=1da121ac&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableDecomposition.vue?vue&type=template&id=1da121ac& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "TableDecomposition mb-3" },
    [
      _c("div", { staticClass: "table-container" }, [
        _c(
          "table",
          {
            staticClass:
              "TableDecomposition-table table table-bordered table-responsive",
          },
          [
            _c("thead", { staticClass: "TableDecomposition-thead" }, [
              _c(
                "tr",
                { staticClass: "TableDecomposition-tr" },
                [
                  _vm._m(0),
                  _vm._v(" "),
                  _vm._m(1),
                  _vm._v(" "),
                  _vm._l(_vm.month.daysInMonth, function (day) {
                    return _c(
                      "th",
                      {
                        key: day,
                        staticClass:
                          "TableDecomposition-th text-center px-1 border-r-2",
                        class: {
                          weekend: _vm.is_weekday[day],
                        },
                        attrs: { colspan: "2" },
                      },
                      [_c("div", [_vm._v(_vm._s(day))])]
                    )
                  }),
                ],
                2
              ),
              _vm._v(" "),
              _c(
                "tr",
                {
                  staticClass:
                    "TableDecomposition-tr TableDecomposition-subhead",
                },
                [
                  _c("th", {
                    staticClass:
                      "TableDecomposition-th b-table-sticky-column text-left",
                  }),
                  _vm._v(" "),
                  _c("th", { staticClass: "TableDecomposition-th" }, [
                    _vm._v("\n\t\t\t\t\t\tплан\n\t\t\t\t\t"),
                  ]),
                  _vm._v(" "),
                  _c("th", { staticClass: "TableDecomposition-th" }, [
                    _vm._v("\n\t\t\t\t\t\tфакт\n\t\t\t\t\t"),
                  ]),
                  _vm._v(" "),
                  _vm._l(_vm.month.daysInMonth, function (day) {
                    return [
                      _c(
                        "th",
                        { key: day, staticClass: "TableDecomposition-th" },
                        [_vm._v("\n\t\t\t\t\t\t\tплан\n\t\t\t\t\t\t")]
                      ),
                      _vm._v(" "),
                      _c(
                        "th",
                        {
                          key: day + "a",
                          staticClass: "TableDecomposition-th border-r-2",
                        },
                        [_vm._v("\n\t\t\t\t\t\t\tфакт\n\t\t\t\t\t\t")]
                      ),
                    ]
                  }),
                ],
                2
              ),
            ]),
            _vm._v(" "),
            _c(
              "tbody",
              { staticClass: "TableDecomposition-tbody" },
              _vm._l(_vm.items, function (item, index) {
                return _c(
                  "tr",
                  { key: index, staticClass: "TableDecomposition-tr" },
                  [
                    _c(
                      "td",
                      {
                        staticClass:
                          "TableDecomposition-td b-table-sticky-column text-left px-2 t-name",
                        attrs: { title: item.id },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "wd d-flex align-items-center" },
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: item.name,
                                  expression: "item.name",
                                },
                              ],
                              staticClass:
                                "TableDecomposition-inputName w-250 text-left",
                              attrs: {
                                type: "text",
                                placeholder: "напишите название активности",
                              },
                              domProps: { value: item.name },
                              on: {
                                change: function ($event) {
                                  return _vm.updateSettings(
                                    $event,
                                    item,
                                    index,
                                    "name"
                                  )
                                },
                                input: function ($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(item, "name", $event.target.value)
                                },
                              },
                            }),
                            _vm._v(" "),
                            _c("i", {
                              staticClass: "fa fa-pencil pointer mr-2",
                              attrs: { title: "Поставить план" },
                              on: {
                                click: function ($event) {
                                  return _vm.showModal(index)
                                },
                              },
                            }),
                            _vm._v(" "),
                            _c("i", {
                              staticClass: "fa fa-trash pointer",
                              attrs: { title: "Удалить строку" },
                              on: {
                                click: function ($event) {
                                  return _vm.deleteRecord(item.id, index)
                                },
                              },
                            }),
                          ]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c("td", { staticClass: "TableDecomposition-td" }, [
                      _vm._v(
                        "\n\t\t\t\t\t\t" +
                          _vm._s(Number(item.total_plan).toFixed(0)) +
                          "\n\t\t\t\t\t"
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "td",
                      { staticClass: "TableDecomposition-td border-r-2" },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(Number(item.total_fact).toFixed(0)) +
                            "\n\t\t\t\t\t"
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _vm._l(_vm.month.daysInMonth, function (day) {
                      return [
                        item.editable
                          ? _c(
                              "td",
                              {
                                key: day,
                                staticClass:
                                  "TableDecomposition-td px-0 day-minute text-center",
                                class: {
                                  weekend: _vm.is_weekday[day],
                                },
                              },
                              [
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item[day].plan,
                                      expression: "item[day].plan",
                                    },
                                  ],
                                  staticClass: "TableDecomposition-inputNumber",
                                  attrs: { type: "number" },
                                  domProps: { value: item[day].plan },
                                  on: {
                                    change: function ($event) {
                                      return _vm.updateSettings(
                                        $event,
                                        item,
                                        index,
                                        day
                                      )
                                    },
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        item[day],
                                        "plan",
                                        $event.target.value
                                      )
                                    },
                                  },
                                }),
                              ]
                            )
                          : _c(
                              "td",
                              {
                                key: day + "a",
                                staticClass:
                                  "TableDecomposition-td px-0 day-minute text-center",
                                class: {
                                  weekend: _vm.is_weekday[day],
                                },
                                on: {
                                  click: function ($event) {
                                    return _vm.editMode(item)
                                  },
                                },
                              },
                              [_c("div", [_vm._v(_vm._s(item[day].plan))])]
                            ),
                        _vm._v(" "),
                        item.editable
                          ? _c(
                              "td",
                              {
                                key: day + "b",
                                staticClass:
                                  "TableDecomposition-td px-0 day-minute text-center border-r-2",
                                class: {
                                  "table-danger":
                                    Number(item[day].fact) != 0 &&
                                    Number(item[day].plan) >
                                      Number(item[day].fact),
                                  "table-success":
                                    Number(item[day].fact) != 0 &&
                                    Number(item[day].plan) <=
                                      Number(item[day].fact),
                                  weekend: _vm.is_weekday[day],
                                },
                              },
                              [
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item[day].fact,
                                      expression: "item[day].fact",
                                    },
                                  ],
                                  staticClass: "TableDecomposition-inputNumber",
                                  attrs: { type: "number" },
                                  domProps: { value: item[day].fact },
                                  on: {
                                    change: function ($event) {
                                      return _vm.updateSettings(
                                        $event,
                                        item,
                                        index,
                                        day
                                      )
                                    },
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        item[day],
                                        "fact",
                                        $event.target.value
                                      )
                                    },
                                  },
                                }),
                              ]
                            )
                          : _c(
                              "td",
                              {
                                key: day + "c",
                                staticClass:
                                  "TableDecomposition-td px-0 day-minute text-center border-r-2",
                                class: {
                                  "table-danger":
                                    Number(item[day].fact) != 0 &&
                                    Number(item[day].plan) >
                                      Number(item[day].fact),
                                  "table-success":
                                    Number(item[day].fact) != 0 &&
                                    Number(item[day].plan) <=
                                      Number(item[day].fact),
                                  weekend: _vm.is_weekday[day],
                                },
                                on: {
                                  click: function ($event) {
                                    return _vm.editMode(item)
                                  },
                                },
                              },
                              [_c("div", [_vm._v(_vm._s(item[day].fact))])]
                            ),
                      ]
                    }),
                  ],
                  2
                )
              }),
              0
            ),
          ]
        ),
      ]),
      _vm._v(" "),
      _c(
        "button",
        { staticClass: "btn btn-success", on: { click: _vm.addRecord } },
        [_vm._v("\n\t\t+ Добавить\n\t")]
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          ref: "change-plan-modal",
          attrs: { "hide-footer": "", title: "Проставить план" },
        },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-6" }, [
              _c("label", { attrs: { for: "" } }, [_vm._v("С:")]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model.number",
                    value: _vm.planner.from,
                    expression: "planner.from",
                    modifiers: { number: true },
                  },
                ],
                staticClass: "form-control form-control-sm mb-2",
                attrs: { type: "number", min: "1", max: "31" },
                domProps: { value: _vm.planner.from },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.planner, "from", _vm._n($event.target.value))
                  },
                  blur: function ($event) {
                    return _vm.$forceUpdate()
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-6" }, [
              _c("label", { attrs: { for: "" } }, [_vm._v("По:")]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model.number",
                    value: _vm.planner.to,
                    expression: "planner.to",
                    modifiers: { number: true },
                  },
                ],
                staticClass: "form-control form-control-sm mb-2",
                attrs: { type: "number", min: "1", max: "31" },
                domProps: { value: _vm.planner.to },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.planner, "to", _vm._n($event.target.value))
                  },
                  blur: function ($event) {
                    return _vm.$forceUpdate()
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-6" }, [
              _c("label", { attrs: { for: "" } }, [_vm._v("План:")]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model.number",
                    value: _vm.planner.value,
                    expression: "planner.value",
                    modifiers: { number: true },
                  },
                ],
                staticClass: "form-control form-control-sm mb-2",
                attrs: { type: "number", placeholder: "План", min: "1" },
                domProps: { value: _vm.planner.value },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.planner, "value", _vm._n($event.target.value))
                  },
                  blur: function ($event) {
                    return _vm.$forceUpdate()
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "col-12 mt-3" },
              [
                _c(
                  "b-button",
                  {
                    staticClass: "mt-3",
                    attrs: { variant: "primary", block: "" },
                    on: { click: _vm.changePlan },
                  },
                  [_vm._v("\n\t\t\t\t\tПроставить\n\t\t\t\t")]
                ),
              ],
              1
            ),
          ]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "th",
      { staticClass: "TableDecomposition-th b-table-sticky-column text-left" },
      [
        _c("div", { staticClass: "wd TableDecomposition-header" }, [
          _vm._v("\n\t\t\t\t\t\t\tДекомпозиция на месяц\n\t\t\t\t\t\t"),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "th",
      {
        staticClass: "TableDecomposition-th text-center px-1 border-r-2",
        attrs: { colspan: "2" },
      },
      [_c("b", [_vm._v("Итого")])]
    )
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=template&id=45440b81&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQualityWeekly.vue?vue&type=template&id=45440b81& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "mt-5 quality" }, [
    _c("div", { staticClass: "mb-3" }, [
      _vm._v("\n\t\tКол-во показателей: "),
      _c("b", [_vm._v(_vm._s(_vm.totalCount))]),
      _vm._v(" , Среднее значение: "),
      _c("b", [_vm._v(_vm._s(_vm.totalAvg))]),
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "table-responsive table-container" }, [
      _c("table", { staticClass: "table table-bordered" }, [
        _c("thead", [
          _c(
            "tr",
            [
              _vm._m(0),
              _vm._v(" "),
              _vm._l(_vm.fields, function (field, key) {
                return _c("th", { key: key, class: field.klass }, [
                  _c("div", [_vm._v(_vm._s(field.name))]),
                ])
              }),
            ],
            2
          ),
        ]),
        _vm._v(" "),
        _c(
          "tbody",
          _vm._l(_vm.users, function (item, index) {
            return _c(
              "tr",
              { key: index },
              [
                _c(
                  "td",
                  {
                    staticClass:
                      "b-table-sticky-column text-left t-name wd bg-white",
                  },
                  [
                    _c(
                      "div",
                      { staticClass: "d-flex" },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t\t" +
                            _vm._s(item.name) +
                            "\n\n\t\t\t\t\t\t\t"
                        ),
                        _vm.topUsers.includes(item.id)
                          ? _c("JobtronCup", {
                              attrs: {
                                place: _vm.topUsers.indexOf(item.id) + 1,
                                rotate: "",
                              },
                            })
                          : _vm._e(),
                      ],
                      1
                    ),
                  ]
                ),
                _vm._v(" "),
                _vm._l(_vm.fields, function (field, key) {
                  return [
                    _c("td", { key: key, class: field.klass }, [
                      item[field.key] != 0
                        ? _c("div", [
                            _vm._v(
                              "\n\t\t\t\t\t\t\t\t" +
                                _vm._s(item[field.key]) +
                                "\n\t\t\t\t\t\t\t"
                            ),
                          ])
                        : _vm._e(),
                    ]),
                  ]
                }),
              ],
              2
            )
          }),
          0
        ),
      ]),
    ]),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "th",
      { staticClass: "b-table-sticky-column text-left t-name wd" },
      [_c("div", [_vm._v("Сотрудник")])]
    )
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=template&id=31e214ae&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Cup.vue?vue&type=template&id=31e214ae& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.src
    ? _c("img", {
        staticClass: "JobtronCup",
        class: {
          JobtronCup_rotate: _vm.rotate,
        },
        attrs: { src: _vm.src, alt: "icon" },
      })
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("span", { staticClass: "JobtronSwitch" }, [
    _c("input", {
      staticClass: "JobtronSwitch-input",
      attrs: { type: "checkbox" },
      domProps: { checked: _vm.localValue },
      on: {
        input: function ($event) {
          return _vm.$emit("input", $event.target.checked)
        },
      },
    }),
    _vm._v(" "),
    _c("span", { staticClass: "JobtronSwitch-switch" }),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=template&id=aa0b7408&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/AnalyticsPage.vue?vue&type=template&id=aa0b7408& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.groups
    ? _c(
        "div",
        { staticClass: "AnalyticsPage" },
        [
          _c("div", { staticClass: "AnalyticsPage-filters row mb-4" }, [
            _c("div", { staticClass: "col-3" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.currentGroupId,
                      expression: "currentGroupId",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.currentGroupId = $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      },
                      _vm.fetchData,
                    ],
                  },
                },
                _vm._l(_vm.ggroups, function (group) {
                  return _c(
                    "option",
                    { key: group.id, domProps: { value: group.id } },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(group.name) + "\n\t\t\t\t")]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-2" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.monthInfo.currentMonth,
                      expression: "monthInfo.currentMonth",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.monthInfo,
                          "currentMonth",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      _vm.fetchData,
                    ],
                  },
                },
                _vm._l(_vm.$moment.months(), function (month) {
                  return _c(
                    "option",
                    { key: month, domProps: { value: month } },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(month) + "\n\t\t\t\t")]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-2" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.currentYear,
                      expression: "currentYear",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.currentYear = $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      },
                      _vm.fetchData,
                    ],
                  },
                },
                _vm._l(_vm.years, function (year) {
                  return _c(
                    "option",
                    { key: year, domProps: { value: year } },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(year) + "\n\t\t\t\t")]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-1" }, [
              _c(
                "div",
                {
                  staticClass: "btn btn-primary rounded",
                  on: {
                    click: function ($event) {
                      return _vm.fetchData()
                    },
                  },
                },
                [_c("i", { staticClass: "fa fa-redo-alt" })]
              ),
            ]),
            _vm._v(" "),
            _vm.$laravel.is_admin
              ? _c("div", { staticClass: "col-2" }, [
                  !_vm.firstEnter && !_vm.dataLoaded
                    ? _c(
                        "button",
                        {
                          staticClass: "btn btn-info rounded add-s",
                          attrs: { title: "Создать аналитику" },
                          on: {
                            click: function ($event) {
                              return _vm.add_analytics()
                            },
                          },
                        },
                        [_c("i", { staticClass: "fa fa-plus-square" })]
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  !_vm.noan
                    ? _c(
                        "button",
                        {
                          staticClass: "btn btn-info rounded add-s",
                          attrs: { title: "Архивировать" },
                          on: {
                            click: function ($event) {
                              return _vm.archive()
                            },
                          },
                        },
                        [_c("i", { staticClass: "fa fa-trash" })]
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-info rounded add-s ml-2",
                      attrs: { title: "Восстановить из архива" },
                      on: {
                        click: function ($event) {
                          _vm.showArchive = true
                        },
                      },
                    },
                    [_c("i", { staticClass: "fa fa-archive" })]
                  ),
                ])
              : _c("div", { staticClass: "col-1" }),
          ]),
          _vm._v(" "),
          !_vm.firstEnter
            ? [
                _vm.hasPremission
                  ? [
                       true
                        ? [
                            _c(
                              "div",
                              { staticClass: "AnalyticsPage-header wrap mb-4" },
                              [
                                _vm.ready.performances
                                  ? _c("TopGauges", {
                                      key: 123,
                                      staticClass: "AnalyticsPage-gauges",
                                      attrs: {
                                        utility_items: _vm.gauges,
                                        editable: false,
                                        wrapper_class: "d-flex",
                                        page: "analytics",
                                      },
                                    })
                                  : [
                                      _c("div", {
                                        staticClass:
                                          "AnalyticsPage-skeletonImg b-skeleton b-skeleton-img b-skeleton-animate-wave ml-4 mb-4",
                                      }),
                                      _vm._v(" "),
                                      _c("div", {
                                        staticClass:
                                          "AnalyticsPage-skeletonImg b-skeleton b-skeleton-img b-skeleton-animate-wave ml-4 mb-4",
                                      }),
                                      _vm._v(" "),
                                      _c("div", {
                                        staticClass:
                                          "AnalyticsPage-skeletonImg b-skeleton b-skeleton-img b-skeleton-animate-wave ml-a mb-4 mr-4",
                                      }),
                                    ],
                                _vm._v(" "),
                                _vm.ready.fired && _vm.firedInfo
                                  ? _c("div", { staticClass: "p-4" }, [
                                      _c("p", { staticClass: "ap-text" }, [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\tПроцент текучки кадров за прошлый месяц: "
                                        ),
                                        _c("span", [
                                          _vm._v(
                                            _vm._s(
                                              _vm.firedInfo.fired_percent_prev
                                            ) + "%"
                                          ),
                                        ]),
                                      ]),
                                      _vm._v(" "),
                                      _c("p", { staticClass: "ap-text" }, [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\tПроцент текучки кадров за текущий месяц: "
                                        ),
                                        _c("span", [
                                          _vm._v(
                                            _vm._s(
                                              _vm.firedInfo.fired_percent
                                            ) + "%"
                                          ),
                                        ]),
                                      ]),
                                      _vm._v(" "),
                                      _c("p", { staticClass: "ap-text" }, [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\tВ прошлом месяце было уволено: "
                                        ),
                                        _c("span", [
                                          _vm._v(
                                            _vm._s(
                                              _vm.firedInfo.fired_number_prev
                                            )
                                          ),
                                        ]),
                                      ]),
                                      _vm._v(" "),
                                      _c("p", { staticClass: "ap-text" }, [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\tВ текущем месяце было уволено: "
                                        ),
                                        _c("span", [
                                          _vm._v(
                                            _vm._s(_vm.firedInfo.fired_number)
                                          ),
                                        ]),
                                      ]),
                                    ])
                                  : _vm._e(),
                              ],
                              2
                            ),
                            _vm._v(" "),
                            _c(
                              "b-tabs",
                              {
                                attrs: {
                                  type: "card",
                                  "default-active-key": _vm.active,
                                },
                                on: { change: _vm.onTabChange },
                              },
                              [
                                _c(
                                  "b-tab",
                                  {
                                    key: "1",
                                    attrs: { card: "" },
                                    scopedSlots: _vm._u(
                                      [
                                        {
                                          key: "title",
                                          fn: function () {
                                            return [
                                              _c(
                                                "span",
                                                {
                                                  directives: [
                                                    {
                                                      name: "b-popover",
                                                      rawName:
                                                        "v-b-popover.hover.top",
                                                      value: "таблица продаж",
                                                      expression:
                                                        "'таблица продаж'",
                                                      modifiers: {
                                                        hover: true,
                                                        top: true,
                                                      },
                                                    },
                                                  ],
                                                },
                                                [_vm._v("Сводная")]
                                              ),
                                            ]
                                          },
                                          proxy: true,
                                        },
                                      ],
                                      null,
                                      false,
                                      1982419546
                                    ),
                                  },
                                  [
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      { staticClass: "mb-5 mt-4" },
                                      [
                                        _vm.ready.analytics &&
                                        _vm.ready.activities
                                          ? [
                                              _vm.table
                                                ? _c("AnalyticStat", {
                                                    attrs: {
                                                      table: _vm.table,
                                                      fields: _vm.columns,
                                                      activeuserid:
                                                        _vm.activeuserid,
                                                      "is-admin": _vm.isAdmin,
                                                      "month-info":
                                                        _vm.monthInfo,
                                                      group_id:
                                                        _vm.currentGroupId,
                                                      activities:
                                                        _vm.activitiesOptions,
                                                    },
                                                  })
                                                : _vm._e(),
                                            ]
                                          : _c("b-skeleton-table", {
                                              attrs: {
                                                rows: 6,
                                                columns: 5,
                                                "table-props": {
                                                  bordered: true,
                                                  striped: true,
                                                },
                                              },
                                            }),
                                      ],
                                      2
                                    ),
                                    _vm._v(" "),
                                    _vm.currentGroupId == 53
                                      ? _c("CallBase", {
                                          attrs: {
                                            data: _vm.call_bases,
                                            "month-info": _vm.monthInfo,
                                          },
                                        })
                                      : _vm._e(),
                                    _vm._v(" "),
                                    _vm.ready.decompositions
                                      ? _c("TableDecomposition", {
                                          attrs: {
                                            month: _vm.monthInfo,
                                            decompositions: _vm.decompositions,
                                            "group-id": _vm.currentGroupId,
                                          },
                                        })
                                      : _c("b-skeleton-table", {
                                          attrs: {
                                            rows: 6,
                                            columns: 5,
                                            "table-props": {
                                              bordered: true,
                                              striped: true,
                                            },
                                          },
                                        }),
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "b-tab",
                                  {
                                    key: "2",
                                    staticClass: "position-relative",
                                    attrs: { card: "" },
                                    scopedSlots: _vm._u(
                                      [
                                        {
                                          key: "title",
                                          fn: function () {
                                            return [
                                              _c(
                                                "span",
                                                {
                                                  directives: [
                                                    {
                                                      name: "b-popover",
                                                      rawName:
                                                        "v-b-popover.hover.top",
                                                      value:
                                                        "данные по показателям",
                                                      expression:
                                                        "'данные по показателям'",
                                                      modifiers: {
                                                        hover: true,
                                                        top: true,
                                                      },
                                                    },
                                                  ],
                                                },
                                                [_vm._v("Подробная")]
                                              ),
                                            ]
                                          },
                                          proxy: true,
                                        },
                                      ],
                                      null,
                                      false,
                                      2952101241
                                    ),
                                  },
                                  [
                                    _vm._v(" "),
                                    _vm.ready.activities
                                      ? _c("AnalyticsDetailes", {
                                          attrs: {
                                            activities: _vm.activities,
                                            weeks: _vm.weeks,
                                            "current-group": _vm.currentGroupId,
                                            "month-info": _vm.monthInfo,
                                            "activity-select":
                                              _vm.activitiesOptions,
                                          },
                                          on: {
                                            updateActivity:
                                              _vm.onUpdateActivity,
                                            deleteActivity:
                                              _vm.onDeleteActivity,
                                            orderActivity: _vm.onOrderActivity,
                                          },
                                        })
                                      : _c("b-skeleton-table", {
                                          attrs: {
                                            rows: 6,
                                            columns: 5,
                                            "table-props": {
                                              bordered: true,
                                              striped: true,
                                            },
                                          },
                                        }),
                                  ],
                                  1
                                ),
                              ],
                              1
                            ),
                          ]
                        : 0,
                    ]
                  : [
                      _c("p", { staticClass: "no-info" }, [
                        _vm._v(
                          "\n\t\t\t\tУ вас нет доступа к этой группе\n\t\t\t"
                        ),
                      ]),
                    ],
              ]
            : _vm._e(),
          _vm._v(" "),
          _c("div", { staticClass: "empty-space" }),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              staticClass: "modalle",
              attrs: { title: "Восстановить из архива", size: "lg" },
              on: {
                ok: function ($event) {
                  return _vm.restore_analytics()
                },
              },
              model: {
                value: _vm.showArchive,
                callback: function ($$v) {
                  _vm.showArchive = $$v
                },
                expression: "showArchive",
              },
            },
            [
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-5" }, [
                  _c("p", {}, [_vm._v("\n\t\t\t\t\tОтдел\n\t\t\t\t")]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-7" }, [
                  _c(
                    "select",
                    {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.restore_group,
                          expression: "restore_group",
                        },
                      ],
                      staticClass: "form-control form-control-sm",
                      on: {
                        change: function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.restore_group = $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        },
                      },
                    },
                    _vm._l(_vm.archived_groups, function (archived_group, key) {
                      return _c(
                        "option",
                        { key: key, domProps: { value: archived_group.id } },
                        [
                          _vm._v(
                            "\n\t\t\t\t\t\t" +
                              _vm._s(archived_group.name) +
                              "\n\t\t\t\t\t"
                          ),
                        ]
                      )
                    }),
                    0
                  ),
                ]),
              ]),
            ]
          ),
        ],
        2
      )
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/expr-eval/dist/index.mjs":
/*!***********************************************!*\
  !*** ./node_modules/expr-eval/dist/index.mjs ***!
  \***********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Expression": () => (/* binding */ Expression),
/* harmony export */   "Parser": () => (/* binding */ Parser),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var INUMBER = 'INUMBER';
var IOP1 = 'IOP1';
var IOP2 = 'IOP2';
var IOP3 = 'IOP3';
var IVAR = 'IVAR';
var IVARNAME = 'IVARNAME';
var IFUNCALL = 'IFUNCALL';
var IFUNDEF = 'IFUNDEF';
var IEXPR = 'IEXPR';
var IEXPREVAL = 'IEXPREVAL';
var IMEMBER = 'IMEMBER';
var IENDSTATEMENT = 'IENDSTATEMENT';
var IARRAY = 'IARRAY';

function Instruction(type, value) {
  this.type = type;
  this.value = (value !== undefined && value !== null) ? value : 0;
}

Instruction.prototype.toString = function () {
  switch (this.type) {
    case INUMBER:
    case IOP1:
    case IOP2:
    case IOP3:
    case IVAR:
    case IVARNAME:
    case IENDSTATEMENT:
      return this.value;
    case IFUNCALL:
      return 'CALL ' + this.value;
    case IFUNDEF:
      return 'DEF ' + this.value;
    case IARRAY:
      return 'ARRAY ' + this.value;
    case IMEMBER:
      return '.' + this.value;
    default:
      return 'Invalid Instruction';
  }
};

function unaryInstruction(value) {
  return new Instruction(IOP1, value);
}

function binaryInstruction(value) {
  return new Instruction(IOP2, value);
}

function ternaryInstruction(value) {
  return new Instruction(IOP3, value);
}

function simplify(tokens, unaryOps, binaryOps, ternaryOps, values) {
  var nstack = [];
  var newexpression = [];
  var n1, n2, n3;
  var f;
  for (var i = 0; i < tokens.length; i++) {
    var item = tokens[i];
    var type = item.type;
    if (type === INUMBER || type === IVARNAME) {
      if (Array.isArray(item.value)) {
        nstack.push.apply(nstack, simplify(item.value.map(function (x) {
          return new Instruction(INUMBER, x);
        }).concat(new Instruction(IARRAY, item.value.length)), unaryOps, binaryOps, ternaryOps, values));
      } else {
        nstack.push(item);
      }
    } else if (type === IVAR && values.hasOwnProperty(item.value)) {
      item = new Instruction(INUMBER, values[item.value]);
      nstack.push(item);
    } else if (type === IOP2 && nstack.length > 1) {
      n2 = nstack.pop();
      n1 = nstack.pop();
      f = binaryOps[item.value];
      item = new Instruction(INUMBER, f(n1.value, n2.value));
      nstack.push(item);
    } else if (type === IOP3 && nstack.length > 2) {
      n3 = nstack.pop();
      n2 = nstack.pop();
      n1 = nstack.pop();
      if (item.value === '?') {
        nstack.push(n1.value ? n2.value : n3.value);
      } else {
        f = ternaryOps[item.value];
        item = new Instruction(INUMBER, f(n1.value, n2.value, n3.value));
        nstack.push(item);
      }
    } else if (type === IOP1 && nstack.length > 0) {
      n1 = nstack.pop();
      f = unaryOps[item.value];
      item = new Instruction(INUMBER, f(n1.value));
      nstack.push(item);
    } else if (type === IEXPR) {
      while (nstack.length > 0) {
        newexpression.push(nstack.shift());
      }
      newexpression.push(new Instruction(IEXPR, simplify(item.value, unaryOps, binaryOps, ternaryOps, values)));
    } else if (type === IMEMBER && nstack.length > 0) {
      n1 = nstack.pop();
      nstack.push(new Instruction(INUMBER, n1.value[item.value]));
    } /* else if (type === IARRAY && nstack.length >= item.value) {
      var length = item.value;
      while (length-- > 0) {
        newexpression.push(nstack.pop());
      }
      newexpression.push(new Instruction(IARRAY, item.value));
    } */ else {
      while (nstack.length > 0) {
        newexpression.push(nstack.shift());
      }
      newexpression.push(item);
    }
  }
  while (nstack.length > 0) {
    newexpression.push(nstack.shift());
  }
  return newexpression;
}

function substitute(tokens, variable, expr) {
  var newexpression = [];
  for (var i = 0; i < tokens.length; i++) {
    var item = tokens[i];
    var type = item.type;
    if (type === IVAR && item.value === variable) {
      for (var j = 0; j < expr.tokens.length; j++) {
        var expritem = expr.tokens[j];
        var replitem;
        if (expritem.type === IOP1) {
          replitem = unaryInstruction(expritem.value);
        } else if (expritem.type === IOP2) {
          replitem = binaryInstruction(expritem.value);
        } else if (expritem.type === IOP3) {
          replitem = ternaryInstruction(expritem.value);
        } else {
          replitem = new Instruction(expritem.type, expritem.value);
        }
        newexpression.push(replitem);
      }
    } else if (type === IEXPR) {
      newexpression.push(new Instruction(IEXPR, substitute(item.value, variable, expr)));
    } else {
      newexpression.push(item);
    }
  }
  return newexpression;
}

function evaluate(tokens, expr, values) {
  var nstack = [];
  var n1, n2, n3;
  var f, args, argCount;

  if (isExpressionEvaluator(tokens)) {
    return resolveExpression(tokens, values);
  }

  var numTokens = tokens.length;

  for (var i = 0; i < numTokens; i++) {
    var item = tokens[i];
    var type = item.type;
    if (type === INUMBER || type === IVARNAME) {
      nstack.push(item.value);
    } else if (type === IOP2) {
      n2 = nstack.pop();
      n1 = nstack.pop();
      if (item.value === 'and') {
        nstack.push(n1 ? !!evaluate(n2, expr, values) : false);
      } else if (item.value === 'or') {
        nstack.push(n1 ? true : !!evaluate(n2, expr, values));
      } else if (item.value === '=') {
        f = expr.binaryOps[item.value];
        nstack.push(f(n1, evaluate(n2, expr, values), values));
      } else {
        f = expr.binaryOps[item.value];
        nstack.push(f(resolveExpression(n1, values), resolveExpression(n2, values)));
      }
    } else if (type === IOP3) {
      n3 = nstack.pop();
      n2 = nstack.pop();
      n1 = nstack.pop();
      if (item.value === '?') {
        nstack.push(evaluate(n1 ? n2 : n3, expr, values));
      } else {
        f = expr.ternaryOps[item.value];
        nstack.push(f(resolveExpression(n1, values), resolveExpression(n2, values), resolveExpression(n3, values)));
      }
    } else if (type === IVAR) {
      if (item.value in expr.functions) {
        nstack.push(expr.functions[item.value]);
      } else if (item.value in expr.unaryOps && expr.parser.isOperatorEnabled(item.value)) {
        nstack.push(expr.unaryOps[item.value]);
      } else {
        var v = values[item.value];
        if (v !== undefined) {
          nstack.push(v);
        } else {
          throw new Error('undefined variable: ' + item.value);
        }
      }
    } else if (type === IOP1) {
      n1 = nstack.pop();
      f = expr.unaryOps[item.value];
      nstack.push(f(resolveExpression(n1, values)));
    } else if (type === IFUNCALL) {
      argCount = item.value;
      args = [];
      while (argCount-- > 0) {
        args.unshift(resolveExpression(nstack.pop(), values));
      }
      f = nstack.pop();
      if (f.apply && f.call) {
        nstack.push(f.apply(undefined, args));
      } else {
        throw new Error(f + ' is not a function');
      }
    } else if (type === IFUNDEF) {
      // Create closure to keep references to arguments and expression
      nstack.push((function () {
        var n2 = nstack.pop();
        var args = [];
        var argCount = item.value;
        while (argCount-- > 0) {
          args.unshift(nstack.pop());
        }
        var n1 = nstack.pop();
        var f = function () {
          var scope = Object.assign({}, values);
          for (var i = 0, len = args.length; i < len; i++) {
            scope[args[i]] = arguments[i];
          }
          return evaluate(n2, expr, scope);
        };
        // f.name = n1
        Object.defineProperty(f, 'name', {
          value: n1,
          writable: false
        });
        values[n1] = f;
        return f;
      })());
    } else if (type === IEXPR) {
      nstack.push(createExpressionEvaluator(item, expr));
    } else if (type === IEXPREVAL) {
      nstack.push(item);
    } else if (type === IMEMBER) {
      n1 = nstack.pop();
      nstack.push(n1[item.value]);
    } else if (type === IENDSTATEMENT) {
      nstack.pop();
    } else if (type === IARRAY) {
      argCount = item.value;
      args = [];
      while (argCount-- > 0) {
        args.unshift(nstack.pop());
      }
      nstack.push(args);
    } else {
      throw new Error('invalid Expression');
    }
  }
  if (nstack.length > 1) {
    throw new Error('invalid Expression (parity)');
  }
  // Explicitly return zero to avoid test issues caused by -0
  return nstack[0] === 0 ? 0 : resolveExpression(nstack[0], values);
}

function createExpressionEvaluator(token, expr, values) {
  if (isExpressionEvaluator(token)) return token;
  return {
    type: IEXPREVAL,
    value: function (scope) {
      return evaluate(token.value, expr, scope);
    }
  };
}

function isExpressionEvaluator(n) {
  return n && n.type === IEXPREVAL;
}

function resolveExpression(n, values) {
  return isExpressionEvaluator(n) ? n.value(values) : n;
}

function expressionToString(tokens, toJS) {
  var nstack = [];
  var n1, n2, n3;
  var f, args, argCount;
  for (var i = 0; i < tokens.length; i++) {
    var item = tokens[i];
    var type = item.type;
    if (type === INUMBER) {
      if (typeof item.value === 'number' && item.value < 0) {
        nstack.push('(' + item.value + ')');
      } else if (Array.isArray(item.value)) {
        nstack.push('[' + item.value.map(escapeValue).join(', ') + ']');
      } else {
        nstack.push(escapeValue(item.value));
      }
    } else if (type === IOP2) {
      n2 = nstack.pop();
      n1 = nstack.pop();
      f = item.value;
      if (toJS) {
        if (f === '^') {
          nstack.push('Math.pow(' + n1 + ', ' + n2 + ')');
        } else if (f === 'and') {
          nstack.push('(!!' + n1 + ' && !!' + n2 + ')');
        } else if (f === 'or') {
          nstack.push('(!!' + n1 + ' || !!' + n2 + ')');
        } else if (f === '||') {
          nstack.push('(function(a,b){ return Array.isArray(a) && Array.isArray(b) ? a.concat(b) : String(a) + String(b); }((' + n1 + '),(' + n2 + ')))');
        } else if (f === '==') {
          nstack.push('(' + n1 + ' === ' + n2 + ')');
        } else if (f === '!=') {
          nstack.push('(' + n1 + ' !== ' + n2 + ')');
        } else if (f === '[') {
          nstack.push(n1 + '[(' + n2 + ') | 0]');
        } else {
          nstack.push('(' + n1 + ' ' + f + ' ' + n2 + ')');
        }
      } else {
        if (f === '[') {
          nstack.push(n1 + '[' + n2 + ']');
        } else {
          nstack.push('(' + n1 + ' ' + f + ' ' + n2 + ')');
        }
      }
    } else if (type === IOP3) {
      n3 = nstack.pop();
      n2 = nstack.pop();
      n1 = nstack.pop();
      f = item.value;
      if (f === '?') {
        nstack.push('(' + n1 + ' ? ' + n2 + ' : ' + n3 + ')');
      } else {
        throw new Error('invalid Expression');
      }
    } else if (type === IVAR || type === IVARNAME) {
      nstack.push(item.value);
    } else if (type === IOP1) {
      n1 = nstack.pop();
      f = item.value;
      if (f === '-' || f === '+') {
        nstack.push('(' + f + n1 + ')');
      } else if (toJS) {
        if (f === 'not') {
          nstack.push('(' + '!' + n1 + ')');
        } else if (f === '!') {
          nstack.push('fac(' + n1 + ')');
        } else {
          nstack.push(f + '(' + n1 + ')');
        }
      } else if (f === '!') {
        nstack.push('(' + n1 + '!)');
      } else {
        nstack.push('(' + f + ' ' + n1 + ')');
      }
    } else if (type === IFUNCALL) {
      argCount = item.value;
      args = [];
      while (argCount-- > 0) {
        args.unshift(nstack.pop());
      }
      f = nstack.pop();
      nstack.push(f + '(' + args.join(', ') + ')');
    } else if (type === IFUNDEF) {
      n2 = nstack.pop();
      argCount = item.value;
      args = [];
      while (argCount-- > 0) {
        args.unshift(nstack.pop());
      }
      n1 = nstack.pop();
      if (toJS) {
        nstack.push('(' + n1 + ' = function(' + args.join(', ') + ') { return ' + n2 + ' })');
      } else {
        nstack.push('(' + n1 + '(' + args.join(', ') + ') = ' + n2 + ')');
      }
    } else if (type === IMEMBER) {
      n1 = nstack.pop();
      nstack.push(n1 + '.' + item.value);
    } else if (type === IARRAY) {
      argCount = item.value;
      args = [];
      while (argCount-- > 0) {
        args.unshift(nstack.pop());
      }
      nstack.push('[' + args.join(', ') + ']');
    } else if (type === IEXPR) {
      nstack.push('(' + expressionToString(item.value, toJS) + ')');
    } else if (type === IENDSTATEMENT) ; else {
      throw new Error('invalid Expression');
    }
  }
  if (nstack.length > 1) {
    if (toJS) {
      nstack = [ nstack.join(',') ];
    } else {
      nstack = [ nstack.join(';') ];
    }
  }
  return String(nstack[0]);
}

function escapeValue(v) {
  if (typeof v === 'string') {
    return JSON.stringify(v).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  }
  return v;
}

function contains(array, obj) {
  for (var i = 0; i < array.length; i++) {
    if (array[i] === obj) {
      return true;
    }
  }
  return false;
}

function getSymbols(tokens, symbols, options) {
  options = options || {};
  var withMembers = !!options.withMembers;
  var prevVar = null;

  for (var i = 0; i < tokens.length; i++) {
    var item = tokens[i];
    if (item.type === IVAR || item.type === IVARNAME) {
      if (!withMembers && !contains(symbols, item.value)) {
        symbols.push(item.value);
      } else if (prevVar !== null) {
        if (!contains(symbols, prevVar)) {
          symbols.push(prevVar);
        }
        prevVar = item.value;
      } else {
        prevVar = item.value;
      }
    } else if (item.type === IMEMBER && withMembers && prevVar !== null) {
      prevVar += '.' + item.value;
    } else if (item.type === IEXPR) {
      getSymbols(item.value, symbols, options);
    } else if (prevVar !== null) {
      if (!contains(symbols, prevVar)) {
        symbols.push(prevVar);
      }
      prevVar = null;
    }
  }

  if (prevVar !== null && !contains(symbols, prevVar)) {
    symbols.push(prevVar);
  }
}

function Expression(tokens, parser) {
  this.tokens = tokens;
  this.parser = parser;
  this.unaryOps = parser.unaryOps;
  this.binaryOps = parser.binaryOps;
  this.ternaryOps = parser.ternaryOps;
  this.functions = parser.functions;
}

Expression.prototype.simplify = function (values) {
  values = values || {};
  return new Expression(simplify(this.tokens, this.unaryOps, this.binaryOps, this.ternaryOps, values), this.parser);
};

Expression.prototype.substitute = function (variable, expr) {
  if (!(expr instanceof Expression)) {
    expr = this.parser.parse(String(expr));
  }

  return new Expression(substitute(this.tokens, variable, expr), this.parser);
};

Expression.prototype.evaluate = function (values) {
  values = values || {};
  return evaluate(this.tokens, this, values);
};

Expression.prototype.toString = function () {
  return expressionToString(this.tokens, false);
};

Expression.prototype.symbols = function (options) {
  options = options || {};
  var vars = [];
  getSymbols(this.tokens, vars, options);
  return vars;
};

Expression.prototype.variables = function (options) {
  options = options || {};
  var vars = [];
  getSymbols(this.tokens, vars, options);
  var functions = this.functions;
  return vars.filter(function (name) {
    return !(name in functions);
  });
};

Expression.prototype.toJSFunction = function (param, variables) {
  var expr = this;
  var f = new Function(param, 'with(this.functions) with (this.ternaryOps) with (this.binaryOps) with (this.unaryOps) { return ' + expressionToString(this.simplify(variables).tokens, true) + '; }'); // eslint-disable-line no-new-func
  return function () {
    return f.apply(expr, arguments);
  };
};

var TEOF = 'TEOF';
var TOP = 'TOP';
var TNUMBER = 'TNUMBER';
var TSTRING = 'TSTRING';
var TPAREN = 'TPAREN';
var TBRACKET = 'TBRACKET';
var TCOMMA = 'TCOMMA';
var TNAME = 'TNAME';
var TSEMICOLON = 'TSEMICOLON';

function Token(type, value, index) {
  this.type = type;
  this.value = value;
  this.index = index;
}

Token.prototype.toString = function () {
  return this.type + ': ' + this.value;
};

function TokenStream(parser, expression) {
  this.pos = 0;
  this.current = null;
  this.unaryOps = parser.unaryOps;
  this.binaryOps = parser.binaryOps;
  this.ternaryOps = parser.ternaryOps;
  this.consts = parser.consts;
  this.expression = expression;
  this.savedPosition = 0;
  this.savedCurrent = null;
  this.options = parser.options;
  this.parser = parser;
}

TokenStream.prototype.newToken = function (type, value, pos) {
  return new Token(type, value, pos != null ? pos : this.pos);
};

TokenStream.prototype.save = function () {
  this.savedPosition = this.pos;
  this.savedCurrent = this.current;
};

TokenStream.prototype.restore = function () {
  this.pos = this.savedPosition;
  this.current = this.savedCurrent;
};

TokenStream.prototype.next = function () {
  if (this.pos >= this.expression.length) {
    return this.newToken(TEOF, 'EOF');
  }

  if (this.isWhitespace() || this.isComment()) {
    return this.next();
  } else if (this.isRadixInteger() ||
      this.isNumber() ||
      this.isOperator() ||
      this.isString() ||
      this.isParen() ||
      this.isBracket() ||
      this.isComma() ||
      this.isSemicolon() ||
      this.isNamedOp() ||
      this.isConst() ||
      this.isName()) {
    return this.current;
  } else {
    this.parseError('Unknown character "' + this.expression.charAt(this.pos) + '"');
  }
};

TokenStream.prototype.isString = function () {
  var r = false;
  var startPos = this.pos;
  var quote = this.expression.charAt(startPos);

  if (quote === '\'' || quote === '"') {
    var index = this.expression.indexOf(quote, startPos + 1);
    while (index >= 0 && this.pos < this.expression.length) {
      this.pos = index + 1;
      if (this.expression.charAt(index - 1) !== '\\') {
        var rawString = this.expression.substring(startPos + 1, index);
        this.current = this.newToken(TSTRING, this.unescape(rawString), startPos);
        r = true;
        break;
      }
      index = this.expression.indexOf(quote, index + 1);
    }
  }
  return r;
};

TokenStream.prototype.isParen = function () {
  var c = this.expression.charAt(this.pos);
  if (c === '(' || c === ')') {
    this.current = this.newToken(TPAREN, c);
    this.pos++;
    return true;
  }
  return false;
};

TokenStream.prototype.isBracket = function () {
  var c = this.expression.charAt(this.pos);
  if ((c === '[' || c === ']') && this.isOperatorEnabled('[')) {
    this.current = this.newToken(TBRACKET, c);
    this.pos++;
    return true;
  }
  return false;
};

TokenStream.prototype.isComma = function () {
  var c = this.expression.charAt(this.pos);
  if (c === ',') {
    this.current = this.newToken(TCOMMA, ',');
    this.pos++;
    return true;
  }
  return false;
};

TokenStream.prototype.isSemicolon = function () {
  var c = this.expression.charAt(this.pos);
  if (c === ';') {
    this.current = this.newToken(TSEMICOLON, ';');
    this.pos++;
    return true;
  }
  return false;
};

TokenStream.prototype.isConst = function () {
  var startPos = this.pos;
  var i = startPos;
  for (; i < this.expression.length; i++) {
    var c = this.expression.charAt(i);
    if (c.toUpperCase() === c.toLowerCase()) {
      if (i === this.pos || (c !== '_' && c !== '.' && (c < '0' || c > '9'))) {
        break;
      }
    }
  }
  if (i > startPos) {
    var str = this.expression.substring(startPos, i);
    if (str in this.consts) {
      this.current = this.newToken(TNUMBER, this.consts[str]);
      this.pos += str.length;
      return true;
    }
  }
  return false;
};

TokenStream.prototype.isNamedOp = function () {
  var startPos = this.pos;
  var i = startPos;
  for (; i < this.expression.length; i++) {
    var c = this.expression.charAt(i);
    if (c.toUpperCase() === c.toLowerCase()) {
      if (i === this.pos || (c !== '_' && (c < '0' || c > '9'))) {
        break;
      }
    }
  }
  if (i > startPos) {
    var str = this.expression.substring(startPos, i);
    if (this.isOperatorEnabled(str) && (str in this.binaryOps || str in this.unaryOps || str in this.ternaryOps)) {
      this.current = this.newToken(TOP, str);
      this.pos += str.length;
      return true;
    }
  }
  return false;
};

TokenStream.prototype.isName = function () {
  var startPos = this.pos;
  var i = startPos;
  var hasLetter = false;
  for (; i < this.expression.length; i++) {
    var c = this.expression.charAt(i);
    if (c.toUpperCase() === c.toLowerCase()) {
      if (i === this.pos && (c === '$' || c === '_')) {
        if (c === '_') {
          hasLetter = true;
        }
        continue;
      } else if (i === this.pos || !hasLetter || (c !== '_' && (c < '0' || c > '9'))) {
        break;
      }
    } else {
      hasLetter = true;
    }
  }
  if (hasLetter) {
    var str = this.expression.substring(startPos, i);
    this.current = this.newToken(TNAME, str);
    this.pos += str.length;
    return true;
  }
  return false;
};

TokenStream.prototype.isWhitespace = function () {
  var r = false;
  var c = this.expression.charAt(this.pos);
  while (c === ' ' || c === '\t' || c === '\n' || c === '\r') {
    r = true;
    this.pos++;
    if (this.pos >= this.expression.length) {
      break;
    }
    c = this.expression.charAt(this.pos);
  }
  return r;
};

var codePointPattern = /^[0-9a-f]{4}$/i;

TokenStream.prototype.unescape = function (v) {
  var index = v.indexOf('\\');
  if (index < 0) {
    return v;
  }

  var buffer = v.substring(0, index);
  while (index >= 0) {
    var c = v.charAt(++index);
    switch (c) {
      case '\'':
        buffer += '\'';
        break;
      case '"':
        buffer += '"';
        break;
      case '\\':
        buffer += '\\';
        break;
      case '/':
        buffer += '/';
        break;
      case 'b':
        buffer += '\b';
        break;
      case 'f':
        buffer += '\f';
        break;
      case 'n':
        buffer += '\n';
        break;
      case 'r':
        buffer += '\r';
        break;
      case 't':
        buffer += '\t';
        break;
      case 'u':
        // interpret the following 4 characters as the hex of the unicode code point
        var codePoint = v.substring(index + 1, index + 5);
        if (!codePointPattern.test(codePoint)) {
          this.parseError('Illegal escape sequence: \\u' + codePoint);
        }
        buffer += String.fromCharCode(parseInt(codePoint, 16));
        index += 4;
        break;
      default:
        throw this.parseError('Illegal escape sequence: "\\' + c + '"');
    }
    ++index;
    var backslash = v.indexOf('\\', index);
    buffer += v.substring(index, backslash < 0 ? v.length : backslash);
    index = backslash;
  }

  return buffer;
};

TokenStream.prototype.isComment = function () {
  var c = this.expression.charAt(this.pos);
  if (c === '/' && this.expression.charAt(this.pos + 1) === '*') {
    this.pos = this.expression.indexOf('*/', this.pos) + 2;
    if (this.pos === 1) {
      this.pos = this.expression.length;
    }
    return true;
  }
  return false;
};

TokenStream.prototype.isRadixInteger = function () {
  var pos = this.pos;

  if (pos >= this.expression.length - 2 || this.expression.charAt(pos) !== '0') {
    return false;
  }
  ++pos;

  var radix;
  var validDigit;
  if (this.expression.charAt(pos) === 'x') {
    radix = 16;
    validDigit = /^[0-9a-f]$/i;
    ++pos;
  } else if (this.expression.charAt(pos) === 'b') {
    radix = 2;
    validDigit = /^[01]$/i;
    ++pos;
  } else {
    return false;
  }

  var valid = false;
  var startPos = pos;

  while (pos < this.expression.length) {
    var c = this.expression.charAt(pos);
    if (validDigit.test(c)) {
      pos++;
      valid = true;
    } else {
      break;
    }
  }

  if (valid) {
    this.current = this.newToken(TNUMBER, parseInt(this.expression.substring(startPos, pos), radix));
    this.pos = pos;
  }
  return valid;
};

TokenStream.prototype.isNumber = function () {
  var valid = false;
  var pos = this.pos;
  var startPos = pos;
  var resetPos = pos;
  var foundDot = false;
  var foundDigits = false;
  var c;

  while (pos < this.expression.length) {
    c = this.expression.charAt(pos);
    if ((c >= '0' && c <= '9') || (!foundDot && c === '.')) {
      if (c === '.') {
        foundDot = true;
      } else {
        foundDigits = true;
      }
      pos++;
      valid = foundDigits;
    } else {
      break;
    }
  }

  if (valid) {
    resetPos = pos;
  }

  if (c === 'e' || c === 'E') {
    pos++;
    var acceptSign = true;
    var validExponent = false;
    while (pos < this.expression.length) {
      c = this.expression.charAt(pos);
      if (acceptSign && (c === '+' || c === '-')) {
        acceptSign = false;
      } else if (c >= '0' && c <= '9') {
        validExponent = true;
        acceptSign = false;
      } else {
        break;
      }
      pos++;
    }

    if (!validExponent) {
      pos = resetPos;
    }
  }

  if (valid) {
    this.current = this.newToken(TNUMBER, parseFloat(this.expression.substring(startPos, pos)));
    this.pos = pos;
  } else {
    this.pos = resetPos;
  }
  return valid;
};

TokenStream.prototype.isOperator = function () {
  var startPos = this.pos;
  var c = this.expression.charAt(this.pos);

  if (c === '+' || c === '-' || c === '*' || c === '/' || c === '%' || c === '^' || c === '?' || c === ':' || c === '.') {
    this.current = this.newToken(TOP, c);
  } else if (c === '∙' || c === '•') {
    this.current = this.newToken(TOP, '*');
  } else if (c === '>') {
    if (this.expression.charAt(this.pos + 1) === '=') {
      this.current = this.newToken(TOP, '>=');
      this.pos++;
    } else {
      this.current = this.newToken(TOP, '>');
    }
  } else if (c === '<') {
    if (this.expression.charAt(this.pos + 1) === '=') {
      this.current = this.newToken(TOP, '<=');
      this.pos++;
    } else {
      this.current = this.newToken(TOP, '<');
    }
  } else if (c === '|') {
    if (this.expression.charAt(this.pos + 1) === '|') {
      this.current = this.newToken(TOP, '||');
      this.pos++;
    } else {
      return false;
    }
  } else if (c === '=') {
    if (this.expression.charAt(this.pos + 1) === '=') {
      this.current = this.newToken(TOP, '==');
      this.pos++;
    } else {
      this.current = this.newToken(TOP, c);
    }
  } else if (c === '!') {
    if (this.expression.charAt(this.pos + 1) === '=') {
      this.current = this.newToken(TOP, '!=');
      this.pos++;
    } else {
      this.current = this.newToken(TOP, c);
    }
  } else {
    return false;
  }
  this.pos++;

  if (this.isOperatorEnabled(this.current.value)) {
    return true;
  } else {
    this.pos = startPos;
    return false;
  }
};

TokenStream.prototype.isOperatorEnabled = function (op) {
  return this.parser.isOperatorEnabled(op);
};

TokenStream.prototype.getCoordinates = function () {
  var line = 0;
  var column;
  var newline = -1;
  do {
    line++;
    column = this.pos - newline;
    newline = this.expression.indexOf('\n', newline + 1);
  } while (newline >= 0 && newline < this.pos);

  return {
    line: line,
    column: column
  };
};

TokenStream.prototype.parseError = function (msg) {
  var coords = this.getCoordinates();
  throw new Error('parse error [' + coords.line + ':' + coords.column + ']: ' + msg);
};

function ParserState(parser, tokenStream, options) {
  this.parser = parser;
  this.tokens = tokenStream;
  this.current = null;
  this.nextToken = null;
  this.next();
  this.savedCurrent = null;
  this.savedNextToken = null;
  this.allowMemberAccess = options.allowMemberAccess !== false;
}

ParserState.prototype.next = function () {
  this.current = this.nextToken;
  return (this.nextToken = this.tokens.next());
};

ParserState.prototype.tokenMatches = function (token, value) {
  if (typeof value === 'undefined') {
    return true;
  } else if (Array.isArray(value)) {
    return contains(value, token.value);
  } else if (typeof value === 'function') {
    return value(token);
  } else {
    return token.value === value;
  }
};

ParserState.prototype.save = function () {
  this.savedCurrent = this.current;
  this.savedNextToken = this.nextToken;
  this.tokens.save();
};

ParserState.prototype.restore = function () {
  this.tokens.restore();
  this.current = this.savedCurrent;
  this.nextToken = this.savedNextToken;
};

ParserState.prototype.accept = function (type, value) {
  if (this.nextToken.type === type && this.tokenMatches(this.nextToken, value)) {
    this.next();
    return true;
  }
  return false;
};

ParserState.prototype.expect = function (type, value) {
  if (!this.accept(type, value)) {
    var coords = this.tokens.getCoordinates();
    throw new Error('parse error [' + coords.line + ':' + coords.column + ']: Expected ' + (value || type));
  }
};

ParserState.prototype.parseAtom = function (instr) {
  var unaryOps = this.tokens.unaryOps;
  function isPrefixOperator(token) {
    return token.value in unaryOps;
  }

  if (this.accept(TNAME) || this.accept(TOP, isPrefixOperator)) {
    instr.push(new Instruction(IVAR, this.current.value));
  } else if (this.accept(TNUMBER)) {
    instr.push(new Instruction(INUMBER, this.current.value));
  } else if (this.accept(TSTRING)) {
    instr.push(new Instruction(INUMBER, this.current.value));
  } else if (this.accept(TPAREN, '(')) {
    this.parseExpression(instr);
    this.expect(TPAREN, ')');
  } else if (this.accept(TBRACKET, '[')) {
    if (this.accept(TBRACKET, ']')) {
      instr.push(new Instruction(IARRAY, 0));
    } else {
      var argCount = this.parseArrayList(instr);
      instr.push(new Instruction(IARRAY, argCount));
    }
  } else {
    throw new Error('unexpected ' + this.nextToken);
  }
};

ParserState.prototype.parseExpression = function (instr) {
  var exprInstr = [];
  if (this.parseUntilEndStatement(instr, exprInstr)) {
    return;
  }
  this.parseVariableAssignmentExpression(exprInstr);
  if (this.parseUntilEndStatement(instr, exprInstr)) {
    return;
  }
  this.pushExpression(instr, exprInstr);
};

ParserState.prototype.pushExpression = function (instr, exprInstr) {
  for (var i = 0, len = exprInstr.length; i < len; i++) {
    instr.push(exprInstr[i]);
  }
};

ParserState.prototype.parseUntilEndStatement = function (instr, exprInstr) {
  if (!this.accept(TSEMICOLON)) return false;
  if (this.nextToken && this.nextToken.type !== TEOF && !(this.nextToken.type === TPAREN && this.nextToken.value === ')')) {
    exprInstr.push(new Instruction(IENDSTATEMENT));
  }
  if (this.nextToken.type !== TEOF) {
    this.parseExpression(exprInstr);
  }
  instr.push(new Instruction(IEXPR, exprInstr));
  return true;
};

ParserState.prototype.parseArrayList = function (instr) {
  var argCount = 0;

  while (!this.accept(TBRACKET, ']')) {
    this.parseExpression(instr);
    ++argCount;
    while (this.accept(TCOMMA)) {
      this.parseExpression(instr);
      ++argCount;
    }
  }

  return argCount;
};

ParserState.prototype.parseVariableAssignmentExpression = function (instr) {
  this.parseConditionalExpression(instr);
  while (this.accept(TOP, '=')) {
    var varName = instr.pop();
    var varValue = [];
    var lastInstrIndex = instr.length - 1;
    if (varName.type === IFUNCALL) {
      if (!this.tokens.isOperatorEnabled('()=')) {
        throw new Error('function definition is not permitted');
      }
      for (var i = 0, len = varName.value + 1; i < len; i++) {
        var index = lastInstrIndex - i;
        if (instr[index].type === IVAR) {
          instr[index] = new Instruction(IVARNAME, instr[index].value);
        }
      }
      this.parseVariableAssignmentExpression(varValue);
      instr.push(new Instruction(IEXPR, varValue));
      instr.push(new Instruction(IFUNDEF, varName.value));
      continue;
    }
    if (varName.type !== IVAR && varName.type !== IMEMBER) {
      throw new Error('expected variable for assignment');
    }
    this.parseVariableAssignmentExpression(varValue);
    instr.push(new Instruction(IVARNAME, varName.value));
    instr.push(new Instruction(IEXPR, varValue));
    instr.push(binaryInstruction('='));
  }
};

ParserState.prototype.parseConditionalExpression = function (instr) {
  this.parseOrExpression(instr);
  while (this.accept(TOP, '?')) {
    var trueBranch = [];
    var falseBranch = [];
    this.parseConditionalExpression(trueBranch);
    this.expect(TOP, ':');
    this.parseConditionalExpression(falseBranch);
    instr.push(new Instruction(IEXPR, trueBranch));
    instr.push(new Instruction(IEXPR, falseBranch));
    instr.push(ternaryInstruction('?'));
  }
};

ParserState.prototype.parseOrExpression = function (instr) {
  this.parseAndExpression(instr);
  while (this.accept(TOP, 'or')) {
    var falseBranch = [];
    this.parseAndExpression(falseBranch);
    instr.push(new Instruction(IEXPR, falseBranch));
    instr.push(binaryInstruction('or'));
  }
};

ParserState.prototype.parseAndExpression = function (instr) {
  this.parseComparison(instr);
  while (this.accept(TOP, 'and')) {
    var trueBranch = [];
    this.parseComparison(trueBranch);
    instr.push(new Instruction(IEXPR, trueBranch));
    instr.push(binaryInstruction('and'));
  }
};

var COMPARISON_OPERATORS = ['==', '!=', '<', '<=', '>=', '>', 'in'];

ParserState.prototype.parseComparison = function (instr) {
  this.parseAddSub(instr);
  while (this.accept(TOP, COMPARISON_OPERATORS)) {
    var op = this.current;
    this.parseAddSub(instr);
    instr.push(binaryInstruction(op.value));
  }
};

var ADD_SUB_OPERATORS = ['+', '-', '||'];

ParserState.prototype.parseAddSub = function (instr) {
  this.parseTerm(instr);
  while (this.accept(TOP, ADD_SUB_OPERATORS)) {
    var op = this.current;
    this.parseTerm(instr);
    instr.push(binaryInstruction(op.value));
  }
};

var TERM_OPERATORS = ['*', '/', '%'];

ParserState.prototype.parseTerm = function (instr) {
  this.parseFactor(instr);
  while (this.accept(TOP, TERM_OPERATORS)) {
    var op = this.current;
    this.parseFactor(instr);
    instr.push(binaryInstruction(op.value));
  }
};

ParserState.prototype.parseFactor = function (instr) {
  var unaryOps = this.tokens.unaryOps;
  function isPrefixOperator(token) {
    return token.value in unaryOps;
  }

  this.save();
  if (this.accept(TOP, isPrefixOperator)) {
    if (this.current.value !== '-' && this.current.value !== '+') {
      if (this.nextToken.type === TPAREN && this.nextToken.value === '(') {
        this.restore();
        this.parseExponential(instr);
        return;
      } else if (this.nextToken.type === TSEMICOLON || this.nextToken.type === TCOMMA || this.nextToken.type === TEOF || (this.nextToken.type === TPAREN && this.nextToken.value === ')')) {
        this.restore();
        this.parseAtom(instr);
        return;
      }
    }

    var op = this.current;
    this.parseFactor(instr);
    instr.push(unaryInstruction(op.value));
  } else {
    this.parseExponential(instr);
  }
};

ParserState.prototype.parseExponential = function (instr) {
  this.parsePostfixExpression(instr);
  while (this.accept(TOP, '^')) {
    this.parseFactor(instr);
    instr.push(binaryInstruction('^'));
  }
};

ParserState.prototype.parsePostfixExpression = function (instr) {
  this.parseFunctionCall(instr);
  while (this.accept(TOP, '!')) {
    instr.push(unaryInstruction('!'));
  }
};

ParserState.prototype.parseFunctionCall = function (instr) {
  var unaryOps = this.tokens.unaryOps;
  function isPrefixOperator(token) {
    return token.value in unaryOps;
  }

  if (this.accept(TOP, isPrefixOperator)) {
    var op = this.current;
    this.parseAtom(instr);
    instr.push(unaryInstruction(op.value));
  } else {
    this.parseMemberExpression(instr);
    while (this.accept(TPAREN, '(')) {
      if (this.accept(TPAREN, ')')) {
        instr.push(new Instruction(IFUNCALL, 0));
      } else {
        var argCount = this.parseArgumentList(instr);
        instr.push(new Instruction(IFUNCALL, argCount));
      }
    }
  }
};

ParserState.prototype.parseArgumentList = function (instr) {
  var argCount = 0;

  while (!this.accept(TPAREN, ')')) {
    this.parseExpression(instr);
    ++argCount;
    while (this.accept(TCOMMA)) {
      this.parseExpression(instr);
      ++argCount;
    }
  }

  return argCount;
};

ParserState.prototype.parseMemberExpression = function (instr) {
  this.parseAtom(instr);
  while (this.accept(TOP, '.') || this.accept(TBRACKET, '[')) {
    var op = this.current;

    if (op.value === '.') {
      if (!this.allowMemberAccess) {
        throw new Error('unexpected ".", member access is not permitted');
      }

      this.expect(TNAME);
      instr.push(new Instruction(IMEMBER, this.current.value));
    } else if (op.value === '[') {
      if (!this.tokens.isOperatorEnabled('[')) {
        throw new Error('unexpected "[]", arrays are disabled');
      }

      this.parseExpression(instr);
      this.expect(TBRACKET, ']');
      instr.push(binaryInstruction('['));
    } else {
      throw new Error('unexpected symbol: ' + op.value);
    }
  }
};

function add(a, b) {
  return Number(a) + Number(b);
}

function sub(a, b) {
  return a - b;
}

function mul(a, b) {
  return a * b;
}

function div(a, b) {
  return a / b;
}

function mod(a, b) {
  return a % b;
}

function concat(a, b) {
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.concat(b);
  }
  return '' + a + b;
}

function equal(a, b) {
  return a === b;
}

function notEqual(a, b) {
  return a !== b;
}

function greaterThan(a, b) {
  return a > b;
}

function lessThan(a, b) {
  return a < b;
}

function greaterThanEqual(a, b) {
  return a >= b;
}

function lessThanEqual(a, b) {
  return a <= b;
}

function andOperator(a, b) {
  return Boolean(a && b);
}

function orOperator(a, b) {
  return Boolean(a || b);
}

function inOperator(a, b) {
  return contains(b, a);
}

function sinh(a) {
  return ((Math.exp(a) - Math.exp(-a)) / 2);
}

function cosh(a) {
  return ((Math.exp(a) + Math.exp(-a)) / 2);
}

function tanh(a) {
  if (a === Infinity) return 1;
  if (a === -Infinity) return -1;
  return (Math.exp(a) - Math.exp(-a)) / (Math.exp(a) + Math.exp(-a));
}

function asinh(a) {
  if (a === -Infinity) return a;
  return Math.log(a + Math.sqrt((a * a) + 1));
}

function acosh(a) {
  return Math.log(a + Math.sqrt((a * a) - 1));
}

function atanh(a) {
  return (Math.log((1 + a) / (1 - a)) / 2);
}

function log10(a) {
  return Math.log(a) * Math.LOG10E;
}

function neg(a) {
  return -a;
}

function not(a) {
  return !a;
}

function trunc(a) {
  return a < 0 ? Math.ceil(a) : Math.floor(a);
}

function random(a) {
  return Math.random() * (a || 1);
}

function factorial(a) { // a!
  return gamma(a + 1);
}

function isInteger(value) {
  return isFinite(value) && (value === Math.round(value));
}

var GAMMA_G = 4.7421875;
var GAMMA_P = [
  0.99999999999999709182,
  57.156235665862923517, -59.597960355475491248,
  14.136097974741747174, -0.49191381609762019978,
  0.33994649984811888699e-4,
  0.46523628927048575665e-4, -0.98374475304879564677e-4,
  0.15808870322491248884e-3, -0.21026444172410488319e-3,
  0.21743961811521264320e-3, -0.16431810653676389022e-3,
  0.84418223983852743293e-4, -0.26190838401581408670e-4,
  0.36899182659531622704e-5
];

// Gamma function from math.js
function gamma(n) {
  var t, x;

  if (isInteger(n)) {
    if (n <= 0) {
      return isFinite(n) ? Infinity : NaN;
    }

    if (n > 171) {
      return Infinity; // Will overflow
    }

    var value = n - 2;
    var res = n - 1;
    while (value > 1) {
      res *= value;
      value--;
    }

    if (res === 0) {
      res = 1; // 0! is per definition 1
    }

    return res;
  }

  if (n < 0.5) {
    return Math.PI / (Math.sin(Math.PI * n) * gamma(1 - n));
  }

  if (n >= 171.35) {
    return Infinity; // will overflow
  }

  if (n > 85.0) { // Extended Stirling Approx
    var twoN = n * n;
    var threeN = twoN * n;
    var fourN = threeN * n;
    var fiveN = fourN * n;
    return Math.sqrt(2 * Math.PI / n) * Math.pow((n / Math.E), n) *
      (1 + (1 / (12 * n)) + (1 / (288 * twoN)) - (139 / (51840 * threeN)) -
      (571 / (2488320 * fourN)) + (163879 / (209018880 * fiveN)) +
      (5246819 / (75246796800 * fiveN * n)));
  }

  --n;
  x = GAMMA_P[0];
  for (var i = 1; i < GAMMA_P.length; ++i) {
    x += GAMMA_P[i] / (n + i);
  }

  t = n + GAMMA_G + 0.5;
  return Math.sqrt(2 * Math.PI) * Math.pow(t, n + 0.5) * Math.exp(-t) * x;
}

function stringOrArrayLength(s) {
  if (Array.isArray(s)) {
    return s.length;
  }
  return String(s).length;
}

function hypot() {
  var sum = 0;
  var larg = 0;
  for (var i = 0; i < arguments.length; i++) {
    var arg = Math.abs(arguments[i]);
    var div;
    if (larg < arg) {
      div = larg / arg;
      sum = (sum * div * div) + 1;
      larg = arg;
    } else if (arg > 0) {
      div = arg / larg;
      sum += div * div;
    } else {
      sum += arg;
    }
  }
  return larg === Infinity ? Infinity : larg * Math.sqrt(sum);
}

function condition(cond, yep, nope) {
  return cond ? yep : nope;
}

/**
* Decimal adjustment of a number.
* From @escopecz.
*
* @param {Number} value The number.
* @param {Integer} exp  The exponent (the 10 logarithm of the adjustment base).
* @return {Number} The adjusted value.
*/
function roundTo(value, exp) {
  // If the exp is undefined or zero...
  if (typeof exp === 'undefined' || +exp === 0) {
    return Math.round(value);
  }
  value = +value;
  exp = -(+exp);
  // If the value is not a number or the exp is not an integer...
  if (isNaN(value) || !(typeof exp === 'number' && exp % 1 === 0)) {
    return NaN;
  }
  // Shift
  value = value.toString().split('e');
  value = Math.round(+(value[0] + 'e' + (value[1] ? (+value[1] - exp) : -exp)));
  // Shift back
  value = value.toString().split('e');
  return +(value[0] + 'e' + (value[1] ? (+value[1] + exp) : exp));
}

function setVar(name, value, variables) {
  if (variables) variables[name] = value;
  return value;
}

function arrayIndex(array, index) {
  return array[index | 0];
}

function max(array) {
  if (arguments.length === 1 && Array.isArray(array)) {
    return Math.max.apply(Math, array);
  } else {
    return Math.max.apply(Math, arguments);
  }
}

function min(array) {
  if (arguments.length === 1 && Array.isArray(array)) {
    return Math.min.apply(Math, array);
  } else {
    return Math.min.apply(Math, arguments);
  }
}

function arrayMap(f, a) {
  if (typeof f !== 'function') {
    throw new Error('First argument to map is not a function');
  }
  if (!Array.isArray(a)) {
    throw new Error('Second argument to map is not an array');
  }
  return a.map(function (x, i) {
    return f(x, i);
  });
}

function arrayFold(f, init, a) {
  if (typeof f !== 'function') {
    throw new Error('First argument to fold is not a function');
  }
  if (!Array.isArray(a)) {
    throw new Error('Second argument to fold is not an array');
  }
  return a.reduce(function (acc, x, i) {
    return f(acc, x, i);
  }, init);
}

function arrayFilter(f, a) {
  if (typeof f !== 'function') {
    throw new Error('First argument to filter is not a function');
  }
  if (!Array.isArray(a)) {
    throw new Error('Second argument to filter is not an array');
  }
  return a.filter(function (x, i) {
    return f(x, i);
  });
}

function stringOrArrayIndexOf(target, s) {
  if (!(Array.isArray(s) || typeof s === 'string')) {
    throw new Error('Second argument to indexOf is not a string or array');
  }

  return s.indexOf(target);
}

function arrayJoin(sep, a) {
  if (!Array.isArray(a)) {
    throw new Error('Second argument to join is not an array');
  }

  return a.join(sep);
}

function sign(x) {
  return ((x > 0) - (x < 0)) || +x;
}

var ONE_THIRD = 1/3;
function cbrt(x) {
  return x < 0 ? -Math.pow(-x, ONE_THIRD) : Math.pow(x, ONE_THIRD);
}

function expm1(x) {
  return Math.exp(x) - 1;
}

function log1p(x) {
  return Math.log(1 + x);
}

function log2(x) {
  return Math.log(x) / Math.LN2;
}

function Parser(options) {
  this.options = options || {};
  this.unaryOps = {
    sin: Math.sin,
    cos: Math.cos,
    tan: Math.tan,
    asin: Math.asin,
    acos: Math.acos,
    atan: Math.atan,
    sinh: Math.sinh || sinh,
    cosh: Math.cosh || cosh,
    tanh: Math.tanh || tanh,
    asinh: Math.asinh || asinh,
    acosh: Math.acosh || acosh,
    atanh: Math.atanh || atanh,
    sqrt: Math.sqrt,
    cbrt: Math.cbrt || cbrt,
    log: Math.log,
    log2: Math.log2 || log2,
    ln: Math.log,
    lg: Math.log10 || log10,
    log10: Math.log10 || log10,
    expm1: Math.expm1 || expm1,
    log1p: Math.log1p || log1p,
    abs: Math.abs,
    ceil: Math.ceil,
    floor: Math.floor,
    round: Math.round,
    trunc: Math.trunc || trunc,
    '-': neg,
    '+': Number,
    exp: Math.exp,
    not: not,
    length: stringOrArrayLength,
    '!': factorial,
    sign: Math.sign || sign
  };

  this.binaryOps = {
    '+': add,
    '-': sub,
    '*': mul,
    '/': div,
    '%': mod,
    '^': Math.pow,
    '||': concat,
    '==': equal,
    '!=': notEqual,
    '>': greaterThan,
    '<': lessThan,
    '>=': greaterThanEqual,
    '<=': lessThanEqual,
    and: andOperator,
    or: orOperator,
    'in': inOperator,
    '=': setVar,
    '[': arrayIndex
  };

  this.ternaryOps = {
    '?': condition
  };

  this.functions = {
    random: random,
    fac: factorial,
    min: min,
    max: max,
    hypot: Math.hypot || hypot,
    pyt: Math.hypot || hypot, // backward compat
    pow: Math.pow,
    atan2: Math.atan2,
    'if': condition,
    gamma: gamma,
    roundTo: roundTo,
    map: arrayMap,
    fold: arrayFold,
    filter: arrayFilter,
    indexOf: stringOrArrayIndexOf,
    join: arrayJoin
  };

  this.consts = {
    E: Math.E,
    PI: Math.PI,
    'true': true,
    'false': false
  };
}

Parser.prototype.parse = function (expr) {
  var instr = [];
  var parserState = new ParserState(
    this,
    new TokenStream(this, expr),
    { allowMemberAccess: this.options.allowMemberAccess }
  );

  parserState.parseExpression(instr);
  parserState.expect(TEOF, 'EOF');

  return new Expression(instr, this);
};

Parser.prototype.evaluate = function (expr, variables) {
  return this.parse(expr).evaluate(variables);
};

var sharedParser = new Parser();

Parser.parse = function (expr) {
  return sharedParser.parse(expr);
};

Parser.evaluate = function (expr, variables) {
  return sharedParser.parse(expr).evaluate(variables);
};

var optionNameMap = {
  '+': 'add',
  '-': 'subtract',
  '*': 'multiply',
  '/': 'divide',
  '%': 'remainder',
  '^': 'power',
  '!': 'factorial',
  '<': 'comparison',
  '>': 'comparison',
  '<=': 'comparison',
  '>=': 'comparison',
  '==': 'comparison',
  '!=': 'comparison',
  '||': 'concatenate',
  'and': 'logical',
  'or': 'logical',
  'not': 'logical',
  '?': 'conditional',
  ':': 'conditional',
  '=': 'assignment',
  '[': 'array',
  '()=': 'fndef'
};

function getOptionName(op) {
  return optionNameMap.hasOwnProperty(op) ? optionNameMap[op] : op;
}

Parser.prototype.isOperatorEnabled = function (op) {
  var optionName = getOptionName(op);
  var operators = this.options.operators || {};

  return !(optionName in operators) || !!operators[optionName];
};

/*!
 Based on ndef.parser, by Raphael Graf(r@undefined.ch)
 http://www.undefined.ch/mparser/index.html

 Ported to JavaScript and modified by Matthew Crumley (email@matthewcrumley.com, http://silentmatt.com/)

 You are free to use and modify this code in anyway you find useful. Please leave this comment in the code
 to acknowledge its original source. If you feel like it, I enjoy hearing about projects that use my code,
 but don't feel like you have to let me know or ask permission.
*/

// Backwards compatibility
var index = {
  Parser: Parser,
  Expression: Expression
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (index);



/***/ })

}]);