"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["StructurePage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'AccessSelectFormControl',
  components: {},
  props: {
    items: {
      type: Array,
      "default": function _default() {
        return [];
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'UISidebar',
  props: {
    title: {
      type: String,
      "default": ''
    },
    open: {
      type: Boolean
    },
    width: {
      type: String,
      "default": ''
    },
    link: {
      type: String,
      "default": ''
    }
  },
  data: function data() {
    return {};
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureEditCard.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureEditCard.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_Structure_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/Structure.js */ "./resources/js/stores/Structure.js");
/* harmony import */ var _ui_AccessSelect_AccessSelect_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ui/AccessSelect/AccessSelect.vue */ "./resources/js/components/ui/AccessSelect/AccessSelect.vue");
/* harmony import */ var _ui_AccessSelect_AccessSelectFormControl_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ui/AccessSelect/AccessSelectFormControl.vue */ "./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue");
/* harmony import */ var _ui_Overlay_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ui/Overlay.vue */ "./resources/js/components/ui/Overlay.vue");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






var DESC_DIVIDER = '◕◕';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'StructureEditCard',
  components: {
    AccessSelect: _ui_AccessSelect_AccessSelect_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    AccessSelectFormControl: _ui_AccessSelect_AccessSelectFormControl_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    JobtronOverlay: _ui_Overlay_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  props: {
    card: {
      type: Object,
      "default": null
    },
    users: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    departmentsList: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    positions: {
      type: Array,
      "default": function _default() {
        return [];
      }
    }
  },
  data: function data() {
    var _this = this;
    return {
      departmentName: this.card.group_id ? this.departmentsList.find(function (opt) {
        return opt.id === _this.card.group_id;
      }) : [{
        id: null,
        name: this.card.name
      }],
      director: this.card.is_vacant ? {
        id: 0,
        name: 'Вакантная',
        /* eslint-disable-next-line camelcase */
        last_name: 'позиция',
        avatar: '/user.png'
      } : this.card.manager ? this.users.find(function (user) {
        return user.id === _this.card.manager.user_id;
      }) : '',
      result: (this.card.description || '').split(DESC_DIVIDER)[0],
      position: this.card.manager && this.card.manager.position_id ? this.positions.find(function (pos) {
        return pos.id === _this.card.manager.position_id;
      }) : '',
      group: !!this.card.is_group || false,
      autoUsers: !!this.card.status || false,
      bgColor: this.card.color || '#d0def5',
      nameTag: this.card.group_id ? [] : [{
        id: null,
        name: this.card.name
      }],
      accessList: this.card.users.reduce(function (result, u) {
        if (_this.card.manager && _this.card.manager.user_id === u.id) return result;
        var user = _this.users.find(function (user) {
          return user.id === u.id;
        });
        if (user) result.push(_objectSpread(_objectSpread({}, user), {}, {
          type: 1,
          name: "".concat(user.name, " ").concat(user.last_name)
        }));
        return result;
      }, []),
      isAccessSelect: false,
      vacantDescription: (this.card.description || DESC_DIVIDER).split(DESC_DIVIDER)[1]
    };
  },
  computed: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_4__.mapState)(_stores_Structure_js__WEBPACK_IMPORTED_MODULE_0__.useStructureStore, ['editedCard'])), {}, {
    groupOptions: function groupOptions() {
      return [].concat(_toConsumableArray(this.nameTag), _toConsumableArray(this.departmentsList));
    },
    posOptions: function posOptions() {
      return [].concat(_toConsumableArray(this.positions), [{
        id: 0,
        name: '+ Создать новую должность'
      }]);
    },
    usersAndBlank: function usersAndBlank() {
      return [{
        id: 0,
        name: 'Вакантная',
        /* eslint-disable-next-line camelcase */
        last_name: 'позиция',
        avatar: '/user.png'
      }].concat(_toConsumableArray(this.users));
    }
  }),
  watch: {
    position: function position() {
      if (this.position && this.position.id === 0) {
        this.$refs.createPosLink.click();
      }
    },
    departmentName: function departmentName(value) {
      if (value !== null && value !== void 0 && value.id) this.autoManager();
    }
  },
  mounted: function mounted() {},
  beforeUnmount: function beforeUnmount() {},
  methods: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_4__.mapActions)(_stores_Structure_js__WEBPACK_IMPORTED_MODULE_0__.useStructureStore, ['createCard', 'updateCard', 'deleteCard', 'closeEditCard'])), {}, {
    autoManager: function autoManager() {
      var _this2 = this;
      if (!this.users) return;
      var manager = this.users.find(function (user) {
        if (!user.profile_group) return false;
        var group = user.profile_group.find(function (group) {
          return group.id === _this2.departmentName.id;
        });
        if (group) return group.is_head;
        return false;
      });
      if (manager) {
        this.director = manager;
        this.position = this.positions.find(function (pos) {
          return pos.id === manager.position_id;
        });
      }
    },
    saveDepartment: function saveDepartment() {
      var _this3 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var _this3$position, _this3$director;
        var isGroup, hasName, saveData, data;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                isGroup = _this3.departmentName && _this3.departmentName.id;
                hasName = _this3.nameTag.length; // const hasPosition = this.position && this.position.id
                if (isGroup || hasName) {
                  _context.next = 4;
                  break;
                }
                return _context.abrupt("return", _this3.$toast.error('Укажите отдел или название департамента'));
              case 4:
                // if(!hasPosition) return this.$toast.error('Укажите должность руководителя')
                /* eslint-disable camelcase */
                saveData = {
                  id: _this3.card.id,
                  parent_id: _this3.card.parent_id,
                  group_id: isGroup ? _this3.departmentName.id : null,
                  description: _this3.result + DESC_DIVIDER + _this3.vacantDescription,
                  color: _this3.bgColor,
                  users: _toConsumableArray(_this3.getUsers()).filter(_this3.unique),
                  status: _this3.autoUsers,
                  is_group: _this3.group,
                  manager: {
                    user_id: null,
                    position_id: (_this3$position = _this3.position) === null || _this3$position === void 0 ? void 0 : _this3$position.id
                  },
                  is_vacant: !!(_this3.director && _this3.director.id === 0)
                };
                if ((_this3$director = _this3.director) !== null && _this3$director !== void 0 && _this3$director.id) {
                  saveData.users.push({
                    id: _this3.director.id
                  });
                  saveData.manager.user_id = _this3.director.id;
                } else if (_this3.director) {
                  saveData.is_vacant = true;
                }
                /* eslint-enable camelcase */

                if (!isGroup && hasName) {
                  saveData.name = _this3.nameTag[0].name;
                }
                _this3.closeEditCard();
                _context.prev = 8;
                _context.next = 11;
                return _this3[_this3.card.id > 0 ? 'updateCard' : 'createCard'](saveData);
              case 11:
                data = _context.sent;
                if (data) _this3.$toast.success('Карточка сохранена');
                _context.next = 18;
                break;
              case 15:
                _context.prev = 15;
                _context.t0 = _context["catch"](8);
                _this3.$toast.error('Карточка не сохранена');
              case 18:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[8, 15]]);
      }))();
    },
    deleteDepartment: function deleteDepartment() {
      var _this4 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var data;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;
                _context2.next = 3;
                return _this4.deleteCard(_this4.card.id);
              case 3:
                data = _context2.sent;
                if (data) _this4.$toast.success('Карточка удалена');
                _this4.closeEditCard();
                _context2.next = 11;
                break;
              case 8:
                _context2.prev = 8;
                _context2.t0 = _context2["catch"](0);
                _this4.$toast.error('Карточка не удалена');
              case 11:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[0, 8]]);
      }))();
    },
    tagName: function tagName(search) {
      this.nameTag = [{
        id: null,
        name: search
      }];
      this.departmentName = {
        id: null,
        name: search
      };
    },
    selectName: function selectName(option) {
      if (!option.id) return;
      this.nameTag = [];
    },
    getUsers: function getUsers() {
      var _this5 = this;
      return this.accessList.reduce(function (result, item) {
        switch (item.type) {
          case 1:
            result.push({
              id: item.id
            });
            break;
          case 2:
            _this5.users.forEach(function (user) {
              if (!user.profile_group) return;
              var group = user.profile_group.find(function (group) {
                return group.id === item.id;
              });
              if (group) result.push({
                id: user.id
              });
            });
            break;
          case 3:
            _this5.users.forEach(function (user) {
              if (user.position_id === item.id) result.push({
                id: user.id
              });
            });
            break;
        }
        return result;
      }, []);
    },
    unique: function unique(value, index, array) {
      return array.findIndex(function (item) {
        return item.id === value.id;
      }) === index;
    }
  })
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureInfo.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureInfo.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'StructureInfo',
  components: {},
  props: {
    info: {
      type: Object,
      "default": function _default() {
        return {};
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _StructureInfo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StructureInfo */ "./resources/js/pages/Structure/StructureInfo.vue");
/* harmony import */ var _stores_Structure_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/stores/Structure.js */ "./resources/js/stores/Structure.js");
/* harmony import */ var _ui_PulseCard_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ui/PulseCard.vue */ "./resources/js/components/ui/PulseCard.vue");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





var DESC_DIVIDER = '◕◕';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'StructureItem',
  components: {
    StructureInfo: _StructureInfo__WEBPACK_IMPORTED_MODULE_0__["default"],
    PulseCard: _ui_PulseCard_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  props: {
    card: {
      type: Object,
      "default": null
    },
    level: {
      type: Number,
      "default": 0
    },
    editStructure: Boolean,
    dictionaries: {
      type: Object,
      "default": function _default() {
        return {
          users: [],
          /* eslint-disable-next-line camelcase */
          profile_groups: [],
          positions: []
        };
      }
    },
    skipUsers: {
      type: Array,
      "default": function _default() {
        return [];
      }
    }
  },
  data: function data() {
    return {
      startLine: '1px',
      endLine: '2px',
      resultWidth: '0',
      halfWidth: 0
    };
  },
  computed: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_3__.mapState)(_stores_Structure_js__WEBPACK_IMPORTED_MODULE_1__.useStructureStore, ['cards', 'isEditMode', 'isDemo', 'demo'])), {}, {
    children: function children() {
      var _this = this;
      if (this.isDemo) {
        return this.demo.structure.reduce(function (result, child) {
          if (child.parent_id === _this.card.id) {
            result.push(child);
          }
          return result;
        }, []);
      }
      return this.cards.reduce(function (result, child) {
        if (child.parent_id === _this.card.id) {
          result.push(child);
        }
        return result;
      }, []);
    },
    localSkip: function localSkip() {
      if (this.card.manager) return [].concat(_toConsumableArray(this.skipUsers), [this.card.manager.user_id]);
      return this.skipUsers;
    },
    name: function name() {
      var _this2 = this;
      if (!this.card) return '';
      if (!this.card.group_id) return this.card.name;
      var group = this.dictionaries.profile_groups.find(function (group) {
        return group.id === _this2.card.group_id;
      });
      if (group) return group.name;
      return '';
    },
    manager: function manager() {
      var _this3 = this;
      if (!this.card) return null;
      if (!this.card.manager) return null;
      var manager = this.dictionaries.users.find(function (user) {
        return user.id === _this3.card.manager.user_id;
      });
      if (manager) return manager;
      if (this.card.is_vacant) return {
        id: 0,
        name: 'Вакантная',
        /* eslint-disable-next-line camelcase */
        last_name: 'позиция',
        avatar: '/user.png'
      };
      return null;
    },
    position: function position() {
      var _this4 = this;
      if (!this.card) return null;
      if (!this.card.manager) return null;
      return this.dictionaries.positions.find(function (pos) {
        return pos.id === _this4.card.manager.position_id;
      });
    },
    users: function users() {
      var _this5 = this;
      if (this.card.status && this.card.group_id) {
        return this.dictionaries.users.filter(function (user) {
          var _user$profile_group;
          if (_this5.localSkip.includes(user.id)) return false;
          return !!((_user$profile_group = user.profile_group) !== null && _user$profile_group !== void 0 && _user$profile_group.find(function (group) {
            return group.id === _this5.card.group_id;
          }));
        });
      }
      return this.card.users.reduce(function (result, userPivot) {
        if (_this5.localSkip.includes(userPivot.id)) return result;
        var user = _this5.dictionaries.users.find(function (u) {
          return u.id === userPivot.id;
        });
        if (user) result.push(user);
        return result;
      }, []);
    },
    employeesCount: function employeesCount() {
      return this.children.length + this.users.length;
    },
    description: function description() {
      return (this.card.description || DESC_DIVIDER).split(DESC_DIVIDER);
    },
    isVacant: function isVacant() {
      return this.card.is_vacant || this.manager && this.manager.user_id === 0;
    },
    isCurrentUserCard: function isCurrentUserCard() {
      /* global Laravel */
      if (this.manager && this.manager.id === Laravel.userId) return true;
      return this.users.some(function (user) {
        return user.id === Laravel.userId;
      });
    }
  }),
  watch: {
    card: function card() {
      this.drawLines();
    }
  },
  mounted: function mounted() {
    this.drawLines();
  },
  methods: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_3__.mapActions)(_stores_Structure_js__WEBPACK_IMPORTED_MODULE_1__.useStructureStore, ['addCard', 'editCard', 'showMoreUsers'])), {}, {
    drawLines: function drawLines() {
      var _this6 = this;
      this.$nextTick(function () {
        if (_this6.$refs.group) {
          var children = _this6.$refs.group.children;
          _this6.resultWidth = _this6.$refs.group.offsetWidth - children.length * 5;
          _this6.startLine = "".concat(children[0].offsetWidth / 2 + 8, "px");
          _this6.endLine = "".concat(children[children.length - 1].offsetWidth / 2 + 8, "px");
        }
        if (_this6.$refs.structureItem) {
          _this6.halfWidth = "".concat(_this6.$refs.structureItem.offsetWidth / 2, "px");
        }
        _this6.$emit('updateLines');
      });
    },
    addNew: function addNew() {
      this.addCard(this.card.id);
      this.$forceUpdate();
    }
  })
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructurePage.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructurePage.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StructureItem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StructureItem */ "./resources/js/pages/Structure/StructureItem.vue");
/* harmony import */ var _StructureEditCard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StructureEditCard */ "./resources/js/pages/Structure/StructureEditCard.vue");
/* harmony import */ var _StructureUsersMore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./StructureUsersMore */ "./resources/js/pages/Structure/StructureUsersMore.vue");
/* harmony import */ var _ui_SimpleSidebar_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ui/SimpleSidebar.vue */ "./resources/js/components/ui/SimpleSidebar.vue");
/* harmony import */ var _ui_Button_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ui/Button.vue */ "./resources/js/components/ui/Button.vue");
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_Company_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/stores/Company.js */ "./resources/js/stores/Company.js");
/* harmony import */ var _stores_Structure_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/stores/Structure.js */ "./resources/js/stores/Structure.js");
/* harmony import */ var _stores_api_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/stores/api.js */ "./resources/js/stores/api.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//










/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'StructurePage',
  components: {
    StructureItem: _StructureItem__WEBPACK_IMPORTED_MODULE_0__["default"],
    StructureEditCard: _StructureEditCard__WEBPACK_IMPORTED_MODULE_1__["default"],
    StructureUsersMore: _StructureUsersMore__WEBPACK_IMPORTED_MODULE_2__["default"],
    SimpleSidebar: _ui_SimpleSidebar_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    JobtronButton: _ui_Button_vue__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  data: function data() {
    return {
      isDragging: false,
      startX: 0,
      startY: 0,
      scrollLeft: 0,
      scrollTop: 0,
      zoom: 100,
      editStructure: false,
      leftMarginMainCard: 0,
      isSettings: false,
      settings: {
        autoManager: false
      }
    };
  },
  computed: _objectSpread(_objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_8__.mapState)(_stores_Company_js__WEBPACK_IMPORTED_MODULE_5__.useCompanyStore, ['dictionaries', 'centralOwner'])), (0,pinia__WEBPACK_IMPORTED_MODULE_8__.mapState)(_stores_Structure_js__WEBPACK_IMPORTED_MODULE_6__.useStructureStore, ['cards', 'editedCard', 'isEditMode', 'isDemo', 'demo', 'moreUsers'])), {}, {
    actualDictionaries: function actualDictionaries() {
      return {
        users: this.dictionaries.users.filter(function (user) {
          return !user.deleted_at && user.last_seen;
        }),
        /* eslint-disable-next-line camelcase */
        profile_groups: this.dictionaries.profile_groups.filter(function (group) {
          return group.active;
        }),
        positions: this.dictionaries.positions.filter(function (pos) {
          return !pos.deleted_at;
        })
      };
    },
    owner: function owner() {
      var _this = this;
      if (!this.centralOwner) return null;
      return this.dictionaries.users.find(function (user) {
        return user.email === _this.centralOwner.email;
      });
    },
    cardsOrFirst: function cardsOrFirst() {
      if (this.cards && this.cards.length) {
        return this.cards;
      }
      /* eslint-disable camelcase */
      var ownerCard = _objectSpread(_objectSpread({}, this.getEmptyCard()), {}, {
        id: null,
        parent_id: null,
        name: 'Генеральный директор',
        is_vacant: false
      });
      /* eslint-enable camelcase */

      if (this.owner) {
        /* eslint-disable camelcase */
        ownerCard.manager = {
          user_id: this.owner.id,
          position_id: this.owner.position_id
        };
        /* eslint-enable camelcase */
        ownerCard.users = [{
          id: this.owner.id
        }];
      }
      return [ownerCard];
    },
    rootCard: function rootCard() {
      if (this.isDemo) return this.demo.structure.find(function (card) {
        return !card.parentId;
      });
      return this.cardsOrFirst.find(function (card) {
        return !card.parentId;
      });
    }
  }),
  watch: {
    editedCard: function editedCard(val) {
      if (val) {
        this.stopDrag();
      }
    }
  },
  mounted: function mounted() {
    var _this2 = this;
    return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
      return _regeneratorRuntime().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return _this2.checkDemo();
            case 2:
              _context.next = 4;
              return _this2.fetchSettings();
            case 4:
              _context.next = 6;
              return _this2.fetchDictionaries();
            case 6:
              _context.next = 8;
              return _this2.fetchCentralOwner();
            case 8:
              _context.next = 10;
              return _this2.structureGet();
            case 10:
              _this2.drawLines();
              _this2.autoZoom();
              if (_this2.settings.autoManager) _this2.updateManagers();
              window.addEventListener('wheel', _this2.scrollArea, {
                passive: false
              });
              window.addEventListener('storage', _this2.checkTabEvents, false);
            case 15:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }))();
  },
  beforeUnmount: function beforeUnmount() {
    window.removeEventListener('wheel', this.scrollArea);
    window.removeEventListener('storage', this.checkTabEvents, false);
  },
  methods: _objectSpread(_objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_8__.mapActions)(_stores_Company_js__WEBPACK_IMPORTED_MODULE_5__.useCompanyStore, ['fetchDictionaries', 'fetchCentralOwner'])), (0,pinia__WEBPACK_IMPORTED_MODULE_8__.mapActions)(_stores_Structure_js__WEBPACK_IMPORTED_MODULE_6__.useStructureStore, ['structureGet', 'toggleEdit', 'getEmptyCard', 'closeEditCard', 'setDemo', 'updateCard'])), {}, {
    // ScrollZoom
    autoZoom: function autoZoom() {
      var _this3 = this;
      this.$nextTick(function () {
        if (!_this3.$refs.container) return;
        if (!_this3.$refs.rootCard) return;
        var widthAwailable = _this3.$refs.container.clientWidth - 40;
        var heightAwailable = _this3.$refs.container.clientHeight - 40;
        var zoom = _this3.zoom / 100;
        var cardsWidth = _this3.$refs.rootCard.$el.clientWidth * zoom;
        var cardsHeight = _this3.$refs.rootCard.$el.clientHeight * zoom;
        if ((cardsWidth > widthAwailable || cardsHeight > heightAwailable) && _this3.zoom > 10) {
          _this3.zoom -= 2;
          requestAnimationFrame(_this3.autoZoom);
        }
      });
    },
    scrollToBlock: function scrollToBlock(id) {
      var _this4 = this;
      this.$nextTick(function () {
        var addedDepartment = document.querySelector("#id-".concat(id));
        addedDepartment.scrollIntoView({
          behavior: 'smooth',
          block: 'center'
        });
        _this4.drawLines();
      });
    },
    scrollArea: function scrollArea(event) {
      if (event.ctrlKey) {
        event.preventDefault();
        this.zoom = Math.min(Math.max(this.zoom + (event.deltaY > 0 ? -10 : 10), 10), 200);
      }
    },
    // ScrollZoom
    // Lines
    recursiveUpdate: function recursiveUpdate(component) {
      var _this5 = this;
      if (component.drawLines) {
        component.drawLines();
      }
      if (component.$children) {
        component.$children.forEach(function (childComponent) {
          _this5.recursiveUpdate(childComponent);
        });
      }
    },
    drawLines: function drawLines() {
      if (!this.$refs.departmentsArea) return;
      var children = _toConsumableArray(this.$refs.departmentsArea.children);
      if (!children.length) {
        this.leftMarginMainCard = 0;
        return;
      }
      var sumWidth = 0;
      children.forEach(function (c) {
        return sumWidth += c.offsetWidth;
      });
      this.leftMarginMainCard = "".concat(Math.round(sumWidth / 2 - 164), "px");
    },
    updateLines: function updateLines() {
      var _this6 = this;
      this.$nextTick(function () {
        _this6.drawLines();
      });
      this.$forceUpdate();
    },
    // Lines
    // DND
    startDrag: function startDrag(event) {
      if (this.editedCard) return;
      this.isDragging = true;
      this.startX = event.clientX;
      this.startY = event.clientY;
      this.scrollLeft = this.$refs.container.scrollLeft;
      this.scrollTop = this.$refs.container.scrollTop;
    },
    stopDrag: function stopDrag() {
      this.isDragging = false;
    },
    onDrag: function onDrag(event) {
      if (!this.isDragging) return;
      var deltaX = event.clientX - this.startX;
      var deltaY = event.clientY - this.startY;
      this.$refs.container.scrollLeft = this.scrollLeft - deltaX;
      this.$refs.container.scrollTop = this.scrollTop - deltaY;
    },
    // DND
    // Settings
    fetchSettings: function fetchSettings() {
      var _this7 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var _yield$_fetchSettings, settings;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return (0,_stores_api_js__WEBPACK_IMPORTED_MODULE_7__.fetchSettings)('structure_auto_manager');
              case 2:
                _yield$_fetchSettings = _context2.sent;
                settings = _yield$_fetchSettings.settings;
                _this7.settings.autoManager = parseInt(settings.custom_structure_auto_manager);
              case 5:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    updateSettings: function updateSettings() {
      var _this8 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return (0,_stores_api_js__WEBPACK_IMPORTED_MODULE_7__.updateSettings)({
                  type: 'structure_auto_manager',
                  custom_structure_auto_manager: _this8.settings.autoManager
                });
              case 2:
                _this8.$toast.success('Настройки сохранены');
              case 3:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    toggleSettings: function toggleSettings() {
      this.isSettings = !this.isSettings;
    },
    onSaveSettings: function onSaveSettings() {
      this.isSettings = false;
      this.updateSettings();
    },
    // Settings
    // Demo
    checkDemo: function checkDemo() {
      var _this9 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        var _yield$_fetchSettings2, settings;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return (0,_stores_api_js__WEBPACK_IMPORTED_MODULE_7__.fetchSettings)('structure_demo_removed');
              case 2:
                _yield$_fetchSettings2 = _context4.sent;
                settings = _yield$_fetchSettings2.settings;
                if (!parseInt(settings.custom_structure_demo_removed)) {
                  _this9.setDemo(true);
                }
              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    removeDemo: function removeDemo() {
      var _this10 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return (0,_stores_api_js__WEBPACK_IMPORTED_MODULE_7__.updateSettings)({
                  type: 'structure_demo_removed',
                  custom_structure_demo_removed: 1
                });
              case 2:
                /* eslint-enable camelcase */
                _this10.$toast.success('Демо данные удалены');
                _this10.setDemo(false);
              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    },
    // Demo
    checkTabEvents: function checkTabEvents(event) {
      var _this11 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        var message, loader;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                if (!(event.key !== 'event.updatePositions')) {
                  _context6.next = 2;
                  break;
                }
                return _context6.abrupt("return");
              case 2:
                message = JSON.parse(event.newValue);
                if (message) {
                  _context6.next = 5;
                  break;
                }
                return _context6.abrupt("return");
              case 5:
                if (!message.command) {
                  _context6.next = 10;
                  break;
                }
                loader = _this11.$loading.show();
                _context6.next = 9;
                return _this11.fetchDictionaries(true);
              case 9:
                loader.hide();
              case 10:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6);
      }))();
    },
    updateManagers: function updateManagers() {
      var _this12 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee7() {
        var _iterator, _step, _loop, _ret;
        return _regeneratorRuntime().wrap(function _callee7$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                if (_this12.dictionaries.users) {
                  _context8.next = 2;
                  break;
                }
                return _context8.abrupt("return");
              case 2:
                _iterator = _createForOfIteratorHelper(_this12.cards);
                _context8.prev = 3;
                _loop = /*#__PURE__*/_regeneratorRuntime().mark(function _loop() {
                  var _manager, _card$manager, _card$manager3;
                  var card, manager, _card$manager2;
                  return _regeneratorRuntime().wrap(function _loop$(_context7) {
                    while (1) {
                      switch (_context7.prev = _context7.next) {
                        case 0:
                          card = _step.value;
                          if (card.group_id) {
                            _context7.next = 3;
                            break;
                          }
                          return _context7.abrupt("return", "continue");
                        case 3:
                          manager = _this12.dictionaries.users.find(function (user) {
                            if (!user.profile_group) return false;
                            var group = user.profile_group.find(function (group) {
                              return group.id === card.group_id;
                            });
                            if (group) return group.is_head;
                            return false;
                          });
                          if (!((_manager = !manager) !== null && _manager !== void 0 ? _manager : (_card$manager = card.manager) === null || _card$manager === void 0 ? void 0 : _card$manager.user_id)) {
                            _context7.next = 7;
                            break;
                          }
                          _context7.next = 7;
                          return _this12.updateCard(_objectSpread(_objectSpread({}, card), {}, {
                            manager: {
                              user_id: null,
                              position_id: (_card$manager2 = card.manager) === null || _card$manager2 === void 0 ? void 0 : _card$manager2.position_id
                            },
                            is_vacant: true
                          }));
                        case 7:
                          if (!(manager && manager.id !== ((_card$manager3 = card.manager) === null || _card$manager3 === void 0 ? void 0 : _card$manager3.user_id))) {
                            _context7.next = 10;
                            break;
                          }
                          _context7.next = 10;
                          return _this12.updateCard(_objectSpread(_objectSpread({}, card), {}, {
                            manager: {
                              user_id: manager.id,
                              position_id: manager.position_id
                            },
                            is_vacant: false
                          }));
                        case 10:
                        case "end":
                          return _context7.stop();
                      }
                    }
                  }, _loop);
                });
                _iterator.s();
              case 6:
                if ((_step = _iterator.n()).done) {
                  _context8.next = 13;
                  break;
                }
                return _context8.delegateYield(_loop(), "t0", 8);
              case 8:
                _ret = _context8.t0;
                if (!(_ret === "continue")) {
                  _context8.next = 11;
                  break;
                }
                return _context8.abrupt("continue", 11);
              case 11:
                _context8.next = 6;
                break;
              case 13:
                _context8.next = 18;
                break;
              case 15:
                _context8.prev = 15;
                _context8.t1 = _context8["catch"](3);
                _iterator.e(_context8.t1);
              case 18:
                _context8.prev = 18;
                _iterator.f();
                return _context8.finish(18);
              case 21:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee7, null, [[3, 15, 18, 21]]);
      }))();
    }
  })
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _StructureInfo_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StructureInfo.vue */ "./resources/js/pages/Structure/StructureInfo.vue");
/* harmony import */ var _stores_Structure_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/stores/Structure.js */ "./resources/js/stores/Structure.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'StructureUsersMore',
  components: {
    StructureInfo: _StructureInfo_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    users: {
      type: Array,
      "default": function _default() {}
    }
  },
  computed: _objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_2__.mapState)(_stores_Structure_js__WEBPACK_IMPORTED_MODULE_1__.useStructureStore, ['moreUsers'])),
  mounted: function mounted() {},
  methods: _objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_2__.mapActions)(_stores_Structure_js__WEBPACK_IMPORTED_MODULE_1__.useStructureStore, ['showMoreUsers']))
});

/***/ }),

/***/ "./resources/js/pages/Structure/mockApi.js":
/*!*************************************************!*\
  !*** ./resources/js/pages/Structure/mockApi.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "departments": () => (/* binding */ departments),
/* harmony export */   "dictionaries": () => (/* binding */ dictionaries),
/* harmony export */   "positions": () => (/* binding */ positions),
/* harmony export */   "profile_groups": () => (/* binding */ profile_groups),
/* harmony export */   "structure": () => (/* binding */ structure),
/* harmony export */   "structure_old": () => (/* binding */ structure_old),
/* harmony export */   "users": () => (/* binding */ users)
/* harmony export */ });
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
/* eslint-disable camelcase */

var users = [{
  id: 1,
  position_id: 42,
  name: 'Иван',
  last_name: 'Иванов',
  birthday: '05.06.1990',
  phone: '+7(777)1234567',
  email: 'director@example.com',
  avatar: 'https://randomuser.me/api/portraits/men/1.jpg',
  last_seen: '2023-07-26'
}, {
  id: 2,
  position_id: 43,
  name: 'Анастасия',
  last_name: 'Гришковецкая',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/women/1.jpg',
  last_seen: '2023-07-26'
}, {
  id: 3,
  position_id: 44,
  name: 'Лилиан',
  last_name: 'Левина',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/women/2.jpg',
  last_seen: '2023-07-26'
}, {
  id: 4,
  position_id: 45,
  name: 'Дашики',
  last_name: 'Ямшина',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/women/3.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 1
  }]
}, {
  id: 5,
  position_id: 46,
  name: 'Кирилл',
  last_name: 'Толмацкий',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/men/2.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 2
  }]
}, {
  id: 6,
  position_id: 22,
  name: 'Нииколай',
  last_name: 'Королев',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/men/50.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 3
  }]
}, {
  id: 7,
  position_id: 22,
  name: 'Светлана',
  last_name: 'Шу',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/women/4.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 4
  }]
}, {
  id: 8,
  position_id: 46,
  name: 'Виктор',
  last_name: 'Лампин',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/men/3.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 5
  }]
}, {
  id: 9,
  position_id: 3,
  name: 'Роман',
  last_name: 'Павлов',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/men/51.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 6
  }]
}, {
  id: 10,
  position_id: 47,
  name: 'Иван',
  last_name: 'Деловой',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/men/8.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 7
  }]
}, {
  id: 11,
  position_id: 43,
  name: 'Анастасия',
  last_name: 'Гришковецкая',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/women/11.jpg',
  last_seen: '2023-07-26',
  profile_groups: []
}, {
  id: 12,
  position_id: 45,
  name: 'Майя',
  last_name: 'Топтунова',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/women/12.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 8
  }]
}, {
  id: 13,
  position_id: 46,
  name: 'Ася',
  last_name: 'Казанцева',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/women/13.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 9
  }]
}, {
  id: 14,
  position_id: 41,
  name: 'Ирина',
  last_name: 'Пашкова',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/women/50.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 10
  }]
}, {
  id: 15,
  position_id: 46,
  name: 'Настя',
  last_name: 'Филлипова',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/women/14.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 11
  }]
}, {
  id: 16,
  position_id: 45,
  name: 'Ефремов',
  last_name: 'Максим',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/men/6.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 17,
  position_id: 46,
  name: 'Орест',
  last_name: 'Френзенский',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/men/8.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 13
  }]
}, {
  id: 18,
  position_id: 46,
  name: 'Орест',
  last_name: 'Френзенский',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/men/9.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 13
  }]
}, {
  id: 19,
  position_id: 45,
  name: 'Галина',
  last_name: 'Симакина',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/women/15.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 13
  }]
}, {
  id: 20,
  position_id: 45,
  name: 'Хасан',
  last_name: 'Фаримов',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/men/13.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 13
  }]
}, {
  id: 21,
  position_id: 45,
  name: 'Василий',
  last_name: 'Медведев',
  birthday: '10.10.1985',
  phone: '+7(700)5654323',
  email: 'test.test@gmail.com',
  avatar: 'https://randomuser.me/api/portraits/men/5.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 13
  }]
}, {
  id: 101,
  position_id: 30,
  position_name: 'Консультант',
  name: 'Елена',
  last_name: 'Сидорова',
  fullName: 'Елена Сидорова',
  birthday: '05.06.1990',
  phone: '+7(777)1234567',
  email: 'elena.sidorova@example.com',
  avatar: 'https://randomuser.me/api/portraits/women/27.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 102,
  position_id: 31,
  position_name: 'HR менеджер',
  name: 'Иван',
  last_name: 'Петров',
  fullName: 'Иван Петров',
  birthday: '20.02.1988',
  phone: '+7(999)9876543',
  email: 'ivan.petrov@example.com',
  avatar: 'https://randomuser.me/api/portraits/men/2.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 103,
  position_id: 32,
  position_name: 'IT специалист',
  name: 'Мария',
  last_name: 'Иванова',
  fullName: 'Мария Иванова',
  birthday: '15.09.1992',
  phone: '+7(777)5554321',
  email: 'maria.ivanova@example.com',
  avatar: 'https://randomuser.me/api/portraits/women/3.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 104,
  position_id: 33,
  position_name: 'Менеджер по продажам',
  name: 'Александр',
  last_name: 'Смирнов',
  fullName: 'Александр Смирнов',
  birthday: '01.01.1975',
  phone: '+7(495)5551212',
  email: 'alexandr.smirnov@example.com',
  avatar: 'https://randomuser.me/api/portraits/men/4.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 105,
  position_id: 34,
  position_name: 'Таргетолог',
  name: 'Ольга',
  last_name: 'Васильева',
  fullName: 'Ольга Васильева',
  birthday: '12.12.1987',
  phone: '+7(916)1234567',
  email: 'olga.vasilieva@example.com',
  avatar: 'https://randomuser.me/api/portraits/women/5.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 106,
  position_id: 35,
  position_name: 'Младший помощник',
  name: 'Павел',
  last_name: 'Сергеев',
  fullName: 'Павел Сергеев',
  birthday: '18.03.1991',
  phone: '+7(905)1234567',
  email: 'pavel.sergeev@example.com',
  avatar: 'https://randomuser.me/api/portraits/men/24.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 107,
  position_id: 36,
  position_name: 'Старший рекрутер',
  name: 'Татьяна',
  last_name: 'Николаева',
  fullName: 'Татьяна Николаева',
  birthday: '25.05.1995',
  phone: '+7(903)1234567',
  email: 'tatiana.nikolaeva@example.com',
  avatar: 'https://randomuser.me/api/portraits/women/7.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 108,
  position_id: 5,
  position_name: 'Маркетолог',
  name: 'Ирина',
  last_name: 'Лагинуш',
  fullName: 'Ирина Лагинуш',
  birthday: '12.11.1990',
  phone: '+7(903)1235567',
  email: 'irina90dar@example.com',
  avatar: 'https://randomuser.me/api/portraits/women/8.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 109,
  position_id: 19,
  position_name: 'Программист',
  name: 'Максим',
  last_name: 'Иванов',
  fullName: 'Максим Иванов',
  birthday: '05.06.1985',
  phone: '+7(903)1236677',
  email: 'max85@example.com',
  avatar: 'https://randomuser.me/api/portraits/men/5.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 110,
  position_id: 37,
  position_name: 'Дизайнер',
  name: 'Екатерина',
  last_name: 'Сидорова',
  fullName: 'Екатерина Сидорова',
  birthday: '25.01.1993',
  phone: '+7(903)1112255',
  email: 'kate93@example.com',
  avatar: 'https://randomuser.me/api/portraits/women/7.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 111,
  position_id: 38,
  position_name: 'HR-менеджер',
  name: 'Дмитрий',
  last_name: 'Смирнов',
  fullName: 'Дмитрий Смирнов',
  birthday: '15.09.1987',
  phone: '+7(903)6789900',
  email: 'dmitry87@example.com',
  avatar: 'https://randomuser.me/api/portraits/men/7.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 112,
  position_id: 39,
  position_name: 'Бухгалтер',
  name: 'Ольга',
  last_name: 'Петрова',
  fullName: 'Ольга Петрова',
  birthday: '30.04.1980',
  phone: '+7(903)5557788',
  email: 'olga80@example.com',
  avatar: 'https://randomuser.me/api/portraits/women/3.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 113,
  position_id: 33,
  position_name: 'Менеджер по продажам',
  name: 'Андрей',
  last_name: 'Кузнецов',
  fullName: 'Андрей Кузнецов',
  birthday: '08.07.1992',
  phone: '+7(903)2221122',
  email: 'andrew92@example.com',
  avatar: 'https://randomuser.me/api/portraits/men/9.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 113,
  position_id: 40,
  position_name: 'Аналитик',
  name: 'Анастасия',
  last_name: 'Павлова',
  fullName: 'Анастасия Павлова',
  birthday: '23.12.1988',
  phone: '+7(903)4443322',
  email: 'anastasia88@example.com',
  avatar: 'https://randomuser.me/api/portraits/women/2.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}, {
  id: 114,
  position_id: 41,
  position_name: 'Менеджер по маркетингу',
  name: 'Сергей',
  last_name: 'Ковалев',
  fullName: 'Сергей Ковалев',
  birthday: '01.03.1991',
  phone: '+7(903)9994433',
  email: 'sergey91@example.com',
  avatar: 'https://randomuser.me/api/portraits/men/8.jpg',
  last_seen: '2023-07-26',
  profile_groups: [{
    id: 12
  }]
}];
var positions = [{
  id: 1,
  name: 'Финансовый аналитик'
}, {
  id: 2,
  name: 'Дизайнер интерфейсов'
}, {
  id: 3,
  name: 'Разработчик программного обеспечения'
}, {
  id: 4,
  name: 'HR-специалист'
}, {
  id: 5,
  name: 'Маркетолог'
}, {
  id: 6,
  name: 'Инженер-конструктор'
}, {
  id: 7,
  name: 'Адвокат'
}, {
  id: 8,
  name: 'Преподаватель'
}, {
  id: 9,
  name: 'Архитектор'
}, {
  id: 10,
  name: 'Менеджер по закупкам'
}, {
  id: 11,
  name: 'Менеджер по персоналу'
}, {
  id: 12,
  name: 'Технический писатель'
}, {
  id: 13,
  name: 'Копирайтер'
}, {
  id: 14,
  name: 'Аналитик данных'
}, {
  id: 15,
  name: 'Контент-менеджер'
}, {
  id: 16,
  name: 'Системный администратор'
}, {
  id: 17,
  name: 'Тестировщик'
}, {
  id: 18,
  name: 'Директор'
}, {
  id: 19,
  name: 'Программист'
}, {
  id: 20,
  name: 'Редактор'
}, {
  id: 21,
  name: 'Переводчик'
}, {
  id: 22,
  name: 'Технический писатель'
}, {
  id: 23,
  name: 'Строитель'
}, {
  id: 24,
  name: 'Интернет-магазин'
}, {
  id: 25,
  name: 'Директор по маркетингу'
}, {
  id: 26,
  name: 'Директор по продажам'
}, {
  id: 27,
  name: 'Технический писатель'
}, {
  id: 28,
  name: 'Директор по развитию'
}, {
  id: 29,
  name: 'Директор по управлению персоналом'
}, {
  id: 30,
  name: 'Консультант'
}, {
  id: 31,
  name: 'HR менеджер'
}, {
  id: 32,
  name: 'IT специалист'
}, {
  id: 33,
  name: 'Менеджер по продажам'
}, {
  id: 34,
  name: 'Таргетолог'
}, {
  id: 35,
  name: 'Младший помощник'
}, {
  id: 36,
  name: 'Старший рекрутер'
}, {
  id: 37,
  name: 'Дизайнер'
}, {
  id: 38,
  name: 'HR-менеджер'
}, {
  id: 39,
  name: 'Бухгалтер'
}, {
  id: 40,
  name: 'Аналитик'
}, {
  id: 41,
  name: 'Менеджер по маркетингу'
}, {
  id: 42,
  name: 'Генеральный директор'
}, {
  id: 43,
  name: 'Коммерческий директор'
}, {
  id: 44,
  name: 'Директор по персоналу'
}, {
  id: 45,
  name: 'Начальник'
}, {
  id: 46,
  name: 'Руководитель'
}, {
  id: 47,
  name: "\u0414\u0438\u0437\u0430\u0439\u043D\u0435\u0440 \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u043E\u0432, UI\\UX"
}];
var departments = ['Отдел продаж', 'Отдел маркетинга', 'Отдел разработки', 'Отдел тестирования', 'Финансовый отдел', 'Отдел кадров', 'Отдел закупок', 'Отдел логистики', 'Отдел качества', 'Отдел безопасности', 'Отдел обслуживания клиентов', 'Отдел PR', 'Отдел исследований и разработок', 'Отдел производства', 'Отдел снабжения', 'Отдел IT', 'Отдел аналитики', 'Отдел дизайна', 'Отдел технической поддержки', 'Отдел контроля качества', 'Отдел управления проектами', 'Отдел планирования', 'Отдел стратегического развития', 'Отдел экономического анализа', 'Отдел законодательного сопровождения', 'Отдел корпоративной безопасности', 'Отдел архитектуры', 'Отдел криптографии', 'Отдел научных исследований', 'Отдел международных отношений'];
var profile_groups = [{
  id: 1,
  name: 'Отдел найма и обучения',
  active: 1
}, {
  id: 2,
  name: 'Сектор подбора персонала',
  active: 1
}, {
  id: 3,
  name: 'Call-центр',
  active: 1
}, {
  id: 4,
  name: 'Отдел заботы',
  active: 1
}, {
  id: 5,
  name: 'Сектор приёмной',
  active: 1
}, {
  id: 6,
  name: 'IT-отдел',
  active: 1
}, {
  id: 7,
  name: 'IT-сектор',
  active: 1
}, {
  id: 8,
  name: 'Отдел маркетинга',
  active: 1
}, {
  id: 9,
  name: 'Сектор PR',
  active: 1
}, {
  id: 10,
  name: 'Сектор интернет-продвижения',
  active: 1
}, {
  id: 11,
  name: 'Сектор дизайна',
  active: 1
}, {
  id: 12,
  name: 'Отдел продаж',
  active: 1
}, {
  id: 13,
  name: 'Сектор холодных продаж',
  active: 1
}, {
  id: 14,
  name: 'Группа ХП-01',
  active: 1
}, {
  id: 15,
  name: 'Менеджеры ХП-01',
  active: 1
}, {
  id: 16,
  name: 'Отдел по работе с клиентами',
  active: 1
}, {
  id: 17,
  name: 'Сектор сопровождения клиетов',
  active: 1
}];
var resultText = 'Жулимэ — это суета материального мира, попытка сделать из жулимэ монету. Если у тебя ворс неблагородный, если ты делаешь монету из плохого ворса, то ты не сигмач.';
var dictionaries = {
  users: users,
  profile_groups: profile_groups,
  positions: positions
};
function getUsers(count) {
  var rUsers = users.slice(-14);
  var result = [];
  for (var i = 0; i < count; ++i) {
    var user = rUsers[Math.floor(Math.random() * rUsers.length)];
    result.push(user);
  }
  return result;
}
var structure = [{
  id: 1,
  parent_id: null,
  name: 'Генеральный директор',
  group_id: null,
  status: 0,
  is_group: 0,
  description: resultText,
  color: 'rgb(124, 174, 243)',
  manager: {
    user_id: 1,
    position_id: 42
  },
  users: [{
    id: 1
  }]
}, {
  id: 2,
  parent_id: 1,
  name: 'Коммерческий департамент',
  group_id: null,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#EBF3FB',
  manager: {
    user_id: 2,
    position_id: 43
  },
  users: [{
    id: 2
  }]
}, {
  id: 3,
  parent_id: 2,
  name: 'Департамент персонала',
  group_id: null,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F7FDFF',
  manager: {
    user_id: 3,
    position_id: 44
  },
  users: [{
    id: 3
  }]
}, {
  id: 4,
  parent_id: 3,
  name: null,
  group_id: 1,
  status: 0,
  is_group: 1,
  description: resultText,
  color: '#F7FDFF',
  manager: {
    user_id: 4,
    position_id: 45
  },
  users: [{
    id: 4
  }]
}, {
  id: 5,
  parent_id: 4,
  name: null,
  group_id: 2,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F7FDFF',
  manager: {
    user_id: 5,
    position_id: 46
  },
  users: [{
    id: 5
  }].concat(_toConsumableArray(getUsers(28)))
}, {
  id: 6,
  parent_id: 4,
  name: null,
  group_id: 3,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F7FDFF',
  manager: {
    user_id: 6,
    position_id: 22
  },
  users: [{
    id: 6
  }].concat(_toConsumableArray(getUsers(56)))
}, {
  id: 7,
  parent_id: 3,
  name: null,
  group_id: 4,
  status: 0,
  is_group: 1,
  description: resultText,
  color: '#F7FDFF',
  manager: {
    user_id: 7,
    position_id: 45
  },
  users: [{
    id: 7
  }].concat(_toConsumableArray(getUsers(12)))
}, {
  id: 8,
  parent_id: 7,
  name: null,
  group_id: 5,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F7FDFF',
  manager: {
    user_id: 8,
    position_id: 46
  },
  users: [{
    id: 8
  }].concat(_toConsumableArray(getUsers(13)))
}, {
  id: 9,
  parent_id: 7,
  name: null,
  group_id: 6,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F7FDFF',
  manager: {
    user_id: 9,
    position_id: 3
  },
  users: [{
    id: 9
  }].concat(_toConsumableArray(getUsers(12)))
}, {
  id: 10,
  parent_id: 7,
  name: null,
  group_id: 7,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F7FDFF',
  manager: {
    user_id: 10,
    position_id: 47
  },
  users: [{
    id: 10
  }].concat(_toConsumableArray(getUsers(12)))
}, {
  id: 11,
  parent_id: 2,
  name: 'Коммерческий департамент',
  group_id: null,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 11,
    position_id: 43
  },
  users: [{
    id: 11
  }]
}, {
  id: 12,
  parent_id: 11,
  name: null,
  group_id: 8,
  status: 0,
  is_group: 1,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 12,
    position_id: 45
  },
  users: [{
    id: 12
  }].concat(_toConsumableArray(getUsers(22)))
}, {
  id: 13,
  parent_id: 12,
  name: null,
  group_id: 9,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 13,
    position_id: 46
  },
  users: [{
    id: 13
  }].concat(_toConsumableArray(getUsers(22)))
}, {
  id: 14,
  parent_id: 12,
  name: null,
  group_id: 10,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 14,
    position_id: 41
  },
  users: [{
    id: 14
  }].concat(_toConsumableArray(getUsers(22)))
}, {
  id: 15,
  parent_id: 12,
  name: null,
  group_id: 11,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 15,
    position_id: 46
  },
  users: [{
    id: 15
  }].concat(_toConsumableArray(getUsers(22)))
}, {
  id: 16,
  parent_id: 11,
  name: null,
  group_id: 12,
  status: 1,
  is_group: 1,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 16,
    position_id: 45
  },
  users: [{
    id: 16
  }]
}, {
  id: 17,
  parent_id: 16,
  name: null,
  group_id: 13,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 17,
    position_id: 46
  },
  users: [{
    id: 17
  }].concat(_toConsumableArray(getUsers(22)))
}, {
  id: 18,
  parent_id: 16,
  name: null,
  group_id: 14,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 18,
    position_id: 46
  },
  users: [{
    id: 18
  }].concat(_toConsumableArray(getUsers(22)))
}, {
  id: 19,
  parent_id: 16,
  name: null,
  group_id: 15,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F6FFFE',
  manager: null,
  is_vacant: true,
  users: _toConsumableArray(getUsers(5))
}, {
  id: 20,
  parent_id: 11,
  name: null,
  group_id: 16,
  status: 0,
  is_group: 1,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 19,
    position_id: 45
  },
  users: [{
    id: 19
  }]
}, {
  id: 21,
  parent_id: 20,
  name: null,
  group_id: 16,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 20,
    position_id: 45
  },
  users: [{
    id: 20
  }].concat(_toConsumableArray(getUsers(3)))
}, {
  id: 22,
  parent_id: 20,
  name: null,
  group_id: 17,
  status: 0,
  is_group: 0,
  description: resultText,
  color: '#F6FFFE',
  manager: {
    user_id: 21,
    position_id: 45
  },
  users: [{
    id: 21
  }].concat(_toConsumableArray(getUsers(3)))
}];
var structure_old = [{
  id: 2,
  departmentChildren: [{
    id: 3,
    departmentChildren: [{
      id: 4,
      group: true,
      departmentChildren: [{
        id: 5,
        employeesCount: 28
      }, {
        id: 6,
        employeesCount: 56
      }]
    }, {
      id: 7,
      employeesCount: 12,
      group: true,
      departmentChildren: [{
        id: 8,
        employeesCount: 12
      }, {
        id: 9,
        employeesCount: 12
      }, {
        id: 10,
        employeesCount: 1
      }]
    }]
  }, {
    id: 11,
    departmentChildren: [{
      id: 12,
      employeesCount: 22,
      group: true,
      departmentChildren: [{
        id: 13,
        employeesCount: 22
      }, {
        id: 14,
        department: '',
        employeesCount: 22,
        result: resultText,
        users: users
      }, {
        id: 15,
        employeesCount: 22
      }]
    }, {
      id: 16,
      employeesCount: 444,
      group: true,
      departmentChildren: [{
        id: 17,
        employeesCount: 22
      }, {
        id: 18,
        employeesCount: 22
      }, {
        id: 19,
        employeesCount: 5
      }]
    }, {
      id: 20,
      employeesCount: 56,
      group: true,
      departmentChildren: [{
        id: 21,
        employeesCount: 3,
        result: resultText
      }, {
        id: 22,
        employeesCount: 4,
        result: resultText
      }]
    }]
  }, {
    id: Math.floor(Math.random() * 10000),
    department: 'Финансовый департамент',
    position: 'Финансовый директор',
    employeesCount: 38,
    result: resultText,
    group: true,
    director: {
      fullName: 'Ольга Залуцкая',
      birthday: '10.10.1985',
      phone: '+7(700)5654323',
      email: 'test.test@gmail.com',
      photo: 'https://randomuser.me/api/portraits/women/17.jpg'
    },
    departmentChildren: [{
      id: Math.floor(Math.random() * 10000),
      department: 'Бухгалтерия',
      position: 'Главный бухгалтер',
      employeesCount: 38,
      director: {
        fullName: 'Вера Котельникова',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/women/19.jpg'
      }
    }, {
      id: Math.floor(Math.random() * 10000),
      department: 'Материальный сектор',
      position: 'Руководитель',
      employeesCount: 2,
      result: resultText,
      director: {
        fullName: 'Стася Тринадцатко',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/women/18.jpg'
      }
    }, {
      id: Math.floor(Math.random() * 10000),
      department: 'Сектор заработной платы',
      position: 'Руководитель',
      employeesCount: 22,
      result: resultText,
      director: {
        fullName: 'Надежда Галанова',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/women/21.jpg'
      }
    }, {
      id: Math.floor(Math.random() * 10000),
      department: 'Сектор налогового учёта',
      position: 'Руководитель',
      employeesCount: 5,
      result: resultText,
      director: {
        fullName: 'Катерина Пачковская',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/women/22.jpg'
      }
    }]
  }, {
    id: 23,
    department: 'Производственный департамент',
    position: 'Директор производства',
    employeesCount: 67,
    director: {
      fullName: 'Игорь Джабраилов',
      birthday: '10.10.1985',
      phone: '+7(700)5654323',
      email: 'test.test@gmail.com',
      photo: 'https://randomuser.me/api/portraits/men/16.jpg'
    },
    departmentChildren: [{
      id: 24,
      department: 'Отдел закупок',
      position: 'Начальник',
      employeesCount: 22,
      group: true,
      director: {
        fullName: 'Дашики Ямшина',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/women/23.jpg'
      },
      departmentChildren: [{
        id: 25,
        department: 'Сектор снабжения',
        position: 'Руководитель',
        employeesCount: 28,
        result: resultText,
        director: {
          fullName: 'Кирилл Толмацкий',
          birthday: '10.10.1985',
          phone: '+7(700)5654323',
          email: 'test.test@gmail.com',
          photo: 'https://randomuser.me/api/portraits/men/19.jpg'
        }
      }, {
        id: 26,
        department: 'Сектор обслуживания оборудования',
        position: 'Руководитель',
        employeesCount: 56,
        result: resultText,
        director: {
          fullName: 'Надежда Галанова',
          birthday: '10.10.1985',
          phone: '+7(700)5654323',
          email: 'test.test@gmail.com',
          photo: 'https://randomuser.me/api/portraits/women/24.jpg'
        }
      }]
    }, {
      id: 27,
      department: 'Отдел производства',
      employeesCount: 0
    }]
  }]
}, {
  id: 28,
  department: 'Коммерческий департамент',
  position: 'Административный директор',
  employeesCount: 100,
  bgc: '#F9F6FF',
  director: {
    fullName: 'Идрак Мирзализаде',
    birthday: '10.10.1985',
    phone: '+7(700)5654323',
    email: 'test.test@gmail.com',
    photo: 'https://randomuser.me/api/portraits/men/18.jpg'
  },
  departmentChildren: [{
    id: 29,
    department: 'Отдел безопасности',
    position: 'Начальник отдела',
    employeesCount: 22,
    group: true,
    director: {
      fullName: 'Константин Самойлов',
      birthday: '10.10.1985',
      phone: '+7(700)5654323',
      email: 'test.test@gmail.com',
      photo: 'https://randomuser.me/api/portraits/men/20.jpg'
    },
    departmentChildren: [{
      id: 30,
      department: 'Сектор безопасности',
      position: 'Руководитель',
      employeesCount: 8,
      result: resultText,
      director: {
        fullName: 'Кирилл Толмацкий',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/men/21.jpg'
      }
    }, {
      id: 31,
      department: 'Сектор юристов',
      position: 'Главный юрист',
      employeesCount: 5,
      result: resultText,
      director: {
        fullName: 'Вадим Пастильный',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/men/22.jpg'
      }
    }, {
      id: 32,
      department: 'Сектор охраны труда',
      position: 'Руководитель',
      employeesCount: 2,
      result: resultText,
      director: {
        fullName: 'Вадим Саликов',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/men/23.jpg'
      }
    }]
  }, {
    id: 33,
    department: 'Административный отдел',
    position: 'Директор по персоналу',
    employeesCount: 19,
    result: resultText,
    group: false,
    director: {
      fullName: 'Лилиан Левина',
      birthday: '10.10.1985',
      phone: '+7(700)5654323',
      email: 'test.test@gmail.com',
      photo: 'https://randomuser.me/api/portraits/women/24.jpg'
    },
    departmentChildren: [{
      id: 34,
      department: 'Совет директоров',
      position: 'Председатель совета директоров',
      employeesCount: 9,
      result: resultText,
      director: {
        fullName: 'Никита Косов',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/men/25.jpg'
      },
      departmentChildren: [{
        id: 35,
        department: 'Участники совета',
        employeesCount: 5,
        users: users
      }]
    }, {
      id: 36,
      department: 'Служба стратегического управления',
      position: 'Начальник отдела',
      employeesCount: 17,
      result: resultText,
      director: {
        fullName: 'Григорий Квадратов',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/men/26.jpg'
      }
    }, {
      id: 37,
      department: 'Совет руководителей',
      position: 'Начальник отдела',
      employeesCount: 17,
      result: resultText,
      director: {
        fullName: 'Елена Губова',
        birthday: '10.10.1985',
        phone: '+7(700)5654323',
        email: 'test.test@gmail.com',
        photo: 'https://randomuser.me/api/portraits/women/26.jpg'
      }
    }]
  }]
}];


/***/ }),

/***/ "./resources/js/stores/Structure.js":
/*!******************************************!*\
  !*** ./resources/js/stores/Structure.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useStructureStore": () => (/* binding */ useStructureStore)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_api_structure__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/api/structure */ "./resources/js/stores/api/structure.js");
/* harmony import */ var _pages_Structure_mockApi_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/pages/Structure/mockApi.js */ "./resources/js/pages/Structure/mockApi.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
/* eslint-disable camelcase */




function recursiveToFlat(struct) {
  var result = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  if (!struct) return result;
  result.push({
    id: struct.id,
    name: struct.name,
    parent_id: struct.parent_id,
    description: struct.description,
    color: struct.color,
    created_at: struct.created_at,
    updated_at: struct.updated_at,
    group_id: struct.group_id,
    is_vacant: struct.is_vacant,
    status: struct.status,
    users: struct.users,
    manager: struct.manager,
    is_group: struct.is_group
  });
  if (struct.childrens && struct.childrens.length) {
    struct.childrens.forEach(function (child) {
      return recursiveToFlat(child, result);
    });
  }
  return result;
}
function cardToRequest(card) {
  var _card$users, _card$manager, _card$manager2;
  var request = {
    parent_id: card.parent_id,
    description: card.description,
    color: card.color,
    user_ids: (_card$users = card.users) === null || _card$users === void 0 ? void 0 : _card$users.map(function (user) {
      return user.id;
    }),
    position_id: (_card$manager = card.manager) === null || _card$manager === void 0 ? void 0 : _card$manager.position_id,
    manager_id: (_card$manager2 = card.manager) === null || _card$manager2 === void 0 ? void 0 : _card$manager2.user_id,
    status: card.status,
    is_group: card.is_group,
    is_vacant: card.is_vacant
  };
  if (!request.position_id) request.position_id = null;
  if (card.group_id) request.group_id = card.group_id;
  if (card.name) request.name = card.name;
  return request;
}

// function responseToCard(response){
// 	const card = response.structure_card
// 	card.users = response.structure_card_user.map(id => ({id}))
// 	card.manager = response.structure_card_manager
// 	return card
// }

var useStructureStore = (0,pinia__WEBPACK_IMPORTED_MODULE_2__.defineStore)('structure', {
  state: function state() {
    return {
      isReady: false,
      isLoading: false,
      // state here
      cards: [],
      isEditMode: false,
      newId: -1,
      editedCard: null,
      moreUsers: null,
      demo: {
        dictionaries: _pages_Structure_mockApi_js__WEBPACK_IMPORTED_MODULE_1__.dictionaries,
        structure: _pages_Structure_mockApi_js__WEBPACK_IMPORTED_MODULE_1__.structure,
        id: 1000
      },
      isDemo: false
    };
  },
  actions: {
    structureGet: function structureGet() {
      var _this = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var _yield$_structureGet, structure_card;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _this.isLoading = true;
                _context.prev = 1;
                _context.next = 4;
                return (0,_stores_api_structure__WEBPACK_IMPORTED_MODULE_0__.structureGet)();
              case 4:
                _yield$_structureGet = _context.sent;
                structure_card = _yield$_structureGet.structure_card;
                // update state here
                _this.cards = recursiveToFlat(structure_card);
                _this.isReady = true;
                _context.next = 13;
                break;
              case 10:
                _context.prev = 10;
                _context.t0 = _context["catch"](1);
                console.error('fetchApi', _context.t0);
              case 13:
                _this.isLoading = false;
              case 14:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[1, 10]]);
      }))();
    },
    toggleEdit: function toggleEdit() {
      this.isEditMode = !this.isEditMode;
    },
    addCard: function addCard(parentId) {
      if (this.isDemo) {
        var _card = this.demo.structure.find(function (card) {
          return card.id === parentId;
        });
        var _empty = this.getEmptyCard();
        _empty.parent_id = parentId;
        if (_card) {
          _empty.color = _card.color;
        }
        this.demo.structure.push(_empty);
        return;
      }
      var card = this.cards.find(function (card) {
        return card.id === parentId;
      });
      var empty = this.getEmptyCard();
      empty.parent_id = parentId;
      if (card) {
        empty.color = card.color;
      }
      this.cards.push(empty);
    },
    editCard: function editCard(card) {
      this.editedCard = card;
    },
    showMoreUsers: function showMoreUsers(users) {
      this.moreUsers = users;
    },
    closeEditCard: function closeEditCard() {
      this.editedCard = null;
    },
    createCard: function createCard(card) {
      var _this2 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var index, request, data;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!_this2.isDemo) {
                  _context2.next = 6;
                  break;
                }
                index = _this2.demo.structure.findIndex(function (c) {
                  return c.id === card.id;
                });
                _this2.demo.structure.splice(index, 1);
                card.id = ++_this2.demo.id;
                _this2.demo.structure.push(card);
                return _context2.abrupt("return", card);
              case 6:
                request = cardToRequest(card);
                _context2.next = 9;
                return (0,_stores_api_structure__WEBPACK_IMPORTED_MODULE_0__.structureCreate)(request);
              case 9:
                data = _context2.sent;
                _context2.next = 12;
                return _this2.structureGet();
              case 12:
                _this2.closeEditCard();
                return _context2.abrupt("return", data);
              case 14:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    updateCard: function updateCard(card) {
      var _this3 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var index, request, data, old;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!_this3.isDemo) {
                  _context3.next = 5;
                  break;
                }
                index = _this3.demo.structure.findIndex(function (c) {
                  return c.id === card.id;
                });
                _this3.demo.structure.splice(index, 1, card);
                if (card.color !== _this3.demo.structure[index].color) _this3.updateColor(card.id, card.color);
                return _context3.abrupt("return", card);
              case 5:
                request = cardToRequest(card);
                _context3.next = 8;
                return (0,_stores_api_structure__WEBPACK_IMPORTED_MODULE_0__.structureUpdate)(card.id, request);
              case 8:
                data = _context3.sent;
                old = _this3.cards.findIndex(function (c) {
                  return c.id === card.id;
                });
                if (!(~old && card.color !== _this3.cards[old].color)) {
                  _context3.next = 13;
                  break;
                }
                _context3.next = 13;
                return _this3.updateColor(card.id, card.color);
              case 13:
                if (~old) _this3.cards.splice(old, 1, card);
                _this3.closeEditCard();
                return _context3.abrupt("return", data);
              case 16:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    deleteCard: function deleteCard(cardId) {
      var _this4 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        var _index, index;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                if (!_this4.isDemo) {
                  _context4.next = 4;
                  break;
                }
                _index = _this4.demo.structure.findIndex(function (card) {
                  return card.id === cardId;
                });
                _this4.demo.structure.splice(_index, 1);
                return _context4.abrupt("return", true);
              case 4:
                if (!(cardId === null)) {
                  _context4.next = 6;
                  break;
                }
                return _context4.abrupt("return");
              case 6:
                if (!(cardId > 0)) {
                  _context4.next = 9;
                  break;
                }
                _context4.next = 9;
                return (0,_stores_api_structure__WEBPACK_IMPORTED_MODULE_0__.structureDelete)(cardId);
              case 9:
                index = _this4.cards.findIndex(function (card) {
                  return card.id === cardId;
                });
                _this4.cards.splice(index, 1);
                _this4.closeEditCard();
                return _context4.abrupt("return", true);
              case 13:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    updateColor: function updateColor(cardId, color) {
      var _this5 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        var topCard, _iterator, _step, card;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                topCard = _this5.cards.find(function (card) {
                  return card.id === cardId;
                });
                if (topCard) {
                  _context5.next = 3;
                  break;
                }
                return _context5.abrupt("return");
              case 3:
                _iterator = _createForOfIteratorHelper(_this5.cards);
                _context5.prev = 4;
                _iterator.s();
              case 6:
                if ((_step = _iterator.n()).done) {
                  _context5.next = 13;
                  break;
                }
                card = _step.value;
                if (!(card.parent_id === cardId)) {
                  _context5.next = 11;
                  break;
                }
                _context5.next = 11;
                return _this5.updateCard(_objectSpread(_objectSpread({}, card), {}, {
                  color: color
                }));
              case 11:
                _context5.next = 6;
                break;
              case 13:
                _context5.next = 18;
                break;
              case 15:
                _context5.prev = 15;
                _context5.t0 = _context5["catch"](4);
                _iterator.e(_context5.t0);
              case 18:
                _context5.prev = 18;
                _iterator.f();
                return _context5.finish(18);
              case 21:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, null, [[4, 15, 18, 21]]);
      }))();
    },
    getEmptyCard: function getEmptyCard() {
      return {
        id: JSON.parse(JSON.stringify(--this.newId)),
        name: '',
        parent_id: 0,
        description: '',
        color: '#7CAEF3',
        group_id: 0,
        status: 1,
        users: [],
        manager: null,
        is_group: 0,
        is_vacant: 0,
        isNew: true
      };
    },
    setDemo: function setDemo(toggle) {
      this.isDemo = toggle;
      return this.demo;
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".AccessSelectFormControl {\n  display: flex;\n  flex-flow: row wrap;\n  align-items: center;\n  justify-content: flex-start;\n  gap: 5px;\n  width: 100%;\n  min-height: 35px;\n  padding: 5px 20px;\n  border: 1px solid #e8e8e8;\n  font-size: 14px;\n  line-height: 1.3;\n  border-radius: 6px;\n  background-color: #F7FAFC;\n}\n.AccessSelectFormControl-item {\n  -webkit-user-select: none;\n     -moz-user-select: none;\n          user-select: none;\n  color: #333;\n}\n.AccessSelectFormControl-item0 {\n  background-color: #f89fa4;\n}\n.AccessSelectFormControl-item1 {\n  background-color: #b5d5e5;\n}\n.AccessSelectFormControl-item2 {\n  background-color: #e5e49b;\n}\n.AccessSelectFormControl-item3 {\n  background-color: #80d593;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".ui-simple-sidebar[data-v-369803ba] {\n  background: rgba(0, 0, 0, 0);\n  width: 100%;\n  height: 100%;\n  left: 0;\n  top: 0;\n  position: fixed;\n  visibility: hidden;\n  transition: 0.3s ease-in-out all;\n  z-index: 101;\n}\n.ui-simple-sidebar-content[data-v-369803ba] {\n  position: absolute;\n  right: -100%;\n  top: 0;\n  border-radius: 12px 0 0 12px;\n  min-height: 450px;\n  background: #fff;\n  z-index: 12;\n  box-shadow: -10px 0px 60px -40px rgba(45, 50, 90, 0.1), 0px 0px 3px 0px rgba(0, 0, 0, 0.05);\n  transition: 0.3s ease-in-out all;\n  overflow: auto;\n}\n.ui-simple-sidebar.is-open[data-v-369803ba] {\n  visibility: visible;\n  background: rgba(0, 0, 0, 0.45);\n}\n.ui-simple-sidebar.is-open .ui-simple-sidebar-content[data-v-369803ba] {\n  right: 60px;\n}\n.ui-simple-sidebar .ui-simple-sidebar-header[data-v-369803ba] {\n  padding: 30px 25px 15px 25px;\n}\n.ui-simple-sidebar .ui-simple-sidebar-header .ui-simple-sidebar-title[data-v-369803ba] {\n  color: #0A1323;\n  font-size: 18px;\n  margin: 0;\n  font-weight: 700;\n}\n.ui-simple-sidebar .ui-simple-sidebar-body[data-v-369803ba] {\n  overflow: auto;\n  max-height: calc(100vh - 135px);\n  min-height: calc(100vh - 135px);\n  padding: 15px 25px 25px 25px;\n}\n.ui-simple-sidebar .ui-simple-sidebar-footer[data-v-369803ba] {\n  min-height: 65px;\n  padding: 15px 25px;\n  border-top: 1px solid #ddd;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".StructureItem-contrast {\n  mix-blend-mode: difference;\n  color: #ddd !important;\n}\n.StructureItem-userAvatar:hover + .StructureInfo {\n  right: -290px !important;\n  opacity: 1 !important;\n  visibility: visible !important;\n}\n.StructureItem-userAvatar + .StructureInfo {\n  right: -270px;\n  opacity: 0;\n  visibility: hidden;\n}\n.StructureItem .PulseCard {\n  border-radius: 12px;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  pointer-events: none;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".user-group-item {\n  position: relative;\n}\n.user-group-item:nth-last-child(-n+4) .StructureInfo {\n  top: auto !important;\n  bottom: calc(100% + 20px) !important;\n  right: auto !important;\n  left: 0 !important;\n}\n.user-group-item:nth-last-child(-n+4) .user-group-photo:hover + .StructureInfo {\n  top: auto !important;\n  bottom: 100% !important;\n  visibility: visible !important;\n  opacity: 1 !important;\n}\n.user-group-photo:hover + .StructureInfo {\n  top: 100% !important;\n  visibility: visible !important;\n  opacity: 1 !important;\n}\n.StructureUsersMore .StructureInfo {\n  top: calc(100% + 20px) !important;\n  right: auto !important;\n  left: 0 !important;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AccessSelectFormControl_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AccessSelectFormControl_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AccessSelectFormControl_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureItem_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureItem.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureItem_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureItem_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureUsersMore_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureUsersMore.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureUsersMore_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureUsersMore_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue":
/*!*****************************************************************************!*\
  !*** ./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AccessSelectFormControl_vue_vue_type_template_id_6507306a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AccessSelectFormControl.vue?vue&type=template&id=6507306a& */ "./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=template&id=6507306a&");
/* harmony import */ var _AccessSelectFormControl_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AccessSelectFormControl.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=script&lang=js&");
/* harmony import */ var _AccessSelectFormControl_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AccessSelectFormControl_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AccessSelectFormControl_vue_vue_type_template_id_6507306a___WEBPACK_IMPORTED_MODULE_0__.render,
  _AccessSelectFormControl_vue_vue_type_template_id_6507306a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue":
/*!******************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& */ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&");
/* harmony import */ var _SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SimpleSidebar.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&");
/* harmony import */ var _SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& */ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "369803ba",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/SimpleSidebar.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Structure/StructureEditCard.vue":
/*!************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureEditCard.vue ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StructureEditCard_vue_vue_type_template_id_1b93a8d0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StructureEditCard.vue?vue&type=template&id=1b93a8d0& */ "./resources/js/pages/Structure/StructureEditCard.vue?vue&type=template&id=1b93a8d0&");
/* harmony import */ var _StructureEditCard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StructureEditCard.vue?vue&type=script&lang=js& */ "./resources/js/pages/Structure/StructureEditCard.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _StructureEditCard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StructureEditCard_vue_vue_type_template_id_1b93a8d0___WEBPACK_IMPORTED_MODULE_0__.render,
  _StructureEditCard_vue_vue_type_template_id_1b93a8d0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Structure/StructureEditCard.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Structure/StructureInfo.vue":
/*!********************************************************!*\
  !*** ./resources/js/pages/Structure/StructureInfo.vue ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StructureInfo_vue_vue_type_template_id_01d8c10c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StructureInfo.vue?vue&type=template&id=01d8c10c& */ "./resources/js/pages/Structure/StructureInfo.vue?vue&type=template&id=01d8c10c&");
/* harmony import */ var _StructureInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StructureInfo.vue?vue&type=script&lang=js& */ "./resources/js/pages/Structure/StructureInfo.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _StructureInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StructureInfo_vue_vue_type_template_id_01d8c10c___WEBPACK_IMPORTED_MODULE_0__.render,
  _StructureInfo_vue_vue_type_template_id_01d8c10c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Structure/StructureInfo.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Structure/StructureItem.vue":
/*!********************************************************!*\
  !*** ./resources/js/pages/Structure/StructureItem.vue ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StructureItem_vue_vue_type_template_id_3d6d1cf1___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StructureItem.vue?vue&type=template&id=3d6d1cf1& */ "./resources/js/pages/Structure/StructureItem.vue?vue&type=template&id=3d6d1cf1&");
/* harmony import */ var _StructureItem_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StructureItem.vue?vue&type=script&lang=js& */ "./resources/js/pages/Structure/StructureItem.vue?vue&type=script&lang=js&");
/* harmony import */ var _StructureItem_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./StructureItem.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/Structure/StructureItem.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _StructureItem_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StructureItem_vue_vue_type_template_id_3d6d1cf1___WEBPACK_IMPORTED_MODULE_0__.render,
  _StructureItem_vue_vue_type_template_id_3d6d1cf1___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Structure/StructureItem.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Structure/StructurePage.vue":
/*!********************************************************!*\
  !*** ./resources/js/pages/Structure/StructurePage.vue ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StructurePage_vue_vue_type_template_id_2a77e66d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StructurePage.vue?vue&type=template&id=2a77e66d& */ "./resources/js/pages/Structure/StructurePage.vue?vue&type=template&id=2a77e66d&");
/* harmony import */ var _StructurePage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StructurePage.vue?vue&type=script&lang=js& */ "./resources/js/pages/Structure/StructurePage.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _StructurePage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StructurePage_vue_vue_type_template_id_2a77e66d___WEBPACK_IMPORTED_MODULE_0__.render,
  _StructurePage_vue_vue_type_template_id_2a77e66d___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Structure/StructurePage.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Structure/StructureUsersMore.vue":
/*!*************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureUsersMore.vue ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StructureUsersMore_vue_vue_type_template_id_c150fee2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StructureUsersMore.vue?vue&type=template&id=c150fee2& */ "./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=template&id=c150fee2&");
/* harmony import */ var _StructureUsersMore_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StructureUsersMore.vue?vue&type=script&lang=js& */ "./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=script&lang=js&");
/* harmony import */ var _StructureUsersMore_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./StructureUsersMore.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _StructureUsersMore_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StructureUsersMore_vue_vue_type_template_id_c150fee2___WEBPACK_IMPORTED_MODULE_0__.render,
  _StructureUsersMore_vue_vue_type_template_id_c150fee2___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Structure/StructureUsersMore.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AccessSelectFormControl_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AccessSelectFormControl.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AccessSelectFormControl_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Structure/StructureEditCard.vue?vue&type=script&lang=js&":
/*!*************************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureEditCard.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureEditCard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureEditCard.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureEditCard.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureEditCard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Structure/StructureInfo.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureInfo.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureInfo.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureInfo.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Structure/StructureItem.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureItem.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureItem_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureItem.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureItem_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Structure/StructurePage.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructurePage.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StructurePage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructurePage.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructurePage.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StructurePage_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureUsersMore_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureUsersMore.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureUsersMore_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************!*\
  !*** ./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_AccessSelectFormControl_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&":
/*!****************************************************************************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/Structure/StructureItem.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureItem.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureItem_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureItem.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureUsersMore_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureUsersMore.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=template&id=6507306a&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=template&id=6507306a& ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AccessSelectFormControl_vue_vue_type_template_id_6507306a___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AccessSelectFormControl_vue_vue_type_template_id_6507306a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AccessSelectFormControl_vue_vue_type_template_id_6507306a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AccessSelectFormControl.vue?vue&type=template&id=6507306a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=template&id=6507306a&");


/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/Structure/StructureEditCard.vue?vue&type=template&id=1b93a8d0&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureEditCard.vue?vue&type=template&id=1b93a8d0& ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureEditCard_vue_vue_type_template_id_1b93a8d0___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureEditCard_vue_vue_type_template_id_1b93a8d0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureEditCard_vue_vue_type_template_id_1b93a8d0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureEditCard.vue?vue&type=template&id=1b93a8d0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureEditCard.vue?vue&type=template&id=1b93a8d0&");


/***/ }),

/***/ "./resources/js/pages/Structure/StructureInfo.vue?vue&type=template&id=01d8c10c&":
/*!***************************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureInfo.vue?vue&type=template&id=01d8c10c& ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureInfo_vue_vue_type_template_id_01d8c10c___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureInfo_vue_vue_type_template_id_01d8c10c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureInfo_vue_vue_type_template_id_01d8c10c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureInfo.vue?vue&type=template&id=01d8c10c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureInfo.vue?vue&type=template&id=01d8c10c&");


/***/ }),

/***/ "./resources/js/pages/Structure/StructureItem.vue?vue&type=template&id=3d6d1cf1&":
/*!***************************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureItem.vue?vue&type=template&id=3d6d1cf1& ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureItem_vue_vue_type_template_id_3d6d1cf1___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureItem_vue_vue_type_template_id_3d6d1cf1___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureItem_vue_vue_type_template_id_3d6d1cf1___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureItem.vue?vue&type=template&id=3d6d1cf1& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=template&id=3d6d1cf1&");


/***/ }),

/***/ "./resources/js/pages/Structure/StructurePage.vue?vue&type=template&id=2a77e66d&":
/*!***************************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructurePage.vue?vue&type=template&id=2a77e66d& ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructurePage_vue_vue_type_template_id_2a77e66d___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructurePage_vue_vue_type_template_id_2a77e66d___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructurePage_vue_vue_type_template_id_2a77e66d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructurePage.vue?vue&type=template&id=2a77e66d& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructurePage.vue?vue&type=template&id=2a77e66d&");


/***/ }),

/***/ "./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=template&id=c150fee2&":
/*!********************************************************************************************!*\
  !*** ./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=template&id=c150fee2& ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureUsersMore_vue_vue_type_template_id_c150fee2___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureUsersMore_vue_vue_type_template_id_c150fee2___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StructureUsersMore_vue_vue_type_template_id_c150fee2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StructureUsersMore.vue?vue&type=template&id=c150fee2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=template&id=c150fee2&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=template&id=6507306a&":
/*!***************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/AccessSelect/AccessSelectFormControl.vue?vue&type=template&id=6507306a& ***!
  \***************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "AccessSelectFormControl",
      on: {
        click: function ($event) {
          return _vm.$emit("click", $event)
        },
      },
    },
    [
      _vm._t("default", function () {
        return _vm._l(_vm.items, function (item, index) {
          return _c(
            "b-badge",
            {
              key: index,
              staticClass: "AccessSelectFormControl-item",
              class: ["AccessSelectFormControl-item" + item.type],
            },
            [_vm._v("\n\t\t\t" + _vm._s(item.name) + "\n\t\t")]
          )
        })
      }),
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "ui-simple-sidebar",
      class: [{ "is-open": _vm.open }],
      on: {
        click: function ($event) {
          if ($event.target !== $event.currentTarget) {
            return null
          }
          return _vm.$emit("close")
        },
      },
    },
    [
      _c(
        "div",
        {
          staticClass: "ui-simple-sidebar-content",
          style: "width:" + _vm.width,
        },
        [
          _c("div", { staticClass: "ui-simple-sidebar-header" }, [
            _c("p", { staticClass: "ui-simple-sidebar-title" }, [
              _vm._v("\n\t\t\t\t" + _vm._s(_vm.title) + "\n\t\t\t"),
            ]),
            _vm._v(" "),
            _c("span", { domProps: { innerHTML: _vm._s(_vm.link) } }),
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "ui-simple-sidebar-body" },
            [_vm._t("body")],
            2
          ),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "ui-simple-sidebar-footer" },
            [_vm._t("footer")],
            2
          ),
        ]
      ),
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureEditCard.vue?vue&type=template&id=1b93a8d0&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureEditCard.vue?vue&type=template&id=1b93a8d0& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "StructureEditCard" },
    [
      _c("div", { staticClass: "edit-card" }, [
        _c("div", { staticClass: "edit-card-header" }, [
          _c("p", { staticClass: "edit-card-title" }, [
            _vm._v("\n\t\t\t\tРедактировать блок\n\t\t\t"),
          ]),
          _vm._v(" "),
          _c(
            "span",
            {
              staticClass: "edit-card-close",
              on: {
                click: function ($event) {
                  return _vm.$emit("close", false)
                },
              },
            },
            [_vm._v("x")]
          ),
        ]),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "edit-card-body" },
          [
            _c("multiselect", {
              attrs: {
                options: _vm.groupOptions,
                taggable: "",
                placeholder: "Отдел \\ департамент \\ подразделение",
                "track-by": "id",
                label: "name",
              },
              on: { tag: _vm.tagName, select: _vm.selectName },
              model: {
                value: _vm.departmentName,
                callback: function ($$v) {
                  _vm.departmentName = $$v
                },
                expression: "departmentName",
              },
            }),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "collapse-block" },
              [
                _c(
                  "p",
                  {
                    directives: [
                      {
                        name: "b-toggle",
                        rawName: "v-b-toggle.collapse-director",
                        modifiers: { "collapse-director": true },
                      },
                    ],
                    staticClass: "collapse-item",
                  },
                  [
                    _c("i", { staticClass: "fa fa-plus" }),
                    _vm._v(" Руководитель\n\t\t\t\t"),
                  ]
                ),
                _vm._v(" "),
                _c(
                  "b-collapse",
                  { attrs: { id: "collapse-director" } },
                  [
                    _c("multiselect", {
                      attrs: {
                        options: _vm.posOptions,
                        "track-by": "id",
                        label: "name",
                        placeholder: "Должность",
                      },
                      model: {
                        value: _vm.position,
                        callback: function ($$v) {
                          _vm.position = $$v
                        },
                        expression: "position",
                      },
                    }),
                    _vm._v(" "),
                    _c("multiselect", {
                      staticClass: "multiselect-users mt-3",
                      attrs: {
                        options: _vm.usersAndBlank,
                        label: "name",
                        "track-by": "id",
                        placeholder: "Выберите руководителя",
                      },
                      scopedSlots: _vm._u([
                        {
                          key: "singleLabel",
                          fn: function () {
                            return [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t" +
                                  _vm._s(_vm.director.name) +
                                  " " +
                                  _vm._s(_vm.director.last_name) +
                                  "\n\t\t\t\t\t\t"
                              ),
                            ]
                          },
                          proxy: true,
                        },
                        {
                          key: "option",
                          fn: function (props) {
                            return [
                              _c("img", {
                                staticClass: "user-image",
                                attrs: {
                                  src: props.option.avatar,
                                  alt: "photo",
                                },
                              }),
                              _vm._v(" "),
                              _c("div", { staticClass: "user-full-name" }, [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t\t" +
                                    _vm._s(props.option.name) +
                                    " " +
                                    _vm._s(props.option.last_name) +
                                    "\n\t\t\t\t\t\t\t"
                                ),
                              ]),
                            ]
                          },
                        },
                      ]),
                      model: {
                        value: _vm.director,
                        callback: function ($$v) {
                          _vm.director = $$v
                        },
                        expression: "director",
                      },
                    }),
                    _vm._v(" "),
                    _vm.director && _vm.director.id === 0
                      ? _c("b-form-textarea", {
                          staticClass: "mt-3",
                          attrs: {
                            placeholder:
                              "Опишите условия на которых можно занять эту должность",
                          },
                          model: {
                            value: _vm.vacantDescription,
                            callback: function ($$v) {
                              _vm.vacantDescription = $$v
                            },
                            expression: "vacantDescription",
                          },
                        })
                      : _vm._e(),
                    _vm._v(" "),
                    _c("b-form-textarea", {
                      staticClass: "mt-3",
                      attrs: { placeholder: "Результат" },
                      model: {
                        value: _vm.result,
                        callback: function ($$v) {
                          _vm.result = $$v
                        },
                        expression: "result",
                      },
                    }),
                  ],
                  1
                ),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "b-form-checkbox",
              {
                attrs: { switch: "" },
                model: {
                  value: _vm.autoUsers,
                  callback: function ($$v) {
                    _vm.autoUsers = $$v
                  },
                  expression: "autoUsers",
                },
              },
              [
                _vm._v(
                  "\n\t\t\t\tАвтоматически подтягивать сотрудников\n\t\t\t"
                ),
              ]
            ),
            _vm._v(" "),
            !_vm.autoUsers
              ? _c(
                  "div",
                  { staticClass: "collapse-block" },
                  [
                    _c(
                      "p",
                      {
                        directives: [
                          {
                            name: "b-toggle",
                            rawName: "v-b-toggle.collapse-users",
                            modifiers: { "collapse-users": true },
                          },
                        ],
                        staticClass: "collapse-item",
                      },
                      [
                        _c("i", { staticClass: "fa fa-plus" }),
                        _vm._v(" Сотрудники\n\t\t\t\t"),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-collapse",
                      { attrs: { id: "collapse-users" } },
                      [
                        _c("AccessSelectFormControl", {
                          attrs: { items: _vm.accessList },
                          on: {
                            click: function ($event) {
                              _vm.isAccessSelect = true
                            },
                          },
                        }),
                      ],
                      1
                    ),
                  ],
                  1
                )
              : _vm._e(),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "collapse-block" },
              [
                _c(
                  "p",
                  {
                    directives: [
                      {
                        name: "b-toggle",
                        rawName: "v-b-toggle.collapse-more",
                        modifiers: { "collapse-more": true },
                      },
                    ],
                    staticClass: "collapse-item",
                  },
                  [
                    _c("i", { staticClass: "fa fa-plus" }),
                    _vm._v(" Дополнительные настройки\n\t\t\t\t"),
                  ]
                ),
                _vm._v(" "),
                _c("b-collapse", { attrs: { id: "collapse-more" } }, [
                  _c(
                    "div",
                    { staticClass: "d-flex justify-content-between aic" },
                    [
                      _c("label", { staticClass: "select-color" }, [
                        _c("span", { staticClass: "label" }, [
                          _vm._v("Цвет блока"),
                        ]),
                        _vm._v(" "),
                        _c("span", { staticClass: "circle-picker" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.bgColor,
                                expression: "bgColor",
                              },
                            ],
                            attrs: { type: "color" },
                            domProps: { value: _vm.bgColor },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.bgColor = $event.target.value
                              },
                            },
                          }),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c(
                        "b-form-group",
                        {
                          staticClass: "custom-switch custom-switch-sm",
                          attrs: { id: "input-group-4" },
                        },
                        [
                          _c(
                            "b-form-checkbox",
                            {
                              attrs: { switch: "" },
                              model: {
                                value: _vm.group,
                                callback: function ($$v) {
                                  _vm.group = $$v
                                },
                                expression: "group",
                              },
                            },
                            [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t\tГруппировать отделы\n\t\t\t\t\t\t\t"
                              ),
                            ]
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ]),
              ],
              1
            ),
          ],
          1
        ),
        _vm._v(" "),
        _c("div", { staticClass: "edit-card-footer" }, [
          _c("div", { staticClass: "d-flex align-items-center" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  disabled: _vm.card.parent_id < 0,
                  title:
                    _vm.card.parent_id < 0
                      ? "Сохраните вышестоящую карточку"
                      : "",
                },
                on: { click: _vm.saveDepartment },
              },
              [_vm._v("\n\t\t\t\t\tСохранить\n\t\t\t\t")]
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-light ml-2",
                on: {
                  click: function ($event) {
                    return _vm.$emit("close", false)
                  },
                },
              },
              [_vm._v("\n\t\t\t\t\tОтмена\n\t\t\t\t")]
            ),
          ]),
          _vm._v(" "),
          _vm.card.parent_id
            ? _c(
                "button",
                {
                  staticClass: "btn btn-remove",
                  on: { click: _vm.deleteDepartment },
                },
                [_c("i", { staticClass: "fa fa-trash" })]
              )
            : _vm._e(),
        ]),
      ]),
      _vm._v(" "),
      _vm.isAccessSelect
        ? _c(
            "JobtronOverlay",
            {
              attrs: { z: 10003 },
              on: {
                close: function ($event) {
                  _vm.isAccessSelect = false
                },
              },
            },
            [
              _c("AccessSelect", {
                attrs: {
                  tabs: ["Сотрудники", "Отделы", "Должности"],
                  "submit-button": "",
                  "access-dictionaries": {
                    users: _vm.users,
                    profile_groups: _vm.departmentsList,
                    positions: _vm.positions,
                  },
                  absolute: "",
                },
                model: {
                  value: _vm.accessList,
                  callback: function ($$v) {
                    _vm.accessList = $$v
                  },
                  expression: "accessList",
                },
              }),
            ],
            1
          )
        : _vm._e(),
      _vm._v(" "),
      _c("a", {
        ref: "createPosLink",
        staticClass: "hidden",
        attrs: {
          target: "_blank",
          href: "/timetracking/settings?tab=2#nav-home",
        },
      }),
      _vm._v(" "),
      _vm.editedCard
        ? _c("div", {
            staticClass: "backdrop-structure-area",
            on: { click: _vm.closeEditCard },
          })
        : _vm._e(),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureInfo.vue?vue&type=template&id=01d8c10c&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureInfo.vue?vue&type=template&id=01d8c10c& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "StructureInfo additional-info" },
    [
      _vm._t("default", function () {
        return [
          _c("img", {
            staticClass: "addi-director-photo",
            attrs: {
              src: _vm.info.avatar ? _vm.info.avatar : "/user.png",
              alt: "photo",
            },
          }),
          _vm._v(" "),
          _c("div", { staticClass: "addi-content" }, [
            _vm.info.name || _vm.info.last_name
              ? _c("div", { staticClass: "addi-fullname" }, [
                  _vm._v(
                    "\n\t\t\t\t" +
                      _vm._s(_vm.info.name || "") +
                      " " +
                      _vm._s(_vm.info.last_name || "") +
                      "\n\t\t\t"
                  ),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.info.position
              ? _c("p", { staticClass: "addi-item" }, [
                  _c("span", [_vm._v("Должность: ")]),
                  _vm._v(" " + _vm._s(_vm.info.position) + "\n\t\t\t"),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.info.birthday
              ? _c("p", { staticClass: "addi-item" }, [
                  _c("span", [_vm._v("Дата рождения: ")]),
                  _vm._v(
                    _vm._s(
                      _vm.$moment(_vm.info.birthday).format("DD.MM.YYYY")
                    ) + "\n\t\t\t"
                  ),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.info.phone
              ? _c("p", { staticClass: "addi-item" }, [
                  _c("span", [_vm._v("Телефон: ")]),
                  _vm._v(" " + _vm._s(_vm.info.phone) + "\n\t\t\t"),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.info.email
              ? _c("p", { staticClass: "addi-item addi-email" }, [
                  _c("span", [_vm._v("E-mail: ")]),
                  _vm._v(" " + _vm._s(_vm.info.email) + "\n\t\t\t"),
                ])
              : _vm._e(),
          ]),
        ]
      }),
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=template&id=3d6d1cf1&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureItem.vue?vue&type=template&id=3d6d1cf1& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      ref: "structureItem",
      staticClass: "StructureItem structure-item",
      class: [{ grouped: _vm.card.is_group }, "lvl" + _vm.level],
      style: { "--half-width": _vm.halfWidth },
    },
    [
      _c(
        "div",
        {
          staticClass: "structure-card",
          class: { "no-result": !(_vm.children && _vm.children.length) },
          style: { backgroundColor: _vm.card.color },
          attrs: { id: "id-" + _vm.card.id },
        },
        [
          _c(
            "div",
            {
              staticClass: "structure-card-header",
              class: { "no-body": _vm.employeesCount === 0 && !_vm.manager },
            },
            [
              _c(
                "p",
                {
                  staticClass: "StructureItem-contrast department",
                  class: { "is-new": _vm.card.isNew },
                },
                [_vm._v("\n\t\t\t\t" + _vm._s(_vm.name) + "\n\t\t\t")]
              ),
              _vm._v(" "),
              _vm.employeesCount > 0
                ? _c("p", { staticClass: "StructureItem-contrast count" }, [
                    _vm._v(
                      "\n\t\t\t\t" +
                        _vm._s(_vm.employeesCount) +
                        " сотрудников\n\t\t\t"
                    ),
                  ])
                : _c("p", { staticClass: "StructureItem-contrast count" }, [
                    _vm._v("\n\t\t\t\tНет сотрудников\n\t\t\t"),
                  ]),
              _vm._v(" "),
              _vm.isEditMode
                ? _c("i", {
                    staticClass: "fa fa-cog structure-edit",
                    on: {
                      click: function ($event) {
                        return _vm.editCard(_vm.card)
                      },
                    },
                  })
                : _vm._e(),
            ]
          ),
          _vm._v(" "),
          _vm.manager ||
          _vm.isVacant ||
          (_vm.card.users && _vm.card.users.length)
            ? _c(
                "div",
                { staticClass: "structure-card-body" },
                [
                  _vm.isVacant
                    ? [
                        _c("img", {
                          staticClass: "director-photo",
                          attrs: { src: "/user.png", alt: "photo" },
                        }),
                        _vm._v(" "),
                        _vm.description[1]
                          ? _c("StructureInfo", {
                              scopedSlots: _vm._u(
                                [
                                  {
                                    key: "default",
                                    fn: function () {
                                      return [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t" +
                                            _vm._s(_vm.description[1]) +
                                            "\n\t\t\t\t\t"
                                        ),
                                      ]
                                    },
                                    proxy: true,
                                  },
                                ],
                                null,
                                false,
                                1947458
                              ),
                            })
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.position
                          ? _c(
                              "p",
                              {
                                staticClass: "StructureItem-contrast position",
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t" +
                                    _vm._s(_vm.position.name) +
                                    "\n\t\t\t\t"
                                ),
                              ]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _c(
                          "p",
                          { staticClass: "StructureItem-contrast full-name" },
                          [_vm._v("\n\t\t\t\t\tВакантная позиция\n\t\t\t\t")]
                        ),
                      ]
                    : _vm.manager
                    ? [
                        _c("img", {
                          staticClass: "director-photo",
                          attrs: { src: _vm.manager.avatar, alt: "photo" },
                        }),
                        _vm._v(" "),
                        _c("StructureInfo", {
                          attrs: {
                            info: {
                              avatar: _vm.manager.avatar,
                              name: _vm.manager.name,
                              last_name: _vm.manager.last_name,
                              birthday: _vm.manager.birthday,
                              phone: _vm.card.parent_id
                                ? _vm.manager.phone
                                : "",
                              email: _vm.manager.email,
                            },
                          },
                        }),
                        _vm._v(" "),
                        _vm.position
                          ? _c(
                              "p",
                              {
                                staticClass: "StructureItem-contrast position",
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t" +
                                    _vm._s(_vm.position.name) +
                                    "\n\t\t\t\t"
                                ),
                              ]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _c(
                          "p",
                          { staticClass: "StructureItem-contrast full-name" },
                          [
                            _vm._v(
                              "\n\t\t\t\t\t" +
                                _vm._s(_vm.manager.name) +
                                " " +
                                _vm._s(_vm.manager.last_name) +
                                "\n\t\t\t\t"
                            ),
                          ]
                        ),
                      ]
                    : _vm._e(),
                  _vm._v(" "),
                  (_vm.manager || _vm.isVacant) && _vm.users && _vm.users.length
                    ? _c("hr", { staticClass: "divider-users" })
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.users && _vm.users.length
                    ? [
                        _c(
                          "div",
                          { staticClass: "users-group" },
                          [
                            _vm._l(_vm.users, function (user, usrIdx) {
                              return [
                                usrIdx < 6
                                  ? _c("img", {
                                      key: usrIdx,
                                      staticClass: "StructureItem-userAvatar",
                                      attrs: {
                                        src: user.avatar,
                                        alt: "photo",
                                        title: user.name + " " + user.last_name,
                                      },
                                    })
                                  : _vm._e(),
                                _vm._v(" "),
                                _c("StructureInfo", {
                                  key: "i" + usrIdx,
                                  attrs: {
                                    info: {
                                      avatar: user.avatar,
                                      name: user.name,
                                      last_name: user.last_name,
                                      birthday: user.birthday,
                                      position: user.position_name,
                                      email: user.email,
                                    },
                                  },
                                }),
                              ]
                            }),
                            _vm._v(" "),
                            _vm.users.length > 5
                              ? _c(
                                  "span",
                                  {
                                    staticClass: "user-group-more",
                                    on: {
                                      click: function ($event) {
                                        return _vm.showMoreUsers(_vm.users)
                                      },
                                    },
                                  },
                                  [_vm._v(_vm._s(_vm.users.length - 6))]
                                )
                              : _vm._e(),
                          ],
                          2
                        ),
                      ]
                    : _vm._e(),
                ],
                2
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.isEditMode
            ? _c("i", {
                staticClass: "fa fa-plus-circle structure-add",
                class: { "has-result": _vm.description[0] },
                on: { click: _vm.addNew },
              })
            : _vm._e(),
          _vm._v(" "),
          _vm.isCurrentUserCard
            ? _c("PulseCard", { attrs: { size: 3 } })
            : _vm._e(),
        ],
        1
      ),
      _vm._v(" "),
      _vm.children && _vm.children.length
        ? [
            _c(
              "div",
              {
                ref: "group",
                staticClass: "structure-group",
                style: {
                  "--start-line": _vm.startLine,
                  "--end-line": _vm.endLine,
                },
              },
              _vm._l(_vm.children, function (child, index) {
                return _c("StructureItem", {
                  key: index,
                  attrs: {
                    card: child,
                    level: _vm.level + 1,
                    dictionaries: _vm.dictionaries,
                    "skip-users": _vm.localSkip,
                  },
                  on: { updateLines: _vm.drawLines },
                })
              }),
              1
            ),
          ]
        : _vm._e(),
      _vm._v(" "),
      _vm.description[0]
        ? _c(
            "div",
            {
              staticClass: "structure-card-result",
              style: {
                backgroundColor: _vm.card.color,
                width: _vm.resultWidth > 0 ? _vm.resultWidth + "px" : null,
              },
            },
            [
              _c("p", { staticClass: "StructureItem-contrast result-title" }, [
                _vm._v("\n\t\t\tРезультаты\n\t\t"),
              ]),
              _vm._v(" "),
              _c("p", { staticClass: "StructureItem-contrast result-text" }, [
                _vm._v("\n\t\t\t" + _vm._s(_vm.description[0]) + "\n\t\t"),
              ]),
            ]
          )
        : _vm._e(),
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructurePage.vue?vue&type=template&id=2a77e66d&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructurePage.vue?vue&type=template&id=2a77e66d& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      ref: "container",
      staticClass: "structure-container",
      class: [
        { "is-dragging": _vm.isDragging },
        { "overflow-hidden": _vm.editedCard },
      ],
      on: {
        mousedown: _vm.startDrag,
        mouseup: _vm.stopDrag,
        mousemove: _vm.onDrag,
      },
    },
    [
      _vm.$can("structure_edit")
        ? _c(
            "div",
            {
              staticClass: "structure-company-controls",
              on: {
                mousemove: function ($event) {
                  $event.stopPropagation()
                },
                mousedown: function ($event) {
                  $event.stopPropagation()
                },
              },
            },
            [
              _c("div", { staticClass: "actions" }, [
                _vm.isDemo
                  ? _c(
                      "button",
                      {
                        staticClass: "remove-demo",
                        on: { click: _vm.removeDemo },
                      },
                      [_vm._v("\n\t\t\t\tУдалить демо данные\n\t\t\t")]
                    )
                  : _vm._e(),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "icon-btn",
                    class: { active: _vm.isEditMode },
                    on: { click: _vm.toggleEdit },
                  },
                  [_c("i", { staticClass: "fa fa-pen" })]
                ),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "icon-btn",
                    on: { click: _vm.toggleSettings },
                  },
                  [_c("i", { staticClass: "icon-nd-settings" })]
                ),
              ]),
            ]
          )
        : _vm._e(),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "range-zoom",
          on: {
            mousemove: function ($event) {
              $event.stopPropagation()
            },
            mousedown: function ($event) {
              $event.stopPropagation()
            },
          },
        },
        [
          _c("input", {
            directives: [
              {
                name: "model",
                rawName: "v-model.number",
                value: _vm.zoom,
                expression: "zoom",
                modifiers: { number: true },
              },
            ],
            staticClass: "range-input",
            attrs: {
              id: "range-input",
              min: "10",
              max: "200",
              step: "1",
              type: "range",
            },
            domProps: { value: _vm.zoom },
            on: {
              __r: function ($event) {
                _vm.zoom = _vm._n($event.target.value)
              },
              blur: function ($event) {
                return _vm.$forceUpdate()
              },
            },
          }),
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "structure-company-area",
          style: {
            zoom: _vm.zoom / 100,
            "-moz-transform": "scale(" + _vm.zoom / 100 + ")",
          },
        },
        [
          _c(
            "div",
            { ref: "departmentsArea", staticClass: "departments-area" },
            [
              _vm.rootCard
                ? [
                    _c("StructureItem", {
                      ref: "rootCard",
                      attrs: {
                        card: _vm.rootCard,
                        level: 0,
                        dictionaries: _vm.isDemo
                          ? _vm.demo.dictionaries
                          : _vm.actualDictionaries,
                      },
                      on: {
                        scrollToBlock: _vm.scrollToBlock,
                        updateLines: _vm.drawLines,
                      },
                    }),
                  ]
                : _vm._e(),
            ],
            2
          ),
        ]
      ),
      _vm._v(" "),
      _vm.editedCard
        ? _c("StructureEditCard", {
            attrs: {
              card: _vm.editedCard,
              users: _vm.isDemo
                ? _vm.demo.dictionaries.users
                : _vm.actualDictionaries.users,
              positions: _vm.isDemo
                ? _vm.demo.dictionaries.users
                : _vm.actualDictionaries.positions,
              "departments-list": _vm.isDemo
                ? _vm.demo.dictionaries.users
                : _vm.actualDictionaries.profile_groups,
            },
            on: { close: _vm.closeEditCard },
          })
        : _vm._e(),
      _vm._v(" "),
      _vm.moreUsers
        ? _c("StructureUsersMore", { attrs: { users: _vm.moreUsers } })
        : _vm._e(),
      _vm._v(" "),
      _c("SimpleSidebar", {
        attrs: { title: "Настройки", open: _vm.isSettings, width: "30%" },
        on: {
          close: function ($event) {
            _vm.isSettings = false
          },
        },
        scopedSlots: _vm._u([
          {
            key: "body",
            fn: function () {
              return [
                _c(
                  "b-form-checkbox",
                  {
                    attrs: { switch: "", size: "lg" },
                    model: {
                      value: _vm.settings.autoManager,
                      callback: function ($$v) {
                        _vm.$set(_vm.settings, "autoManager", $$v)
                      },
                      expression: "settings.autoManager",
                    },
                  },
                  [
                    _vm._v(
                      "\n\t\t\t\tОбновлять автоматически информацию о руководителях отделов\n\t\t\t"
                    ),
                  ]
                ),
              ]
            },
            proxy: true,
          },
          {
            key: "footer",
            fn: function () {
              return [
                _c("JobtronButton", { on: { click: _vm.onSaveSettings } }, [
                  _vm._v("\n\t\t\t\tСохранить\n\t\t\t"),
                ]),
              ]
            },
            proxy: true,
          },
        ]),
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=template&id=c150fee2&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Structure/StructureUsersMore.vue?vue&type=template&id=c150fee2& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "StructureUsersMore" }, [
    _c(
      "div",
      { ref: "usersMore", staticClass: "StructureUsersMore user-group-modal" },
      [
        _vm.users.length
          ? [
              _c(
                "div",
                { staticClass: "user-group-list" },
                _vm._l(_vm.users, function (user, idx) {
                  return _c(
                    "div",
                    { key: idx, staticClass: "user-group-item" },
                    [
                      _c("img", {
                        staticClass: "user-group-photo",
                        attrs: { src: user.avatar, alt: "photo" },
                      }),
                      _vm._v(" "),
                      _c("StructureInfo", {
                        attrs: {
                          info: {
                            avatar: user.avatar,
                            name: user.name,
                            last_name: user.last_name,
                            birthday: user.birthday,
                            position: user.position_name,
                            email: user.email,
                          },
                        },
                      }),
                      _vm._v(" "),
                      _c("div", [
                        _c("p", { staticClass: "user-group-full-name" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t\t" +
                              _vm._s(user.name) +
                              " " +
                              _vm._s(user.last_name) +
                              "\n\t\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("p", { staticClass: "user-group-position" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t\t" +
                              _vm._s(user.position_name) +
                              "\n\t\t\t\t\t\t"
                          ),
                        ]),
                      ]),
                    ],
                    1
                  )
                }),
                0
              ),
            ]
          : _vm._e(),
      ],
      2
    ),
    _vm._v(" "),
    _vm.moreUsers
      ? _c("div", {
          staticClass: "backdrop-structure-area",
          on: {
            click: function ($event) {
              return _vm.showMoreUsers(null)
            },
          },
        })
      : _vm._e(),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);