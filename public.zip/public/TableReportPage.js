"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["TableReportPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'GroupExcelImport',
  props: {
    status: {
      type: String,
      "default": ''
    },
    group_id: {
      type: Number,
      "default": 0
    }
  },
  data: function data() {
    return {
      message: null,
      activebtn: null,
      file: undefined,
      items: [],
      date: null,
      filename: '',
      showStepTwo: false,
      errors: []
    };
  },
  created: function created() {},
  methods: {
    saveConnects: function saveConnects() {
      var _this2 = this;
      var loader = this.$loading.show();
      this.axios.post('/timetracking/settings/groups/importexcel/save', {
        date: this.date,
        items: this.items,
        filename: this.filename,
        group: this.group_id
      }).then(function () {
        _this2.$toast.info('Сохранено');
        loader.hide();
      })["catch"](function (e) {
        loader.hide();
        alert(e);
      });
    },
    uploadFile: function uploadFile() {
      var loader = this.$loading.show();
      var formData = new FormData();
      formData.append('file', this.file);
      formData.append('group_id', this.group_id);
      var _this = this;
      this.axios.post('/timetracking/settings/groups/importexcel', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(function (response) {
        if (response.data.errors.length > 0) {
          _this.errors = response.data.errors;
          loader.hide();
          return;
        }
        _this.items = response.data.items;
        _this.items.sort(function (a, b) {
          return a.name > b.name ? 1 : -1;
        });
        _this.errors = [];
        if (response.data.items.length > 0) _this.showStepTwo = true;
        _this.users = response.data.users;
        _this.users.push({
          id: 0,
          name: '',
          last_name: ''
        });
        _this.date = response.data.date;
        _this.filename = response.data.filename;
        loader.hide();
      })["catch"](function (e) {
        loader.hide();
        alert(e);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_Portal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/Portal */ "./resources/js/stores/Portal.js");
/* harmony import */ var _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/ui/Sidebar */ "./resources/js/components/ui/Sidebar.vue");
/* harmony import */ var _components_imports_GroupExcelImport__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/imports/GroupExcelImport */ "./resources/js/components/imports/GroupExcelImport.vue");
/* harmony import */ var _composables_yearOptions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/composables/yearOptions */ "./resources/js/composables/yearOptions.js");
/* harmony import */ var _composables_fire_causes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/composables/fire_causes */ "./resources/js/composables/fire_causes.js");
/* harmony import */ var _stores_api_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/stores/api.js */ "./resources/js/stores/api.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"]; if (null != _i) { var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1; try { if (_x = (_i = _i.call(arr)).next, 0 === i) { if (Object(_i) !== _i) return; _n = !1; } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0) { ; } } catch (err) { _d = !0, _e = err; } finally { try { if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return; } finally { if (_d) throw _e; } } return _arr; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */



 // сайдбар table
 // импорт в табели



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TableReport',
  components: {
    Sidebar: _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_1__["default"],
    GroupExcelImport: _components_imports_GroupExcelImport__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  props: {
    groups: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    fines: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activeuserid: {
      type: String,
      "default": function _default() {
        return '';
      }
    },
    activeuserpos: {
      type: String,
      "default": function _default() {
        return '';
      }
    },
    canEdit: {
      type: Boolean,
      "default": function _default() {
        return false;
      }
    }
  },
  data: function data() {
    var now = new Date();
    return {
      isBp: window.location.hostname.split('.')[0] === 'bp',
      data: {},
      showExcelImport: false,
      openSidebar: false,
      sidebarTitle: '',
      sidebarContent: {},
      commentAbsent: '',
      sidebarHistory: [],
      items: [],
      fields: [],
      head_ids: [],
      editMode: false,
      dayInfoText: '',
      scrollLeft: 0,
      // scroller
      maxScrollWidth: 0,
      // scroller
      defaultScrollValue: 0,
      // scroller
      totalRows: 1,
      currentPage: 1,
      editable_time: false,
      perPage: 1000,
      pageOptions: [5, 10, 15],
      total_resources: 0,
      apllyPersonResponse: '',
      dayPercentage: now.getDate() / 31 * 100,
      group_editors: [],
      users: [],
      hasPermission: false,
      dateInfo: {
        currentMonth: null,
        currentYear: now.getFullYear(),
        monthEnd: 0,
        workDays: 0,
        weekDays: 0,
        daysInMonth: 0,
        date: null,
        month: null
      },
      dataLoaded: false,
      currentGroup: null,
      dateTypes: [{
        label: 'Обычный',
        color: '#fff',
        type: 0
      }, {
        label: 'Выходной',
        color: '#ccc',
        type: 1,
        popover: 'Выходной – без начислений'
      }, {
        label: 'Прогул',
        color: 'red',
        type: 2,
        popover: 'Прогул – будет отмечен красным цветом, без начислений'
      }, {
        label: 'Больничный',
        color: 'aqua',
        type: 3,
        popover: 'Больничный – будет отмечен голубым цветом, без начислений'
      }, {
        label: 'Стажер',
        color: 'orange',
        type: 5,
        popover: 'Если оплачиваемая стажировка – 50% от дневного оклада, не оплачивая – без начислений'
      }, {
        label: 'Переобучение',
        color: 'pink',
        type: 6,
        popover: 'Будет начислено 50% от дневного оклада'
      }],
      numClicks: 0,
      currentEditingCell: {},
      comment: '',
      commentDay: '',
      commentFines: '',
      commentFiring: '',
      commentFiring2: '',
      currentDayType: {},
      modalVisible: false,
      modalVisibleDay: false,
      modalVisibleFines: false,
      modalVisibleFiring: false,
      modalVisibleApply: false,
      modalVisibleAbsence: false,
      modalTitle: '',
      currentMinutes: 0,
      errors: [],
      user_types: 0,
      url_page: '',
      firingItems: {
        file: undefined,
        filename: '',
        type: 1 // Без отработки
      },

      applyItems: {
        schedule: ''
      },
      fire_causes: []
    };
  },
  computed: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_6__.mapState)(_stores_Portal__WEBPACK_IMPORTED_MODULE_0__.usePortalStore, ['portal'])), {}, {
    years: function years() {
      if (!this.portal.created_at) return [new Date().getFullYear()];
      return (0,_composables_yearOptions__WEBPACK_IMPORTED_MODULE_3__.useYearOptions)(new Date(this.portal.created_at).getFullYear());
    }
  }),
  watch: {
    scrollLeft: function scrollLeft(value) {
      var container = document.querySelector('.table-responsive');
      container.scrollLeft = value;
    },
    user_types: function user_types() {
      this.fetchData();
    },
    groups: function groups() {
      this.init();
    }
  },
  created: function created() {
    if (this.groups) {
      this.init();
    }
  },
  methods: {
    init: function init() {
      this.dateInfo.currentMonth = this.dateInfo.currentMonth ? this.dateInfo.currentMonth : this.$moment().format('MMMM');
      var currentMonth = this.$moment(this.dateInfo.currentMonth, 'MMMM');

      //Расчет выходных дней
      this.dateInfo.monthEnd = currentMonth.endOf('month'); //Конец месяца
      this.dateInfo.weekDays = currentMonth.weekdayCalc(this.dateInfo.monthEnd, [6]); //Колличество выходных
      this.dateInfo.daysInMonth = currentMonth.daysInMonth(); //Колличество дней в месяце
      this.dateInfo.workDays = this.dateInfo.daysInMonth - this.dateInfo.weekDays; //Колличество рабочих дней

      //Текущая группа
      this.currentGroup = this.currentGroup ? this.currentGroup : this.groups[0]['id'];
      this.fetchData();
    },
    copy: function copy() {
      var _this = this;
      var Url = this.$refs['mylink' + this.currentGroup];
      Url.value = window.location.origin + '/autocheck/' + this.currentGroup;
      Url.select();
      document.execCommand('copy');
      if (confirm("\u0415\u0441\u043B\u0438 \u043D\u0430\u0436\u043C\u0435\u0442\u0435 \"\u041E\u041A\", \u0442\u043E \u0441\u0442\u0430\u0436\u0435\u0440\u044B \u0434\u043E\u043B\u0436\u043D\u044B \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u0438\u0442\u044C \u043F\u043E \u0441\u0441\u044B\u043B\u043A\u0435 \u0438 \u043E\u0442\u043C\u0435\u0447\u0430\u0442\u044C\u0441\u044F \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0438 30 \u043C\u0438\u043D\u0443\u0442.\n            \n\u041F\u043E\u0441\u043B\u0435 30 \u043C\u0438\u043D\u0443\u0442 \u043A\u0442\u043E \u043D\u0435 \u043E\u0442\u043C\u0435\u0442\u0438\u043B\u0441\u044F, \u043F\u0435\u0440\u0435\u0439\u0434\u0443\u0442 \u0432 \u0441\u0442\u0430\u0442\u0443\u0441 \"\u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442\". \n\u0412\u044B \u0443\u0432\u0435\u0440\u0435\u043D\u044B?") == false) {
        return '';
      }
      this.axios.post('/autochecker/' + this.currentGroup, {}).then(function (response) {
        if (response.data.code == 200) {
          _this.$toast.success('Ссылка скопирована. Через 30 минут (в ' + response.data.time + ') не отмеченные стажеры перейдут в статус "Отсутствует"');
        } else {
          _this.$toast.error('Попробуйте нажать еще раз');
        }
      })["catch"](function (error) {
        alert(error);
      });
    },
    openModalDay: function openModalDay(dayType) {
      this.modalTitle = this.sidebarTitle + ' (' + dayType.label + ')';
      this.currentDayType = dayType;
      this.modalVisibleDay = true;
    },
    openModalApply: function openModalApply(dayType) {
      this.currentDayType = dayType;
      this.modalVisibleApply = true;
    },
    openModalAbsence: function openModalAbsence(dayType) {
      this.currentDayType = dayType;
      this.modalVisibleAbsence = true;
      this.fire_causes = _composables_fire_causes__WEBPACK_IMPORTED_MODULE_4__.absence_causes;
    },
    openFiringModal: function openFiringModal(dayType, type) {
      this.modalTitle = this.sidebarTitle + ' (' + dayType.label + ')';
      this.currentDayType = dayType;
      this.modalVisibleFiring = true;
      this.firingItems.type = type;
      this.fire_causes = type == 0 ? _composables_fire_causes__WEBPACK_IMPORTED_MODULE_4__.fire_trainee_causes : _composables_fire_causes__WEBPACK_IMPORTED_MODULE_4__.fire_employee_causes;
    },
    openModalFine: function openModalFine() {
      this.errors = [];
      this.modalVisibleFines = true;
    },
    openModal: function openModal(event) {
      var hour = event.target.value;
      var clearedValue = hour.replace(',', '.');
      var value = parseFloat(clearedValue) * 60;
      this.currentMinutes = value;
      this.modalVisible = true;
      try {
        this.$toast.info('C ' + this.currentEditingCell.item[this.currentEditingCell.field.key].hour + ' на ' + hour);
      } catch (e) {
        alert(e);
      }
    },
    openDay: function openDay(data) {
      if (this.editMode) return;
      if (data.field.key == 'name') return;
      this.openSidebar = true;
      this.sidebarTitle = "".concat(data.item.name, " - ").concat(data.field.key, " ").concat(this.dateInfo.currentMonth, " ");
      this.sidebarContent = {
        data: data,
        history: "".concat(data.item[data.field.key] ? data.item[data.field.key].tooltip : ''),
        historyTotal: "\u0418\u0442\u043E\u0433\u043E: ".concat(data.value.hour, " \u0447.").replace('undefined', '0.0'),
        day: data.field.key,
        user_id: data.item.user_id,
        fines: (data.item.fines[data.field.key] || []).filter(function (value, index, array) {
          return array.indexOf(value) === index;
        })
      };
      this.sidebarHistory = data.item.history.filter(function (x) {
        return parseInt(x.day) === parseInt(data.field.key);
      });
    },
    setUserFired: function setUserFired() {
      var _this2 = this;
      this.errors = [];
      if (this.firingItems.type == 2 && this.firingItems.file == undefined) {
        this.errors.push('Заявление об увольнении обязательно!');
      }
      var comment = this.commentFiring || this.commentFiring2;
      if (!comment) this.errors.push('Причина увольнения обязательна');
      if (this.errors.length) return;
      var formData = new FormData();
      formData.append('month', this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M'));
      formData.append('day', this.sidebarContent.day);
      formData.append('user_id', this.sidebarContent.user_id);
      formData.append('year', this.dateInfo.currentYear);
      formData.append('type', this.currentDayType.type);
      formData.append('comment', comment);
      formData.append('file', this.firingItems.file);
      formData.append('fire_type', this.firingItems.type);
      this.axios.post('/timetracking/set-day', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(function (response) {
        var v = _this2.items[_this2.sidebarContent.data.index]['_cellVariants'];
        var _ref = "day-".concat(_this2.currentDayType.type);
        var _ref2 = _slicedToArray(_ref, 1);
        _this2.sidebarContent.day = _ref2[0];
        _this2.items[_this2.sidebarContent.data.index]['_cellVariants'] = v;
        _this2.fetchData();
        _this2.openSidebar = false;
        if (response.data.success == 1) {
          _this2.sidebarHistory.push(response.data.history);
          _this2.modalVisibleFiring = false;
          _this2.commentFiring = '';
          _this2.commentFiring2 = '';
          _this2.currentDayType = {};
          _this2.errors = [];
        }
      })["catch"](function (error) {
        alert(error);
      });
    },
    setDayWithoutComment: function setDayWithoutComment(type) {
      var _this3 = this;
      var day = this.sidebarContent.day;
      this.axios.post('/timetracking/set-day', {
        month: this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M'),
        day: day,
        user_id: this.sidebarContent.user_id,
        enable_comment: this.sidebarContent.data.item.enable_comment,
        type: type,
        group_id: this.currentGroup,
        comment: ' ',
        year: this.dateInfo.currentYear
      }).then(function (response) {
        var v = _this3.items[_this3.sidebarContent.data.index]['_cellVariants'];
        var _ref3 = "day-".concat(_this3.currentDayType.type);
        var _ref4 = _slicedToArray(_ref3, 1);
        day = _ref4[0];
        _this3.items[_this3.sidebarContent.data.index]['_cellVariants'] = v;
        _this3.fetchData();
        _this3.openSidebar = false;
        if (response.data.success == 1) {
          _this3.sidebarHistory.push(response.data.history);
          _this3.currentDayType = {};
        }
      })["catch"](function (error) {
        alert(error);
      });
    },
    setDayType: function setDayType() {
      var _this4 = this;
      if (this.commentDay.length > 0) {
        this.axios.post('/timetracking/set-day', {
          month: this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M'),
          day: this.sidebarContent.day,
          user_id: this.sidebarContent.user_id,
          type: this.currentDayType.type,
          comment: this.commentDay,
          year: this.dateInfo.currentYear
        }).then(function (response) {
          var v = _this4.items[_this4.sidebarContent.data.index]['_cellVariants'];
          var _ref5 = "day-".concat(_this4.currentDayType.type);
          var _ref6 = _slicedToArray(_ref5, 1);
          _this4.sidebarContent.day = _ref6[0];
          _this4.items[_this4.sidebarContent.data.index]['_cellVariants'] = v;
          _this4.fetchData();
          _this4.openSidebar = false;
          if (response.data.success == 1) {
            _this4.sidebarHistory.push(response.data.history);
            _this4.modalVisibleDay = false;
            _this4.commentDay = '';
            _this4.currentDayType = {};
          }
        })["catch"](function (error) {
          alert(error);
        });
      } else {
        this.errors = ['Комментарий обязателен'];
      }
    },
    saveFines: function saveFines() {
      var _this5 = this;
      if (this.commentFines.length > 0) {
        this.openSidebar = false;
        var loader = this.$loading.show();
        this.axios.post('/timetracking/user-fine', {
          date: this.dateInfo.shortDate + '-' + this.sidebarContent.day,
          user_id: this.sidebarContent.user_id,
          fines: this.sidebarContent.fines,
          comment: this.commentFines
        }).then(function () {
          _this5.fetchData();
          loader.hide();
          _this5.commentFines = '';
          _this5.modalVisibleFines = false;
        })["catch"](function (error) {
          loader.hide();
          alert(error);
        });
      } else {
        this.errors = ['Комментарий обязателен'];
      }
    },
    dayInfo: function dayInfo(data) {
      var _data$item;
      if (!((_data$item = data.item) !== null && _data$item !== void 0 && _data$item._cellVariants)) return;
      // if (!isNaN(data.field.key))
      this.dayInfoText = "".concat(data.item.name, " - ").concat(data.field.key, " ").concat(this.dateInfo.currentMonth);
    },
    //Установка выбранного года
    setYear: function setYear() {
      this.dateInfo.currentYear = this.dateInfo.currentYear ? this.dateInfo.currentYear : this.$moment().format('YYYY');
    },
    //Установка выбранного месяца
    setMonth: function setMonth() {
      var year = this.dateInfo.currentYear;
      this.dateInfo.currentMonth = this.dateInfo.currentMonth ? this.dateInfo.currentMonth : this.$moment().format('MMMM');
      this.dateInfo.date = "".concat(this.dateInfo.currentMonth, " ").concat(year);
      this.dateInfo.shortDate = this.$moment("".concat(this.dateInfo.currentMonth, " ").concat(year), 'MMMM YYYY').locale('ru').format('YYYY-MM');
      this.dateInfo.month = this.$moment("".concat(this.dateInfo.currentMonth, " ").concat(year), 'MMMM YYYY').locale('ru').format('MM');
      this.dateInfo.year = year;
      var currentMonth = this.$moment(this.dateInfo.currentMonth, 'MMMM');
      //Расчет выходных дней
      this.dateInfo.monthEnd = currentMonth.endOf('month'); //Конец месяца
      this.dateInfo.weekDays = currentMonth.weekdayCalc(currentMonth.startOf('month').toString(), currentMonth.endOf('month').toString(), [6]); //Колличество выходных
      this.dateInfo.daysInMonth = currentMonth.daysInMonth(); //Колличество дней в месяце
      this.dateInfo.workDays = this.dateInfo.daysInMonth - this.dateInfo.weekDays; //Колличество рабочих дней
    },
    //Установка заголовока таблицы
    readOnlyFix: function readOnlyFix(event) {
      if (this.editable_time && this.canEdit) {
        event.target.readOnly = '';
      }
    },
    setFields: function setFields() {
      var fields = [];
      fields = [{
        key: 'name',
        stickyColumn: true,
        label: 'Имя',
        sortable: true,
        "class": 'text-left px-3 t-name'
      }, {
        key: 'total',
        label: '',
        sortable: true,
        "class": 'text-center td-lightgreen'
      }];
      var days = this.dateInfo.daysInMonth;
      for (var i = 1; i <= days; i++) {
        var dayName = this.$moment("".concat(i, " ").concat(this.dateInfo.date), 'D MMMM YYYY').locale('en').format('ddd');
        fields.push({
          key: "".concat(i),
          label: "".concat(i),
          sortable: true,
          "class": "day ".concat(dayName)
        });
      }
      this.fields = fields;
    },
    //Загрузка данных для таблицы
    fetchData: function fetchData() {
      var _this6 = this;
      var url = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
      if (url === null) {
        if (this.url_page === '') {
          url = '/timetracking/reports';
        } else {
          url = this.url_page;
        }
      } else {
        this.url_page = url;
      }
      var loader = this.$loading.show();
      this.axios.post(url, {
        month: this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M'),
        year: this.dateInfo.currentYear,
        group_id: this.currentGroup,
        user_types: this.user_types
      }).then(function (response) {
        if (response.data.error && response.data.error == 'access') {
          _this6.hasPermission = false;
          loader.hide();
          return;
        }
        _this6.hasPermission = true;
        _this6.data = response.data;
        _this6.head_ids = _this6.data.head_ids;
        _this6.total_resources = response.data.total_resources;
        _this6.editable_time = response.data.editable_time == 1 ? true : false;
        _this6.setYear();
        _this6.setMonth();
        _this6.setFields();
        _this6.loadItems();
        _this6.dataLoaded = true;
        setTimeout(function () {
          var container = document.querySelector('.table-responsive');
          _this6.maxScrollWidth = container.scrollWidth - container.offsetWidth;
          if (_this6.dayPercentage > 50) {
            // this.scrollLeft = (this.maxScrollWidth * this.dayPercentage) / 100
            // this.defaultScrollValue = this.scrollLeft
          }
        }, 1000);
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    //Добавление загруженных данных в таблицу
    loadItems: function loadItems() {
      var _this7 = this;
      var items = [];
      var daily_totals = {};
      for (var i = 1; i <= 31; i++) {
        daily_totals[i] = 0;
      }
      this.data.users.forEach(function (item) {
        var dayHours = [];
        var startEnd = [];
        var total = 0;
        item.timetracking.forEach(function (tt) {
          if (typeof dayHours[tt.date] === 'undefined') {
            dayHours[tt.date] = {
              hour: 0,
              tooltip: '',
              updated: tt.updated
            };
          }
          var tt_hours = 0;
          if (tt.updated === 1 || tt.updated === 2 || tt.updated === 3) dayHours[tt.date].updated = 1;
          var enter = _this7.$moment.utc(tt.enter, 'YYYY-MM-DD HH:mm:ss').local().format('HH:mm');
          var exit = _this7.$moment.utc(tt.exit, 'YYYY-MM-DD HH:mm:ss').local().format('HH:mm');
          startEnd[tt.date] += "<tr><td>".concat(enter, "</td><td>").concat(exit, "</td></td>");
          if (dayHours[tt.date].updated === 1 || dayHours[tt.date].updated === 2 || dayHours[tt.date].updated === 3) {
            if (tt.updated !== 0) {
              dayHours[tt.date].hour = Number(tt.minutes / 60);
            }
            tt_hours = Number(tt.minutes / 60);
          } else {
            if (tt.minutes > 0) {
              dayHours[tt.date].hour += Number(tt.minutes / 60);
              tt_hours += Number(tt.minutes / 60);
            }
          }
          if (Number(tt.date) >= Number(item.applied_at)) {
            total += Number(tt_hours);
            daily_totals[tt.date] += Number(tt_hours);
          }
        });

        //Время, история
        dayHours.forEach(function (dh, key) {
          var resultHour = item.user_type == 'office' ? Number(parseFloat(dh.hour)).toFixed(1) : Number(parseFloat(dh.hour)).toFixed(1);
          var checkHour = resultHour > 0 ? resultHour : 0;
          var fine = [];
          if (item.selectedFines[key]) {
            fine = item.selectedFines[key];
          }
          dayHours[key] = {
            hour: Number(checkHour).toFixed(1),
            tooltip: "<table class=\"table table-sm mb-0 \">".concat(startEnd[key].replace('undefined', '').replace('Invalid date', 'Еще не завершен'), "</table>"),
            key: key,
            fine: fine.length > 0,
            updated: dh.updated === 1 || dh.updated === 2
          };
        });
        var v = [];
        Object.keys(item.dayTypes).forEach(function (k) {
          if (item.dayTypes) v[k] = "day-".concat(item.dayTypes[k]);
        });
        Object.keys(item.fines).forEach(function (k) {
          if (item.fines[k].status == 1) {
            v[parseInt(item.fines[k].date)] += ' table-day-2';
          }
        });
        Object.keys(item.weekdays).forEach(function (k) {
          if (Number(item.weekdays[k]) == 1) {
            v[Number(k)] += ' table-day-1';
          }
        });
        var variants = {
          _cellVariants: v
        };
        items.push(_objectSpread(_objectSpread({
          name: "".concat(item.name, " ").concat(item.last_name),
          total: Number(total).toFixed(1),
          enable_comment: item.enable_comment,
          id: item.id,
          fines: item.selectedFines,
          user_id: item.id,
          user_type: item.user_type,
          is_trainee: item.is_trainee,
          requested: item.requested,
          applied_at: item.applied_at,
          history: item.track_history
        }, variants), dayHours));
      });
      this.items = items;
      for (var _i2 = 1; _i2 <= 31; _i2++) {
        daily_totals[_i2] = Number(daily_totals[_i2]).toFixed(1);
      }
      this.items.unshift(daily_totals);
      this.totalRows = this.items.length;
    },
    editDay: function editDay(data) {
      try {
        this.$toast.info('Вы редактируете ' + this.currentEditingCell.field.key + ' число  у ' + this.currentEditingCell.item.name);
      } catch (err) {
        console.error('editDay');
      }
      this.currentEditingCell = data;
    },
    updateHour: function updateHour() {
      var _this8 = this;
      if (this.isEmpty(this.currentEditingCell)) {
        this.$toast.error('Что-то пошло не так. Выберите поле и попробуйте снова');
        return;
      }
      if (this.comment.length > 0) {
        var loader = this.$loading.show();
        this.axios.post('/timetracking/reports/update/day', {
          year: this.dateInfo.currentYear,
          month: this.dateInfo.month,
          day: this.currentEditingCell.field.key,
          user_id: this.currentEditingCell.item.user_id,
          minutes: this.currentMinutes,
          comment: this.comment
        }).then(function (response) {
          if (response.data.error && response.data.error == 'access') {
            _this8.hasPermission = false;
            loader.hide();
            return;
          }
          _this8.currentEditingCell = {};
          _this8.fetchData();
          loader.hide();
          _this8.modalVisible = false;
          _this8.comment = '';
          _this8.errors = [];
        })["catch"](function (error) {
          loader.hide();
          alert(error);
        });
      } else {
        this.errors = ['Комментарий обязателен'];
      }
    },
    isEmpty: function isEmpty(obj) {
      for (var prop in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, prop)) {
          return false;
        }
      }
      return JSON.stringify(obj) === JSON.stringify({});
    },
    applyPerson: function applyPerson() {
      var _this9 = this;
      if (this.applyItems.schedule.length == 0) {
        return '';
      }
      this.axios.post('/timetracking/apply-person', {
        user_id: this.sidebarContent.user_id,
        schedule: this.applyItems.schedule,
        group_id: this.currentGroup
      }).then(function (response) {
        _this9.apllyPersonResponse = response.data.msg;
        _this9.sidebarContent.data.item.requested = _this9.$moment().format('DD.MM.Y HH:mm');
        _this9.modalVisibleApply = false;
        (0,_stores_api_js__WEBPACK_IMPORTED_MODULE_5__.triggerApplyEmployee)(_this9.sidebarContent.user_id);
        setTimeout(function () {
          _this9.apllyPersonResponse = '';
        }, 2000);
      })["catch"](function (error) {
        alert(error);
      });
    },
    setUserAbsent: function setUserAbsent() {
      var _this10 = this;
      if (!this.commentAbsent) return alert('Укажите причину отсутвия');
      var day = this.sidebarContent.day;
      var loader = this.$loading.show();
      this.axios.post('/timetracking/set-day', {
        year: this.dateInfo.currentYear,
        month: this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M'),
        day: day,
        user_id: this.sidebarContent.user_id,
        enable_comment: this.sidebarContent.data.item.enable_comment,
        type: 2,
        group_id: this.currentGroup,
        comment: this.commentAbsent
      }).then(function (response) {
        (0,_stores_api_js__WEBPACK_IMPORTED_MODULE_5__.triggerAbsentInternship)(_this10.sidebarContent.user_id);
        var v = _this10.items[_this10.sidebarContent.data.index]['_cellVariants'];
        var _ref7 = "day-".concat(_this10.currentDayType.type);
        var _ref8 = _slicedToArray(_ref7, 1);
        day = _ref8[0];
        _this10.items[_this10.sidebarContent.data.index]['_cellVariants'] = v;
        _this10.fetchData();
        _this10.openSidebar = false;
        if (response.data.success == 1) {
          _this10.sidebarHistory.push(response.data.history);
          _this10.currentDayType = {};
        }
        _this10.modalVisibleAbsence = false;
        _this10.commentAbsent = '';
        loader.hide();
      })["catch"](function (error) {
        alert(error);
      });
    },
    detectClick: function detectClick(data) {
      var _data$item2;
      if (!((_data$item2 = data.item) !== null && _data$item2 !== void 0 && _data$item2._cellVariants)) return;
      //if([48,53,65,66].includes(this.currentGroup) || this.activeuserid == 5) { // if RECRUITING GROUP ENABLE EDIT HOURS ON DBLCLICK
      if (this.editable_time && this.canEdit) {
        this.numClicks++;
        if (this.numClicks === 1) {
          var self = this;
          setTimeout(function () {
            if (self.numClicks === 1) {
              self.openDay(data);
            } else {
              self.editDay(data);
            }
            self.numClicks = 0;
          }, 300);
        }
      } else {
        // ANOTHER GGROUPS JUST OPEN SIDEBAR
        this.openDay(data);
      }
    },
    sortCompare: function sortCompare(aRow, bRow, key, sortDesc, formatter, compareOptions, compareLocale) {
      var a = aRow[key]; // or use Lodash `_.get()`
      var b = bRow[key];
      if (!aRow.id) {
        return sortDesc ? 1 : -1;
      }
      if (!bRow.id) {
        return sortDesc ? -1 : 1;
      }
      if (typeof a === 'number' && typeof b === 'number' || a instanceof Date && b instanceof Date) {
        // If both compared fields are native numbers or both are native dates
        return a < b ? -1 : a > b ? 1 : 0;
      } else {
        // Otherwise stringify the field data and use String.prototype.localeCompare
        return (b || '').toString().localeCompare((a || '').toString(), compareLocale, compareOptions);
      }
    }
  }
});

/***/ }),

/***/ "./resources/js/composables/fire_causes.js":
/*!*************************************************!*\
  !*** ./resources/js/composables/fire_causes.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "absence_causes": () => (/* binding */ absence_causes),
/* harmony export */   "fire_employee_causes": () => (/* binding */ fire_employee_causes),
/* harmony export */   "fire_trainee_causes": () => (/* binding */ fire_trainee_causes)
/* harmony export */ });
/* eslint-disable camelcase */

var absence_causes = ['Был на основной работе', 'Бросает трубку', 'Забыл (-а), после обеда присутствует', 'Нашел(-а) другую работу', 'Не понравились условия оплаты труда', 'Не сдал экзамен', 'Не смог подключиться', 'Не хочет долго стажироваться', 'Не хочет работать 6 дней', 'Отсутствовал(а) более 3 дней', 'Ребенок заболел, не сможет совмещать'];
var fire_trainee_causes = ['Был на основной работе', 'Бросает трубку',
// 'Вышел (-ла) из группы',
// 'Забыл (-а), после обеда присутствует',
'Нашел(-а) другую работу',
// 'Не был на обучении / стажировке',
// 'Не выходит на связь',
'Не понравились условия оплаты труда', 'Не справился с обязанностями', 'Не сдал экзамен', 'Не смог подключиться', 'Не хочет долго стажироваться', 'Не хочет работать 6 дней',
// 'Отказ от стажировки',
'Отсутствовал(а) более 3 дней',
// 'По техническим причинам',
// 'Пропал с обучения',
'Ребенок заболел, не сможет совмещать'
// 'Удалился (-ась), не актуально',
];

var fire_employee_causes = ['Взял перерыв, позже возможно будет работать', 'Дисциплинарные нарушения', 'Дубликат, 2 учетки', 'Заказчик снял с проекта', 'Игнорирование предупреждений', 'Не справился с обязанностями', 'Конфликт с коллегами', 'Нашел(-а) другую работу', 'Неадекватная личность', 'Некому за ребенком присматривать', 'Не выходит на связь более 7 дней', 'Не успевает по учебе', 'Не устраивает график', 'Не устраивает ЗП', 'Не устраивает пункт в договоре', 'Оказалось что есть вторая работа', 'Переезд в другой город', 'Плохие рабочие показатели/не справился', 'По семейным обстоятельствам', 'По состоянию здоровья', 'По техническим причинам', 'Проект закрыт. Снят с линии', 'Решил(-а) работать оффлайн', 'Слишком большая нагрузка'];

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=style&index=0&lang=scss&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=style&index=0&lang=scss& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@charset \"UTF-8\";\n.con {\n  padding: 15px;\n}\np.heading {\n  font-size: 1.25rem;\n  color: #007bff;\n  font-weight: 700;\n  margin-bottom: 20px;\n}\n.custom-file {\n  height: 80px;\n}\n.custom-file .custom-file-input ~ .custom-file-label::after {\n  content: \"Обзор\";\n}\n.custom-file .custom-file-label {\n  height: 80px;\n}\n.custom-file .custom-file-label::after {\n  height: 100%;\n}\n.b-tooltip {\n  min-width: 300px;\n  text-align: left !important;\n}\n.cb {\n  background: #f1f1f1;\n  padding: 3px 0;\n  width: 37px;\n  height: 37px;\n  border-radius: 3px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.cb input {\n  width: 30px;\n  height: 20px;\n  display: block;\n}\n.p {\n  margin-bottom: 0;\n  line-height: 33px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".table-report-sidebar {\n  position: fixed;\n  top: 0;\n  right: 6rem;\n  z-index: 100;\n  width: 100%;\n  height: 100%;\n}\n.table-report-sidebar .table-report-backdrop {\n  position: absolute;\n  top: 0;\n  left: 0;\n  z-index: 10;\n  width: 100%;\n  height: 100%;\n  background-color: #333;\n  opacity: 0.5;\n}\n.table-report-sidebar .table-report-content {\n  position: absolute;\n  top: 0;\n  right: 0;\n  width: 400px;\n  height: 100vh;\n  border-radius: 20px 0 0 20px;\n  z-index: 15;\n  background-color: #fff;\n}\n.table-report-sidebar .table-report-content .table-report-header {\n  background: #ECF0F9;\n  padding: 3rem;\n  display: flex;\n  align-items: center;\n}\n.table-report-sidebar .table-report-content .table-report-header .table-report-title {\n  font-size: 16px;\n  font-weight: 600;\n  line-height: 1;\n}\n.table-report-sidebar .table-report-content .table-report-header .table-report-close {\n  width: 35px;\n  height: 35px;\n  cursor: pointer;\n  margin-right: 15px;\n}\n.table-report-sidebar .table-report-content .table-report-body .nav-tabs .nav-item .nav-link {\n  color: #8D8D8D;\n  font-size: 1.7rem;\n  font-weight: 600;\n  transition: color 0.3s;\n  padding-top: 1.5rem;\n  cursor: pointer;\n  margin-right: 0;\n  border-bottom: none;\n}\n.table-report-sidebar .table-report-content .table-report-body .nav-tabs .nav-item .nav-link.active {\n  border-top: 4px solid #ED2353;\n  color: #ED2353;\n}\n.table-report-sidebar .table-report-content .table-report-body .tab-content {\n  padding: 0 20px;\n}\n.hovered-text {\n  margin-top: 15px;\n  color: #62788B;\n}\n.table-custom-report th, .table-custom-report td {\n  vertical-align: middle;\n}\n.table-custom-report th .td-div, .table-custom-report td .td-div {\n  height: 40px;\n  min-width: 50px;\n  padding: 0 10px;\n  position: relative;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n}\n.table-custom-report thead th, .table-custom-report thead td {\n  text-align: center;\n  padding: 10px !important;\n  vertical-align: middle;\n}\n.table-custom-report thead th:first-child, .table-custom-report thead td:first-child {\n  padding: 0 15px !important;\n}\n.table-custom-report tbody th, .table-custom-report tbody td {\n  padding: 0 !important;\n}\n.table-custom-report tbody th:first-child, .table-custom-report tbody td:first-child {\n  padding: 0 15px !important;\n}\n.table-custom-report .td-lightgreen {\n  background-color: #B7E100;\n}\n.table-custom-report .table-day-2 {\n  color: #333;\n  background-color: #f58c94;\n}\n.table-custom-report .table-day-2 input {\n  color: #333;\n}\n.table-custom-report .table-day-3 {\n  color: rgb(0, 0, 0);\n  background-color: aqua !important;\n}\n.table-custom-report .table-day-4 {\n  color: rgb(0, 0, 0);\n  background-color: rgb(200, 162, 200) !important;\n}\n.table-custom-report .table-day-5 {\n  color: rgb(0, 0, 0);\n  background-color: #ffd76d !important;\n}\n.table-custom-report .table-day-6 {\n  color: #fff;\n  background-color: pink !important;\n}\n.table-custom-report .table-day-7 {\n  color: #fff;\n  background-color: #ffc107 !important;\n}\n.table-custom-report .cell-border {\n  position: absolute;\n  right: -1px;\n  bottom: -5px;\n  border-top: 6px solid transparent;\n  border-bottom: 6px solid transparent;\n  border-left: 6px solid #b8daff;\n  transform: rotate(45deg);\n}\n.editmode {\n  opacity: 0;\n  height: 36px;\n}\n.editmode:active {\n  opacity: 1;\n}\n.history {\n  height: 100vh;\n  overflow-y: auto;\n}\n.history p {\n  font-size: 14px;\n  color: #424242;\n}\n.fines-modal {\n  overflow-y: auto;\n  max-height: calc(100vh - 225px);\n}\n.fines-modal .custom-checkbox {\n  margin-bottom: 10px;\n}\n.b-table-sticky-header {\n  max-height: calc(100vh - 250px);\n}\n.table-day-1 {\n  color: rgb(0, 0, 0);\n  background: #fef1cb !important;\n}\n.temari .button-day_0 {\n  border: 1px solid #999;\n  color: #333;\n  background-color: #fff;\n}\n.temari .button-day_0:hover {\n  background-color: #d8d8d8;\n}\n.temari .button-day_1 {\n  border: 1px solid #958d73;\n  background-color: #e5dab6;\n  color: #333;\n}\n.temari .button-day_1:hover {\n  background-color: #c7bd9e;\n}\n.temari .button-day_2 .img-info {\n  filter: contrast(100);\n}\n.temari .button-day_3 {\n  border: 1px solid #4489c9;\n  background-color: #4c9ee5;\n  color: #fff;\n}\n.temari .button-day_3:hover {\n  background-color: #4489c9;\n}\n.temari .button-day_3 .img-info {\n  filter: contrast(100);\n}\n.temari .button-day_5 {\n  border: 1px solid #e6983f;\n  background-color: #faa544;\n  color: #fff;\n}\n.temari .button-day_5:hover {\n  background-color: #e6983f;\n}\n.temari .button-day_5 .img-info {\n  filter: contrast(100);\n}\n.temari .button-day_6 {\n  border: 1px solid #98116c;\n  background-color: #bc1585;\n  color: #fff;\n}\n.temari .button-day_6:hover {\n  background-color: #98116c;\n}\n.temari .button-day_6 .img-info {\n  filter: contrast(100);\n}\n.temari .button-day_7 {\n  border: 1px solid #bf2216;\n  background-color: #df271a;\n  color: #fff;\n}\n.temari .button-day_7:hover {\n  background-color: #bf2216;\n}\n.temari .button-day_7 .img-info {\n  filter: contrast(100);\n}\n.my-table .day.Sat.table-day-2, .my-table .day.Sun.table-day-2 {\n  color: #fff;\n  background-color: red;\n}\n.updated .cell-border {\n  border-left-color: red;\n}\n.badgy {\n  font-size: 0.75em;\n}\n.temari {\n  height: calc(100vh - 180px);\n  display: flex;\n  flex-direction: column;\n}\n.ddf div {\n  display: flex;\n}\n.ddf .custom-control {\n  margin-right: 15px;\n}\n.fz12 {\n  line-height: 1.4em;\n  font-size: 12px;\n  margin-bottom: 0;\n}\n.fz14 {\n  font-size: 14px;\n  line-height: 1.4em;\n  padding: 10px 0;\n}\nhr {\n  margin: 2px !important;\n}\n.hider {\n  position: absolute;\n  left: -10px;\n  width: 10px;\n  height: 10px;\n  opacity: 0;\n  display: block;\n}\n.ddpointer {\n  margin-top: 2px;\n  cursor: pointer;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=style&index=0&lang=scss&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=style&index=0&lang=scss& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_GroupExcelImport_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./GroupExcelImport.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_GroupExcelImport_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_GroupExcelImport_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableReport_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableReport.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableReport_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableReport_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/imports/GroupExcelImport.vue":
/*!**************************************************************!*\
  !*** ./resources/js/components/imports/GroupExcelImport.vue ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _GroupExcelImport_vue_vue_type_template_id_4b9897ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GroupExcelImport.vue?vue&type=template&id=4b9897ae& */ "./resources/js/components/imports/GroupExcelImport.vue?vue&type=template&id=4b9897ae&");
/* harmony import */ var _GroupExcelImport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./GroupExcelImport.vue?vue&type=script&lang=js& */ "./resources/js/components/imports/GroupExcelImport.vue?vue&type=script&lang=js&");
/* harmony import */ var _GroupExcelImport_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./GroupExcelImport.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/imports/GroupExcelImport.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _GroupExcelImport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _GroupExcelImport_vue_vue_type_template_id_4b9897ae___WEBPACK_IMPORTED_MODULE_0__.render,
  _GroupExcelImport_vue_vue_type_template_id_4b9897ae___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/imports/GroupExcelImport.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/TableReport.vue":
/*!********************************************!*\
  !*** ./resources/js/pages/TableReport.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TableReport_vue_vue_type_template_id_5f5e52a9___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TableReport.vue?vue&type=template&id=5f5e52a9& */ "./resources/js/pages/TableReport.vue?vue&type=template&id=5f5e52a9&");
/* harmony import */ var _TableReport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TableReport.vue?vue&type=script&lang=js& */ "./resources/js/pages/TableReport.vue?vue&type=script&lang=js&");
/* harmony import */ var _TableReport_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TableReport.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/TableReport.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TableReport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TableReport_vue_vue_type_template_id_5f5e52a9___WEBPACK_IMPORTED_MODULE_0__.render,
  _TableReport_vue_vue_type_template_id_5f5e52a9___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/TableReport.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/imports/GroupExcelImport.vue?vue&type=script&lang=js&":
/*!***************************************************************************************!*\
  !*** ./resources/js/components/imports/GroupExcelImport.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_GroupExcelImport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./GroupExcelImport.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_GroupExcelImport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/TableReport.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/pages/TableReport.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableReport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableReport.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableReport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/imports/GroupExcelImport.vue?vue&type=style&index=0&lang=scss&":
/*!************************************************************************************************!*\
  !*** ./resources/js/components/imports/GroupExcelImport.vue?vue&type=style&index=0&lang=scss& ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_GroupExcelImport_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./GroupExcelImport.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/TableReport.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************!*\
  !*** ./resources/js/pages/TableReport.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableReport_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableReport.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/imports/GroupExcelImport.vue?vue&type=template&id=4b9897ae&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/components/imports/GroupExcelImport.vue?vue&type=template&id=4b9897ae& ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GroupExcelImport_vue_vue_type_template_id_4b9897ae___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GroupExcelImport_vue_vue_type_template_id_4b9897ae___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GroupExcelImport_vue_vue_type_template_id_4b9897ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./GroupExcelImport.vue?vue&type=template&id=4b9897ae& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=template&id=4b9897ae&");


/***/ }),

/***/ "./resources/js/pages/TableReport.vue?vue&type=template&id=5f5e52a9&":
/*!***************************************************************************!*\
  !*** ./resources/js/pages/TableReport.vue?vue&type=template&id=5f5e52a9& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableReport_vue_vue_type_template_id_5f5e52a9___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableReport_vue_vue_type_template_id_5f5e52a9___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableReport_vue_vue_type_template_id_5f5e52a9___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableReport.vue?vue&type=template&id=5f5e52a9& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=template&id=5f5e52a9&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=template&id=4b9897ae&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/imports/GroupExcelImport.vue?vue&type=template&id=4b9897ae& ***!
  \************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "con" }, [
    _c("div", { staticClass: "first-step" }, [
      _c("div", { staticClass: "row" }, [
        _c(
          "div",
          { staticClass: "col-md-12" },
          [
            _c(
              "p",
              { staticClass: "heading" },
              [
                _vm._v("\n\t\t\t\t\tШаг 1: Загрузите Excel файл\n\t\t\t\t\t"),
                _c(
                  "b-button",
                  {
                    staticClass: "ml-2",
                    attrs: { id: "btn", variant: "default", size: "sm" },
                  },
                  [_c("i", { staticClass: "fa fa-info" })]
                ),
              ],
              1
            ),
            _vm._v(" "),
            _c("b-tooltip", { attrs: { target: "btn", placement: "bottom" } }, [
              _c("div", [
                _c("div", [
                  _vm._v(
                    "Excel файл для импорта должен содержать в первом ряду поля:"
                  ),
                ]),
                _vm._v(" "),
                _c("div", [_vm._v("Имя сотрудника")]),
                _vm._v(" "),
                _c("div", [_vm._v("Фамилия сотрудника")]),
                _vm._v(" "),
                _c("div", [_vm._v("Длительность разговора")]),
                _vm._v(" "),
                _c("div", [_vm._v("Дата и время создания")]),
              ]),
            ]),
          ],
          1
        ),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-md-12" }, [
          _c(
            "form",
            {
              attrs: {
                id: "import-contact",
                method: "post",
                enctype: "multipart/form-data",
              },
            },
            [
              _c("div", { staticClass: "message" }),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "files" },
                [
                  _c("span", [_vm._v("Файл")]),
                  _vm._v(" "),
                  _c("b-form-file", {
                    staticClass: "mt-3",
                    attrs: {
                      state: Boolean(_vm.file),
                      placeholder: "Выберите или перетащите файл сюда...",
                      "drop-placeholder": "Перетащите файл сюда...",
                      accept:
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel",
                    },
                    model: {
                      value: _vm.file,
                      callback: function ($$v) {
                        _vm.file = $$v
                      },
                      expression: "file",
                    },
                  }),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-button",
                {
                  staticClass: "mt-2 mb-2",
                  attrs: { variant: "primary" },
                  on: { click: _vm.uploadFile },
                },
                [
                  _c("i", { staticClass: "fa fa-file" }),
                  _vm._v(" Загрузить\n\t\t\t\t\t"),
                ]
              ),
            ],
            1
          ),
        ]),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "col-md-12" },
          _vm._l(_vm.errors, function (error) {
            return _c("p", { key: error, staticStyle: { color: "red" } }, [
              _vm._v("\n\t\t\t\t\t" + _vm._s(error) + "\n\t\t\t\t"),
            ])
          }),
          0
        ),
      ]),
    ]),
    _vm._v(" "),
    !_vm.showStepTwo
      ? _c("div", { staticClass: "mt-4" }, [
          _c("h5", [_vm._v("Примечания")]),
          _vm._v(" "),
          _c("p", [
            _vm._v(
              '1. В табель можно импортировать только тех сотрудников, которые в должности "Оператор"'
            ),
          ]),
          _vm._v(" "),
          _c("p", [
            _vm._v(
              "\n\t\t\t2. Если у оператора в табели уже есть какая-то цифра, то есть уже отмечено какое-то количество часов,\n\t\t\tа в файле импорта нет по нему данных, то в табели за импортируемую дату обнулятся часы: так как у него в файле импорта нет минут разговора\n\t\t"
            ),
          ]),
        ])
      : _vm._e(),
    _vm._v(" "),
    _vm.showStepTwo
      ? _c(
          "div",
          [
            _vm._m(0),
            _vm._v(" "),
            _vm._m(1),
            _vm._v(" "),
            _vm._l(_vm.items, function (item) {
              return _c("div", { key: item.name, staticClass: "row" }, [
                _c("div", { staticClass: "col-md-5" }, [
                  _c("input", {
                    staticClass: "form-control",
                    attrs: { type: "text", disabled: "" },
                    domProps: { value: item.name },
                  }),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-md-5" }, [
                  _c(
                    "select",
                    {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: item.id,
                          expression: "item.id",
                        },
                      ],
                      staticClass: "form-control",
                      on: {
                        change: function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.$set(
                            item,
                            "id",
                            $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          )
                        },
                      },
                    },
                    _vm._l(_vm.users, function (user) {
                      return _c(
                        "option",
                        { key: user.id, domProps: { value: user.id } },
                        [
                          _vm._v(
                            "\n\t\t\t\t\t\t" +
                              _vm._s(user.name) +
                              " " +
                              _vm._s(user.last_name) +
                              " ID " +
                              _vm._s(user.id) +
                              "\n\t\t\t\t\t"
                          ),
                        ]
                      )
                    }),
                    0
                  ),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-md-2" }, [
                  _c("p", { staticClass: "p" }, [
                    _vm._v(
                      "\n\t\t\t\t\t" +
                        _vm._s(Number(item.hours)) +
                        " часов\n\t\t\t\t"
                    ),
                  ]),
                ]),
              ])
            }),
            _vm._v(" "),
            _c("div", { staticClass: "row" }, [
              _c(
                "div",
                { staticClass: "col-md-12 mt-2" },
                [
                  _c(
                    "b-button",
                    {
                      attrs: { variant: "primary" },
                      on: { click: _vm.saveConnects },
                    },
                    [
                      _c("i", { staticClass: "fa fa-save" }),
                      _vm._v(
                        " Сохранить за " + _vm._s(_vm.date) + "\n\t\t\t\t"
                      ),
                    ]
                  ),
                ],
                1
              ),
            ]),
          ],
          2
        )
      : _vm._e(),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-12" }, [
        _c("p", { staticClass: "heading mt-4" }, [
          _vm._v("\n\t\t\t\t\tШаг 2: Соедините поля\n\t\t\t\t"),
        ]),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-md-5" }, [
        _c("p", [_vm._v("Сотрудник в Excel")]),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "col-md-5" }, [
        _c("p", [_vm._v("Сотрудник в табели")]),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "col-md-2" }, [_c("p", [_vm._v("Время")])]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=template&id=5f5e52a9&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableReport.vue?vue&type=template&id=5f5e52a9& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.groups
    ? _c(
        "div",
        { staticClass: "mt-4" },
        [
          _c("div", { staticClass: "mb-0" }, [
            _c("div", { staticClass: "row mb-4" }, [
              _c("div", { staticClass: "col-3" }, [
                _c(
                  "select",
                  {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.currentGroup,
                        expression: "currentGroup",
                      },
                    ],
                    staticClass: "form-control",
                    on: {
                      change: [
                        function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.currentGroup = $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        },
                        function ($event) {
                          return _vm.fetchData()
                        },
                      ],
                    },
                  },
                  _vm._l(_vm.groups, function (group) {
                    return _c(
                      "option",
                      { key: group.id, domProps: { value: group.id } },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(group.name) + "\n\t\t\t\t\t"
                        ),
                      ]
                    )
                  }),
                  0
                ),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-3" }, [
                _c(
                  "select",
                  {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.dateInfo.currentMonth,
                        expression: "dateInfo.currentMonth",
                      },
                    ],
                    staticClass: "form-control",
                    on: {
                      change: [
                        function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.$set(
                            _vm.dateInfo,
                            "currentMonth",
                            $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          )
                        },
                        function ($event) {
                          return _vm.fetchData()
                        },
                      ],
                    },
                  },
                  _vm._l(_vm.$moment.months(), function (month) {
                    return _c(
                      "option",
                      { key: month, domProps: { value: month } },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(month) + "\n\t\t\t\t\t"
                        ),
                      ]
                    )
                  }),
                  0
                ),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-2" }, [
                _c(
                  "select",
                  {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.dateInfo.currentYear,
                        expression: "dateInfo.currentYear",
                      },
                    ],
                    staticClass: "form-control",
                    on: {
                      change: [
                        function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.$set(
                            _vm.dateInfo,
                            "currentYear",
                            $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          )
                        },
                        function ($event) {
                          return _vm.fetchData()
                        },
                      ],
                    },
                  },
                  _vm._l(_vm.years, function (year) {
                    return _c(
                      "option",
                      { key: year, domProps: { value: year } },
                      [_vm._v("\n\t\t\t\t\t\t" + _vm._s(year) + "\n\t\t\t\t\t")]
                    )
                  }),
                  0
                ),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-1" }, [
                _c(
                  "div",
                  {
                    staticClass: "btn btn-primary",
                    on: {
                      click: function ($event) {
                        return _vm.fetchData()
                      },
                    },
                  },
                  [_c("i", { staticClass: "fa fa-redo-alt" })]
                ),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-2" }),
            ]),
            _vm._v(" "),
            _vm.hasPermission
              ? _c("div", [
                  _c("div", { staticClass: "row my-4" }, [
                    _c(
                      "div",
                      { staticClass: "col-6 d-flex align-items-center" },
                      [
                        _c(
                          "b-form-group",
                          { staticClass: "d-flex ddf mb-0" },
                          [
                            _c(
                              "b-form-radio",
                              {
                                attrs: { name: "some-radios", value: "0" },
                                model: {
                                  value: _vm.user_types,
                                  callback: function ($$v) {
                                    _vm.user_types = $$v
                                  },
                                  expression: "user_types",
                                },
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\tДействующие\n\t\t\t\t\t\t"
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-form-radio",
                              {
                                attrs: { name: "some-radios", value: "2" },
                                model: {
                                  value: _vm.user_types,
                                  callback: function ($$v) {
                                    _vm.user_types = $$v
                                  },
                                  expression: "user_types",
                                },
                              },
                              [_vm._v("\n\t\t\t\t\t\t\tСтажеры\n\t\t\t\t\t\t")]
                            ),
                            _vm._v(" "),
                            _c(
                              "b-form-radio",
                              {
                                attrs: { name: "some-radios", value: "1" },
                                model: {
                                  value: _vm.user_types,
                                  callback: function ($$v) {
                                    _vm.user_types = $$v
                                  },
                                  expression: "user_types",
                                },
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\tУволенные\n\t\t\t\t\t\t"
                                ),
                              ]
                            ),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _vm.currentGroup != 23 &&
                        _vm.user_types == 2 &&
                        _vm.isBp
                          ? _c(
                              "button",
                              {
                                staticClass: "btn rounded btn-primary ml-2",
                                style: { padding: "2px 8px" },
                                on: {
                                  click: function ($event) {
                                    return _vm.copy()
                                  },
                                },
                              },
                              [
                                _c("i", {
                                  staticClass: "fa fa-clone ddpointer",
                                }),
                                _vm._v(
                                  "\n\t\t\t\t\t\tНачать отметку\n\t\t\t\t\t"
                                ),
                              ]
                            )
                          : _vm._e(),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      {
                        staticClass:
                          "col-6 d-flex align-items-center justify-content-end",
                      },
                      [
                        _c("input", {
                          ref: "mylink" + _vm.currentGroup,
                          staticClass: "hider",
                          attrs: { type: "text" },
                        }),
                        _vm._v(" "),
                        (_vm.currentGroup == 42 && _vm.canEdit) ||
                        (_vm.currentGroup == 88 && _vm.canEdit)
                          ? _c(
                              "button",
                              {
                                staticClass: "btn btn-primary mr-2 rounded",
                                style: { padding: "2px 8px" },
                                on: {
                                  click: function ($event) {
                                    _vm.showExcelImport = !_vm.showExcelImport
                                  },
                                },
                              },
                              [
                                _c("i", { staticClass: "fa fa-upload" }),
                                _vm._v(
                                  "\n\t\t\t\t\t\tИмпорт EXCEL\n\t\t\t\t\t"
                                ),
                              ]
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _c(
                          "p",
                          { staticClass: "text-right fz-09 text-black mb-0" },
                          [
                            _c("span", [_vm._v("Сотрудники:")]),
                            _vm._v(" "),
                            _c("b", [
                              _vm._v(
                                " " +
                                  _vm._s(_vm.items.length - 1) +
                                  " | " +
                                  _vm._s(_vm.total_resources)
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "table-container" },
                    [
                      _c("b-table", {
                        staticClass:
                          "text-nowrap text-right table-custom-report",
                        attrs: {
                          id: "tabelTable",
                          responsive: "",
                          bordered: "",
                          "sticky-header": true,
                          small: true,
                          items: _vm.items,
                          fields: _vm.fields,
                          "show-empty": "",
                          "empty-text": "Нет данных",
                          "current-page": _vm.currentPage,
                          "per-page": _vm.perPage,
                          "sort-compare": _vm.sortCompare,
                        },
                        scopedSlots: _vm._u(
                          [
                            {
                              key: "head(total)",
                              fn: function () {
                                return [
                                  _c("img", {
                                    directives: [
                                      {
                                        name: "b-popover",
                                        rawName: "v-b-popover.hover.right",
                                        value:
                                          "Общее количество часов по строке",
                                        expression:
                                          "'Общее количество часов по строке'",
                                        modifiers: { hover: true, right: true },
                                      },
                                    ],
                                    staticClass: "img-info",
                                    attrs: {
                                      src: "/images/dist/profit-info.svg",
                                    },
                                  }),
                                ]
                              },
                              proxy: true,
                            },
                            {
                              key: "cell(name)",
                              fn: function (name) {
                                return [
                                  _c(
                                    "div",
                                    [
                                      _vm.$can("users_view")
                                        ? _c("span", [
                                            _c(
                                              "a",
                                              {
                                                attrs: {
                                                  href:
                                                    "/timetracking/edit-person?id=" +
                                                    name.item.id,
                                                  target: "_blank",
                                                  title: name.item.id,
                                                },
                                              },
                                              [_vm._v(_vm._s(name.value))]
                                            ),
                                          ])
                                        : _c("span", [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\t" +
                                                _vm._s(name.value) +
                                                "\n\t\t\t\t\t\t\t"
                                            ),
                                          ]),
                                      _vm._v(" "),
                                      name.field.key == "name" && name.value
                                        ? _c(
                                            "b-badge",
                                            {
                                              attrs: {
                                                pill: "",
                                                variant: "success",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "\n\t\t\t\t\t\t\t\t" +
                                                  _vm._s(name.item.user_type) +
                                                  "\n\t\t\t\t\t\t\t"
                                              ),
                                            ]
                                          )
                                        : _vm._e(),
                                      _vm._v(" "),
                                      name.field.key == "name" &&
                                      name.item.is_trainee
                                        ? _c(
                                            "span",
                                            {
                                              staticClass:
                                                "badgy badge-warning badge-pill",
                                            },
                                            [
                                              _vm._v(
                                                "\n\t\t\t\t\t\t\t\tСтажер\n\t\t\t\t\t\t\t"
                                              ),
                                            ]
                                          )
                                        : _vm._e(),
                                    ],
                                    1
                                  ),
                                ]
                              },
                            },
                            {
                              key: "cell(total)",
                              fn: function (total) {
                                return [
                                  _c("div", { staticClass: "td-div" }, [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t" +
                                        _vm._s(total.value) +
                                        "\n\t\t\t\t\t\t"
                                    ),
                                  ]),
                                ]
                              },
                            },
                            {
                              key: "cell()",
                              fn: function (dataItem) {
                                return [
                                  _c(
                                    "div",
                                    {
                                      staticClass: "td-div",
                                      class: {
                                        updated: dataItem.value.updated,
                                        pointer: dataItem.item._cellVariants,
                                      },
                                      on: {
                                        mouseover: function ($event) {
                                          return _vm.dayInfo(dataItem)
                                        },
                                        click: function ($event) {
                                          return _vm.detectClick(dataItem)
                                        },
                                      },
                                    },
                                    [
                                      dataItem.value.hour
                                        ? [
                                            _c("input", {
                                              staticClass: "cell-input",
                                              attrs: {
                                                type: "number",
                                                min: 0,
                                                max: 24,
                                                step: 0.1,
                                                readonly: true,
                                              },
                                              domProps: {
                                                value: dataItem.value.hour,
                                              },
                                              on: {
                                                mouseover: function ($event) {
                                                  return $event.preventDefault()
                                                },
                                                dblclick: _vm.readOnlyFix,
                                                change: _vm.openModal,
                                              },
                                            }),
                                          ]
                                        : [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\t" +
                                                _vm._s(
                                                  dataItem.value.hour
                                                    ? dataItem.value.hour
                                                    : dataItem.value
                                                ) +
                                                "\n\t\t\t\t\t\t\t"
                                            ),
                                          ],
                                      _vm._v(" "),
                                      dataItem.value.tooltip
                                        ? _c("div", {
                                            staticClass: "cell-border",
                                            attrs: {
                                              id:
                                                "cell-border-" +
                                                dataItem.item.id +
                                                "-" +
                                                dataItem.field.key,
                                            },
                                          })
                                        : _vm._e(),
                                      _vm._v(" "),
                                      dataItem.value.tooltip
                                        ? _c(
                                            "b-popover",
                                            {
                                              attrs: {
                                                target:
                                                  "cell-border-" +
                                                  dataItem.item.id +
                                                  "-" +
                                                  dataItem.field.key,
                                                triggers: "hover",
                                                placement: "top",
                                              },
                                              scopedSlots: _vm._u(
                                                [
                                                  {
                                                    key: "title",
                                                    fn: function () {
                                                      return [
                                                        _vm._v(
                                                          "\n\t\t\t\t\t\t\t\t\tВремя работы\n\t\t\t\t\t\t\t\t"
                                                        ),
                                                      ]
                                                    },
                                                    proxy: true,
                                                  },
                                                ],
                                                null,
                                                true
                                              ),
                                            },
                                            [
                                              _vm._v(" "),
                                              _c("div", {
                                                domProps: {
                                                  innerHTML: _vm._s(
                                                    dataItem.value.tooltip
                                                  ),
                                                },
                                              }),
                                            ]
                                          )
                                        : _vm._e(),
                                    ],
                                    2
                                  ),
                                ]
                              },
                            },
                          ],
                          null,
                          false,
                          843413774
                        ),
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "d-flex align-items-start justify-content-between mt-3",
                    },
                    [
                      _c("p", { staticClass: "hovered-text" }, [
                        _vm._v(
                          "\n\t\t\t\t\t" +
                            _vm._s(_vm.dayInfoText) +
                            "\n\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "overflow-auto d-flex" },
                        [
                          _c("b-pagination", {
                            staticClass: "my-0",
                            attrs: {
                              "total-rows": _vm.totalRows,
                              "per-page": _vm.perPage,
                              align: "fill",
                              size: "sm",
                            },
                            model: {
                              value: _vm.currentPage,
                              callback: function ($$v) {
                                _vm.currentPage = $$v
                              },
                              expression: "currentPage",
                            },
                          }),
                        ],
                        1
                      ),
                    ]
                  ),
                ])
              : _c("div", [
                  _c("p", [_vm._v("У вас нет доступа к этой группе")]),
                ]),
          ]),
          _vm._v(" "),
          _vm.showExcelImport
            ? _c(
                "Sidebar",
                {
                  attrs: {
                    title: "Импорт EXCEL",
                    open: _vm.showExcelImport,
                    width: "75%",
                  },
                  on: {
                    close: function ($event) {
                      _vm.showExcelImport = false
                    },
                  },
                },
                [
                  _c("GroupExcelImport", {
                    attrs: { group_id: _vm.currentGroup },
                  }),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.openSidebar
            ? _c("aside", { staticClass: "table-report-sidebar" }, [
                _c("div", { staticClass: "table-report-content" }, [
                  _c("div", { staticClass: "table-report-header" }, [
                    _c("img", {
                      staticClass: "table-report-close",
                      attrs: {
                        "data-v-8e314866": "",
                        src: "/images/dist/popup-close.svg",
                        alt: "Close icon",
                      },
                      on: {
                        click: function ($event) {
                          if ($event.target !== $event.currentTarget) {
                            return null
                          }
                          _vm.openSidebar = false
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c("span", { staticClass: "table-report-title" }, [
                      _vm._v(_vm._s(_vm.sidebarTitle)),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "table-report-body" },
                    [
                      _c(
                        "b-tabs",
                        { attrs: { "content-class": "mt-3", justified: "" } },
                        [
                          _c(
                            "b-tab",
                            { attrs: { title: "🕒 История", active: "" } },
                            [
                              _vm.sidebarHistory &&
                              _vm.sidebarHistory.length > 0
                                ? [
                                    _c(
                                      "div",
                                      { staticClass: "history" },
                                      _vm._l(
                                        _vm.sidebarHistory,
                                        function (item, index) {
                                          return _c(
                                            "div",
                                            { key: index, staticClass: "mb-3" },
                                            [
                                              _c("p", { staticClass: "fz12" }, [
                                                _c(
                                                  "b",
                                                  { staticClass: "text-black" },
                                                  [_vm._v("Дата:")]
                                                ),
                                                _vm._v(
                                                  "\n\t\t\t\t\t\t\t\t\t\t" +
                                                    _vm._s(
                                                      new Date(item.created_at)
                                                        .addHours(-6)
                                                        .toLocaleString("ru-RU")
                                                    ) +
                                                    "\n\t\t\t\t\t\t\t\t\t"
                                                ),
                                              ]),
                                              _vm._v(" "),
                                              _c("p", { staticClass: "fz12" }, [
                                                _c(
                                                  "b",
                                                  { staticClass: "text-black" },
                                                  [_vm._v("Автор:")]
                                                ),
                                                _vm._v(
                                                  " " +
                                                    _vm._s(item.author) +
                                                    " "
                                                ),
                                                _c("br"),
                                              ]),
                                              _vm._v(" "),
                                              _c("p", {
                                                staticClass: "fz14 mb-0",
                                                domProps: {
                                                  innerHTML: _vm._s(
                                                    item.description
                                                  ),
                                                },
                                              }),
                                              _c("br"),
                                              _vm._v(" "),
                                              _c("hr"),
                                            ]
                                          )
                                        }
                                      ),
                                      0
                                    ),
                                  ]
                                : [
                                    _c("p", [
                                      _vm._v("История изменения отсутствует"),
                                    ]),
                                  ],
                            ],
                            2
                          ),
                          _vm._v(" "),
                          _vm.canEdit
                            ? [
                                _c(
                                  "b-tab",
                                  { attrs: { title: "📆 Статус" } },
                                  [
                                    !_vm.sidebarContent.data.item.is_trainee
                                      ? [
                                          _c(
                                            "div",
                                            { staticClass: "temari" },
                                            [
                                              _vm._l(
                                                _vm.dateTypes,
                                                function (dateType) {
                                                  return _c(
                                                    "div",
                                                    {
                                                      key: dateType.label,
                                                      class: [
                                                        dateType.type == 4
                                                          ? "mt-auto"
                                                          : "mb-2",
                                                      ],
                                                    },
                                                    [
                                                      _c(
                                                        "b-button",
                                                        {
                                                          class:
                                                            "button-day_" +
                                                            dateType.type,
                                                          attrs: { block: "" },
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.openModalDay(
                                                                dateType
                                                              )
                                                            },
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                              _vm._s(
                                                                dateType.label
                                                              ) +
                                                              "\n\t\t\t\t\t\t\t\t\t\t\t"
                                                          ),
                                                          dateType.popover
                                                            ? _c("img", {
                                                                directives: [
                                                                  {
                                                                    name: "b-popover",
                                                                    rawName:
                                                                      "v-b-popover.hover.bottom",
                                                                    value:
                                                                      dateType.popover,
                                                                    expression:
                                                                      "dateType.popover",
                                                                    modifiers: {
                                                                      hover: true,
                                                                      bottom: true,
                                                                    },
                                                                  },
                                                                ],
                                                                staticClass:
                                                                  "img-info",
                                                                attrs: {
                                                                  src: "/images/dist/profit-info.svg",
                                                                },
                                                              })
                                                            : _vm._e(),
                                                        ]
                                                      ),
                                                    ],
                                                    1
                                                  )
                                                }
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "div",
                                                { staticClass: "mt-auto" },
                                                [
                                                  _c(
                                                    "b-button",
                                                    {
                                                      class: "button-day_7",
                                                      attrs: { block: "" },
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          return _vm.openFiringModal(
                                                            {
                                                              label:
                                                                "Уволить без отработки",
                                                              color: "#d35dd3",
                                                              type: 4,
                                                            },
                                                            1
                                                          )
                                                        },
                                                      },
                                                    },
                                                    [
                                                      _vm._v(
                                                        "\n\t\t\t\t\t\t\t\t\t\t\tУволить без отработки\n\t\t\t\t\t\t\t\t\t\t\t"
                                                      ),
                                                      _c("img", {
                                                        directives: [
                                                          {
                                                            name: "b-popover",
                                                            rawName:
                                                              "v-b-popover.hover.top",
                                                            value:
                                                              "У сотрудника сразу закроется доступ к профилю",
                                                            expression:
                                                              "'У сотрудника сразу закроется доступ к профилю'",
                                                            modifiers: {
                                                              hover: true,
                                                              top: true,
                                                            },
                                                          },
                                                        ],
                                                        staticClass: "img-info",
                                                        attrs: {
                                                          src: "/images/dist/profit-info.svg",
                                                        },
                                                      }),
                                                    ]
                                                  ),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "div",
                                                { staticClass: "mt-2" },
                                                [
                                                  _c(
                                                    "b-button",
                                                    {
                                                      class: "button-day_7",
                                                      attrs: { block: "" },
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          return _vm.openFiringModal(
                                                            {
                                                              label:
                                                                "Уволить с отработкой",
                                                              color: "#c8a2c8",
                                                              type: 4,
                                                            },
                                                            2
                                                          )
                                                        },
                                                      },
                                                    },
                                                    [
                                                      _vm._v(
                                                        "\n\t\t\t\t\t\t\t\t\t\t\tУволить с отработкой\n\t\t\t\t\t\t\t\t\t\t\t"
                                                      ),
                                                      _c("img", {
                                                        directives: [
                                                          {
                                                            name: "b-popover",
                                                            rawName:
                                                              "v-b-popover.hover.top",
                                                            value:
                                                              "Доступ к профилю закроется через 14 календарных дней",
                                                            expression:
                                                              "'Доступ к профилю закроется через 14 календарных дней'",
                                                            modifiers: {
                                                              hover: true,
                                                              top: true,
                                                            },
                                                          },
                                                        ],
                                                        staticClass: "img-info",
                                                        attrs: {
                                                          src: "/images/dist/profit-info.svg",
                                                        },
                                                      }),
                                                    ]
                                                  ),
                                                ],
                                                1
                                              ),
                                            ],
                                            2
                                          ),
                                        ]
                                      : [
                                          _c("div", { staticClass: "temari" }, [
                                            _c(
                                              "button",
                                              {
                                                staticClass:
                                                  "btn btn-warning btn-block",
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.openModalAbsence(
                                                      {
                                                        type: 2,
                                                        label:
                                                          "Отсутствовал на стажировке",
                                                      }
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n\t\t\t\t\t\t\t\t\t\tОтсутствовал на стажировке\n\t\t\t\t\t\t\t\t\t"
                                                ),
                                              ]
                                            ),
                                            _vm._v(" "),
                                            _vm.sidebarContent.data.item
                                              .requested == null
                                              ? _c(
                                                  "button",
                                                  {
                                                    staticClass:
                                                      "btn btn-primary btn-block",
                                                    on: {
                                                      click: function ($event) {
                                                        return _vm.openModalApply(
                                                          {
                                                            type: 8,
                                                            label:
                                                              "Принят на работу",
                                                          }
                                                        )
                                                      },
                                                    },
                                                  },
                                                  [
                                                    _vm._v(
                                                      "\n\t\t\t\t\t\t\t\t\t\tПринять на работу\n\t\t\t\t\t\t\t\t\t"
                                                    ),
                                                  ]
                                                )
                                              : _vm._e(),
                                            _vm._v(" "),
                                            _c(
                                              "button",
                                              {
                                                staticClass:
                                                  "btn btn-info btn-block",
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.setDayWithoutComment(
                                                      7
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n\t\t\t\t\t\t\t\t\t\tПодключился позже\n\t\t\t\t\t\t\t\t\t"
                                                ),
                                              ]
                                            ),
                                            _vm._v(" "),
                                            _c(
                                              "div",
                                              {
                                                staticClass: "mt-3",
                                                staticStyle: {
                                                  color: "green",
                                                  "text-align": "center",
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n\t\t\t\t\t\t\t\t\t\t" +
                                                    _vm._s(
                                                      _vm.apllyPersonResponse
                                                    ) +
                                                    "\n\t\t\t\t\t\t\t\t\t"
                                                ),
                                              ]
                                            ),
                                            _vm._v(" "),
                                            _vm.sidebarContent.data.item
                                              .requested !== null
                                              ? _c(
                                                  "div",
                                                  {
                                                    staticClass: "mt-3",
                                                    staticStyle: {
                                                      color: "green",
                                                      "text-align": "center",
                                                    },
                                                  },
                                                  [
                                                    _vm._v(
                                                      "\n\t\t\t\t\t\t\t\t\t\tЗаявка на принятие на работу была подана в " +
                                                        _vm._s(
                                                          _vm.sidebarContent
                                                            .data.item.requested
                                                        ) +
                                                        "\n\t\t\t\t\t\t\t\t\t"
                                                    ),
                                                  ]
                                                )
                                              : _vm._e(),
                                            _vm._v(" "),
                                            _c(
                                              "button",
                                              {
                                                staticClass:
                                                  "btn btn-danger btn-block mt-auto",
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.openFiringModal(
                                                      {
                                                        label: "Уволить",
                                                        color: "#c8a2c8",
                                                        type: 4,
                                                      },
                                                      0
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n\t\t\t\t\t\t\t\t\t\tУволить\n\t\t\t\t\t\t\t\t\t"
                                                ),
                                              ]
                                            ),
                                          ]),
                                        ],
                                  ],
                                  2
                                ),
                                _vm._v(" "),
                                !_vm.sidebarContent.data.item.is_trainee
                                  ? _c(
                                      "b-tab",
                                      { attrs: { title: "⚠️Штрафы" } },
                                      [
                                        _c(
                                          "b-form-group",
                                          {
                                            staticClass: "fines-modal",
                                            scopedSlots: _vm._u(
                                              [
                                                {
                                                  key: "label",
                                                  fn: function () {
                                                    return [
                                                      _vm._v(
                                                        "\n\t\t\t\t\t\t\t\t\tСистема депремирования\n\t\t\t\t\t\t\t\t\t"
                                                      ),
                                                      _c("img", {
                                                        directives: [
                                                          {
                                                            name: "b-popover",
                                                            rawName:
                                                              "v-b-popover.hover.bottom",
                                                            value:
                                                              "При активации, от окладной части будет вычитаться соответственные суммы депремирований",
                                                            expression:
                                                              "'При активации, от окладной части будет вычитаться соответственные суммы депремирований'",
                                                            modifiers: {
                                                              hover: true,
                                                              bottom: true,
                                                            },
                                                          },
                                                        ],
                                                        staticClass: "img-info",
                                                        attrs: {
                                                          src: "/images/dist/profit-info.svg",
                                                        },
                                                      }),
                                                    ]
                                                  },
                                                  proxy: true,
                                                },
                                              ],
                                              null,
                                              false,
                                              3372543892
                                            ),
                                          },
                                          [
                                            _vm._v(" "),
                                            _c(
                                              "b-form-checkbox-group",
                                              {
                                                attrs: {
                                                  name: "flavour-2a",
                                                  stacked: "",
                                                },
                                                model: {
                                                  value:
                                                    _vm.sidebarContent.fines,
                                                  callback: function ($$v) {
                                                    _vm.$set(
                                                      _vm.sidebarContent,
                                                      "fines",
                                                      $$v
                                                    )
                                                  },
                                                  expression:
                                                    "sidebarContent.fines",
                                                },
                                              },
                                              _vm._l(
                                                _vm.fines,
                                                function (fine) {
                                                  return _c(
                                                    "b-form-checkbox",
                                                    {
                                                      key: fine.value,
                                                      attrs: {
                                                        value: fine.value,
                                                      },
                                                    },
                                                    [
                                                      _c("span", {
                                                        domProps: {
                                                          innerHTML: _vm._s(
                                                            fine.text
                                                          ),
                                                        },
                                                      }),
                                                    ]
                                                  )
                                                }
                                              ),
                                              1
                                            ),
                                          ],
                                          1
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "b-button",
                                          {
                                            attrs: { variant: "primary" },
                                            on: { click: _vm.openModalFine },
                                          },
                                          [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\tСохранить\n\t\t\t\t\t\t\t"
                                            ),
                                          ]
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ]
                            : _vm._e(),
                        ],
                        2
                      ),
                    ],
                    1
                  ),
                ]),
                _vm._v(" "),
                _c("div", {
                  staticClass: "table-report-backdrop",
                  on: {
                    click: function ($event) {
                      if ($event.target !== $event.currentTarget) {
                        return null
                      }
                      _vm.openSidebar = false
                    },
                  },
                }),
              ])
            : _vm._e(),
          _vm._v(" "),
           false
            ? 0
            : _vm._e(),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                "ok-text": "Да",
                "cancel-text": "Нет",
                title: "Вы уверены?",
                size: "md",
              },
              on: { ok: _vm.saveFines },
              model: {
                value: _vm.modalVisibleFines,
                callback: function ($$v) {
                  _vm.modalVisibleFines = $$v
                },
                expression: "modalVisibleFines",
              },
            },
            [
              _vm._l(_vm.errors, function (error) {
                return [
                  _c(
                    "b-alert",
                    { key: error, attrs: { show: "", variant: "danger" } },
                    [_vm._v("\n\t\t\t\t" + _vm._s(error) + "\n\t\t\t")]
                  ),
                ]
              }),
              _vm._v(" "),
              _c("b-form-input", {
                attrs: { placeholder: "Комментарий", required: true },
                model: {
                  value: _vm.commentFines,
                  callback: function ($$v) {
                    _vm.commentFines = $$v
                  },
                  expression: "commentFines",
                },
              }),
            ],
            2
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                "ok-text": "Да",
                "cancel-text": "Нет",
                title: _vm.modalTitle,
                size: "md",
              },
              on: { ok: _vm.setDayType },
              model: {
                value: _vm.modalVisibleDay,
                callback: function ($$v) {
                  _vm.modalVisibleDay = $$v
                },
                expression: "modalVisibleDay",
              },
            },
            [
              _vm._l(_vm.errors, function (error) {
                return [
                  _c(
                    "b-alert",
                    { key: error, attrs: { show: "", variant: "danger" } },
                    [_vm._v("\n\t\t\t\t" + _vm._s(error) + "\n\t\t\t")]
                  ),
                ]
              }),
              _vm._v(" "),
              _c("b-form-input", {
                attrs: { placeholder: "Комментарий", required: true },
                model: {
                  value: _vm.commentDay,
                  callback: function ($$v) {
                    _vm.commentDay = $$v
                  },
                  expression: "commentDay",
                },
              }),
            ],
            2
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                "ok-text": "Да",
                "cancel-text": "Нет",
                title: "Принятие на работу",
                size: "md",
              },
              on: { ok: _vm.applyPerson },
              model: {
                value: _vm.modalVisibleApply,
                callback: function ($$v) {
                  _vm.modalVisibleApply = $$v
                },
                expression: "modalVisibleApply",
              },
            },
            [
              _vm._l(_vm.errors, function (error) {
                return [
                  _c(
                    "b-alert",
                    { key: error, attrs: { show: "", variant: "danger" } },
                    [_vm._v("\n\t\t\t\t" + _vm._s(error) + "\n\t\t\t")]
                  ),
                ]
              }),
              _vm._v(" "),
              _c("b-form-input", {
                attrs: {
                  placeholder: "Напишите со скольки и до скольки рабочий день",
                  required: true,
                },
                model: {
                  value: _vm.applyItems.schedule,
                  callback: function ($$v) {
                    _vm.$set(_vm.applyItems, "schedule", $$v)
                  },
                  expression: "applyItems.schedule",
                },
              }),
            ],
            2
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                "ok-text": "Да",
                "cancel-text": "Нет",
                title: "Отсутствовал на стажировке",
                size: "md",
              },
              on: { ok: _vm.setUserAbsent },
              model: {
                value: _vm.modalVisibleAbsence,
                callback: function ($$v) {
                  _vm.modalVisibleAbsence = $$v
                },
                expression: "modalVisibleAbsence",
              },
            },
            [
              _vm._l(_vm.errors, function (error) {
                return [
                  _c(
                    "b-alert",
                    { key: error, attrs: { show: "", variant: "danger" } },
                    [_vm._v("\n\t\t\t\t" + _vm._s(error) + "\n\t\t\t")]
                  ),
                ]
              }),
              _vm._v(" "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.commentAbsent,
                      expression: "commentAbsent",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.commentAbsent = $event.target.multiple
                        ? $$selectedVal
                        : $$selectedVal[0]
                    },
                  },
                },
                [
                  _c(
                    "option",
                    { attrs: { value: "", disabled: "", selected: "" } },
                    [_vm._v("\n\t\t\t\tВыберите причину\n\t\t\t")]
                  ),
                  _vm._v(" "),
                  _vm._l(_vm.fire_causes, function (cause) {
                    return _c(
                      "option",
                      { key: cause, domProps: { value: cause } },
                      [_vm._v("\n\t\t\t\t" + _vm._s(cause) + "\n\t\t\t")]
                    )
                  }),
                ],
                2
              ),
            ],
            2
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                "ok-text": "Да",
                "cancel-text": "Нет",
                title: _vm.modalTitle,
                size: "md",
              },
              on: { ok: _vm.setUserFired },
              model: {
                value: _vm.modalVisibleFiring,
                callback: function ($$v) {
                  _vm.modalVisibleFiring = $$v
                },
                expression: "modalVisibleFiring",
              },
            },
            [
              _vm._l(_vm.errors, function (error) {
                return [
                  _c(
                    "b-alert",
                    { key: error, attrs: { show: "", variant: "danger" } },
                    [_vm._v("\n\t\t\t\t" + _vm._s(error) + "\n\t\t\t")]
                  ),
                ]
              }),
              _vm._v(" "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.commentFiring2,
                      expression: "commentFiring2",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.commentFiring2 = $event.target.multiple
                        ? $$selectedVal
                        : $$selectedVal[0]
                    },
                  },
                },
                [
                  _c(
                    "option",
                    { attrs: { value: "", disabled: "", selected: "" } },
                    [_vm._v("\n\t\t\t\tВыберите причину\n\t\t\t")]
                  ),
                  _vm._v(" "),
                  _vm._l(_vm.fire_causes, function (cause) {
                    return _c(
                      "option",
                      { key: cause, domProps: { value: cause } },
                      [_vm._v("\n\t\t\t\t" + _vm._s(cause) + "\n\t\t\t")]
                    )
                  }),
                ],
                2
              ),
              _vm._v(" "),
              _vm.firingItems.type == 2
                ? _c("b-form-file", {
                    staticClass: "mt-3",
                    attrs: {
                      state: Boolean(_vm.firingItems.file),
                      placeholder: "Выберите или перетащите файл сюда...",
                      "drop-placeholder": "Перетащите файл сюда...",
                    },
                    model: {
                      value: _vm.firingItems.file,
                      callback: function ($$v) {
                        _vm.$set(_vm.firingItems, "file", $$v)
                      },
                      expression: "firingItems.file",
                    },
                  })
                : _vm._e(),
            ],
            2
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                "ok-text": "Да",
                "cancel-text": "Нет",
                title: "Вы уверены?",
                size: "md",
              },
              on: { ok: _vm.updateHour },
              model: {
                value: _vm.modalVisible,
                callback: function ($$v) {
                  _vm.modalVisible = $$v
                },
                expression: "modalVisible",
              },
            },
            [
              _vm._l(_vm.errors, function (error) {
                return [
                  _c(
                    "b-alert",
                    { key: error, attrs: { show: "", variant: "danger" } },
                    [_vm._v("\n\t\t\t\t" + _vm._s(error) + "\n\t\t\t")]
                  ),
                ]
              }),
              _vm._v(" "),
              _c("b-form-input", {
                attrs: { placeholder: "Комментарий", required: true },
                model: {
                  value: _vm.comment,
                  callback: function ($$v) {
                    _vm.comment = $$v
                  },
                  expression: "comment",
                },
              }),
            ],
            2
          ),
        ],
        1
      )
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);