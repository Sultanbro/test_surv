"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["FinesPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'PageFines',
  data: function data() {
    return {
      fines: [],
      savedfines: [],
      alert: {
        show: false,
        message: '',
        "class": 'alert-danger'
      },
      preloaderShow: false
    };
  },
  created: function created() {
    this.getFines();
  },
  methods: {
    getFines: function getFines() {
      var _this = this;
      this.axios.get('/timetracking/fine', {}).then(function (response) {
        _this.savedfines = JSON.parse(JSON.stringify(response.data.fines));
        _this.fines = response.data.fines;
      })["catch"](function (error) {
        console.error(error);
      });
    },
    addFine: function addFine() {
      this.fines.push({
        id: 0,
        name: 'Новый штраф',
        /* eslint-disable-next-line camelcase */
        penalty_amount: 0
      });
    },
    saveFines: function saveFines() {
      var _this2 = this;
      if (this.validateFields() && !this.preloaderShow) {
        this.alert.show = false;
        var newfines = this.getNewFines();
        var deletedfines = this.getDeletedFines();
        var editedfines = this.getEditedFines();
        this.preloaderShow = true;
        this.axios.put('/timetracking/fine', {
          newfines: newfines,
          editedfines: editedfines,
          deletedfines: deletedfines
        }).then(function (response) {
          _this2.alert.message = response.data.message;
          _this2.alert["class"] = 'alert-success';
          _this2.alert.show = true;
          _this2.getFines();
          _this2.preloaderShow = false;
        })["catch"](function (error) {
          console.error(error);
        });
      }
    },
    deleteFine: function deleteFine(index) {
      this.fines.splice(index, 1);
    },
    closeAlert: function closeAlert() {
      this.alert.show = false;
    },
    validateFields: function validateFields() {
      var _this3 = this;
      var result = true;
      this.fines.forEach(function (element) {
        if (!element.name || !element.penalty_amount) {
          _this3.alert.message = 'Заполните все поля!';
          _this3.alert.show = true;
          _this3.alert["class"] = 'alert-danger';
          result = false;
          return false;
        }
      });
      return result;
    },
    getNewFines: function getNewFines() {
      var newFines = [];
      this.fines.forEach(function (element) {
        if (element.id === 0) {
          newFines.push(element);
        }
      });
      return newFines;
    },
    getDeletedFines: function getDeletedFines() {
      var _this4 = this;
      var deletedFines = [];
      this.savedfines.forEach(function (element) {
        if (!_this4.fines.find(function (fine) {
          return fine.id === element.id;
        })) {
          deletedFines.push(element.id);
        }
      });
      return deletedFines;
    },
    getEditedFines: function getEditedFines() {
      var _this5 = this;
      var editedFines = [];
      this.savedfines.forEach(function (element) {
        var foundFine = _this5.fines.find(function (fine) {
          return fine.id === element.id;
        });
        if (foundFine && (foundFine.name !== element.name || foundFine.penalty_amount !== element.penalty_amount)) {
          editedFines.push(foundFine);
        }
      });
      return editedFines;
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".table-container .in-table-textarea[data-v-83703480] {\n  padding: 5px 20px !important;\n  min-width: 500px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Fines_vue_vue_type_style_index_0_id_83703480_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Fines_vue_vue_type_style_index_0_id_83703480_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Fines_vue_vue_type_style_index_0_id_83703480_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/pages/Fines.vue":
/*!**************************************!*\
  !*** ./resources/js/pages/Fines.vue ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Fines_vue_vue_type_template_id_83703480_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Fines.vue?vue&type=template&id=83703480&scoped=true& */ "./resources/js/pages/Fines.vue?vue&type=template&id=83703480&scoped=true&");
/* harmony import */ var _Fines_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Fines.vue?vue&type=script&lang=js& */ "./resources/js/pages/Fines.vue?vue&type=script&lang=js&");
/* harmony import */ var _Fines_vue_vue_type_style_index_0_id_83703480_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true& */ "./resources/js/pages/Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Fines_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Fines_vue_vue_type_template_id_83703480_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _Fines_vue_vue_type_template_id_83703480_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "83703480",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Fines.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Fines.vue?vue&type=script&lang=js&":
/*!***************************************************************!*\
  !*** ./resources/js/pages/Fines.vue?vue&type=script&lang=js& ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Fines_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Fines.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Fines_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true&":
/*!************************************************************************************************!*\
  !*** ./resources/js/pages/Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true& ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Fines_vue_vue_type_style_index_0_id_83703480_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=style&index=0&id=83703480&lang=scss&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/Fines.vue?vue&type=template&id=83703480&scoped=true&":
/*!*********************************************************************************!*\
  !*** ./resources/js/pages/Fines.vue?vue&type=template&id=83703480&scoped=true& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Fines_vue_vue_type_template_id_83703480_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Fines_vue_vue_type_template_id_83703480_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Fines_vue_vue_type_template_id_83703480_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Fines.vue?vue&type=template&id=83703480&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=template&id=83703480&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=template&id=83703480&scoped=true&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Fines.vue?vue&type=template&id=83703480&scoped=true& ***!
  \************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-row",
        [
          _c("b-col", { attrs: { cols: "12", lg: "8" } }, [
            _c(
              "div",
              { staticClass: "table-container" },
              [
                _c(
                  "b-table-simple",
                  { staticClass: "table-striped table-hover" },
                  [
                    _c(
                      "b-thead",
                      [
                        _c(
                          "b-tr",
                          [
                            _c("b-th", { staticClass: "text-left" }, [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t\tСистема депремирования\n\t\t\t\t\t\t\t"
                              ),
                            ]),
                            _vm._v(" "),
                            _c("b-th", { staticClass: "text-left" }, [
                              _vm._v("\n\t\t\t\t\t\t\t\tСумма\n\t\t\t\t\t\t\t"),
                            ]),
                            _vm._v(" "),
                            _c("b-th"),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-tbody",
                      _vm._l(_vm.fines, function (fine, index) {
                        return _c(
                          "b-tr",
                          { key: index },
                          [
                            _c(
                              "b-td",
                              [
                                _c("b-textarea", {
                                  staticClass: "in-table-textarea",
                                  model: {
                                    value: fine.name,
                                    callback: function ($$v) {
                                      _vm.$set(
                                        fine,
                                        "name",
                                        typeof $$v === "string"
                                          ? $$v.trim()
                                          : $$v
                                      )
                                    },
                                    expression: "fine.name",
                                  },
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-td",
                              [
                                _c("b-form-input", {
                                  attrs: { type: "number" },
                                  model: {
                                    value: fine.penalty_amount,
                                    callback: function ($$v) {
                                      _vm.$set(
                                        fine,
                                        "penalty_amount",
                                        typeof $$v === "string"
                                          ? $$v.trim()
                                          : $$v
                                      )
                                    },
                                    expression: "fine.penalty_amount",
                                  },
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c("b-td", [
                              _c(
                                "button",
                                {
                                  staticClass: "btn btn-danger",
                                  attrs: {
                                    type: "button",
                                    "data-id": fine.id,
                                    title: "Удалить штраф",
                                  },
                                  on: {
                                    click: function ($event) {
                                      return _vm.deleteFine(index)
                                    },
                                  },
                                },
                                [
                                  _c("i", {
                                    staticClass: "fa fa-trash",
                                    attrs: { "aria-hidden": "true" },
                                  }),
                                ]
                              ),
                            ]),
                          ],
                          1
                        )
                      }),
                      1
                    ),
                  ],
                  1
                ),
              ],
              1
            ),
          ]),
        ],
        1
      ),
      _vm._v(" "),
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col mt-2 mb-4" }, [
          _c(
            "button",
            {
              staticClass: "btn btn-primary",
              attrs: { type: "button", title: "Добавить новый штраф" },
              on: {
                click: function ($event) {
                  return _vm.addFine()
                },
              },
            },
            [_vm._v("\n\t\t\t\tДобавить\n\t\t\t")]
          ),
          _vm._v(" "),
          _c(
            "button",
            {
              staticClass: "btn btn-success",
              attrs: { type: "button", title: "Сохранить изменения в штрафах" },
              on: {
                click: function ($event) {
                  return _vm.saveFines()
                },
              },
            },
            [
              _vm._v("\n\t\t\t\tСохранить "),
              _vm.preloaderShow
                ? _c("img", {
                    attrs: {
                      src: "/images/preloader.gif",
                      width: "20",
                      height: "20",
                    },
                  })
                : _vm._e(),
            ]
          ),
        ]),
      ]),
      _vm._v(" "),
      _vm.alert.show
        ? _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-8" }, [
              _c(
                "div",
                { staticClass: "alert mt-2 mb-3", class: _vm.alert.class },
                [
                  _vm._v(
                    "\n\t\t\t\t" + _vm._s(_vm.alert.message) + "\n\t\t\t\t"
                  ),
                  _c(
                    "button",
                    {
                      staticClass: "close mb-3",
                      attrs: { type: "button" },
                      on: {
                        click: function ($event) {
                          return _vm.closeAlert()
                        },
                      },
                    },
                    [
                      _c("span", { attrs: { "aria-hidden": "true" } }, [
                        _vm._v("×"),
                      ]),
                    ]
                  ),
                ]
              ),
            ]),
          ])
        : _vm._e(),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);