"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["TopPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ui_Switch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ui/Switch */ "./resources/js/components/ui/Switch.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TopSwitches',
  components: {
    JobtronSwitch: _ui_Switch__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    items: {
      type: Object,
      "default": function _default() {
        return {};
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_Portal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/Portal */ "./resources/js/stores/Portal.js");
/* harmony import */ var _composables_yearOptions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/composables/yearOptions */ "./resources/js/composables/yearOptions.js");
/* harmony import */ var _stores_api_top_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/stores/api/top.js */ "./resources/js/stores/api/top.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'NPS',
  props: {
    activeuserid: {
      type: Number,
      "default": 0
    },
    show_header: {
      type: Boolean,
      "default": true
    }
  },
  data: function data() {
    var _this = this;
    return {
      users: [],
      fields: [],
      currentYear: new Date().getFullYear(),
      monthInfo: {
        currentMonth: null,
        monthEnd: 0,
        workDays: 0,
        weekDays: 0,
        daysInMonth: 0
      },
      ukey: 1,
      sortCol: '',
      sortOrder: 'asc',
      sortFn: {
        asc: {
          str: function str(a, b) {
            return (a[_this.sortCol] || '').localeCompare(b[_this.sortCol] || '');
          },
          data: function data(a, b) {
            return (Number(a[_this.sortCol]) || 0) - (Number(b[_this.sortCol]) || 0);
          }
        },
        desc: {
          str: function str(b, a) {
            return (a[_this.sortCol] || '').localeCompare(b[_this.sortCol] || '');
          },
          data: function data(b, a) {
            return (Number(a[_this.sortCol]) || 0) - (Number(b[_this.sortCol]) || 0);
          }
        }
      }
    };
  },
  computed: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_3__.mapState)(_stores_Portal__WEBPACK_IMPORTED_MODULE_0__.usePortalStore, ['portal'])), {}, {
    years: function years() {
      if (!this.portal.created_at) return [new Date().getFullYear()];
      return (0,_composables_yearOptions__WEBPACK_IMPORTED_MODULE_1__.useYearOptions)(new Date(this.portal.created_at).getFullYear());
    },
    sorted: function sorted() {
      if (!this.sortCol) return this.users;
      var toSort = this.users.slice();
      if (['group_id', 'position', 'name'].includes(this.sortCol)) {
        toSort.sort(this.sortFn[this.sortOrder].str);
      } else {
        toSort.sort(this.sortFn[this.sortOrder].data);
      }
      return toSort;
    }
  }),
  created: function created() {
    this.setMonth();
    this.setMonthsTableFields();
    this.fetchData();
  },
  methods: {
    setMonth: function setMonth() {
      this.monthInfo.currentMonth = this.monthInfo.currentMonth ? this.monthInfo.currentMonth : this.$moment().format('MMMM');
      this.monthInfo.month = this.monthInfo.currentMonth ? this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M') : this.$moment().format('M');
      var currentMonth = this.$moment(this.monthInfo.currentMonth, 'MMMM');
      //Расчет выходных дней
      this.monthInfo.monthEnd = currentMonth.endOf('month'); //Конец месяца
      this.monthInfo.weekDays = currentMonth.weekdayCalc(currentMonth.startOf('month').toString(), currentMonth.endOf('month').toString(), [6]); //Колличество выходных
      this.monthInfo.daysInMonth = new Date(2021, this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M'), 0).getDate(); //Колличество дней в месяце
      this.monthInfo.workDays = this.monthInfo.daysInMonth - this.monthInfo.weekDays; //Колличество рабочих дней
    },
    fetchData: function fetchData() {
      var _this2 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var loader, _yield$fetchTopNPS, users;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                loader = _this2.$loading.show();
                _context.prev = 1;
                _context.next = 4;
                return (0,_stores_api_top_js__WEBPACK_IMPORTED_MODULE_2__.fetchTopNPS)({
                  month: _this2.$moment(_this2.monthInfo.currentMonth, 'MMMM').format('M'),
                  year: _this2.currentYear
                });
              case 4:
                _yield$fetchTopNPS = _context.sent;
                users = _yield$fetchTopNPS.users;
                _this2.setMonth();
                _this2.users = _this2.addAvg(users);
                _this2.ukey++;
                _context.next = 14;
                break;
              case 11:
                _context.prev = 11;
                _context.t0 = _context["catch"](1);
                alert(_context.t0);
              case 14:
                loader.hide();
              case 15:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[1, 11]]);
      }))();
    },
    addAvg: function addAvg(users) {
      users.forEach(function (user) {
        var count = 0;
        var sum = 0;
        for (var i = 1, l = 12; i <= l; ++i) {
          if (user[i]) {
            ++count;
            sum += Number(user[i]) || 0;
          }
        }
        user.avg = sum / count || 0;
        user.avg = user.avg.toFixed(user.avg === parseInt(user.avg) ? 0 : 1);
      });
      return users;
    },
    setMonthsTableFields: function setMonthsTableFields() {
      var fieldsArray = [];
      var order = 1;
      fieldsArray.push({
        key: 'group_id',
        name: 'Отдел',
        order: order++,
        klass: ' text-left bg-blue w-200'
      });
      fieldsArray.push({
        key: 'position',
        name: 'Должность',
        order: order++,
        klass: ' text-left bg-blue'
      });
      fieldsArray.push({
        key: 'name',
        name: 'ФИО',
        order: order++,
        klass: ' text-left bg-blue w-200'
      });
      fieldsArray.push({
        key: 'avg',
        name: 'Среднее',
        order: order++,
        klass: 'text-center px-1'
      });
      for (var i = 1; i <= 12; i++) {
        if (i.length == 1) i = '0' + i;
        fieldsArray.push({
          key: i,
          name: this.$moment(this.currentYear + '-' + i + '-01').format('MMMM'),
          order: order++,
          klass: 'text-center px-1 month'
        });
      }
      this.fields = fieldsArray;
    },
    doSort: function doSort(col) {
      if (this.sortCol === col) {
        this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
        return;
      }
      this.sortOrder = 'asc';
      this.sortCol = col;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TableRentability',
  props: {
    year: {
      type: Number,
      "default": 0
    },
    month: {
      type: Number,
      "default": 0
    }
  },
  data: function data() {
    return {
      items: [],
      months: {
        1: 'Январь',
        2: 'Февраль',
        3: 'Март',
        4: 'Апрель',
        5: 'Май',
        6: 'Июнь',
        7: 'Июль',
        8: 'Август',
        9: 'Сентябрь',
        10: 'Октябрь',
        11: 'Ноябрь',
        12: 'Декабрь'
      },
      tops: {},
      skey: 1,
      sorts: {}
    };
  },
  watch: {
    year: function year() {
      this.fetchData();
    },
    month: function month() {
      this.fetchData();
    }
  },
  created: function created() {
    this.fetchData();
  },
  methods: {
    countTop: function countTop() {
      var _this = this;
      Object.keys(this.months).forEach(function (key) {
        var s = _this.items[0]['c' + key];
        var a = (_this.items[0]['l' + key] - s) / s * 100;
        _this.tops[key] = isNaN(a) ? '' : Number(a).toFixed(1) + '%';
      });
    },
    countRents: function countRents() {
      this.items.forEach(function (item) {
        for (var i = 1; i <= 12; i++) {
          var l = item['l' + i];
          var c = item['c' + i];
          var a = (l - c) / l * 100;
          item['r' + i] = !isFinite(a) ? '' : Number(a).toFixed(1) + '%';
          item['rc' + i] = !isFinite(a) ? 0 : Number(a);
        }
      });
    },
    fetchData: function fetchData() {
      var _this2 = this;
      this.axios.post('/timetracking/top/get-rentability', {
        year: this.year,
        month: this.month
      }).then(function (response) {
        _this2.items = response.data;
        _this2.countRents();
        _this2.countTop();
        _this2.skey++;
      });
    },
    update: function update(month, index) {
      var _this3 = this;
      var item = this.items[index];
      this.axios.post('/timetracking/top/top_edited_value/update', {
        year: this.year,
        month: month,
        value: item['l' + month],
        /* eslint-disable-next-line camelcase */
        group_id: item.group_id
      }).then(function () {
        var i = month;
        item['r' + i] = Number(item['c' + i]) > 0 ? Number(Number(item['l' + i]) * 1000 / Number(item['c' + i])).toFixed(1) : 0;
        item['rc' + i] = item['r' + i] + '%';
        item['ed' + i] = true;
        _this3.$toast.success('Сохранено');
      });
    },
    numberWithCommas: function numberWithCommas(x) {
      return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    },
    sort: function sort(field) {
      if (this.sorts[field] === undefined) {
        this.sorts[field] = 'asc';
      }
      var item = this.items[0];
      this.items.shift();
      if (this.sorts[field] === 'desc') {
        this.items.sort(function (a, b) {
          return a[field] > b[field] ? 1 : -1;
        });
        this.sorts[field] = 'asc';
      } else {
        this.items.sort(function (a, b) {
          return a[field] < b[field] ? 1 : -1;
        });
        this.sorts[field] = 'desc';
      }
      this.items.unshift(item);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'JobtronSwitch',
  components: {},
  props: {
    value: {
      type: Boolean
    }
  },
  data: function data() {
    return {
      localValue: this.value
    };
  },
  watch: {
    value: function value() {
      this.localValue = this.value;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_Portal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/Portal */ "./resources/js/stores/Portal.js");
/* harmony import */ var _components_tables_TableRentability__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/tables/TableRentability */ "./resources/js/components/tables/TableRentability.vue");
/* harmony import */ var _components_tables_NPS__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/tables/NPS */ "./resources/js/components/tables/NPS.vue");
/* harmony import */ var _components_pages_Top_TopSwitches__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/pages/Top/TopSwitches */ "./resources/js/components/pages/Top/TopSwitches.vue");
/* harmony import */ var _composables_yearOptions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/composables/yearOptions */ "./resources/js/composables/yearOptions.js");
/* harmony import */ var _ui_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ui/Button */ "./resources/js/components/ui/Button.vue");
/* harmony import */ var _ui_Sidebar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ui/Sidebar */ "./resources/js/components/ui/Sidebar.vue");
/* harmony import */ var _stores_api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/stores/api */ "./resources/js/stores/api.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */



var VGauge = function VGauge() {
  return __webpack_require__.e(/*! import() | TopGauges */ "TopGauges").then(__webpack_require__.bind(__webpack_require__, /*! vgauge */ "./node_modules/vgauge/dist/VGauge.esm.js"));
};
var TopGauges = function TopGauges() {
  return __webpack_require__.e(/*! import() | TopGauges */ "TopGauges").then(__webpack_require__.bind(__webpack_require__, /*! @/components/TopGauges */ "./resources/js/components/TopGauges.vue"));
}; // TOП спидометры, есть и в аналитике
 // ТОП рентабельность
 // Оценка руководителей





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'PageTop',
  components: {
    TopGauges: TopGauges,
    VGauge: VGauge,
    TableRentability: _components_tables_TableRentability__WEBPACK_IMPORTED_MODULE_1__["default"],
    NPS: _components_tables_NPS__WEBPACK_IMPORTED_MODULE_2__["default"],
    TopSwitches: _components_pages_Top_TopSwitches__WEBPACK_IMPORTED_MODULE_3__["default"],
    JobtronButton: _ui_Button__WEBPACK_IMPORTED_MODULE_5__["default"],
    SideBar: _ui_Sidebar__WEBPACK_IMPORTED_MODULE_6__["default"]
  },
  props: {
    data: {
      type: Object,
      "default": null
    },
    activeuserid: {
      type: Number,
      "default": null
    }
  },
  data: function data() {
    var now = new Date();
    return {
      afterCreated: false,
      activeTab: 0,
      utility: [],
      // первая вкладка
      rentability: [],
      // вторая
      proceeds: [],
      // третья

      utilitySwitch: {},
      rentabilitySwitch: {},
      proceedsSwitch: {},
      prognoz_groups: [],
      //
      currentYear: now.getFullYear(),
      monthInfo: {
        currentMonth: null,
        monthEnd: 0,
        workDays: 0,
        weekDays: 0,
        daysInMonth: 0,
        month: now.getMonth() + 1
      },
      gaugeOptions: {
        angle: 0,
        staticLabels: {
          font: '9px sans-serif',
          // Specifies font
          labels: [0, 50, 80, 100, 120],
          // Print labels at these values
          color: '#000000',
          // Optional: Label text color
          fractionDigits: 0 // Optional: Numerical precision. 0=round off.
        },

        staticZones: [{
          strokeStyle: '#F03E3E',
          min: 0,
          max: 49
        },
        // Red
        {
          strokeStyle: '#fd7e14',
          min: 50,
          max: 79
        },
        // Orange
        {
          strokeStyle: '#FFDD00',
          min: 80,
          max: 90
        },
        // Yellow
        {
          strokeStyle: '#30B32D',
          min: 91,
          max: 120
        } // Green
        ],

        pointer: {
          length: 0.5,
          // // Relative to gauge radius
          strokeWidth: 0.025,
          // The thickness
          color: '#000000' // Fill color
        },

        limitMax: true,
        limitMin: true,
        lineWidth: 0.2,
        radiusScale: 0.8,
        colorStart: '#6FADCF',
        generateGradient: true,
        highDpiSupport: true
      },
      ukey: 1,
      isArchiveOpen: false
    };
  },
  computed: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_8__.mapState)(_stores_Portal__WEBPACK_IMPORTED_MODULE_0__.usePortalStore, ['portal'])), {}, {
    years: function years() {
      if (!this.portal.created_at) return [new Date().getFullYear()];
      return (0,_composables_yearOptions__WEBPACK_IMPORTED_MODULE_4__.useYearOptions)(new Date(this.portal.created_at).getFullYear());
    },
    activeUtility: function activeUtility() {
      var _this = this;
      return this.utility.filter(function (util) {
        return _this.utilitySwitch[util.id] && _this.utilitySwitch[util.id].value;
      });
    },
    archiveUtility: function archiveUtility() {
      var _this2 = this;
      return this.utility.filter(function (util) {
        return !(_this2.utilitySwitch[util.id] && _this2.utilitySwitch[util.id].value);
      });
    },
    switches: function switches() {
      switch (this.activeTab) {
        case 1:
          return this.rentabilitySwitch;
        case 2:
          return this.proceedsSwitch;
      }
      return this.utilitySwitch;
    }
  }),
  watch: {
    data: function data() {
      this.init();
    }
  },
  created: function created() {
    if (this.data) {
      this.init();
    }
  },
  methods: {
    init: function init() {
      this.utility = this.data.utility;
      this.proceeds = this.data.proceeds;
      this.prognoz_groups = this.data.prognoz_groups;
      this.setMonth();
      this.fetchData();
      this.fetchSwitches();
    },
    showIcons: function showIcons() {
      this.rentability = this.data.rentability;
    },
    setMonth: function setMonth() {
      this.monthInfo.currentMonth = this.monthInfo.currentMonth ? this.monthInfo.currentMonth : this.$moment().format('MMMM');
      this.monthInfo.month = this.monthInfo.currentMonth ? this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M') : this.$moment().format('M');
      var currentMonth = this.$moment(this.monthInfo.currentMonth, 'MMMM');
      //Расчет выходных дней
      this.monthInfo.monthEnd = currentMonth.endOf('month'); //Конец месяца
      this.monthInfo.weekDays = currentMonth.weekdayCalc(currentMonth.startOf('month').toString(), currentMonth.endOf('month').toString(), [6]); //Колличество выходных
      this.monthInfo.daysInMonth = new Date(this.currentYear, this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M'), 0).getDate(); //Колличество дней в месяце
      this.monthInfo.workDays = this.monthInfo.daysInMonth - this.monthInfo.weekDays; //Колличество рабочих дней
    },
    fetchData: function fetchData() {
      var _this3 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var loader, _yield$fetchTop, rentability, utility, proceeds;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                loader = _this3.$loading.show();
                _context.prev = 1;
                _context.next = 4;
                return (0,_stores_api__WEBPACK_IMPORTED_MODULE_7__.fetchTop)({
                  month: _this3.$moment(_this3.monthInfo.currentMonth, 'MMMM').format('M'),
                  year: _this3.currentYear
                });
              case 4:
                _yield$fetchTop = _context.sent;
                rentability = _yield$fetchTop.rentability;
                utility = _yield$fetchTop.utility;
                proceeds = _yield$fetchTop.proceeds;
                _this3.setMonth();
                if (_this3.afterCreated) _this3.rentability = rentability;
                _this3.afterCreated = true;
                _this3.utility = utility;
                _this3.proceeds = proceeds;
                _this3.ukey++;
                _context.next = 19;
                break;
              case 16:
                _context.prev = 16;
                _context.t0 = _context["catch"](1);
                alert(_context.t0);
              case 19:
                loader.hide();
              case 20:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[1, 16]]);
      }))();
    },
    fetchSwitches: function fetchSwitches() {
      var _this4 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var _yield$fetchArchiveUt, utility, _yield$fetchArchiveRe, rentability, _yield$fetchArchivePr, proceeds;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;
                _context2.next = 3;
                return (0,_stores_api__WEBPACK_IMPORTED_MODULE_7__.fetchArchiveUtility)();
              case 3:
                _yield$fetchArchiveUt = _context2.sent;
                utility = _yield$fetchArchiveUt.data;
                _this4.utilitySwitch = utility.reduce(function (result, group) {
                  result[group.id] = _objectSpread(_objectSpread({}, group), {}, {
                    value: !!group["switch"]
                  });
                  return result;
                }, {});
                _context2.next = 8;
                return (0,_stores_api__WEBPACK_IMPORTED_MODULE_7__.fetchArchiveRentability)();
              case 8:
                _yield$fetchArchiveRe = _context2.sent;
                rentability = _yield$fetchArchiveRe.data;
                _this4.rentabilitySwitch = rentability.reduce(function (result, group) {
                  result[group.id] = _objectSpread(_objectSpread({}, group), {}, {
                    value: !!group["switch"]
                  });
                  return result;
                }, {});
                _context2.next = 13;
                return (0,_stores_api__WEBPACK_IMPORTED_MODULE_7__.fetchArchiveProceeds)();
              case 13:
                _yield$fetchArchivePr = _context2.sent;
                proceeds = _yield$fetchArchivePr.data;
                _this4.proceedsSwitch = proceeds.reduce(function (result, group) {
                  result[group.id] = _objectSpread(_objectSpread({}, group), {}, {
                    value: !!group["switch"]
                  });
                  return result;
                }, {});
                _context2.next = 21;
                break;
              case 18:
                _context2.prev = 18;
                _context2.t0 = _context2["catch"](0);
                console.error('[fetchSwitches]', _context2.t0);
              case 21:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[0, 18]]);
      }))();
    },
    isWeekend: function isWeekend(field) {
      var arr = field.split('.');
      var month = Number(arr[1]) - 1;
      var dayOfWeek = new Date(this.currentYear, month, arr[0]).getDay();
      return dayOfWeek == 6 || dayOfWeek == 0;
    },
    saveRentGauge: function saveRentGauge(g_index) {
      var _this5 = this;
      var loader = this.$loading.show();
      this.axios.post('/timetracking/top/save_rent_max', {
        gauge: this.rentability[g_index]
      }).then(function () {
        _this5.$toast.success('Успешно сохранено!');
        _this5.rentability[g_index].editable = false;
        _this5.fetchData();
        loader.hide();
      })["catch"](function (error) {
        alert(error);
        loader.hide();
      });
    },
    saveGroupPlan: function saveGroupPlan(index) {
      var _this6 = this;
      var loader = this.$loading.show();
      var prognozGroup = this.prognoz_groups[index];
      this.axios.post('/timetracking/top/save_group_plan', {
        group_id: prognozGroup.id,
        plan: prognozGroup.plan
      }).then(function () {
        _this6.$toast.success('Успешно сохранено!');
        prognozGroup.left_to_apply = Number(prognozGroup.plan || 0) - Number(prognozGroup.fired || 0);
        loader.hide();
      })["catch"](function (error) {
        alert(error);
        loader.hide();
      });
    },
    updateProceed: function updateProceed(record, field, type) {
      var _this7 = this;
      var loader = this.$loading.show();
      this.axios.post('/timetracking/top/proceeds/update', {
        group_id: record['group_id'],
        value: record[field],
        date: field == 'Отдел' ? this.proceeds.fields[5] : field,
        name: record['Отдел'],
        type: type,
        year: this.currentYear
      }).then(function () {
        _this7.$toast.success('Успешно сохранено!');
        loader.hide();
      })["catch"](function (error) {
        alert(error);
        loader.hide();
      });
    },
    addRow: function addRow() {
      var length = this.proceeds.records.length;
      var obj = {};
      this.proceeds.fields.forEach(function (field) {
        obj[field] = null;
      });
      obj['group_id'] = this.proceeds.lowest_id - 1;
      this.proceeds.records.splice(length - 1, 0, obj);
    },
    isActiveRentability: function isActiveRentability(groupId) {
      return this.rentabilitySwitch[groupId] && this.rentabilitySwitch[groupId].value;
    },
    onChangeSwitch: function onChangeSwitch(_ref) {
      var id = _ref.id,
        value = _ref.value;
      var switch_column = ['switch_utility', 'switch_rentability', 'switch_proceeds'][this.activeTab];
      (0,_stores_api__WEBPACK_IMPORTED_MODULE_7__.switchArchiveTop)({
        id: id,
        switch_column: switch_column,
        switch_value: value ? 1 : 0
      });
      var name = ['utilitySwitch', 'rentabilitySwitch', 'proceedsSwitch'][this.activeTab];
      var item = this[name][id];
      if (item) {
        item.value = !item.value;
        item["switch"] = item.value ? 1 : 0;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".TopSwitches-row {\n  display: flex;\n  align-items: center;\n  gap: 1rem;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".custom-table-nps tbody th[data-v-0922f59c], .custom-table-nps tbody td[data-v-0922f59c] {\n  padding: 0 !important;\n}\n.custom-table-nps tbody th .inner[data-v-0922f59c], .custom-table-nps tbody td .inner[data-v-0922f59c] {\n  height: 40px;\n  padding: 0 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\ndiv.inner-text[data-v-0922f59c] {\n  display: none;\n}\n.inner:not(.inner-text-top) .inner-text[data-v-0922f59c] {\n  top: 40px;\n}\n.inner.inner-text-top .inner-text[data-v-0922f59c] {\n  bottom: 40px;\n}\n.month:hover div.inner[data-v-0922f59c] {\n  position: relative;\n  background: #eee;\n  cursor: pointer;\n}\n.month:hover div.inner-text[data-v-0922f59c] {\n  position: absolute;\n  right: 0;\n  padding: 15px;\n  width: 400px;\n  max-width: 400px;\n  max-height: 200px;\n  text-align: left;\n  font-size: 13px;\n  background: #fff7c8;\n  border-radius: 5px;\n  cursor: pointer;\n  display: block;\n  border: 1px solid #ddd;\n  overflow-y: auto;\n}\n.bg-blue[data-v-0922f59c] {\n  background: aliceblue;\n}\ntd.month[data-v-0922f59c] {\n  vertical-align: middle;\n}\n.w-200[data-v-0922f59c] {\n  min-width: 200px;\n}\n.w-50[data-v-0922f59c] {\n  width: 50%;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=1&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=1&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".NPS-th {\n  cursor: pointer;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n          user-select: none;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".custom-table-rentability th[data-v-6f7e829c], .custom-table-rentability td[data-v-6f7e829c] {\n  padding: 0 15px !important;\n  height: 40px;\n}\n.br1[data-v-6f7e829c] {\n  border-right: 1px solid #bababa;\n}\n.bb1[data-v-6f7e829c] {\n  border-bottom: 1px solid #a7a7a7;\n}\n.c-red[data-v-6f7e829c] {\n  background: rgb(247, 88, 88);\n}\n.c-orange[data-v-6f7e829c] {\n  background: rgb(255, 196, 85);\n}\n.c-yellow[data-v-6f7e829c] {\n  background: rgb(255, 255, 107);\n}\n.c-green[data-v-6f7e829c] {\n  background: rgb(86, 172, 86);\n}\n.edited[data-v-6f7e829c] {\n  background: rgb(239, 236, 130);\n}\n.input[data-v-6f7e829c] {\n  border: 0;\n  margin: 0;\n  width: 110px;\n  padding: 5px 0px 5px 13px;\n  text-align: center;\n}\n.fz-12[data-v-6f7e829c] {\n  font-size: 12px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".JobtronSwitch {\n  display: inline-block;\n  position: relative;\n}\n.JobtronSwitch-switch {\n  display: block;\n  width: 48px;\n  height: 30px;\n  background: #8BABD8;\n  border-radius: 20px;\n  cursor: pointer;\n}\n.JobtronSwitch-switch:before {\n  content: \"\";\n  width: 20px;\n  height: 20px;\n  position: absolute;\n  z-index: 3;\n  top: 5px;\n  left: 5px;\n  background-color: #fff;\n  border-radius: 20px;\n  box-shadow: 0px 4px 4px rgba(50, 50, 71, 0.18), 0px 4px 8px rgba(50, 50, 71, 0.16);\n}\n.JobtronSwitch-input {\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  z-index: 5;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  opacity: 0;\n  cursor: pointer;\n}\n.JobtronSwitch-input:checked ~ .JobtronSwitch-switch {\n  background: #3361FF;\n}\n.JobtronSwitch-input:checked ~ .JobtronSwitch-switch:before {\n  left: auto;\n  right: 5px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".table-custom-forecast {\n  table-layout: fixed;\n  width: auto;\n}\n.table-custom-forecast .td-blue {\n  background-color: #DDE9FF;\n  border: 1px solid #bdcff1 !important;\n}\n.table-custom-forecast thead th {\n  width: 20%;\n  max-width: 20%;\n}\n.table-custom-forecast thead th:first-child {\n  width: 40%;\n  max-width: 40%;\n}\n.table-custom-forecast tbody td input {\n  width: 100%;\n}\n.weekend {\n  background-color: #fef2cb !important;\n}\n.gauge-block {\n  margin-right: 10px;\n  margin-top: 10px;\n}\n.gauge-title {\n  font-weight: bold;\n  display: none;\n  text-align: center;\n  font-size: 20px;\n}\n.w-250 {\n  width: 200px;\n}\n.w-300 {\n  width: 220px;\n}\n.w-full {\n  width: 100%;\n}\n.w-295 {\n  width: 295px;\n  min-width: 295px !important;\n}\n.w-80 {\n  width: 80px;\n  min-width: 80px !important;\n}\n.w-125 {\n  width: 125px;\n  min-width: 125px !important;\n}\n.w-60 {\n  width: 60px;\n  min-width: 60px !important;\n}\n.bg-grey {\n  background: #f0f0f0;\n}\n.fa-cog {\n  display: none;\n  font-size: 12px;\n  position: relative;\n  top: -2px;\n  color: #1076b0;\n  cursor: pointer;\n}\n.gauge {\n  cursor: pointer;\n}\n.gauge:last-child {\n  border-bottom: none;\n}\n.gauge:hover .fa-cog {\n  display: block;\n}\n.br-1 {\n  border-right: 1px solid #f3f3f3;\n  border-bottom: 1px solid #f3f3f3;\n}\n.text-20 {\n  font-size: 20px;\n}\ntable.tops th:first-child,\ntable.tops td:first-child {\n  background: #ebedf5;\n  font-weight: bold;\n  min-width: 200px;\n  text-align: left !important;\n  position: sticky;\n  left: 0;\n  border-right: 2px solid #a1b7cc !important;\n  border-left: 2px solid #a1b7cc !important;\n}\ntable.tops thead td,\ntable.tops thead th {\n  border-left: 1px solid #cccccc !important;\n}\ntable.proceed tr:last-child td {\n  font-weight: 700;\n  color: #045e92;\n}\ninput.form-control.form-control-sm.wiwi {\n  padding: 0 10px;\n  margin-bottom: 4px;\n  width: 100%;\n}\n.link-btn {\n  border-radius: 3px;\n  text-align: center;\n  cursor: pointer;\n  position: absolute;\n  right: 5px;\n  top: 76px;\n}\n.w-700 {\n  width: 700px;\n}\n.w-700 input {\n  border: 0;\n  text-align: center;\n  width: 43px;\n}\n.input {\n  border: 0;\n  text-align: center;\n  margin-bottom: 0;\n  padding-left: 19px;\n  width: 100px;\n  background: transparent;\n}\n.input-2 {\n  text-align: left;\n  width: 100%;\n  border: 0;\n  margin-bottom: 0;\n  background: transparent;\n}\n.no-table {\n  width: auto !important;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TopSwitches_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TopSwitches.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TopSwitches_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TopSwitches_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_style_index_0_id_0922f59c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_style_index_0_id_0922f59c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_style_index_0_id_0922f59c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=1&lang=scss&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=1&lang=scss& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_style_index_1_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./NPS.vue?vue&type=style&index=1&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=1&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_style_index_1_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_style_index_1_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableRentability_vue_vue_type_style_index_0_id_6f7e829c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableRentability_vue_vue_type_style_index_0_id_6f7e829c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableRentability_vue_vue_type_style_index_0_id_6f7e829c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=style&index=0&lang=scss&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=style&index=0&lang=scss& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Top_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Top.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Top_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Top_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/pages/Top/TopSwitches.vue":
/*!***********************************************************!*\
  !*** ./resources/js/components/pages/Top/TopSwitches.vue ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TopSwitches_vue_vue_type_template_id_34cb16d7___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TopSwitches.vue?vue&type=template&id=34cb16d7& */ "./resources/js/components/pages/Top/TopSwitches.vue?vue&type=template&id=34cb16d7&");
/* harmony import */ var _TopSwitches_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TopSwitches.vue?vue&type=script&lang=js& */ "./resources/js/components/pages/Top/TopSwitches.vue?vue&type=script&lang=js&");
/* harmony import */ var _TopSwitches_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TopSwitches.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/pages/Top/TopSwitches.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TopSwitches_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TopSwitches_vue_vue_type_template_id_34cb16d7___WEBPACK_IMPORTED_MODULE_0__.render,
  _TopSwitches_vue_vue_type_template_id_34cb16d7___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/pages/Top/TopSwitches.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/tables/NPS.vue":
/*!************************************************!*\
  !*** ./resources/js/components/tables/NPS.vue ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _NPS_vue_vue_type_template_id_0922f59c_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NPS.vue?vue&type=template&id=0922f59c&scoped=true& */ "./resources/js/components/tables/NPS.vue?vue&type=template&id=0922f59c&scoped=true&");
/* harmony import */ var _NPS_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NPS.vue?vue&type=script&lang=js& */ "./resources/js/components/tables/NPS.vue?vue&type=script&lang=js&");
/* harmony import */ var _NPS_vue_vue_type_style_index_0_id_0922f59c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true& */ "./resources/js/components/tables/NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true&");
/* harmony import */ var _NPS_vue_vue_type_style_index_1_lang_scss___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NPS.vue?vue&type=style&index=1&lang=scss& */ "./resources/js/components/tables/NPS.vue?vue&type=style&index=1&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;



/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _NPS_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _NPS_vue_vue_type_template_id_0922f59c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _NPS_vue_vue_type_template_id_0922f59c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "0922f59c",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/tables/NPS.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/tables/TableRentability.vue":
/*!*************************************************************!*\
  !*** ./resources/js/components/tables/TableRentability.vue ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TableRentability_vue_vue_type_template_id_6f7e829c_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TableRentability.vue?vue&type=template&id=6f7e829c&scoped=true& */ "./resources/js/components/tables/TableRentability.vue?vue&type=template&id=6f7e829c&scoped=true&");
/* harmony import */ var _TableRentability_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TableRentability.vue?vue&type=script&lang=js& */ "./resources/js/components/tables/TableRentability.vue?vue&type=script&lang=js&");
/* harmony import */ var _TableRentability_vue_vue_type_style_index_0_id_6f7e829c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true& */ "./resources/js/components/tables/TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TableRentability_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TableRentability_vue_vue_type_template_id_6f7e829c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _TableRentability_vue_vue_type_template_id_6f7e829c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "6f7e829c",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/tables/TableRentability.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/Switch.vue":
/*!***********************************************!*\
  !*** ./resources/js/components/ui/Switch.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Switch.vue?vue&type=template&id=40141c18& */ "./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&");
/* harmony import */ var _Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Switch.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&");
/* harmony import */ var _Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Switch.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.render,
  _Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/Switch.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Top.vue":
/*!************************************!*\
  !*** ./resources/js/pages/Top.vue ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Top_vue_vue_type_template_id_6ae91248___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Top.vue?vue&type=template&id=6ae91248& */ "./resources/js/pages/Top.vue?vue&type=template&id=6ae91248&");
/* harmony import */ var _Top_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Top.vue?vue&type=script&lang=js& */ "./resources/js/pages/Top.vue?vue&type=script&lang=js&");
/* harmony import */ var _Top_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Top.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/Top.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Top_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Top_vue_vue_type_template_id_6ae91248___WEBPACK_IMPORTED_MODULE_0__.render,
  _Top_vue_vue_type_template_id_6ae91248___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Top.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/pages/Top/TopSwitches.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/pages/Top/TopSwitches.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TopSwitches_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TopSwitches.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TopSwitches_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/tables/NPS.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./resources/js/components/tables/NPS.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./NPS.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/tables/TableRentability.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/tables/TableRentability.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableRentability_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableRentability.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableRentability_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/components/ui/Switch.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Top.vue?vue&type=script&lang=js&":
/*!*************************************************************!*\
  !*** ./resources/js/pages/Top.vue?vue&type=script&lang=js& ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Top_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Top.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Top_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/pages/Top/TopSwitches.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/components/pages/Top/TopSwitches.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TopSwitches_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TopSwitches.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/tables/NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/components/tables/NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true& ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_style_index_0_id_0922f59c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=0&id=0922f59c&lang=scss&scoped=true&");


/***/ }),

/***/ "./resources/js/components/tables/NPS.vue?vue&type=style&index=1&lang=scss&":
/*!**********************************************************************************!*\
  !*** ./resources/js/components/tables/NPS.vue?vue&type=style&index=1&lang=scss& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_style_index_1_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./NPS.vue?vue&type=style&index=1&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=style&index=1&lang=scss&");


/***/ }),

/***/ "./resources/js/components/tables/TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true&":
/*!***********************************************************************************************************************!*\
  !*** ./resources/js/components/tables/TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true& ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableRentability_vue_vue_type_style_index_0_id_6f7e829c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=style&index=0&id=6f7e829c&lang=scss&scoped=true&");


/***/ }),

/***/ "./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************!*\
  !*** ./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/Top.vue?vue&type=style&index=0&lang=scss&":
/*!**********************************************************************!*\
  !*** ./resources/js/pages/Top.vue?vue&type=style&index=0&lang=scss& ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Top_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Top.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/pages/Top/TopSwitches.vue?vue&type=template&id=34cb16d7&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/pages/Top/TopSwitches.vue?vue&type=template&id=34cb16d7& ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TopSwitches_vue_vue_type_template_id_34cb16d7___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TopSwitches_vue_vue_type_template_id_34cb16d7___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TopSwitches_vue_vue_type_template_id_34cb16d7___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TopSwitches.vue?vue&type=template&id=34cb16d7& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=template&id=34cb16d7&");


/***/ }),

/***/ "./resources/js/components/tables/NPS.vue?vue&type=template&id=0922f59c&scoped=true&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/tables/NPS.vue?vue&type=template&id=0922f59c&scoped=true& ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_template_id_0922f59c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_template_id_0922f59c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NPS_vue_vue_type_template_id_0922f59c_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./NPS.vue?vue&type=template&id=0922f59c&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=template&id=0922f59c&scoped=true&");


/***/ }),

/***/ "./resources/js/components/tables/TableRentability.vue?vue&type=template&id=6f7e829c&scoped=true&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/components/tables/TableRentability.vue?vue&type=template&id=6f7e829c&scoped=true& ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableRentability_vue_vue_type_template_id_6f7e829c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableRentability_vue_vue_type_template_id_6f7e829c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableRentability_vue_vue_type_template_id_6f7e829c_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableRentability.vue?vue&type=template&id=6f7e829c&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=template&id=6f7e829c&scoped=true&");


/***/ }),

/***/ "./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&":
/*!******************************************************************************!*\
  !*** ./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=template&id=40141c18& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&");


/***/ }),

/***/ "./resources/js/pages/Top.vue?vue&type=template&id=6ae91248&":
/*!*******************************************************************!*\
  !*** ./resources/js/pages/Top.vue?vue&type=template&id=6ae91248& ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Top_vue_vue_type_template_id_6ae91248___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Top_vue_vue_type_template_id_6ae91248___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Top_vue_vue_type_template_id_6ae91248___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Top.vue?vue&type=template&id=6ae91248& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=template&id=6ae91248&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=template&id=34cb16d7&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/pages/Top/TopSwitches.vue?vue&type=template&id=34cb16d7& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "TopSwitches" },
    _vm._l(_vm.items, function (item, id) {
      return _c(
        "label",
        { key: id, staticClass: "TopSwitches-row" },
        [
          _c("JobtronSwitch", {
            staticClass: "TopSwitches-input",
            attrs: { value: item.value },
            on: {
              input: function ($event) {
                return _vm.$emit("change", { id: item.id, value: $event })
              },
            },
          }),
          _vm._v(" "),
          _c("span", { staticClass: "TopSwitches-label" }, [
            _vm._v("\n\t\t\t" + _vm._s(item.name) + "\n\t\t"),
          ]),
        ],
        1
      )
    }),
    0
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=template&id=0922f59c&scoped=true&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/NPS.vue?vue&type=template&id=0922f59c&scoped=true& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "mb-0" }, [
    _vm.show_header
      ? _c("div", { staticClass: "row mb-3 mt-3" }, [
          _c("div", { staticClass: "col-2" }, [
            _c(
              "select",
              {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.currentYear,
                    expression: "currentYear",
                  },
                ],
                staticClass: "form-control",
                on: {
                  change: [
                    function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.currentYear = $event.target.multiple
                        ? $$selectedVal
                        : $$selectedVal[0]
                    },
                    _vm.fetchData,
                  ],
                },
              },
              _vm._l(_vm.years, function (year) {
                return _c("option", { key: year, domProps: { value: year } }, [
                  _vm._v("\n\t\t\t\t\t" + _vm._s(year) + "\n\t\t\t\t"),
                ])
              }),
              0
            ),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-1" }, [
            _c(
              "div",
              {
                staticClass: "btn btn-primary rounded",
                on: {
                  click: function ($event) {
                    return _vm.fetchData()
                  },
                },
              },
              [_c("i", { staticClass: "fa fa-redo-alt" })]
            ),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-6" }),
          _vm._v(" "),
          _c("div", { staticClass: "col-3" }),
        ])
      : _vm._e(),
    _vm._v(" "),
    _c("div", { staticClass: "table-responsive table-container mt-4" }, [
      _c(
        "table",
        { key: _vm.ukey, staticClass: "table custom-table-nps table-bordered" },
        [
          _c("thead", [
            _c(
              "tr",
              [
                _vm._l(_vm.fields, function (field, key) {
                  return [
                    _c(
                      "th",
                      {
                        key: key,
                        staticClass: "NPS-th",
                        class: field.klass,
                        on: {
                          click: function ($event) {
                            return _vm.doSort(field.key)
                          },
                        },
                      },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t\t" +
                            _vm._s(field.name) +
                            "\n\t\t\t\t\t\t"
                        ),
                      ]
                    ),
                  ]
                }),
              ],
              2
            ),
          ]),
          _vm._v(" "),
          _c(
            "tbody",
            _vm._l(_vm.sorted, function (item, index) {
              return _c(
                "tr",
                { key: index },
                [
                  _vm._l(_vm.fields, function (field, key) {
                    return [
                      _c("td", { key: key, class: field.klass }, [
                        _c(
                          "div",
                          {
                            staticClass: "inner",
                            class: {
                              "inner-text-top": index > _vm.fields.length - 4,
                            },
                          },
                          [
                            _c("div", [_vm._v(_vm._s(item[field.key]))]),
                            _vm._v(" "),
                            _c("div", { staticClass: "inner-text" }, [
                              item.texts[field.key] !== undefined
                                ? _c("b", [
                                    _vm._v(
                                      "Оценки (" +
                                        _vm._s(item.grades[field.key]) +
                                        ")"
                                    ),
                                  ])
                                : _vm._e(),
                              _vm._v(" "),
                              _c("div", { staticClass: "d-flex" }, [
                                _c(
                                  "div",
                                  { staticClass: "w-50" },
                                  [
                                    _c("b", [
                                      _vm._v(
                                        "Плюсы (" +
                                          _vm._s(
                                            item.texts[field.key] !== undefined
                                              ? item.texts[field.key].length
                                              : 0
                                          ) +
                                          ")"
                                      ),
                                    ]),
                                    _vm._v(" "),
                                    _vm._l(
                                      item.texts[field.key],
                                      function (text, plusIndex) {
                                        return _c("div", { key: plusIndex }, [
                                          _c("b", [
                                            _vm._v(_vm._s(plusIndex + 1) + ":"),
                                          ]),
                                          _vm._v(
                                            " " +
                                              _vm._s(text) +
                                              "\n\t\t\t\t\t\t\t\t\t\t\t"
                                          ),
                                        ])
                                      }
                                    ),
                                  ],
                                  2
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { staticClass: "w-50" },
                                  [
                                    _c("b", [
                                      _vm._v(
                                        "Минусы (" +
                                          _vm._s(
                                            item.minuses[field.key] !==
                                              undefined
                                              ? item.minuses[field.key].length
                                              : 0
                                          ) +
                                          ")"
                                      ),
                                    ]),
                                    _vm._v(" "),
                                    _vm._l(
                                      item.minuses[field.key],
                                      function (text, minusIndex) {
                                        return _c("div", { key: minusIndex }, [
                                          _c("b", [
                                            _vm._v(
                                              _vm._s(minusIndex + 1) + ":"
                                            ),
                                          ]),
                                          _vm._v(
                                            " " +
                                              _vm._s(text) +
                                              "\n\t\t\t\t\t\t\t\t\t\t\t"
                                          ),
                                        ])
                                      }
                                    ),
                                  ],
                                  2
                                ),
                              ]),
                            ]),
                          ]
                        ),
                      ]),
                    ]
                  }),
                ],
                2
              )
            }),
            0
          ),
        ]
      ),
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "empty-space" }),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=template&id=6f7e829c&scoped=true&":
/*!***********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableRentability.vue?vue&type=template&id=6f7e829c&scoped=true& ***!
  \***********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { key: _vm.skey, staticClass: "mb-3" }, [
    _c("div", { staticClass: "table-container" }, [
      _c(
        "table",
        {
          staticClass:
            "table table-bordered table-responsive whitespace-no-wrap custom-table-rentability",
        },
        [
          _c("thead", [
            _c(
              "tr",
              [
                _c("th", { staticClass: "b-table-sticky-column" }),
                _vm._v(" "),
                _c("th"),
                _vm._v(" "),
                _vm._l(_vm.months, function (m, key) {
                  return [
                    _c(
                      "th",
                      {
                        key: key,
                        staticClass: "text-center",
                        attrs: { colspan: "2" },
                      },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t\t" + _vm._s(m) + "\n\t\t\t\t\t\t"
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "th",
                      { key: key + "a", staticClass: "br1 text-center" },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t\t" +
                            _vm._s(_vm.tops[key]) +
                            "\n\t\t\t\t\t\t"
                        ),
                      ]
                    ),
                  ]
                }),
              ],
              2
            ),
            _vm._v(" "),
            _c(
              "tr",
              [
                _c("th", { staticClass: "b-table-sticky-column" }, [
                  _c("div", { staticClass: "d-flex align-items-center" }, [
                    _c(
                      "p",
                      {
                        staticClass: "mb-0 fz-12",
                        on: {
                          click: function ($event) {
                            return _vm.sort("name")
                          },
                        },
                      },
                      [
                        _vm._v("\n\t\t\t\t\t\t\t\tНазвание "),
                        _c("i", { staticClass: "fa fa-sort ml-1" }),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("th", [
                  _c("div", { staticClass: "d-flex align-items-center" }, [
                    _c(
                      "p",
                      {
                        staticClass: "mb-0 fz-12",
                        on: {
                          click: function ($event) {
                            return _vm.sort("date")
                          },
                        },
                      },
                      [
                        _vm._v("\n\t\t\t\t\t\t\t\tДата "),
                        _c("i", { staticClass: "fa fa-sort ml-1" }),
                      ]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _vm._l(12, function (i) {
                  return [
                    _c(
                      "th",
                      {
                        key: i,
                        staticClass: "font-bold text-center  bb1",
                        on: {
                          click: function ($event) {
                            return _vm.sort("l" + i)
                          },
                        },
                      },
                      [_vm._m(0, true)]
                    ),
                    _vm._v(" "),
                    _c(
                      "th",
                      {
                        key: i + "a",
                        staticClass: "font-bold text-center bb1",
                        on: {
                          click: function ($event) {
                            return _vm.sort("c" + i)
                          },
                        },
                      },
                      [_vm._m(1, true)]
                    ),
                    _vm._v(" "),
                    _c(
                      "th",
                      {
                        key: i + "b",
                        staticClass: "font-bold text-center br1 bb1",
                        on: {
                          click: function ($event) {
                            return _vm.sort("r" + i)
                          },
                        },
                      },
                      [_vm._m(2, true)]
                    ),
                  ]
                }),
              ],
              2
            ),
          ]),
          _vm._v(" "),
          _c(
            "tbody",
            _vm._l(_vm.items, function (item, index) {
              return _c(
                "tr",
                { key: index },
                [
                  _c(
                    "td",
                    {
                      staticClass:
                        "table-primary b-table-sticky-column text-left px-2 t-name wdf",
                    },
                    [_c("div", [_vm._v(_vm._s(item.name))])]
                  ),
                  _vm._v(" "),
                  _c("td", { staticClass: "text-center" }, [
                    _c("div", [_vm._v(_vm._s(item.date_formatted))]),
                  ]),
                  _vm._v(" "),
                  _vm._l(12, function (i) {
                    return [
                      _c(
                        "td",
                        {
                          key: i,
                          staticClass: "text-center",
                          class: { "p-0": index != 0 },
                        },
                        [
                          index != 0
                            ? _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: item["l" + i],
                                    expression: "item['l' + i]",
                                  },
                                ],
                                staticClass: "input",
                                class: { edited: item["ed" + i] },
                                attrs: { type: "number" },
                                domProps: { value: item["l" + i] },
                                on: {
                                  change: function ($event) {
                                    return _vm.update(i, index)
                                  },
                                  input: function ($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(item, "l" + i, $event.target.value)
                                  },
                                },
                              })
                            : _c("div", [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t\t" +
                                    _vm._s(item["l" + i]) +
                                    "\n\t\t\t\t\t\t\t"
                                ),
                              ]),
                        ]
                      ),
                      _vm._v(" "),
                      _c("td", { key: i + "a", staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t\t" +
                            _vm._s(_vm.numberWithCommas(item["c" + i])) +
                            "\n\t\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c(
                        "td",
                        {
                          key: i + "b",
                          staticClass: "text-center br1",
                          class: {
                            "c-red text-white":
                              item["rc" + i] < 20 && item["rc" + i] != "",
                            "c-orange":
                              item["rc" + i] >= 20 && item["rc" + i] < 50,
                            "c-yellow":
                              item["rc" + i] >= 50 && item["rc" + i] < 75,
                            "c-green text-white": item["rc" + i] >= 75,
                          },
                        },
                        [
                          _vm._v(
                            "\n\t\t\t\t\t\t\t" +
                              _vm._s(item["r" + i]) +
                              "\n\t\t\t\t\t\t"
                          ),
                        ]
                      ),
                    ]
                  }),
                ],
                2
              )
            }),
            0
          ),
        ]
      ),
    ]),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "d-flex align-items-center" }, [
      _vm._v("\n\t\t\t\t\t\t\t\tвыручка "),
      _c("i", { staticClass: "fa fa-sort ml-1" }),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "d-flex align-items-center" }, [
      _vm._v("\n\t\t\t\t\t\t\t\tФОТ "),
      _c("i", { staticClass: "fa fa-sort ml-1" }),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "d-flex align-items-center" }, [
      _vm._v("\n\t\t\t\t\t\t\t\tМаржа "),
      _c("i", { staticClass: "fa fa-sort ml-1" }),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("span", { staticClass: "JobtronSwitch" }, [
    _c("input", {
      staticClass: "JobtronSwitch-input",
      attrs: { type: "checkbox" },
      domProps: { checked: _vm.localValue },
      on: {
        input: function ($event) {
          return _vm.$emit("input", $event.target.checked)
        },
      },
    }),
    _vm._v(" "),
    _c("span", { staticClass: "JobtronSwitch-switch" }),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=template&id=6ae91248&":
/*!**********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Top.vue?vue&type=template&id=6ae91248& ***!
  \**********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.data
    ? _c(
        "div",
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-3" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.monthInfo.currentMonth,
                      expression: "monthInfo.currentMonth",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.monthInfo,
                          "currentMonth",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      _vm.fetchData,
                    ],
                  },
                },
                _vm._l(_vm.$moment.months(), function (month) {
                  return _c(
                    "option",
                    { key: month, domProps: { value: month } },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(month) + "\n\t\t\t\t")]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-2" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.currentYear,
                      expression: "currentYear",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.currentYear = $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      },
                      _vm.fetchData,
                    ],
                  },
                },
                _vm._l(_vm.years, function (year) {
                  return _c(
                    "option",
                    { key: year, domProps: { value: year } },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(year) + "\n\t\t\t\t")]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-1" }, [
              _c(
                "div",
                {
                  staticClass: "btn btn-primary rounded",
                  on: {
                    click: function ($event) {
                      return _vm.fetchData()
                    },
                  },
                },
                [_c("i", { staticClass: "fa fa-redo-alt" })]
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-6" }),
          ]),
          _vm._v(" "),
          _c(
            "b-tabs",
            {
              staticClass: "mt-4",
              attrs: { type: "card" },
              scopedSlots: _vm._u(
                [
                  {
                    key: "tabs-end",
                    fn: function () {
                      return [
                        _vm.activeTab < 3
                          ? _c(
                              "JobtronButton",
                              {
                                staticClass: "ml-a",
                                attrs: { small: "", secondary: "" },
                                on: {
                                  click: function ($event) {
                                    _vm.isArchiveOpen = true
                                  },
                                },
                              },
                              [_c("i", { staticClass: "icon-nd-settings" })]
                            )
                          : _vm._e(),
                      ]
                    },
                    proxy: true,
                  },
                ],
                null,
                false,
                2452232466
              ),
              model: {
                value: _vm.activeTab,
                callback: function ($$v) {
                  _vm.activeTab = $$v
                },
                expression: "activeTab",
              },
            },
            [
              _c(
                "b-tab",
                { key: "1", attrs: { title: "Полезность", card: "" } },
                [
                  _c(
                    "div",
                    {
                      staticClass: "d-flex flex-column",
                      staticStyle: { "margin-bottom": "350px" },
                    },
                    [
                      _c("TopGauges", {
                        key: _vm.ukey,
                        attrs: {
                          utility_items: _vm.activeUtility,
                          editable: true,
                          wrapper_class: " br-1",
                          page: "top",
                        },
                      }),
                    ],
                    1
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "b-tab",
                {
                  key: "2",
                  attrs: { title: "Рентабельность операторов", card: "" },
                  on: {
                    click: function ($event) {
                      return _vm.showIcons()
                    },
                  },
                },
                [
                  _c(
                    "div",
                    { key: _vm.ukey, staticClass: "d-flex flex-wrap mb-5" },
                    [
                      _vm._l(_vm.rentability, function (gauge, g_index) {
                        return [
                          _vm.isActiveRentability(gauge.group_id)
                            ? _c(
                                "div",
                                { key: gauge.name, staticClass: "gauge-block" },
                                [
                                  _c(
                                    "div",
                                    {
                                      on: {
                                        click: function ($event) {
                                          gauge.editable = !gauge.editable
                                        },
                                      },
                                    },
                                    [
                                      _c("VGauge", {
                                        attrs: {
                                          value: gauge.value,
                                          unit: "%",
                                          options: gauge.options,
                                          "max-value": Number(gauge.max_value),
                                          top: true,
                                          height: "75px",
                                          width: "125px",
                                          "gauge-value-class": "gauge-span",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "p",
                                    {
                                      staticClass: "text-center font-bold",
                                      staticStyle: {
                                        "font-size": "14px",
                                        "margin-bottom": "0",
                                      },
                                    },
                                    [
                                      _c(
                                        "a",
                                        {
                                          attrs: {
                                            href:
                                              "/timetracking/an?group=" +
                                              gauge.group_id +
                                              "&active=1&load=1",
                                            target: "_blank",
                                          },
                                        },
                                        [_vm._v(_vm._s(gauge.name))]
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "p",
                                    {
                                      staticClass:
                                        "text-center font-bold text-14",
                                    },
                                    [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t" +
                                          _vm._s(gauge.value) +
                                          "%\n\t\t\t\t\t\t"
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  gauge.editable
                                    ? _c(
                                        "div",
                                        {
                                          staticClass: "mb-5 edt-window",
                                          staticStyle: { width: "125px" },
                                        },
                                        [
                                          _c("div", [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "d-flex justify-content-between align-items-center",
                                              },
                                              [
                                                _c(
                                                  "span",
                                                  {
                                                    staticClass: "pr-2 l-label",
                                                  },
                                                  [_vm._v("Max")]
                                                ),
                                                _vm._v(" "),
                                                _c("input", {
                                                  directives: [
                                                    {
                                                      name: "model",
                                                      rawName: "v-model",
                                                      value: gauge.max_value,
                                                      expression:
                                                        "gauge.max_value",
                                                    },
                                                  ],
                                                  staticClass:
                                                    "form-control form-control-sm w-250 wiwi",
                                                  attrs: { type: "text" },
                                                  domProps: {
                                                    value: gauge.max_value,
                                                  },
                                                  on: {
                                                    input: function ($event) {
                                                      if (
                                                        $event.target.composing
                                                      ) {
                                                        return
                                                      }
                                                      _vm.$set(
                                                        gauge,
                                                        "max_value",
                                                        $event.target.value
                                                      )
                                                    },
                                                  },
                                                }),
                                              ]
                                            ),
                                          ]),
                                          _vm._v(" "),
                                          _c("div", { staticClass: "d-flex" }, [
                                            _c(
                                              "button",
                                              {
                                                staticClass:
                                                  "btn btn-primary rounded mt-1 mr-2",
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.saveRentGauge(
                                                      g_index
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n\t\t\t\t\t\t\t\t\tСохранить\n\t\t\t\t\t\t\t\t"
                                                ),
                                              ]
                                            ),
                                          ]),
                                        ]
                                      )
                                    : _vm._e(),
                                ]
                              )
                            : _vm._e(),
                        ]
                      }),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "ml-a pt-4" },
                        [
                          _vm.archiveUtility.length
                            ? _c(
                                "JobtronButton",
                                {
                                  attrs: { title: "Открыть архив" },
                                  on: {
                                    click: function ($event) {
                                      _vm.isArchiveOpen = true
                                    },
                                  },
                                },
                                [_vm._v("\n\t\t\t\t\t\tАрхив\n\t\t\t\t\t")]
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    2
                  ),
                  _vm._v(" "),
                  _c("TableRentability", {
                    attrs: {
                      year: +_vm.currentYear,
                      month: +_vm.monthInfo.month,
                    },
                  }),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-tab", { key: "3", attrs: { title: "Выручка", card: "" } }, [
                _c(
                  "div",
                  { staticClass: "table-responsive table-container mt-4" },
                  [
                    _c(
                      "table",
                      {
                        staticClass:
                          "table table-bordered whitespace-no-wrap custom-table-revenue",
                      },
                      [
                        _c("thead", [
                          _c(
                            "tr",
                            _vm._l(
                              _vm.proceeds.fields,
                              function (field, findex) {
                                return _c(
                                  "th",
                                  {
                                    key: findex,
                                    staticClass: "t-name table-title",
                                    class: {
                                      "w-295 b-table-sticky-column":
                                        findex == 0,
                                      "w-125": findex == 1,
                                      "w-80": findex == 2,
                                      "w-60": findex == 3,
                                      "text-center": findex != 0,
                                      "text-left": findex == 0,
                                    },
                                  },
                                  [
                                    ["+/-"].includes(field)
                                      ? [
                                          _c("i", {
                                            directives: [
                                              {
                                                name: "b-popover",
                                                rawName:
                                                  "v-b-popover.hover.right.html",
                                                value:
                                                  "100% - ( План * Кол-во календарных дней )/ (Итого * Кол-во отработанных дней)",
                                                expression:
                                                  "'100% - ( План * Кол-во календарных дней )/ (Итого * Кол-во отработанных дней)'",
                                                modifiers: {
                                                  hover: true,
                                                  right: true,
                                                  html: true,
                                                },
                                              },
                                            ],
                                            staticClass: "fa fa-info-circle",
                                            attrs: {
                                              title: "Опережение плана",
                                            },
                                          }),
                                        ]
                                      : _vm._e(),
                                    _vm._v(" "),
                                    ["%"].includes(field)
                                      ? [
                                          _c("i", {
                                            directives: [
                                              {
                                                name: "b-popover",
                                                rawName:
                                                  "v-b-popover.hover.right.html",
                                                value: "( Итого / План ) * 100",
                                                expression:
                                                  "'( Итого / План ) * 100'",
                                                modifiers: {
                                                  hover: true,
                                                  right: true,
                                                  html: true,
                                                },
                                              },
                                            ],
                                            staticClass: "fa fa-info-circle",
                                            attrs: {
                                              title: "Выполнение плана",
                                            },
                                          }),
                                        ]
                                      : _vm._e(),
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\t" +
                                        _vm._s(field) +
                                        "  "
                                    ),
                                    field == "Отдел"
                                      ? _c("i", {
                                          staticClass: "fa fa-plus-square",
                                          on: {
                                            click: function ($event) {
                                              return _vm.addRow()
                                            },
                                          },
                                        })
                                      : _vm._e(),
                                  ],
                                  2
                                )
                              }
                            ),
                            0
                          ),
                        ]),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          [
                            _vm._l(
                              _vm.proceeds.records,
                              function (record, rindex) {
                                return [
                                  (_vm.proceedsSwitch[record.group_id] &&
                                    _vm.proceedsSwitch[record.group_id]
                                      .value) ||
                                  !record.group_id
                                    ? _c(
                                        "tr",
                                        { key: rindex },
                                        _vm._l(
                                          _vm.proceeds.fields,
                                          function (field, findex) {
                                            return _c(
                                              "td",
                                              {
                                                key: findex,
                                                staticClass:
                                                  "t-name table-title",
                                                class: {
                                                  "bg-grey": [
                                                    "w1",
                                                    "w2",
                                                    "w3",
                                                    "w4",
                                                    "w5",
                                                    "w6",
                                                  ].includes(field),
                                                  weekend: _vm.isWeekend(field),
                                                  "text-left b-table-sticky-column":
                                                    ["Отдел"].includes(field),
                                                },
                                              },
                                              [
                                                ![
                                                  "%",
                                                  "План",
                                                  "Итого",
                                                  "+/-",
                                                  "Отдел",
                                                ].includes(field)
                                                  ? [
                                                      record["group_id"] < 0
                                                        ? _c("div", [
                                                            _c("input", {
                                                              directives: [
                                                                {
                                                                  name: "model",
                                                                  rawName:
                                                                    "v-model",
                                                                  value:
                                                                    record[
                                                                      field
                                                                    ],
                                                                  expression:
                                                                    "record[field]",
                                                                },
                                                              ],
                                                              staticClass:
                                                                "input",
                                                              attrs: {
                                                                type: "number",
                                                              },
                                                              domProps: {
                                                                value:
                                                                  record[field],
                                                              },
                                                              on: {
                                                                change:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    return _vm.updateProceed(
                                                                      record,
                                                                      field,
                                                                      "day"
                                                                    )
                                                                  },
                                                                input:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    if (
                                                                      $event
                                                                        .target
                                                                        .composing
                                                                    ) {
                                                                      return
                                                                    }
                                                                    _vm.$set(
                                                                      record,
                                                                      field,
                                                                      $event
                                                                        .target
                                                                        .value
                                                                    )
                                                                  },
                                                              },
                                                            }),
                                                          ])
                                                        : _c("div", [
                                                            record[field] != 0
                                                              ? _c("span", [
                                                                  _vm._v(
                                                                    _vm._s(
                                                                      record[
                                                                        field
                                                                      ]
                                                                    )
                                                                  ),
                                                                ])
                                                              : _c("span"),
                                                          ]),
                                                    ]
                                                  : [
                                                      field == "Отдел"
                                                        ? [
                                                            record[
                                                              "group_id"
                                                            ] >= 0
                                                              ? _c(
                                                                  "a",
                                                                  {
                                                                    attrs: {
                                                                      href:
                                                                        "/timetracking/an?group=" +
                                                                        record[
                                                                          "group_id"
                                                                        ] +
                                                                        "&active=1&load=1",
                                                                      target:
                                                                        "_blank",
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                        _vm._s(
                                                                          record[
                                                                            field
                                                                          ]
                                                                        ) +
                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t"
                                                                    ),
                                                                  ]
                                                                )
                                                              : _c("div", [
                                                                  _c("input", {
                                                                    directives:
                                                                      [
                                                                        {
                                                                          name: "model",
                                                                          rawName:
                                                                            "v-model",
                                                                          value:
                                                                            record[
                                                                              field
                                                                            ],
                                                                          expression:
                                                                            "record[field]",
                                                                        },
                                                                      ],
                                                                    staticClass:
                                                                      "input-2",
                                                                    attrs: {
                                                                      type: "text",
                                                                    },
                                                                    domProps: {
                                                                      value:
                                                                        record[
                                                                          field
                                                                        ],
                                                                    },
                                                                    on: {
                                                                      change:
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          return _vm.updateProceed(
                                                                            record,
                                                                            field,
                                                                            "name"
                                                                          )
                                                                        },
                                                                      input:
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          if (
                                                                            $event
                                                                              .target
                                                                              .composing
                                                                          ) {
                                                                            return
                                                                          }
                                                                          _vm.$set(
                                                                            record,
                                                                            field,
                                                                            $event
                                                                              .target
                                                                              .value
                                                                          )
                                                                        },
                                                                    },
                                                                  }),
                                                                ]),
                                                            _vm._v(" "),
                                                            record.deleted_at
                                                              ? _c("i", {
                                                                  directives: [
                                                                    {
                                                                      name: "b-popover",
                                                                      rawName:
                                                                        "v-b-popover.hover.right.html",
                                                                      value:
                                                                        "Аналитика архвирована " +
                                                                        _vm
                                                                          .$moment(
                                                                            record.deleted_at,
                                                                            "YYYY-MM-DD"
                                                                          )
                                                                          .format(
                                                                            "DD.MM.YYYY"
                                                                          ),
                                                                      expression:
                                                                        "'Аналитика архвирована ' + $moment(record.deleted_at, 'YYYY-MM-DD').format('DD.MM.YYYY')",
                                                                      modifiers:
                                                                        {
                                                                          hover: true,
                                                                          right: true,
                                                                          html: true,
                                                                        },
                                                                    },
                                                                  ],
                                                                  staticClass:
                                                                    "fa fa-info-circle",
                                                                })
                                                              : _vm._e(),
                                                          ]
                                                        : [
                                                            _c("div", [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                  _vm._s(
                                                                    record[
                                                                      field
                                                                    ]
                                                                  ) +
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t"
                                                              ),
                                                            ]),
                                                          ],
                                                    ],
                                              ],
                                              2
                                            )
                                          }
                                        ),
                                        0
                                      )
                                    : _vm._e(),
                                ]
                              }
                            ),
                          ],
                          2
                        ),
                      ]
                    ),
                  ]
                ),
              ]),
              _vm._v(" "),
              _c("b-tab", { key: "6", attrs: { title: "", card: "" } }),
              _vm._v(" "),
              _c("b-tab", { key: "7", attrs: { title: "", card: "" } }),
              _vm._v(" "),
              _c("b-tab", { key: "8", attrs: { title: "", card: "" } }),
              _vm._v(" "),
              _c(
                "b-tab",
                { key: "4", attrs: { title: "Прогноз", card: "" } },
                [
                  _c(
                    "b-row",
                    { staticClass: "m-0" },
                    [
                      _c(
                        "b-col",
                        {
                          staticClass: "p-0 mt-4",
                          attrs: { cols: "12", md: "8" },
                        },
                        [
                          _c(
                            "div",
                            { staticClass: "forecast table-container" },
                            [
                              _c(
                                "table",
                                {
                                  staticClass:
                                    "table table-bordered table-custom-forecast",
                                },
                                [
                                  _c("thead", [
                                    _c(
                                      "th",
                                      {
                                        staticClass:
                                          "text-left t-name table-title td-blue",
                                      },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\tОтдел\n\n\t\t\t\t\t\t\t\t\t"
                                        ),
                                        _c("i", {
                                          directives: [
                                            {
                                              name: "b-popover",
                                              rawName:
                                                "v-b-popover.hover.right.html",
                                              value:
                                                "Прогноз по принятию сотрудников на месяц",
                                              expression:
                                                "'Прогноз по принятию сотрудников на месяц'",
                                              modifiers: {
                                                hover: true,
                                                right: true,
                                                html: true,
                                              },
                                            },
                                          ],
                                          staticClass: "fa fa-info-circle",
                                          attrs: { title: "Отдел" },
                                        }),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "th",
                                      {
                                        staticClass:
                                          "text-center t-name table-title",
                                      },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\tПлан\n\n\t\t\t\t\t\t\t\t\t"
                                        ),
                                        _c("i", {
                                          directives: [
                                            {
                                              name: "b-popover",
                                              rawName:
                                                "v-b-popover.hover.right.html",
                                              value:
                                                "Общий план операторов на проект от Заказчика",
                                              expression:
                                                "'Общий план операторов на проект от Заказчика'",
                                              modifiers: {
                                                hover: true,
                                                right: true,
                                                html: true,
                                              },
                                            },
                                          ],
                                          staticClass: "fa fa-info-circle",
                                          attrs: { title: "План" },
                                        }),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "th",
                                      {
                                        staticClass:
                                          "text-center t-name table-title",
                                      },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\tФакт\n\n\t\t\t\t\t\t\t\t\t"
                                        ),
                                        _c("i", {
                                          directives: [
                                            {
                                              name: "b-popover",
                                              rawName:
                                                "v-b-popover.hover.right.html",
                                              value:
                                                "Фактически работают в группе на должности оператора",
                                              expression:
                                                "'Фактически работают в группе на должности оператора'",
                                              modifiers: {
                                                hover: true,
                                                right: true,
                                                html: true,
                                              },
                                            },
                                          ],
                                          staticClass: "fa fa-info-circle",
                                          attrs: { title: "Факт" },
                                        }),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "th",
                                      {
                                        staticClass:
                                          "text-center t-name table-title",
                                      },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\tОсталось принять\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c(
                                    "tbody",
                                    _vm._l(
                                      _vm.prognoz_groups,
                                      function (group, index) {
                                        return _c("tr", { key: index }, [
                                          _c(
                                            "td",
                                            {
                                              staticClass:
                                                "text-left t-name table-title td-blue align-middle",
                                            },
                                            [
                                              _vm._v(
                                                "\n\t\t\t\t\t\t\t\t\t\t" +
                                                  _vm._s(group.name) +
                                                  "\n\t\t\t\t\t\t\t\t\t"
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "td",
                                            {
                                              staticClass:
                                                "text-center t-name table-title align-middle",
                                            },
                                            [
                                              _c("input", {
                                                directives: [
                                                  {
                                                    name: "model",
                                                    rawName: "v-model",
                                                    value: group.plan,
                                                    expression: "group.plan",
                                                  },
                                                ],
                                                attrs: { type: "number" },
                                                domProps: { value: group.plan },
                                                on: {
                                                  change: function ($event) {
                                                    return _vm.saveGroupPlan(
                                                      index
                                                    )
                                                  },
                                                  input: function ($event) {
                                                    if (
                                                      $event.target.composing
                                                    ) {
                                                      return
                                                    }
                                                    _vm.$set(
                                                      group,
                                                      "plan",
                                                      $event.target.value
                                                    )
                                                  },
                                                },
                                              }),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "td",
                                            {
                                              staticClass:
                                                "text-center t-name table-title align-middle",
                                            },
                                            [
                                              _vm._v(
                                                "\n\t\t\t\t\t\t\t\t\t\t" +
                                                  _vm._s(group.applied) +
                                                  "\n\t\t\t\t\t\t\t\t\t"
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "td",
                                            {
                                              staticClass:
                                                "text-center t-name table-title align-middle",
                                            },
                                            [
                                              _vm._v(
                                                "\n\t\t\t\t\t\t\t\t\t\t" +
                                                  _vm._s(
                                                    isNaN(group.left_to_apply)
                                                      ? 0
                                                      : Number(
                                                          group.left_to_apply
                                                        )
                                                  ) +
                                                  "\n\t\t\t\t\t\t\t\t\t"
                                              ),
                                            ]
                                          ),
                                        ])
                                      }
                                    ),
                                    0
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-tab",
                { key: "5", attrs: { title: "NPS", card: "" } },
                [
                  _c("NPS", {
                    attrs: {
                      activeuserid: +_vm.activeuserid,
                      show_header: false,
                    },
                  }),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "SideBar",
            {
              attrs: {
                title: "Активные спидометры",
                width: "35%",
                open: _vm.isArchiveOpen,
              },
              on: {
                close: function ($event) {
                  _vm.isArchiveOpen = false
                },
              },
            },
            [
              _c("TopSwitches", {
                attrs: { items: _vm.switches },
                on: { change: _vm.onChangeSwitch },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c("div", { staticClass: "empty-space" }),
        ],
        1
      )
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);