"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["PlaylistsPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'UISidebar',
  props: {
    title: {
      type: String,
      "default": ''
    },
    open: {
      type: Boolean
    },
    width: {
      type: String,
      "default": ''
    },
    link: {
      type: String,
      "default": ''
    }
  },
  data: function data() {
    return {};
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Playlists.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Playlists.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_ui_SimpleSidebar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/ui/SimpleSidebar */ "./resources/js/components/ui/SimpleSidebar.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */

var PlaylistEdit = function PlaylistEdit() {
  return __webpack_require__.e(/*! import() | PlaylistEdit */ "PlaylistEdit").then(__webpack_require__.bind(__webpack_require__, /*! @/pages/PlaylistEdit */ "./resources/js/pages/PlaylistEdit.vue"));
}; // редактирование плейлиста

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'PlayLists',
  components: {
    SimpleSidebar: _components_ui_SimpleSidebar__WEBPACK_IMPORTED_MODULE_0__["default"],
    PlaylistEdit: PlaylistEdit
  },
  props: {
    token: {
      type: String,
      "default": ''
    },
    /* eslint-disable vue/prop-name-casing */
    can_edit: {
      type: Boolean,
      "default": false
    },
    category: {
      type: Number,
      "default": 0
    },
    playlist: {
      type: Number,
      "default": 0
    },
    video: {
      type: Number,
      "default": 0
    }
  },
  data: function data() {
    return {
      categories: [],
      showEditCat: false,
      file_img: null,
      editingPlaylist: {
        title: '',
        text: '',
        category_id: ''
      },
      showEditPlaylist: false,
      user_id: 0,
      mode: 'read',
      activeCat: null,
      newcat: '',
      newPlaylist: '',
      activePlaylist: null,
      showAddPlaylist: false,
      showAddCategory: false,
      showSettings: false,
      allow_save_video_without_test: false,
      mylink: window.location.protocol + '//' + window.location.host + window.location.pathname.substring(0, 16),
      data_category: this.category,
      data_playlist: this.playlist,
      myvideo: this.video
    };
  },
  watch: {
    token: function token() {
      this.init();
    }
  },
  created: function created() {
    if (this.token) {
      this.init();
    }
  },
  methods: {
    init: function init() {
      this.fetchData();
    },
    addGroup: function addGroup() {
      this.$refs.playlist.addGroup();
    },
    uploadVideo: function uploadVideo() {
      this.$refs.playlist.uploadVideo();
    },
    savePlaylistEdit: function savePlaylistEdit() {
      this.$refs.playlist.savePlaylist();
    },
    clearUrl: function clearUrl() {
      var newUrl = window.location.protocol + '//' + window.location.host + window.location.pathname.substring(0, 16);
      history.pushState(null, null, newUrl);
    },
    fetchData: function fetchData() {
      var _this = this;
      this.axios.get('/playlists/get').then(function (response) {
        _this.categories = response.data.categories;
        _this.user_id = response.data.user_id;
        if (_this.categories.length > 0) {
          _this.activeCat = _this.categories[_this.category - 1];
          if (_this.playlist > 0) {
            _this.activePlaylist = _this.activeCat.playlists[_this.playlist - 1];
          }
        }
      })["catch"](function (error) {
        alert(error);
      });
    },
    selectPl: function selectPl(i) {
      this.activePlaylist = this.activeCat.playlists[i];
      this.data_playlist = i + 1;
      if (history.pushState) {
        var newUrl = this.mylink.concat('/' + this.data_category, '/' + this.data_playlist);
        history.pushState(null, null, newUrl);
      } else {
        console.warn('History API не поддерживает ваш браузер');
      }
    },
    editCat: function editCat(i) {
      this.showEditCat = true;
      this.newcat = this.categories[i].title;
      this.activeCat = this.categories[i];
    },
    movePl: function movePl(i) {
      this.editingPlaylist = this.activeCat.playlists[i];
      this.showEditPlaylist = true;
    },
    deletePl: function deletePl(i) {
      var _this2 = this;
      if (confirm('Вы уверены что хотите удалить плейлист?')) {
        this.axios.post('/playlists/delete', {
          id: this.activeCat.playlists[i].id
        }).then(function () {
          _this2.activeCat.playlists.splice(i, 1);
          _this2.$toast.success('Удалено');
        });
      }
    },
    selectCat: function selectCat(i) {
      this.activeCat = this.categories[i];
      this.activePlaylist = null;
      this.data_category = i + 1;
      this.data_playlist = 0;
      if (history.pushState) {
        var newUrl = this.mylink.concat('/' + this.data_category, '/' + this.data_playlist);
        history.pushState(null, null, newUrl);
      } else {
        console.warn('History API не поддерживает ваш браузер');
      }
      this.myvideo = 0;
    },
    deleteCat: function deleteCat(i) {
      var _this3 = this;
      if (confirm('Вы уверены что хотите удалить категорию?')) {
        this.axios.post('/playlists/delete-cat', {
          id: this.categories[i].id
        }).then(function () {
          _this3.categories.splice(i, 1);
          _this3.activeCat = null;
          _this3.$toast.success('Удалено');
        });
      }
    },
    savePlaylist: function savePlaylist() {
      var _this4 = this;
      var loader = this.$loading.show();
      var formData = new FormData();
      formData.append('file', this.file_img);
      formData.append('playlist', JSON.stringify(this.editingPlaylist));
      this.axios.post('/playlists/save-fast', formData).then(function (response) {
        if (response.data !== '') _this4.editingPlaylist.img = response.data;
        if (_this4.editingPlaylist.category_id != _this4.activeCat.id) {
          _this4.deleteItemFrom(_this4.editingPlaylist.id, _this4.activeCat.playlists);
          var i = _this4.categories.findIndex(function (el) {
            return el.id == _this4.editingPlaylist.category_id;
          });
          if (i != -1) {
            if (response.data !== '') _this4.editingPlaylist.img = response.data;
            _this4.categories[i].playlists.push(_this4.editingPlaylist);
          }
          _this4.showEditPlaylist = false;
          _this4.editingPlaylist = {};
        }
        loader.hide();
        _this4.$toast.success('Сохранено');
      })["catch"](function (error) {
        console.error(error);
        loader.hide();
      });
    },
    deleteItemFrom: function deleteItemFrom(id, from) {
      var i = from.findIndex(function (el) {
        return el.id == id;
      });
      if (i != -1) from.splice(i, 1);
    },
    back: function back() {
      this.activePlaylist = null;
      window.history.replaceState({
        id: '100'
      }, 'Плейлисты', '/video_playlists');
    },
    addCat: function addCat() {
      var _this5 = this;
      if (this.newcat.length <= 2) {
        alert('Слишком короткое название!');
        return '';
      }
      var loader = this.$loading.show();
      this.axios.post('/playlists/add-cat', {
        title: this.newcat
      }).then(function (response) {
        _this5.showAddCategory = false;
        _this5.newcat = '';
        _this5.categories.push(response.data);
        _this5.$toast.success('Успешно создана!');
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    saveCat: function saveCat() {
      var _this6 = this;
      if (this.activeCat.title.length <= 2) {
        alert('Слишком короткое название!');
        return '';
      }
      var loader = this.$loading.show();
      this.axios.post('/playlists/save-cat', {
        title: this.newcat,
        id: this.activeCat.id
      }).then(function () {
        _this6.showEditCat = false;
        _this6.activeCat.title = _this6.newcat;
        _this6.newcat = '';
        _this6.$toast.success('Сохранено!');
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    addPlaylist: function addPlaylist() {
      var _this7 = this;
      if (this.newPlaylist.length <= 2) {
        alert('Слишком короткое название!');
        return '';
      }
      var loader = this.$loading.show();
      this.axios.post('/playlists/add', {
        title: this.newPlaylist,
        cat_id: this.activeCat.id
      }).then(function (response) {
        _this7.showAddPlaylist = false;
        _this7.newPlaylist = '';
        _this7.activeCat.playlists.push(response.data);
        _this7.$toast.success('Успешно создан!');
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    toggleMode: function toggleMode() {
      this.mode = this.mode == 'read' ? 'edit' : 'read';
    },
    get_settings: function get_settings() {
      var _this8 = this;
      this.axios.post('/settings/get', {
        type: 'video'
      }).then(function (response) {
        _this8.allow_save_video_without_test = response.data.settings.allow_save_video_without_test;
        _this8.showSettings = true;
      })["catch"](function (error) {
        alert(error);
      });
    },
    save_settings: function save_settings() {
      var _this9 = this;
      this.axios.post('/settings/save', {
        type: 'video',
        allow_save_video_without_test: this.allow_save_video_without_test
      }).then(function () {
        _this9.showSettings = false;
      })["catch"](function (error) {
        alert(error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".ui-simple-sidebar[data-v-369803ba] {\n  background: rgba(0, 0, 0, 0);\n  width: 100%;\n  height: 100%;\n  left: 0;\n  top: 0;\n  position: fixed;\n  visibility: hidden;\n  transition: 0.3s ease-in-out all;\n  z-index: 101;\n}\n.ui-simple-sidebar-content[data-v-369803ba] {\n  position: absolute;\n  right: -100%;\n  top: 0;\n  border-radius: 12px 0 0 12px;\n  min-height: 450px;\n  background: #fff;\n  z-index: 12;\n  box-shadow: -10px 0px 60px -40px rgba(45, 50, 90, 0.1), 0px 0px 3px 0px rgba(0, 0, 0, 0.05);\n  transition: 0.3s ease-in-out all;\n  overflow: auto;\n}\n.ui-simple-sidebar.is-open[data-v-369803ba] {\n  visibility: visible;\n  background: rgba(0, 0, 0, 0.45);\n}\n.ui-simple-sidebar.is-open .ui-simple-sidebar-content[data-v-369803ba] {\n  right: 60px;\n}\n.ui-simple-sidebar .ui-simple-sidebar-header[data-v-369803ba] {\n  padding: 30px 25px 15px 25px;\n}\n.ui-simple-sidebar .ui-simple-sidebar-header .ui-simple-sidebar-title[data-v-369803ba] {\n  color: #0A1323;\n  font-size: 18px;\n  margin: 0;\n  font-weight: 700;\n}\n.ui-simple-sidebar .ui-simple-sidebar-body[data-v-369803ba] {\n  overflow: auto;\n  max-height: calc(100vh - 135px);\n  min-height: calc(100vh - 135px);\n  padding: 15px 25px 25px 25px;\n}\n.ui-simple-sidebar .ui-simple-sidebar-footer[data-v-369803ba] {\n  min-height: 65px;\n  padding: 15px 25px;\n  border-top: 1px solid #ddd;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue":
/*!******************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& */ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&");
/* harmony import */ var _SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SimpleSidebar.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&");
/* harmony import */ var _SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& */ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "369803ba",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/SimpleSidebar.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Playlists.vue":
/*!******************************************!*\
  !*** ./resources/js/pages/Playlists.vue ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Playlists_vue_vue_type_template_id_1a2cb928___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Playlists.vue?vue&type=template&id=1a2cb928& */ "./resources/js/pages/Playlists.vue?vue&type=template&id=1a2cb928&");
/* harmony import */ var _Playlists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Playlists.vue?vue&type=script&lang=js& */ "./resources/js/pages/Playlists.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Playlists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Playlists_vue_vue_type_template_id_1a2cb928___WEBPACK_IMPORTED_MODULE_0__.render,
  _Playlists_vue_vue_type_template_id_1a2cb928___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Playlists.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Playlists.vue?vue&type=script&lang=js&":
/*!*******************************************************************!*\
  !*** ./resources/js/pages/Playlists.vue?vue&type=script&lang=js& ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Playlists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Playlists.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Playlists.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Playlists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&":
/*!****************************************************************************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_style_index_0_id_369803ba_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=style&index=0&id=369803ba&lang=scss&scoped=true&");


/***/ }),

/***/ "./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SimpleSidebar_vue_vue_type_template_id_369803ba_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/Playlists.vue?vue&type=template&id=1a2cb928&":
/*!*************************************************************************!*\
  !*** ./resources/js/pages/Playlists.vue?vue&type=template&id=1a2cb928& ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Playlists_vue_vue_type_template_id_1a2cb928___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Playlists_vue_vue_type_template_id_1a2cb928___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Playlists_vue_vue_type_template_id_1a2cb928___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Playlists.vue?vue&type=template&id=1a2cb928& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Playlists.vue?vue&type=template&id=1a2cb928&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/SimpleSidebar.vue?vue&type=template&id=369803ba&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "ui-simple-sidebar",
      class: [{ "is-open": _vm.open }],
      on: {
        click: function ($event) {
          if ($event.target !== $event.currentTarget) {
            return null
          }
          return _vm.$emit("close")
        },
      },
    },
    [
      _c(
        "div",
        {
          staticClass: "ui-simple-sidebar-content",
          style: "width:" + _vm.width,
        },
        [
          _c("div", { staticClass: "ui-simple-sidebar-header" }, [
            _c("p", { staticClass: "ui-simple-sidebar-title" }, [
              _vm._v("\n\t\t\t\t" + _vm._s(_vm.title) + "\n\t\t\t"),
            ]),
            _vm._v(" "),
            _c("span", { domProps: { innerHTML: _vm._s(_vm.link) } }),
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "ui-simple-sidebar-body" },
            [_vm._t("body")],
            2
          ),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "ui-simple-sidebar-footer" },
            [_vm._t("footer")],
            2
          ),
        ]
      ),
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Playlists.vue?vue&type=template&id=1a2cb928&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Playlists.vue?vue&type=template&id=1a2cb928& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.token
    ? _c(
        "div",
        { staticClass: "video-playlists" },
        [
          _c("div", { staticClass: "d-flex" }, [
            _c(
              "div",
              { staticClass: "lp" },
              [
                _c("h1", { staticClass: "page-title" }, [
                  _vm._v("\n\t\t\t\tТемы видео\n\t\t\t"),
                ]),
                _vm._v(" "),
                _vm._l(_vm.categories, function (cat, index) {
                  return _c(
                    "div",
                    {
                      key: cat.id,
                      staticClass: "section d-flex aic jcsb my-2",
                      class: {
                        active:
                          _vm.activeCat != null && _vm.activeCat.id == cat.id,
                      },
                      on: {
                        click: function ($event) {
                          return _vm.selectCat(index)
                        },
                      },
                    },
                    [
                      _c("p", { staticClass: "mb-0" }, [
                        _vm._v(
                          "\n\t\t\t\t\t" + _vm._s(cat.title) + "\n\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "d-flex" }, [
                        cat.id != 0 && _vm.mode == "edit"
                          ? _c("i", {
                              staticClass: "fa fa-pen ml-2",
                              on: {
                                click: function ($event) {
                                  $event.stopPropagation()
                                  return _vm.editCat(index)
                                },
                              },
                            })
                          : _vm._e(),
                        _vm._v(" "),
                        cat.id != 0 && _vm.mode == "edit"
                          ? _c("i", {
                              staticClass: "fa fa-trash text-danger ml-2",
                              on: {
                                click: function ($event) {
                                  $event.stopPropagation()
                                  return _vm.deleteCat(index)
                                },
                              },
                            })
                          : _vm._e(),
                      ]),
                    ]
                  )
                }),
                _vm._v(" "),
                _vm.mode == "edit"
                  ? _c(
                      "button",
                      {
                        staticClass: "btn-add",
                        on: {
                          click: function ($event) {
                            _vm.showAddCategory = true
                          },
                        },
                      },
                      [_vm._v("\n\t\t\t\tДобавить категорию\n\t\t\t")]
                    )
                  : _vm._e(),
              ],
              2
            ),
            _vm._v(" "),
            _c("div", { staticClass: "rp" }, [
              _c("div", { staticClass: "hat" }, [
                _c(
                  "div",
                  { staticClass: "d-flex jsutify-content-between hat-top" },
                  [
                    _c(
                      "div",
                      { staticClass: "bc" },
                      [
                        _c(
                          "a",
                          { attrs: { href: "#" }, on: { click: _vm.back } },
                          [_vm._v("Темы")]
                        ),
                        _vm._v(" "),
                        _vm.activeCat
                          ? [
                              _c("i", { staticClass: "fa fa-chevron-right" }),
                              _vm._v(" "),
                              _c(
                                "a",
                                {
                                  attrs: { href: "#" },
                                  on: { click: _vm.back },
                                },
                                [
                                  _vm._v(
                                    _vm._s(
                                      _vm.activeCat.title +
                                        " (" +
                                        _vm.activeCat.playlists.length +
                                        ")"
                                    )
                                  ),
                                ]
                              ),
                            ]
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.activePlaylist
                          ? [
                              _c("i", { staticClass: "fa fa-chevron-right" }),
                              _vm._v(" "),
                              _c("a", { attrs: { href: "#" } }, [
                                _vm._v(_vm._s(_vm.activePlaylist.title)),
                              ]),
                            ]
                          : _vm._e(),
                      ],
                      2
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "control-btns d-flex" },
                      [
                        _vm.can_edit
                          ? _c("div", { staticClass: "mode_changer" }, [
                              _c("i", {
                                directives: [
                                  {
                                    name: "b-popover",
                                    rawName: "v-b-popover.hover.top",
                                    value: "Включить редактирование видео",
                                    expression:
                                      "'Включить редактирование видео'",
                                    modifiers: { hover: true, top: true },
                                  },
                                ],
                                staticClass: "fa fa-pen",
                                class: { active: _vm.mode == "edit" },
                                on: { click: _vm.toggleMode },
                              }),
                            ])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.activePlaylist == null && _vm.mode == "edit"
                          ? _c("div", { staticClass: "mode_changer ml-2" }, [
                              _c("i", {
                                staticClass: "icon-nd-settings",
                                on: {
                                  click: function ($event) {
                                    return _vm.get_settings()
                                  },
                                },
                              }),
                            ])
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.mode == "edit" && _vm.activePlaylist == null
                          ? _c("i", {
                              staticClass:
                                "btn btn-success fa fa-plus ml-2 d-flex px-2 aic",
                              on: {
                                click: function ($event) {
                                  _vm.showAddPlaylist = true
                                },
                              },
                            })
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.activePlaylist && _vm.mode == "edit"
                          ? [
                              _c("i", {
                                staticClass:
                                  "btn btn-info fa-upload fa ml-2 d-flex px-2 aic",
                                attrs: { title: "Добавить видео" },
                                on: { click: _vm.uploadVideo },
                              }),
                              _vm._v(" "),
                              _c("i", {
                                staticClass:
                                  "btn btn-info fa fa-folder-plus ml-2 d-flex px-2 aic",
                                attrs: { title: "Добавить отдел" },
                                on: { click: _vm.addGroup },
                              }),
                              _vm._v(" "),
                              _c("i", {
                                staticClass:
                                  "btn btn-success fa fa-save ml-2 d-flex px-2 aic",
                                attrs: { title: "Сохранить плейлист" },
                                on: { click: _vm.savePlaylistEdit },
                              }),
                            ]
                          : _vm._e(),
                      ],
                      2
                    ),
                  ]
                ),
                _vm._v(" "),
                _c("div"),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "rp-content" }, [
                _vm.activeCat != null
                  ? _c(
                      "div",
                      [
                        _vm.activePlaylist != null
                          ? _c("PlaylistEdit", {
                              ref: "playlist",
                              attrs: {
                                id: _vm.activePlaylist.id,
                                token: _vm.token,
                                is_course: false,
                                auth_user_id: _vm.user_id,
                                mode: _vm.mode,
                                myvideo: _vm.myvideo,
                              },
                              on: { back: _vm.back },
                            })
                          : _c("div", [
                              _c(
                                "div",
                                { staticClass: "video-container" },
                                _vm._l(
                                  _vm.activeCat.playlists,
                                  function (playlistItem, p_index) {
                                    return _c(
                                      "div",
                                      {
                                        key: playlistItem.id,
                                        staticClass: "playlist mb-4",
                                        on: {
                                          click: function ($event) {
                                            return _vm.selectPl(p_index)
                                          },
                                        },
                                      },
                                      [
                                        _c("div", { staticClass: "left" }, [
                                          _c("img", {
                                            attrs: {
                                              src:
                                                playlistItem.img == "" ||
                                                playlistItem.img == null
                                                  ? "/images/author.jpg"
                                                  : playlistItem.img,
                                              alt: "image",
                                            },
                                          }),
                                          _vm._v(" "),
                                          _vm.mode == "edit"
                                            ? _c(
                                                "div",
                                                { staticClass: "d-flex btns" },
                                                [
                                                  playlistItem.id != 0
                                                    ? _c("i", {
                                                        staticClass:
                                                          "fa fa-pen",
                                                        attrs: {
                                                          title: "Переместить",
                                                        },
                                                        on: {
                                                          click: function (
                                                            $event
                                                          ) {
                                                            $event.stopPropagation()
                                                            return _vm.movePl(
                                                              p_index
                                                            )
                                                          },
                                                        },
                                                      })
                                                    : _vm._e(),
                                                  _vm._v(" "),
                                                  playlistItem.id != 0
                                                    ? _c("i", {
                                                        staticClass:
                                                          "fa fa-trash text-danger ml-2",
                                                        on: {
                                                          click: function (
                                                            $event
                                                          ) {
                                                            $event.stopPropagation()
                                                            return _vm.deletePl(
                                                              p_index
                                                            )
                                                          },
                                                        },
                                                      })
                                                    : _vm._e(),
                                                ]
                                              )
                                            : _vm._e(),
                                        ]),
                                        _vm._v(" "),
                                        _c("div", { staticClass: "right" }, [
                                          _c("div", { staticClass: "title" }, [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\t\t\t" +
                                                _vm._s(playlistItem.title) +
                                                "\n\t\t\t\t\t\t\t\t\t"
                                            ),
                                          ]),
                                          _vm._v(" "),
                                          _c("div", { staticClass: "text" }, [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\t\t\t" +
                                                _vm._s(playlistItem.text) +
                                                "\n\t\t\t\t\t\t\t\t\t"
                                            ),
                                          ]),
                                        ]),
                                      ]
                                    )
                                  }
                                ),
                                0
                              ),
                            ]),
                      ],
                      1
                    )
                  : _vm._e(),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              staticClass: "modalle",
              attrs: { title: "Новый плейлист", size: "md", "hide-footer": "" },
              model: {
                value: _vm.showAddPlaylist,
                callback: function ($$v) {
                  _vm.showAddPlaylist = $$v
                },
                expression: "showAddPlaylist",
              },
            },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.newPlaylist,
                    expression: "newPlaylist",
                  },
                ],
                staticClass: "form-control mb-2",
                attrs: { type: "text", placeholder: "Название..." },
                domProps: { value: _vm.newPlaylist },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.newPlaylist = $event.target.value
                  },
                },
              }),
              _vm._v(" "),
              _c(
                "button",
                {
                  staticClass: "btn btn-primary rounded m-auto",
                  on: { click: _vm.addPlaylist },
                },
                [_c("span", [_vm._v("Сохранить")])]
              ),
            ]
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              staticClass: "modalle",
              attrs: {
                title: "Новая категория",
                size: "md",
                "hide-footer": "",
              },
              model: {
                value: _vm.showAddCategory,
                callback: function ($$v) {
                  _vm.showAddCategory = $$v
                },
                expression: "showAddCategory",
              },
            },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.newcat,
                    expression: "newcat",
                  },
                ],
                staticClass: "form-control mb-2",
                attrs: { type: "text", placeholder: "Название категории..." },
                domProps: { value: _vm.newcat },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.newcat = $event.target.value
                  },
                },
              }),
              _vm._v(" "),
              _c(
                "button",
                {
                  staticClass: "btn btn-primary rounded m-auto",
                  on: { click: _vm.addCat },
                },
                [_c("span", [_vm._v("Сохранить")])]
              ),
            ]
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              staticClass: "modalle",
              attrs: {
                title: "Переименовать категорию",
                size: "md",
                "hide-footer": "",
              },
              model: {
                value: _vm.showEditCat,
                callback: function ($$v) {
                  _vm.showEditCat = $$v
                },
                expression: "showEditCat",
              },
            },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.newcat,
                    expression: "newcat",
                  },
                ],
                staticClass: "form-control mb-2",
                attrs: { type: "text", placeholder: "Название категории..." },
                domProps: { value: _vm.newcat },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.newcat = $event.target.value
                  },
                },
              }),
              _vm._v(" "),
              _c(
                "button",
                {
                  staticClass: "btn btn-primary rounded m-auto",
                  on: { click: _vm.saveCat },
                },
                [_c("span", [_vm._v("Сохранить")])]
              ),
            ]
          ),
          _vm._v(" "),
          _c("SimpleSidebar", {
            attrs: {
              title: "Редактировать плейлист",
              open: _vm.showEditPlaylist,
              width: "50%",
            },
            on: {
              close: function ($event) {
                _vm.showEditPlaylist = false
              },
            },
            scopedSlots: _vm._u(
              [
                {
                  key: "body",
                  fn: function () {
                    return [
                      _vm.editingPlaylist != null
                        ? _c("div", { staticClass: "p-3" }, [
                            _c("div", { staticClass: "d-flex" }, [
                              _c("div", { staticClass: "left f-70" }, [
                                _c("div", { staticClass: "d-flex mb-2" }, [
                                  _c("p", { staticClass: "mb-2 font-bold" }, [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\tНазвание\n\t\t\t\t\t\t\t"
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.editingPlaylist.title,
                                        expression: "editingPlaylist.title",
                                      },
                                    ],
                                    staticClass: "form-control mb-2",
                                    attrs: {
                                      type: "text",
                                      placeholder: "Название плейлиста...",
                                    },
                                    domProps: {
                                      value: _vm.editingPlaylist.title,
                                    },
                                    on: {
                                      input: function ($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.editingPlaylist,
                                          "title",
                                          $event.target.value
                                        )
                                      },
                                    },
                                  }),
                                ]),
                                _vm._v(" "),
                                _c("div", { staticClass: "d-flex mb-2" }, [
                                  _c("p", { staticClass: "mb-0 mr-2" }, [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\tОписание\n\t\t\t\t\t\t\t"
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("textarea", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.editingPlaylist.text,
                                        expression: "editingPlaylist.text",
                                      },
                                    ],
                                    staticClass: "form-control",
                                    attrs: {
                                      placeholder: "Описание плейлиста...",
                                    },
                                    domProps: {
                                      value: _vm.editingPlaylist.text,
                                    },
                                    on: {
                                      input: function ($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.editingPlaylist,
                                          "text",
                                          $event.target.value
                                        )
                                      },
                                    },
                                  }),
                                ]),
                                _vm._v(" "),
                                _c("div", { staticClass: "d-flex mb-2" }, [
                                  _c("p", { staticClass: "mb-0 mr-2" }, [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\tКатегория\n\t\t\t\t\t\t\t"
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c(
                                    "select",
                                    {
                                      directives: [
                                        {
                                          name: "model",
                                          rawName: "v-model",
                                          value:
                                            _vm.editingPlaylist.category_id,
                                          expression:
                                            "editingPlaylist.category_id",
                                        },
                                      ],
                                      staticClass: "form-control",
                                      on: {
                                        change: function ($event) {
                                          var $$selectedVal =
                                            Array.prototype.filter
                                              .call(
                                                $event.target.options,
                                                function (o) {
                                                  return o.selected
                                                }
                                              )
                                              .map(function (o) {
                                                var val =
                                                  "_value" in o
                                                    ? o._value
                                                    : o.value
                                                return val
                                              })
                                          _vm.$set(
                                            _vm.editingPlaylist,
                                            "category_id",
                                            $event.target.multiple
                                              ? $$selectedVal
                                              : $$selectedVal[0]
                                          )
                                        },
                                      },
                                    },
                                    _vm._l(_vm.categories, function (cat) {
                                      return _c(
                                        "option",
                                        {
                                          key: cat.id,
                                          domProps: { value: cat.id },
                                        },
                                        [
                                          _vm._v(
                                            "\n\t\t\t\t\t\t\t\t\t" +
                                              _vm._s(cat.title) +
                                              "\n\t\t\t\t\t\t\t\t"
                                          ),
                                        ]
                                      )
                                    }),
                                    0
                                  ),
                                ]),
                              ]),
                              _vm._v(" "),
                              _c(
                                "div",
                                { staticClass: "right f-30 pl-4" },
                                [
                                  _vm.editingPlaylist.img != ""
                                    ? _c("img", {
                                        staticClass: "book-img mb-5",
                                        attrs: { src: _vm.editingPlaylist.img },
                                      })
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _c("b-form-file", {
                                    ref: "edit_img",
                                    staticClass: "mt-3",
                                    attrs: {
                                      state: Boolean(_vm.file_img),
                                      placeholder:
                                        "Выберите или перетащите файл сюда...",
                                      "drop-placeholder":
                                        "Перетащите файл сюда...",
                                    },
                                    model: {
                                      value: _vm.file_img,
                                      callback: function ($$v) {
                                        _vm.file_img = $$v
                                      },
                                      expression: "file_img",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ]),
                          ])
                        : _vm._e(),
                    ]
                  },
                  proxy: true,
                },
                {
                  key: "footer",
                  fn: function () {
                    return [
                      _vm.editingPlaylist != null
                        ? _c(
                            "button",
                            {
                              staticClass: "btn btn-success mr-2 rounded",
                              on: { click: _vm.savePlaylist },
                            },
                            [_c("span", [_vm._v("Сохранить")])]
                          )
                        : _vm._e(),
                    ]
                  },
                  proxy: true,
                },
              ],
              null,
              false,
              1074350704
            ),
          }),
          _vm._v(" "),
          _c("SimpleSidebar", {
            attrs: {
              title: "Настройки видеокурсов",
              open: _vm.showSettings,
              width: "400px",
            },
            on: {
              close: function ($event) {
                _vm.showSettings = false
              },
            },
            scopedSlots: _vm._u(
              [
                {
                  key: "body",
                  fn: function () {
                    return [
                      _c("label", { staticClass: "d-flex" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.allow_save_video_without_test,
                              expression: "allow_save_video_without_test",
                            },
                          ],
                          staticClass: "form- mb-2 mr-2",
                          attrs: { type: "checkbox" },
                          domProps: {
                            checked: Array.isArray(
                              _vm.allow_save_video_without_test
                            )
                              ? _vm._i(
                                  _vm.allow_save_video_without_test,
                                  null
                                ) > -1
                              : _vm.allow_save_video_without_test,
                          },
                          on: {
                            change: function ($event) {
                              var $$a = _vm.allow_save_video_without_test,
                                $$el = $event.target,
                                $$c = $$el.checked ? true : false
                              if (Array.isArray($$a)) {
                                var $$v = null,
                                  $$i = _vm._i($$a, $$v)
                                if ($$el.checked) {
                                  $$i < 0 &&
                                    (_vm.allow_save_video_without_test =
                                      $$a.concat([$$v]))
                                } else {
                                  $$i > -1 &&
                                    (_vm.allow_save_video_without_test = $$a
                                      .slice(0, $$i)
                                      .concat($$a.slice($$i + 1)))
                                }
                              } else {
                                _vm.allow_save_video_without_test = $$c
                              }
                            },
                          },
                        }),
                        _vm._v(" "),
                        _c("p", [
                          _vm._v(
                            "Разрешить сохранять видео без тестовых вопросов"
                          ),
                        ]),
                      ]),
                    ]
                  },
                  proxy: true,
                },
                {
                  key: "footer",
                  fn: function () {
                    return [
                      _c(
                        "button",
                        {
                          staticClass: "btn btn-primary rounded m-auto",
                          on: {
                            click: function ($event) {
                              return _vm.save_settings()
                            },
                          },
                        },
                        [_c("span", [_vm._v("Сохранить")])]
                      ),
                    ]
                  },
                  proxy: true,
                },
              ],
              null,
              false,
              947997051
            ),
          }),
        ],
        1
      )
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);