"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["TopGauges"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vgauge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vgauge */ "./node_modules/vgauge/dist/VGauge.esm.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TopGauges',
  components: {
    VGauge: vgauge__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    utility_items: {
      type: Array,
      "default": null
    },
    editable: {
      type: Boolean
    },
    wrapper_class: {
      type: String,
      "default": ''
    },
    page: {
      type: String,
      "default": ''
    }
  },
  data: function data() {
    return {
      utility: [],
      skey: 1,
      newGauge: {
        activity_id: null,
        group_id: null,
        name: null,
        cell: '',
        value_type: 'sum'
      },
      showNewGaugeWindow: false,
      group_activities: [],
      colors: {
        '#ca0013': 7,
        // red
        '#F03E3E': 2,
        // red
        '#fd7e14': 4,
        // orange
        '#ffc107': 6,
        // orange light
        '#FFDD00': 3,
        // yellow
        '#42e467': 5,
        // green light,
        '#30B32D': 1 // green,
      },

      reverseColors: {
        '#30B32D': 1,
        // green,
        '#42e467': 5,
        // green light,
        '#FFDD00': 3,
        // yellow
        '#ffc107': 6,
        // orange light
        '#fd7e14': 4,
        // orange
        '#F03E3E': 2,
        // red
        '#ca0013': 7 // red
      }
    };
  },

  watch: {
    utility_items: function utility_items() {
      this.utility = this.utility_items;
      this.normalize();
      //vm.$forceUpdate()
    }
  },
  created: function created() {
    this.utility = this.utility_items;
    this.normalize();
  },
  methods: {
    normalize: function normalize() {
      if (this.page == 'top') {
        this.utility.forEach(function (group) {
          group.gauges.forEach(function (gauge) {
            if (group.gauges.length > 1) {
              gauge.height = '42px';
              gauge.width = '75px';
              if (gauge.options.staticLabels !== undefined) {
                gauge.options.staticLabels.font = '7px sans-serif';
              }
            } else {
              gauge.height = '90px';
              gauge.width = '150px';
              if (gauge.options.staticLabels !== undefined) {
                gauge.options.staticLabels.font = '11px sans-serif';
              }
            }
          });
        });
      } else {
        this.utility.forEach(function (group) {
          group.gauges.forEach(function (gauge) {
            gauge.height = '90px';
            gauge.width = '150px';
            if (gauge.options.staticLabels !== undefined) {
              gauge.options.staticLabels.font = '7px sans-serif';
            }
          });
        });
      }
    },
    save: function save(group, gauge) {
      if (!this.editable) return '';
      var points = JSON.parse(this.utility[group].gauges[gauge].sections);
      this.utility[group].gauges[gauge].options.angle = Number(this.utility[group].gauges[gauge].angle);
      this.utility[group].gauges[gauge].options.staticLabels.labels = points;
      this.utility[group].gauges[gauge].options.staticZones = this.getStaticZones(points, this.utility[group].gauges[gauge].unit);
      this.utility[group].gauges[gauge].key++;
      this.utility[group].gauges[gauge].editable = false;
      this.saveDB(group, gauge);
    },
    delete_gauge: function delete_gauge(group, gauge) {
      var _this = this;
      if (!this.editable) return '';
      this.axios.post('/timetracking/top/delete_gauge', {
        gauge: this.utility[group].gauges[gauge]
      }).then(function () {
        _this.$toast.success('Успешно удален!');
        _this.utility[group].gauges.splice(gauge, 1);
      })["catch"](function (error) {
        alert(error);
      });
    },
    saveDB: function saveDB(group, gauge_index) {
      var _this2 = this;
      this.axios.post('/timetracking/top/save_top_value', {
        gauge: this.utility[group].gauges[gauge_index]
      }).then(function (response) {
        if (response.data.code == 200) {
          _this2.$toast.success('Успешно сохранено!');
          var this_gauge = _this2.utility[group].gauges[gauge_index];
          this_gauge.value = response.data.value;
          this_gauge.options = response.data.options;
          if (_this2.utility[group].gauges[gauge_index].is_main == 1) {
            _this2.utility[group].gauges.splice(gauge_index, 1);
            _this2.utility[group].gauges.forEach(function (item) {
              item.is_main = 0;
            });
            _this2.utility[group].gauges.unshift(this_gauge);
          }
          _this2.skey++;
        } else {
          _this2.$toast.error('Попробуйте нажать еще раз');
        }
      })["catch"](function (error) {
        alert(error);
      });
    },
    edit: function edit(group, gauge) {
      if (!this.editable) return '';
      this.utility[group].gauges[gauge].editable = !this.utility[group].gauges[gauge].editable;
      if (this.visible_gauge_group_index != null && this.visible_gauge_index != null) {
        // Close prev
        this.utility[this.visible_gauge_group_index].gauges[this.visible_gauge_index].editable = false;
      }
      if (this.utility[group].gauges[gauge].editable) {
        this.visible_gauge_group_index = group;
        this.visible_gauge_index = gauge;
      } else {
        this.visible_gauge_group_index = null;
        this.visible_gauge_index = null;
      }
    },
    getStaticZones: function getStaticZones(points, unit) {
      var staticZones = [],
        first = 0,
        second = 1,
        colors = this.colors;
      if (unit == 'мин') {
        colors = this.reverseColors;
      }
      Object.keys(colors).forEach(function (key) {
        if (Number(colors[key]) + 1 <= points.length) {
          staticZones.push({
            strokeStyle: key,
            min: points[first],
            max: points[second]
          });
          first++;
          second++;
        }
      });
      return staticZones;
    },
    showAddWindow: function showAddWindow(group_id, group_index) {
      var _this3 = this;
      this.newGauge.group_id = group_id;
      this.newGauge.group_index = group_index;
      this.axios.post('/timetracking/top/get_activities', {
        group_id: group_id
      }).then(function (response) {
        _this3.group_activities = response.data;
      })["catch"](function (error) {
        alert(error);
      });
      this.showNewGaugeWindow = true;
    },
    create_gauge: function create_gauge() {
      var _this4 = this;
      this.axios.post('/timetracking/top/create_gauge', {
        group_id: this.newGauge.group_id,
        activity_id: this.newGauge.activity_id,
        name: this.newGauge.name,
        value_type: this.newGauge.value_type,
        cell: this.newGauge.cell
      }).then(function (response) {
        _this4.utility[_this4.newGauge.group_index].gauges.push(response.data);
        _this4.newGauge = {
          activity_id: null,
          group_id: null,
          name: null,
          cell: '',
          value_type: 'sum'
        };
        _this4.skey++;
        _this4.normalize();
        _this4.showNewGaugeWindow = false;
        _this4.$toast.success('Успешно сохранено!');
      })["catch"](function (error) {
        alert(error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".l-label {\n  width: 39px;\n  text-align: left;\n}\n.gauge-title {\n  font-weight: bold;\n  display: none;\n  text-align: center;\n  font-size: 20px;\n}\n.h-23 {\n  height: 23px !important;\n  padding: 0 !important;\n}\n.w-250 {\n  width: 200px;\n}\n.w-full {\n  width: 100%;\n}\n.gauge:hover .fa-cog {\n  display: block;\n}\n.gauge {\n  cursor: pointer;\n}\n.gauge:last-child {\n  border-bottom: none;\n}\n.br-1 {\n  border-right: 1px solid #f3f3f3;\n  border-bottom: 1px solid #f3f3f3;\n}\n.text-14 {\n  font-size: 14px;\n  line-height: 14px;\n}\ninput.form-control.form-control-sm.wiwi {\n  padding: 0 10px;\n  margin-bottom: 4px;\n  width: 100%;\n}\n.scale {\n  transition: 0.3s ease all;\n  transform-origin: bottom left;\n}\n.top .scale:hover {\n  transform: scale(1.5);\n  background: #ffffff;\n  box-shadow: 0 0 15px 15px #efefef;\n}\n.scale-tl {\n  transform-origin: top left;\n}\n.underline {\n  text-decoration: underline;\n}\n.scale-tr {\n  transform-origin: top right;\n}\n.scale-bl {\n  transform-origin: bottom left;\n}\n.scale-br {\n  transform-origin: bottom right;\n}\n.w-50 {\n  width: 50%;\n}\n.g-title {\n  font-size: 13px;\n  line-height: 16px;\n  font-weight: 600;\n}\n.edit-window {\n  width: 300px;\n  position: absolute;\n  background: aliceblue;\n  padding: 15px;\n  border: 1px solid #ddd;\n  border-radius: 3px;\n  z-index: 222222;\n}\n.custom-control {\n  display: flex;\n}\n.TopGauges-gauge {\n  width: 50%;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TopGauges_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TopGauges.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TopGauges_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TopGauges_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/vgauge/dist/VGauge.esm.js":
/*!************************************************!*\
  !*** ./node_modules/vgauge/dist/VGauge.esm.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof __webpack_require__.g !== 'undefined' ? __webpack_require__.g : typeof self !== 'undefined' ? self : {};

function createCommonjsModule(fn, module) {
	return module = { exports: {} }, fn(module, module.exports), module.exports;
}

var gauge_min = createCommonjsModule(function (module) {
(function(){var t,i,e,s,n,o,a,h,r,l,p,c,u,d=[].slice,g={}.hasOwnProperty,m=function(t,i){function e(){this.constructor=t;}for(var s in i){ g.call(i,s)&&(t[s]=i[s]); }return e.prototype=i.prototype,t.prototype=new e,t.__super__=i.prototype,t};!function(){var t,i,e,s,n,o,a;for(a=["ms","moz","webkit","o"],e=0,n=a.length;e<n&&(o=a[e],!window.requestAnimationFrame);e++){ window.requestAnimationFrame=window[o+"RequestAnimationFrame"],window.cancelAnimationFrame=window[o+"CancelAnimationFrame"]||window[o+"CancelRequestAnimationFrame"]; }t=null,s=0,i={},requestAnimationFrame?window.cancelAnimationFrame||(t=window.requestAnimationFrame,window.requestAnimationFrame=function(e,n){var o;return o=++s,t(function(){if(!i[o]){ return e() }},n),o},window.cancelAnimationFrame=function(t){return i[t]=!0}):(window.requestAnimationFrame=function(t,i){var e,s,n,o;return e=(new Date).getTime(),o=Math.max(0,16-(e-n)),s=window.setTimeout(function(){return t(e+o)},o),n=e+o,s},window.cancelAnimationFrame=function(t){return clearTimeout(t)});}(),u=function(t){var i,e;for(i=Math.floor(t/3600),e=Math.floor((t-3600*i)/60),t-=3600*i+60*e,t+="",e+="";e.length<2;){ e="0"+e; }for(;t.length<2;){ t="0"+t; }return (i=i?i+":":"")+e+":"+t},p=function(){var t,i,e;return i=1<=arguments.length?d.call(arguments,0):[],e=i[0],t=i[1],r(e.toFixed(t))},c=function(t,i){var e,s,n;s={};for(e in t){ g.call(t,e)&&(n=t[e],s[e]=n); }for(e in i){ g.call(i,e)&&(n=i[e],s[e]=n); }return s},r=function(t){var i,e,s,n;for(t+="",e=t.split("."),s=e[0],n="",e.length>1&&(n="."+e[1]),i=/(\d+)(\d{3})/;i.test(s);){ s=s.replace(i,"$1,$2"); }return s+n},l=function(t){return "#"===t.charAt(0)?t.substring(1,7):t},h=function(){function t(t,i){null==t&&(t=!0),this.clear=null==i||i,t&&AnimationUpdater.add(this);}return t.prototype.animationSpeed=32,t.prototype.update=function(t){var i;return null==t&&(t=!1),!(!t&&this.displayedValue===this.value)&&(this.ctx&&this.clear&&this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height),i=this.value-this.displayedValue,Math.abs(i/this.animationSpeed)<=.001?this.displayedValue=this.value:this.displayedValue=this.displayedValue+i/this.animationSpeed,this.render(),!0)},t}(),e=function(t){function i(){return i.__super__.constructor.apply(this,arguments)}return m(i,t),i.prototype.displayScale=1,i.prototype.forceUpdate=!0,i.prototype.setTextField=function(t,i){return this.textField=t instanceof a?t:new a(t,i)},i.prototype.setMinValue=function(t,i){var e,s,n,o,a;if(this.minValue=t,null==i&&(i=!0),i){for(this.displayedValue=this.minValue,o=this.gp||[],a=[],s=0,n=o.length;s<n;s++){ e=o[s],a.push(e.displayedValue=this.minValue); }return a}},i.prototype.setOptions=function(t){return null==t&&(t=null),this.options=c(this.options,t),this.textField&&(this.textField.el.style.fontSize=t.fontSize+"px"),this.options.angle>.5&&(this.options.angle=.5),this.configDisplayScale(),this},i.prototype.configDisplayScale=function(){var t,i,e,s,n;return s=this.displayScale,!1===this.options.highDpiSupport?delete this.displayScale:(i=window.devicePixelRatio||1,t=this.ctx.webkitBackingStorePixelRatio||this.ctx.mozBackingStorePixelRatio||this.ctx.msBackingStorePixelRatio||this.ctx.oBackingStorePixelRatio||this.ctx.backingStorePixelRatio||1,this.displayScale=i/t),this.displayScale!==s&&(n=this.canvas.G__width||this.canvas.width,e=this.canvas.G__height||this.canvas.height,this.canvas.width=n*this.displayScale,this.canvas.height=e*this.displayScale,this.canvas.style.width=n+"px",this.canvas.style.height=e+"px",this.canvas.G__width=n,this.canvas.G__height=e),this},i.prototype.parseValue=function(t){return t=parseFloat(t)||Number(t),isFinite(t)?t:0},i}(h),a=function(){function t(t,i){this.el=t,this.fractionDigits=i;}return t.prototype.render=function(t){return this.el.innerHTML=p(t.displayedValue,this.fractionDigits)},t}(),t=function(t){function i(t,e){if(this.elem=t,this.text=null!=e&&e,i.__super__.constructor.call(this),void 0===this.elem){ throw new Error("The element isn't defined."); }this.value=1*this.elem.innerHTML,this.text&&(this.value=0);}return m(i,t),i.prototype.displayedValue=0,i.prototype.value=0,i.prototype.setVal=function(t){return this.value=1*t},i.prototype.render=function(){var t;return t=this.text?u(this.displayedValue.toFixed(0)):r(p(this.displayedValue)),this.elem.innerHTML=t},i}(h),o=function(t){function i(t){if(this.gauge=t,void 0===this.gauge){ throw new Error("The element isn't defined."); }this.ctx=this.gauge.ctx,this.canvas=this.gauge.canvas,i.__super__.constructor.call(this,!1,!1),this.setOptions();}return m(i,t),i.prototype.displayedValue=0,i.prototype.value=0,i.prototype.options={strokeWidth:.035,length:.1,color:"#000000",iconPath:null,iconScale:1,iconAngle:0},i.prototype.img=null,i.prototype.setOptions=function(t){if(null==t&&(t=null),this.options=c(this.options,t),this.length=2*this.gauge.radius*this.gauge.options.radiusScale*this.options.length,this.strokeWidth=this.canvas.height*this.options.strokeWidth,this.maxValue=this.gauge.maxValue,this.minValue=this.gauge.minValue,this.animationSpeed=this.gauge.animationSpeed,this.options.angle=this.gauge.options.angle,this.options.iconPath){ return this.img=new Image,this.img.src=this.options.iconPath }},i.prototype.render=function(){var t,i,e,s,n,o,a,h,r;if(t=this.gauge.getAngle.call(this,this.displayedValue),h=Math.round(this.length*Math.cos(t)),r=Math.round(this.length*Math.sin(t)),o=Math.round(this.strokeWidth*Math.cos(t-Math.PI/2)),a=Math.round(this.strokeWidth*Math.sin(t-Math.PI/2)),i=Math.round(this.strokeWidth*Math.cos(t+Math.PI/2)),e=Math.round(this.strokeWidth*Math.sin(t+Math.PI/2)),this.ctx.beginPath(),this.ctx.fillStyle=this.options.color,this.ctx.arc(0,0,this.strokeWidth,0,2*Math.PI,!1),this.ctx.fill(),this.ctx.beginPath(),this.ctx.moveTo(o,a),this.ctx.lineTo(h,r),this.ctx.lineTo(i,e),this.ctx.fill(),this.img){ return s=Math.round(this.img.width*this.options.iconScale),n=Math.round(this.img.height*this.options.iconScale),this.ctx.save(),this.ctx.translate(h,r),this.ctx.rotate(t+Math.PI/180*(90+this.options.iconAngle)),this.ctx.drawImage(this.img,-s/2,-n/2,s,n),this.ctx.restore() }},i}(h),n=function(t){function i(t){var e,s;this.canvas=t,i.__super__.constructor.call(this),this.percentColors=null,"undefined"!=typeof G_vmlCanvasManager&&(this.canvas=window.G_vmlCanvasManager.initElement(this.canvas)),this.ctx=this.canvas.getContext("2d"),e=this.canvas.clientHeight,s=this.canvas.clientWidth,this.canvas.height=e,this.canvas.width=s,this.gp=[new o(this)],this.setOptions();}return m(i,t),i.prototype.elem=null,i.prototype.value=[20],i.prototype.maxValue=80,i.prototype.minValue=0,i.prototype.displayedAngle=0,i.prototype.displayedValue=0,i.prototype.lineWidth=40,i.prototype.paddingTop=.1,i.prototype.paddingBottom=.1,i.prototype.percentColors=null,i.prototype.options={colorStart:"#6fadcf",colorStop:void 0,gradientType:0,strokeColor:"#e0e0e0",pointer:{length:.8,strokeWidth:.035,iconScale:1},angle:.15,lineWidth:.44,radiusScale:1,fontSize:40,limitMax:!1,limitMin:!1},i.prototype.setOptions=function(t){var e,s,n,o,a;for(null==t&&(t=null),i.__super__.setOptions.call(this,t),this.configPercentColors(),this.extraPadding=0,this.options.angle<0&&(o=Math.PI*(1+this.options.angle),this.extraPadding=Math.sin(o)),this.availableHeight=this.canvas.height*(1-this.paddingTop-this.paddingBottom),this.lineWidth=this.availableHeight*this.options.lineWidth,this.radius=(this.availableHeight-this.lineWidth/2)/(1+this.extraPadding),this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height),a=this.gp,s=0,n=a.length;s<n;s++){ e=a[s],e.setOptions(this.options.pointer),e.render(); }return this.render(),this},i.prototype.configPercentColors=function(){var t,i,e,s,n,o,a;if(this.percentColors=null,void 0!==this.options.percentColors){for(this.percentColors=new Array,o=[],e=s=0,n=this.options.percentColors.length-1;0<=n?s<=n:s>=n;e=0<=n?++s:--s){ a=parseInt(l(this.options.percentColors[e][1]).substring(0,2),16),i=parseInt(l(this.options.percentColors[e][1]).substring(2,4),16),t=parseInt(l(this.options.percentColors[e][1]).substring(4,6),16),o.push(this.percentColors[e]={pct:this.options.percentColors[e][0],color:{r:a,g:i,b:t}}); }return o}},i.prototype.set=function(t){var i,e,s,n,a,h,r,l,p;for(t instanceof Array||(t=[t]),e=s=0,r=t.length-1;0<=r?s<=r:s>=r;e=0<=r?++s:--s){ t[e]=this.parseValue(t[e]); }if(t.length>this.gp.length){ for(e=n=0,l=t.length-this.gp.length;0<=l?n<l:n>l;e=0<=l?++n:--n){ i=new o(this),i.setOptions(this.options.pointer),this.gp.push(i); } }else { t.length<this.gp.length&&(this.gp=this.gp.slice(this.gp.length-t.length)); }for(e=0,a=0,h=t.length;a<h;a++){ p=t[a],p>this.maxValue?this.options.limitMax?p=this.maxValue:this.maxValue=p+1:p<this.minValue&&(this.options.limitMin?p=this.minValue:this.minValue=p-1),this.gp[e].value=p,this.gp[e++].setOptions({minValue:this.minValue,maxValue:this.maxValue,angle:this.options.angle}); }return this.value=Math.max(Math.min(t[t.length-1],this.maxValue),this.minValue),AnimationUpdater.run(this.forceUpdate),this.forceUpdate=!1},i.prototype.getAngle=function(t){return (1+this.options.angle)*Math.PI+(t-this.minValue)/(this.maxValue-this.minValue)*(1-2*this.options.angle)*Math.PI},i.prototype.getColorForPercentage=function(t,i){var e,s,n,o,a,h,r;if(0===t){ e=this.percentColors[0].color; }else { for(e=this.percentColors[this.percentColors.length-1].color,n=o=0,h=this.percentColors.length-1;0<=h?o<=h:o>=h;n=0<=h?++o:--o){ if(t<=this.percentColors[n].pct){!0===i?(r=this.percentColors[n-1]||this.percentColors[0],s=this.percentColors[n],a=(t-r.pct)/(s.pct-r.pct),e={r:Math.floor(r.color.r*(1-a)+s.color.r*a),g:Math.floor(r.color.g*(1-a)+s.color.g*a),b:Math.floor(r.color.b*(1-a)+s.color.b*a)}):e=this.percentColors[n].color;break} } }return "rgb("+[e.r,e.g,e.b].join(",")+")"},i.prototype.getColorForValue=function(t,i){var e;return e=(t-this.minValue)/(this.maxValue-this.minValue),this.getColorForPercentage(e,i)},i.prototype.renderStaticLabels=function(t,i,e,s){var n,o,a,h,r,l,c,u,d,g;for(this.ctx.save(),this.ctx.translate(i,e),n=t.font||"10px Times",l=/\d+\.?\d?/,r=n.match(l)[0],u=n.slice(r.length),o=parseFloat(r)*this.displayScale,this.ctx.font=o+u,this.ctx.fillStyle=t.color||"#000000",this.ctx.textBaseline="bottom",this.ctx.textAlign="center",c=t.labels,a=0,h=c.length;a<h;a++){ g=c[a],void 0!==g.label?(!this.options.limitMin||g>=this.minValue)&&(!this.options.limitMax||g<=this.maxValue)&&(n=g.font||t.font,r=n.match(l)[0],u=n.slice(r.length),o=parseFloat(r)*this.displayScale,this.ctx.font=o+u,d=this.getAngle(g.label)-3*Math.PI/2,this.ctx.rotate(d),this.ctx.fillText(p(g.label,t.fractionDigits),0,-s-this.lineWidth/2),this.ctx.rotate(-d)):(!this.options.limitMin||g>=this.minValue)&&(!this.options.limitMax||g<=this.maxValue)&&(d=this.getAngle(g)-3*Math.PI/2,this.ctx.rotate(d),this.ctx.fillText(p(g,t.fractionDigits),0,-s-this.lineWidth/2),this.ctx.rotate(-d)); }return this.ctx.restore()},i.prototype.renderTicks=function(t,i,e,s){var n,o,a,h,r,l,p,c,u,d,g,m,x,f,v,y,V,w,S,M,C;if(t!=={}){for(l=t.divisions||0,S=t.subDivisions||0,a=t.divColor||"#fff",v=t.subColor||"#fff",h=t.divLength||.7,V=t.subLength||.2,u=parseFloat(this.maxValue)-parseFloat(this.minValue),d=parseFloat(u)/parseFloat(t.divisions),y=parseFloat(d)/parseFloat(t.subDivisions),n=parseFloat(this.minValue),o=0+y,c=u/400,r=c*(t.divWidth||1),w=c*(t.subWidth||1),m=[],M=p=0,g=l+1;p<g;M=p+=1){ this.ctx.lineWidth=this.lineWidth*h,x=this.lineWidth/2*(1-h),C=this.radius*this.options.radiusScale+x,this.ctx.strokeStyle=a,this.ctx.beginPath(),this.ctx.arc(0,0,C,this.getAngle(n-r),this.getAngle(n+r),!1),this.ctx.stroke(),o=n+y,n+=d,M!==t.divisions&&S>0?m.push(function(){var t,i,e;for(e=[],f=t=0,i=S-1;t<i;f=t+=1){ this.ctx.lineWidth=this.lineWidth*V,x=this.lineWidth/2*(1-V),C=this.radius*this.options.radiusScale+x,this.ctx.strokeStyle=v,this.ctx.beginPath(),this.ctx.arc(0,0,C,this.getAngle(o-w),this.getAngle(o+w),!1),this.ctx.stroke(),e.push(o+=y); }return e}.call(this)):m.push(void 0); }return m}},i.prototype.render=function(){var t,i,e,s,n,o,a,h,r,l,p,c,u,d,g,m,x;if(m=this.canvas.width/2,s=this.canvas.height*this.paddingTop+this.availableHeight-(this.radius+this.lineWidth/2)*this.extraPadding,t=this.getAngle(this.displayedValue),this.textField&&this.textField.render(this),this.ctx.lineCap="butt",p=this.radius*this.options.radiusScale,this.options.staticLabels&&this.renderStaticLabels(this.options.staticLabels,m,s,p),this.options.staticZones){ for(this.ctx.save(),this.ctx.translate(m,s),this.ctx.lineWidth=this.lineWidth,c=this.options.staticZones,n=0,a=c.length;n<a;n++){ x=c[n],l=x.min,this.options.limitMin&&l<this.minValue&&(l=this.minValue),r=x.max,this.options.limitMax&&r>this.maxValue&&(r=this.maxValue),g=this.radius*this.options.radiusScale,x.height&&(this.ctx.lineWidth=this.lineWidth*x.height,d=this.lineWidth/2*(x.offset||1-x.height),g=this.radius*this.options.radiusScale+d),this.ctx.strokeStyle=x.strokeStyle,this.ctx.beginPath(),this.ctx.arc(0,0,g,this.getAngle(l),this.getAngle(r),!1),this.ctx.stroke(); } }else { void 0!==this.options.customFillStyle?i=this.options.customFillStyle(this):null!==this.percentColors?i=this.getColorForValue(this.displayedValue,this.options.generateGradient):void 0!==this.options.colorStop?(i=0===this.options.gradientType?this.ctx.createRadialGradient(m,s,9,m,s,70):this.ctx.createLinearGradient(0,0,m,0),i.addColorStop(0,this.options.colorStart),i.addColorStop(1,this.options.colorStop)):i=this.options.colorStart,this.ctx.strokeStyle=i,this.ctx.beginPath(),this.ctx.arc(m,s,p,(1+this.options.angle)*Math.PI,t,!1),this.ctx.lineWidth=this.lineWidth,this.ctx.stroke(),this.ctx.strokeStyle=this.options.strokeColor,this.ctx.beginPath(),this.ctx.arc(m,s,p,t,(2-this.options.angle)*Math.PI,!1),this.ctx.stroke(),this.ctx.save(),this.ctx.translate(m,s); }for(this.options.renderTicks&&this.renderTicks(this.options.renderTicks,m,s,p),this.ctx.restore(),this.ctx.translate(m,s),u=this.gp,o=0,h=u.length;o<h;o++){ e=u[o],e.update(!0); }return this.ctx.translate(-m,-s)},i}(e),i=function(t){function i(t){this.canvas=t,i.__super__.constructor.call(this),"undefined"!=typeof G_vmlCanvasManager&&(this.canvas=window.G_vmlCanvasManager.initElement(this.canvas)),this.ctx=this.canvas.getContext("2d"),this.setOptions(),this.render();}return m(i,t),i.prototype.lineWidth=15,i.prototype.displayedValue=0,i.prototype.value=33,i.prototype.maxValue=80,i.prototype.minValue=0,i.prototype.options={lineWidth:.1,colorStart:"#6f6ea0",colorStop:"#c0c0db",strokeColor:"#eeeeee",shadowColor:"#d5d5d5",angle:.35,radiusScale:1},i.prototype.getAngle=function(t){return (1-this.options.angle)*Math.PI+(t-this.minValue)/(this.maxValue-this.minValue)*(2+this.options.angle-(1-this.options.angle))*Math.PI},i.prototype.setOptions=function(t){return null==t&&(t=null),i.__super__.setOptions.call(this,t),this.lineWidth=this.canvas.height*this.options.lineWidth,this.radius=this.options.radiusScale*(this.canvas.height/2-this.lineWidth/2),this},i.prototype.set=function(t){return this.value=this.parseValue(t),this.value>this.maxValue?this.options.limitMax?this.value=this.maxValue:this.maxValue=this.value:this.value<this.minValue&&(this.options.limitMin?this.value=this.minValue:this.minValue=this.value),AnimationUpdater.run(this.forceUpdate),this.forceUpdate=!1},i.prototype.render=function(){var t,i,e,s;return t=this.getAngle(this.displayedValue),s=this.canvas.width/2,e=this.canvas.height/2,this.textField&&this.textField.render(this),i=this.ctx.createRadialGradient(s,e,39,s,e,70),i.addColorStop(0,this.options.colorStart),i.addColorStop(1,this.options.colorStop),this.radius-this.lineWidth/2,this.radius+this.lineWidth/2,this.ctx.strokeStyle=this.options.strokeColor,this.ctx.beginPath(),this.ctx.arc(s,e,this.radius,(1-this.options.angle)*Math.PI,(2+this.options.angle)*Math.PI,!1),this.ctx.lineWidth=this.lineWidth,this.ctx.lineCap="round",this.ctx.stroke(),this.ctx.strokeStyle=i,this.ctx.beginPath(),this.ctx.arc(s,e,this.radius,(1-this.options.angle)*Math.PI,t,!1),this.ctx.stroke()},i}(e),s=function(t){function i(){return i.__super__.constructor.apply(this,arguments)}return m(i,t),i.prototype.strokeGradient=function(t,i,e,s){var n;return n=this.ctx.createRadialGradient(t,i,e,t,i,s),n.addColorStop(0,this.options.shadowColor),n.addColorStop(.12,this.options._orgStrokeColor),n.addColorStop(.88,this.options._orgStrokeColor),n.addColorStop(1,this.options.shadowColor),n},i.prototype.setOptions=function(t){var e,s,n,o;return null==t&&(t=null),i.__super__.setOptions.call(this,t),o=this.canvas.width/2,e=this.canvas.height/2,s=this.radius-this.lineWidth/2,n=this.radius+this.lineWidth/2,this.options._orgStrokeColor=this.options.strokeColor,this.options.strokeColor=this.strokeGradient(o,e,s,n),this},i}(i),window.AnimationUpdater={elements:[],animId:null,addAll:function(t){var i,e,s,n;for(n=[],e=0,s=t.length;e<s;e++){ i=t[e],n.push(AnimationUpdater.elements.push(i)); }return n},add:function(t){return AnimationUpdater.elements.push(t)},run:function(t){var i,e,s,n,o;if(null==t&&(t=!1),isFinite(parseFloat(t))||!0===t){for(e=!0,o=AnimationUpdater.elements,s=0,n=o.length;s<n;s++){ i=o[s],i.update(!0===t)&&(e=!1); }return AnimationUpdater.animId=e?null:requestAnimationFrame(AnimationUpdater.run)}if(!1===t){ return !0===AnimationUpdater.animId&&cancelAnimationFrame(AnimationUpdater.animId),AnimationUpdater.animId=requestAnimationFrame(AnimationUpdater.run) }}},"function"==typeof window.define&&null!=window.define.amd?undefined(function(){return {Gauge:n,Donut:s,BaseDonut:i,TextRenderer:a}}):null!=module.exports?module.exports={Gauge:n,Donut:s,BaseDonut:i,TextRenderer:a}:(window.Gauge=n,window.Donut=s,window.BaseDonut=i,window.TextRenderer=a);}).call(commonjsGlobal);
});
var gauge_min_1 = gauge_min.Gauge;
var gauge_min_2 = gauge_min.Donut;
var gauge_min_3 = gauge_min.BaseDonut;
var gauge_min_4 = gauge_min.TextRenderer;

//
var script = {
  name: "VGauge",
  props: {
    unit: {
      type: String,
      default: ""
    },
    height: {
      type: String,
      default: "200px"
    },
    width: {
      type: String,
      default: "200px"
    },
    decimalPlace: {
      type: Number,
      default: 0
    },
    gaugeValueClass: {
      type: String,
      default: ""
    },
    top: {
      type: Boolean,
      default: false
    },
    maxValue: {
      type: Number,
      default: 100
    },
    minValue: {
      type: Number,
      default: 0
    },
    options: {
      type: Object,
      default: function() {
        return {
          angle: 0.15,
          lineWidth: 0.44,
          radiusScale: 1,
          pointer: {
            length: 0.6,
            strokeWidth: 0.035,
            color: "#000000"
          },
          limitMax: false,
          limitMin: false,
          colorStart: "#6FADCF",
          colorStop: "#8FC0DA",
          strokeColor: "#E0E0E0",
          generateGradient: true,
          highDpiSupport: true
        };
      }
    },
    animationSpeed: {
      type: Number,
      default: 10
    },
    initialValue: {
      type: Number,
      default: 0
    },
    value: {
      type: Number,
      default: 50
    },
    donut: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      gauge: null
    };
  },
  mounted: function mounted() {
    this.initializeGauge();
  },
  beforeDestroy: function beforeDestroy() {
    delete this.gauge;
  },
  watch: {
    value: function(newVal) {
      this.gauge.set(newVal);
    }
  },
  methods: {
    initializeGauge: function initializeGauge() {
      this.gauge = this.donut
        ? new gauge_min_2(this.$refs.gauge)
        : new gauge_min_1(this.$refs.gauge);
      this.gauge.maxValue = this.maxValue;
      this.gauge.setMinValue(this.minValue);
      this.gauge.animationSpeed = this.animationSpeed;
      this.gauge.setOptions(this.options);
      this.gauge.setTextField(this.$refs["gauge-value"], this.decimalPlace);
      this.gauge.set(this.value);
    }
  }
};

function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
/* server only */
, shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
  if (typeof shadowMode !== 'boolean') {
    createInjectorSSR = createInjector;
    createInjector = shadowMode;
    shadowMode = false;
  } // Vue.extend constructor export interop.


  var options = typeof script === 'function' ? script.options : script; // render functions

  if (template && template.render) {
    options.render = template.render;
    options.staticRenderFns = template.staticRenderFns;
    options._compiled = true; // functional template

    if (isFunctionalTemplate) {
      options.functional = true;
    }
  } // scopedId


  if (scopeId) {
    options._scopeId = scopeId;
  }

  var hook;

  if (moduleIdentifier) {
    // server build
    hook = function hook(context) {
      // 2.3 injection
      context = context || // cached call
      this.$vnode && this.$vnode.ssrContext || // stateful
      this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
      // 2.2 with runInNewContext: true

      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__;
      } // inject component styles


      if (style) {
        style.call(this, createInjectorSSR(context));
      } // register component module identifier for async chunk inference


      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier);
      }
    }; // used by ssr in case component is cached and beforeCreate
    // never gets called


    options._ssrRegister = hook;
  } else if (style) {
    hook = shadowMode ? function () {
      style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
    } : function (context) {
      style.call(this, createInjector(context));
    };
  }

  if (hook) {
    if (options.functional) {
      // register for functional component in vue file
      var originalRender = options.render;

      options.render = function renderWithStyleInjection(h, context) {
        hook.call(context);
        return originalRender(h, context);
      };
    } else {
      // inject component registration as beforeCreate hook
      var existing = options.beforeCreate;
      options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
    }
  }

  return script;
}

var normalizeComponent_1 = normalizeComponent;

var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
function createInjector(context) {
  return function (id, style) {
    return addStyle(id, style);
  };
}
var HEAD = document.head || document.getElementsByTagName('head')[0];
var styles = {};

function addStyle(id, css) {
  var group = isOldIE ? css.media || 'default' : id;
  var style = styles[group] || (styles[group] = {
    ids: new Set(),
    styles: []
  });

  if (!style.ids.has(id)) {
    style.ids.add(id);
    var code = css.source;

    if (css.map) {
      // https://developer.chrome.com/devtools/docs/javascript-debugging
      // this makes source maps inside style tags work properly in Chrome
      code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

      code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
    }

    if (!style.element) {
      style.element = document.createElement('style');
      style.element.type = 'text/css';
      if (css.media) { style.element.setAttribute('media', css.media); }
      HEAD.appendChild(style.element);
    }

    if ('styleSheet' in style.element) {
      style.styles.push(code);
      style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
    } else {
      var index = style.ids.size - 1;
      var textNode = document.createTextNode(code);
      var nodes = style.element.childNodes;
      if (nodes[index]) { style.element.removeChild(nodes[index]); }
      if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
    }
  }
}

var browser = createInjector;

/* script */
var __vue_script__ = script;

/* template */
var __vue_render__ = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('div',{staticClass:"gauge-title"},[(_vm.top)?_c('span',{ref:"gauge-value",class:_vm.gaugeValueClass}):_vm._e(),_vm._v(" "),(_vm.top)?_c('span',{class:_vm.gaugeValueClass},[_vm._v(_vm._s(_vm.unit))]):_vm._e()]),_vm._v(" "),_c('canvas',{ref:"gauge",attrs:{"height":_vm.height,"width":_vm.width}}),_vm._v(" "),_c('div',{staticClass:"gauge-title"},[(!_vm.top)?_c('span',{ref:"gauge-value",class:_vm.gaugeValueClass}):_vm._e(),_vm._v(" "),(!_vm.top)?_c('span',{class:_vm.gaugeValueClass},[_vm._v(_vm._s(_vm.unit))]):_vm._e()])])};
var __vue_staticRenderFns__ = [];

  /* style */
  var __vue_inject_styles__ = function (inject) {
    if (!inject) { return }
    inject("data-v-1e740546_0", { source: ".gauge-title span[data-v-1e740546]{display:inline;text-align:center}", map: undefined, media: undefined });

  };
  /* scoped */
  var __vue_scope_id__ = "data-v-1e740546";
  /* module identifier */
  var __vue_module_identifier__ = undefined;
  /* functional template */
  var __vue_is_functional_template__ = false;
  /* style inject SSR */
  

  
  var component = normalizeComponent_1(
    { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
    __vue_inject_styles__,
    __vue_script__,
    __vue_scope_id__,
    __vue_is_functional_template__,
    __vue_module_identifier__,
    browser,
    undefined
  );

// Import vue component

// install function executed by Vue.use()
function install(Vue) {
  if (install.installed) { return; }
  install.installed = true;
  Vue.component('VGauge', component);
}

// Create module definition for Vue.use()
var plugin = {
  install: install,
};

// To auto-install when vue is found
/* global window global */
var GlobalVue = null;
if (typeof window !== 'undefined') {
  GlobalVue = window.Vue;
} else if (typeof __webpack_require__.g !== 'undefined') {
  GlobalVue = __webpack_require__.g.Vue;
}
if (GlobalVue) {
  GlobalVue.use(plugin);
}

// Inject install function into component - allows component
// to be registered via Vue.use() as well as Vue.component()
component.install = install;

// It's possible to expose named exports when writing components that can
// also be used as directives, etc. - eg. import { RollupDemoDirective } from 'rollup-demo';
// export const RollupDemoDirective = component;

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component);


/***/ }),

/***/ "./resources/js/components/TopGauges.vue":
/*!***********************************************!*\
  !*** ./resources/js/components/TopGauges.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TopGauges_vue_vue_type_template_id_1edc52f4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TopGauges.vue?vue&type=template&id=1edc52f4& */ "./resources/js/components/TopGauges.vue?vue&type=template&id=1edc52f4&");
/* harmony import */ var _TopGauges_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TopGauges.vue?vue&type=script&lang=js& */ "./resources/js/components/TopGauges.vue?vue&type=script&lang=js&");
/* harmony import */ var _TopGauges_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TopGauges.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/TopGauges.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TopGauges_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TopGauges_vue_vue_type_template_id_1edc52f4___WEBPACK_IMPORTED_MODULE_0__.render,
  _TopGauges_vue_vue_type_template_id_1edc52f4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/TopGauges.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/TopGauges.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/components/TopGauges.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TopGauges_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TopGauges.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TopGauges_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/TopGauges.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************!*\
  !*** ./resources/js/components/TopGauges.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TopGauges_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TopGauges.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/TopGauges.vue?vue&type=template&id=1edc52f4&":
/*!******************************************************************************!*\
  !*** ./resources/js/components/TopGauges.vue?vue&type=template&id=1edc52f4& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TopGauges_vue_vue_type_template_id_1edc52f4___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TopGauges_vue_vue_type_template_id_1edc52f4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TopGauges_vue_vue_type_template_id_1edc52f4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TopGauges.vue?vue&type=template&id=1edc52f4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=template&id=1edc52f4&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=template&id=1edc52f4&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/TopGauges.vue?vue&type=template&id=1edc52f4& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      key: _vm.skey,
      staticClass: "TopGauges d-flex justify-content-start mt-3",
      class: { top: _vm.page == "top" },
      staticStyle: { "flex-wrap": "wrap" },
    },
    [
      _vm._l(_vm.utility, function (group, group_index) {
        return [
          _c(
            "div",
            {
              key: group_index,
              staticClass: "TopGauges-group",
              class: _vm.wrapper_class,
            },
            [
              _vm.editable
                ? _c(
                    "div",
                    {
                      staticClass:
                        "TopGauges-title text-center font-bold mb-3 mt-2 d-flex justify-content-center",
                    },
                    [
                      _c(
                        "a",
                        {
                          attrs: {
                            href:
                              "/timetracking/an?group=" +
                              group.id +
                              "&active=1&load=1",
                            target: "_blank",
                          },
                        },
                        [_vm._v(_vm._s(group.name))]
                      ),
                      _vm._v(" "),
                      _vm.page == "top" && group.gauges.length < 4
                        ? _c(
                            "div",
                            {
                              staticClass: " ml-2 pointer",
                              attrs: { title: "Добавить новый спидометр" },
                              on: {
                                click: function ($event) {
                                  return _vm.showAddWindow(
                                    group.id,
                                    group_index
                                  )
                                },
                              },
                            },
                            [_c("i", { staticClass: "fa fa-plus-square" })]
                          )
                        : _vm._e(),
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              group.gauges.length
                ? _c(
                    "div",
                    {
                      staticClass:
                        "TopGauges-gauges d-flex justify-content-center",
                      style:
                        _vm.page == "top"
                          ? "flex-wrap:wrap; width: 240px;"
                          : "",
                    },
                    _vm._l(group.gauges, function (gauge, gauge_index) {
                      return _c(
                        "div",
                        {
                          key: gauge.id,
                          staticClass: "TopGauges-gauge text-center gauge",
                          class: {
                            "TopGauges-gauge_single": group.gauges.length === 1,
                          },
                        },
                        [
                          _c(
                            "div",
                            {
                              class: [
                                "scale",
                                {
                                  "scale-bl": +gauge_index === 0,
                                  "scale-br": +gauge_index === 1,
                                  "scale-bl": +gauge_index === 2,
                                  "scale-br": +gauge_index === 3,
                                },
                              ],
                              attrs: { "data-test": gauge_index },
                            },
                            [
                              _c(
                                "p",
                                {
                                  staticClass: "text-center g-title",
                                  class: { underline: gauge.is_main == 1 },
                                },
                                [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(gauge.name) +
                                      " "
                                  ),
                                  _vm.page == "analytics"
                                    ? [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t" +
                                            _vm._s(gauge.diff) +
                                            "%\n\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    : _vm._e(),
                                ],
                                2
                              ),
                              _vm._v(" "),
                              _vm.page == "top"
                                ? _c(
                                    "div",
                                    {
                                      key: gauge.key,
                                      attrs: {
                                        title: "Нажмите, чтобы редактировать",
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.edit(
                                            group_index,
                                            gauge_index
                                          )
                                        },
                                      },
                                    },
                                    [
                                      _c("VGauge", {
                                        attrs: {
                                          value: Number(gauge.value),
                                          height: gauge.height,
                                          options: gauge.options,
                                          width: gauge.width,
                                          unit: gauge.unit.toString(),
                                          "min-value": Number(gauge.min_value),
                                          "max-value": Number(gauge.max_value),
                                          top: true,
                                          "gauge-value-class": "gauge-span",
                                        },
                                      }),
                                    ],
                                    1
                                  )
                                : _c(
                                    "div",
                                    {
                                      key: gauge.key + "a",
                                      attrs: {
                                        title: "Нажмите, чтобы редактировать",
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.edit(
                                            group_index,
                                            gauge_index
                                          )
                                        },
                                      },
                                    },
                                    [
                                      _c("VGauge", {
                                        attrs: {
                                          value: Number(gauge.value),
                                          height: "90px",
                                          options: gauge.options,
                                          width: "150px",
                                          unit: gauge.unit.toString(),
                                          "min-value": Number(gauge.min_value),
                                          "max-value": Number(gauge.max_value),
                                          top: true,
                                          "gauge-value-class": "gauge-span",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                              _vm._v(" "),
                              _c("p", { staticClass: "text-center text-14" }, [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t" +
                                    _vm._s(Number(gauge.value)) +
                                    _vm._s(gauge.unit) +
                                    " из " +
                                    _vm._s(gauge.max_value) +
                                    _vm._s(gauge.unit) +
                                    "\n\t\t\t\t\t\t"
                                ),
                              ]),
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: gauge.editable,
                                  expression: "gauge.editable",
                                },
                              ],
                              staticClass: "mb-5 edit-window",
                            },
                            [
                              _c(
                                "div",
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "d-flex justify-content-between align-items-center",
                                    },
                                    [
                                      _c(
                                        "span",
                                        { staticClass: "pr-2 l-label" },
                                        [_vm._v("Min")]
                                      ),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: gauge.min_value,
                                            expression: "gauge.min_value",
                                          },
                                        ],
                                        staticClass:
                                          "form-control form-control-sm w-250 wiwi",
                                        attrs: { type: "text" },
                                        domProps: { value: gauge.min_value },
                                        on: {
                                          input: function ($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              gauge,
                                              "min_value",
                                              $event.target.value
                                            )
                                          },
                                        },
                                      }),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "d-flex justify-content-between align-items-center",
                                    },
                                    [
                                      _c(
                                        "span",
                                        { staticClass: "pr-2 l-label" },
                                        [_vm._v("Max")]
                                      ),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: gauge.max_value,
                                            expression: "gauge.max_value",
                                          },
                                        ],
                                        staticClass:
                                          "form-control form-control-sm w-250 wiwi",
                                        attrs: { type: "text" },
                                        domProps: { value: gauge.max_value },
                                        on: {
                                          input: function ($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              gauge,
                                              "max_value",
                                              $event.target.value
                                            )
                                          },
                                        },
                                      }),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "d-flex justify-content-between align-items-center",
                                    },
                                    [
                                      _c(
                                        "span",
                                        { staticClass: "pr-2 l-label" },
                                        [_vm._v("Сег")]
                                      ),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: gauge.sections,
                                            expression: "gauge.sections",
                                          },
                                        ],
                                        staticClass:
                                          "form-control form-control-sm w-250 wiwi",
                                        attrs: { type: "text" },
                                        domProps: { value: gauge.sections },
                                        on: {
                                          input: function ($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              gauge,
                                              "sections",
                                              $event.target.value
                                            )
                                          },
                                        },
                                      }),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "d-flex justify-content-between align-items-center",
                                    },
                                    [
                                      _c(
                                        "span",
                                        { staticClass: "pr-2 l-label" },
                                        [_vm._v("Ед.")]
                                      ),
                                      _vm._v(" "),
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: gauge.unit,
                                            expression: "gauge.unit",
                                          },
                                        ],
                                        staticClass:
                                          "form-control form-control-sm wiwi",
                                        attrs: { type: "text" },
                                        domProps: { value: gauge.unit },
                                        on: {
                                          input: function ($event) {
                                            if ($event.target.composing) {
                                              return
                                            }
                                            _vm.$set(
                                              gauge,
                                              "unit",
                                              $event.target.value
                                            )
                                          },
                                        },
                                      }),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  gauge.fixed == 0
                                    ? [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "d-flex justify-content-between align-items-center",
                                          },
                                          [
                                            _c(
                                              "span",
                                              { staticClass: "pr-2 l-label" },
                                              [_vm._v("Наз")]
                                            ),
                                            _vm._v(" "),
                                            _c("input", {
                                              directives: [
                                                {
                                                  name: "model",
                                                  rawName: "v-model",
                                                  value: gauge.name,
                                                  expression: "gauge.name",
                                                },
                                              ],
                                              staticClass:
                                                "form-control form-control-sm wiwi",
                                              attrs: { type: "text" },
                                              domProps: { value: gauge.name },
                                              on: {
                                                input: function ($event) {
                                                  if ($event.target.composing) {
                                                    return
                                                  }
                                                  _vm.$set(
                                                    gauge,
                                                    "name",
                                                    $event.target.value
                                                  )
                                                },
                                              },
                                            }),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "d-flex justify-content-between align-items-center",
                                          },
                                          [
                                            _c(
                                              "span",
                                              { staticClass: "pr-2 l-label" },
                                              [_vm._v("Окр")]
                                            ),
                                            _vm._v(" "),
                                            _c("input", {
                                              directives: [
                                                {
                                                  name: "model",
                                                  rawName: "v-model",
                                                  value: gauge.round,
                                                  expression: "gauge.round",
                                                },
                                              ],
                                              staticClass:
                                                "form-control form-control-sm wiwi",
                                              attrs: { type: "text" },
                                              domProps: { value: gauge.round },
                                              on: {
                                                input: function ($event) {
                                                  if ($event.target.composing) {
                                                    return
                                                  }
                                                  _vm.$set(
                                                    gauge,
                                                    "round",
                                                    $event.target.value
                                                  )
                                                },
                                              },
                                            }),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "d-flex justify-content-between align-items-center",
                                          },
                                          [
                                            _c(
                                              "span",
                                              { staticClass: "pr-2 l-label" },
                                              [_vm._v("Акт")]
                                            ),
                                            _vm._v(" "),
                                            _c(
                                              "select",
                                              {
                                                directives: [
                                                  {
                                                    name: "model",
                                                    rawName: "v-model",
                                                    value: gauge.activity_id,
                                                    expression:
                                                      "gauge.activity_id",
                                                  },
                                                ],
                                                staticClass:
                                                  "form-control form-control-sm h-23",
                                                on: {
                                                  change: function ($event) {
                                                    var $$selectedVal =
                                                      Array.prototype.filter
                                                        .call(
                                                          $event.target.options,
                                                          function (o) {
                                                            return o.selected
                                                          }
                                                        )
                                                        .map(function (o) {
                                                          var val =
                                                            "_value" in o
                                                              ? o._value
                                                              : o.value
                                                          return val
                                                        })
                                                    _vm.$set(
                                                      gauge,
                                                      "activity_id",
                                                      $event.target.multiple
                                                        ? $$selectedVal
                                                        : $$selectedVal[0]
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _c(
                                                  "option",
                                                  {
                                                    key: -1,
                                                    domProps: { value: -1 },
                                                  },
                                                  [
                                                    _vm._v(
                                                      "\n\t\t\t\t\t\t\t\t\t\t\tЯчейка из сводной\n\t\t\t\t\t\t\t\t\t\t"
                                                    ),
                                                  ]
                                                ),
                                                _vm._v(" "),
                                                _vm._l(
                                                  group.group_activities,
                                                  function (
                                                    group_activity,
                                                    key
                                                  ) {
                                                    return _c(
                                                      "option",
                                                      {
                                                        key: key,
                                                        domProps: {
                                                          value:
                                                            group_activity.id,
                                                        },
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                            _vm._s(
                                                              group_activity.name
                                                            ) +
                                                            "\n\t\t\t\t\t\t\t\t\t\t"
                                                        ),
                                                      ]
                                                    )
                                                  }
                                                ),
                                              ],
                                              2
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        gauge.activity_id > 0
                                          ? _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "d-flex justify-content-between align-items-center",
                                              },
                                              [
                                                _c(
                                                  "span",
                                                  {
                                                    staticClass: "pr-2 l-label",
                                                  },
                                                  [_vm._v("Тип")]
                                                ),
                                                _vm._v(" "),
                                                _c(
                                                  "select",
                                                  {
                                                    directives: [
                                                      {
                                                        name: "model",
                                                        rawName: "v-model",
                                                        value: gauge.value_type,
                                                        expression:
                                                          "gauge.value_type",
                                                      },
                                                    ],
                                                    staticClass:
                                                      "form-control form-control-sm h-23",
                                                    on: {
                                                      change: function (
                                                        $event
                                                      ) {
                                                        var $$selectedVal =
                                                          Array.prototype.filter
                                                            .call(
                                                              $event.target
                                                                .options,
                                                              function (o) {
                                                                return o.selected
                                                              }
                                                            )
                                                            .map(function (o) {
                                                              var val =
                                                                "_value" in o
                                                                  ? o._value
                                                                  : o.value
                                                              return val
                                                            })
                                                        _vm.$set(
                                                          gauge,
                                                          "value_type",
                                                          $event.target.multiple
                                                            ? $$selectedVal
                                                            : $$selectedVal[0]
                                                        )
                                                      },
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "option",
                                                      {
                                                        attrs: { value: "sum" },
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n\t\t\t\t\t\t\t\t\t\t\tСумма выполненного\n\t\t\t\t\t\t\t\t\t\t"
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "option",
                                                      {
                                                        attrs: { value: "avg" },
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n\t\t\t\t\t\t\t\t\t\t\tСреднее значение\n\t\t\t\t\t\t\t\t\t\t"
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            )
                                          : _vm._e(),
                                        _vm._v(" "),
                                        gauge.activity_id == -1
                                          ? _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "d-flex justify-content-between align-items-center mt-1",
                                              },
                                              [
                                                _c(
                                                  "span",
                                                  { staticClass: "pr-2" },
                                                  [_vm._v("Ячейка")]
                                                ),
                                                _vm._v(" "),
                                                _c("input", {
                                                  directives: [
                                                    {
                                                      name: "model",
                                                      rawName: "v-model",
                                                      value: gauge.cell,
                                                      expression: "gauge.cell",
                                                    },
                                                  ],
                                                  staticClass:
                                                    "form-control form-control-sm wiwi text-uppercase",
                                                  attrs: { type: "text" },
                                                  domProps: {
                                                    value: gauge.cell,
                                                  },
                                                  on: {
                                                    input: function ($event) {
                                                      if (
                                                        $event.target.composing
                                                      ) {
                                                        return
                                                      }
                                                      _vm.$set(
                                                        gauge,
                                                        "cell",
                                                        $event.target.value
                                                      )
                                                    },
                                                  },
                                                }),
                                              ]
                                            )
                                          : _vm._e(),
                                      ]
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    [
                                      _c(
                                        "b-form-checkbox",
                                        {
                                          attrs: {
                                            value: 1,
                                            "unchecked-value": 0,
                                          },
                                          model: {
                                            value: gauge.reversed,
                                            callback: function ($$v) {
                                              _vm.$set(gauge, "reversed", $$v)
                                            },
                                            expression: "gauge.reversed",
                                          },
                                        },
                                        [
                                          _vm._v(
                                            "\n\t\t\t\t\t\t\t\t\tОтразить цвета\n\t\t\t\t\t\t\t\t"
                                          ),
                                        ]
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    [
                                      _c(
                                        "b-form-checkbox",
                                        {
                                          attrs: {
                                            value: 1,
                                            "unchecked-value": 0,
                                          },
                                          model: {
                                            value: gauge.is_main,
                                            callback: function ($$v) {
                                              _vm.$set(gauge, "is_main", $$v)
                                            },
                                            expression: "gauge.is_main",
                                          },
                                        },
                                        [
                                          _vm._v(
                                            "\n\t\t\t\t\t\t\t\t\tКлючевой\n\t\t\t\t\t\t\t\t"
                                          ),
                                        ]
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "d-flex justify-content-between align-items-center",
                                    },
                                    [
                                      _c("input", {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: gauge.angle,
                                            expression: "gauge.angle",
                                          },
                                        ],
                                        staticClass:
                                          "form-control form-control-sm w-250 mr-2 wiwi",
                                        attrs: {
                                          type: "range",
                                          min: "-0.2",
                                          max: "0.2",
                                          step: "0.01",
                                        },
                                        domProps: { value: gauge.angle },
                                        on: {
                                          __r: function ($event) {
                                            return _vm.$set(
                                              gauge,
                                              "angle",
                                              $event.target.value
                                            )
                                          },
                                        },
                                      }),
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t" +
                                          _vm._s(gauge.angle) +
                                          "\n\t\t\t\t\t\t\t"
                                      ),
                                    ]
                                  ),
                                ],
                                2
                              ),
                              _vm._v(" "),
                              _c("div", { staticClass: "d-flex" }, [
                                _c(
                                  "button",
                                  {
                                    staticClass:
                                      "btn btn-primary rounded mt-1 mr-2",
                                    on: {
                                      click: function ($event) {
                                        return _vm.save(
                                          group_index,
                                          gauge_index
                                        )
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\tСохранить\n\t\t\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "button",
                                  {
                                    staticClass: "btn btn-danger rounded mt-1",
                                    on: {
                                      click: function ($event) {
                                        return _vm.delete_gauge(
                                          group_index,
                                          gauge_index
                                        )
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\tУдалить\n\t\t\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                              ]),
                            ]
                          ),
                        ]
                      )
                    }),
                    0
                  )
                : _vm._e(),
            ]
          ),
        ]
      }),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          staticClass: "modalle",
          attrs: { title: "Добавить новый спидометр", size: "lg" },
          on: {
            ok: function ($event) {
              return _vm.create_gauge()
            },
          },
          model: {
            value: _vm.showNewGaugeWindow,
            callback: function ($$v) {
              _vm.showNewGaugeWindow = $$v
            },
            expression: "showNewGaugeWindow",
          },
        },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-5" }, [
              _c("p", [_vm._v("Название")]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-7" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.newGauge.name,
                    expression: "newGauge.name",
                  },
                ],
                staticClass: "form-control form-control-sm",
                attrs: { type: "text" },
                domProps: { value: _vm.newGauge.name },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.newGauge, "name", $event.target.value)
                  },
                },
              }),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row  mt-1" }, [
            _c("div", { staticClass: "col-5" }, [
              _c("p", {}, [
                _vm._v("\n\t\t\t\t\tВыберите откуда брать данные\n\t\t\t\t"),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-7" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.newGauge.activity_id,
                      expression: "newGauge.activity_id",
                    },
                  ],
                  staticClass: "form-control form-control-sm",
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.$set(
                        _vm.newGauge,
                        "activity_id",
                        $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      )
                    },
                  },
                },
                [
                  _c("option", { key: -1, domProps: { value: -1 } }, [
                    _vm._v("\n\t\t\t\t\t\tЯчейка из сводной\n\t\t\t\t\t"),
                  ]),
                  _vm._v(" "),
                  _vm._l(_vm.group_activities, function (group_activity, key) {
                    return _c(
                      "option",
                      { key: key, domProps: { value: group_activity.id } },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(group_activity.name) +
                            "\n\t\t\t\t\t"
                        ),
                      ]
                    )
                  }),
                ],
                2
              ),
            ]),
          ]),
          _vm._v(" "),
          _vm.newGauge.activity_id == -1
            ? _c("div", { staticClass: "row  mt-1" }, [
                _c("div", { staticClass: "col-5" }, [
                  _c("p", {}, [
                    _vm._v(
                      "\n\t\t\t\t\tВыберите ячейку из аналитики\n\t\t\t\t"
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-7" }, [
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.newGauge.cell,
                        expression: "newGauge.cell",
                      },
                    ],
                    staticClass: "form-control form-control-sm",
                    attrs: { type: "text" },
                    domProps: { value: _vm.newGauge.cell },
                    on: {
                      input: function ($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.newGauge, "cell", $event.target.value)
                      },
                    },
                  }),
                ]),
              ])
            : _vm._e(),
          _vm._v(" "),
          _vm.newGauge.activity_id != -1
            ? _c("div", { staticClass: "row  mt-1" }, [
                _c("div", { staticClass: "col-5" }, [
                  _c("p", {}, [_vm._v("\n\t\t\t\t\tКакое значение\n\t\t\t\t")]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-7" }, [
                  _c(
                    "select",
                    {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.newGauge.value_type,
                          expression: "newGauge.value_type",
                        },
                      ],
                      staticClass: "form-control form-control-sm",
                      on: {
                        change: function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.$set(
                            _vm.newGauge,
                            "value_type",
                            $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          )
                        },
                      },
                    },
                    [
                      _c("option", { attrs: { value: "sum" } }, [
                        _vm._v("\n\t\t\t\t\t\tСумма выполненного\n\t\t\t\t\t"),
                      ]),
                      _vm._v(" "),
                      _c("option", { attrs: { value: "avg" } }, [
                        _vm._v("\n\t\t\t\t\t\tСреднее значение\n\t\t\t\t\t"),
                      ]),
                    ]
                  ),
                ]),
              ])
            : _vm._e(),
        ]
      ),
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);