"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["TableQualityPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _stores_Portal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/Portal */ "./resources/js/stores/Portal.js");
/* harmony import */ var _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/ui/Sidebar */ "./resources/js/components/ui/Sidebar.vue");
/* harmony import */ var _pages_CourseResults__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/pages/CourseResults */ "./resources/js/pages/CourseResults.vue");
/* harmony import */ var _composables_yearOptions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../composables/yearOptions */ "./resources/js/composables/yearOptions.js");
/* harmony import */ var _ui_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ui/Button */ "./resources/js/components/ui/Button.vue");
/* harmony import */ var _ui_Table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ui/Table */ "./resources/js/components/ui/Table.vue");
/* harmony import */ var _ui_Switch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ui/Switch */ "./resources/js/components/ui/Switch.vue");
/* harmony import */ var _stores_api_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/stores/api.js */ "./resources/js/stores/api.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */




 // сайдбар table
 // результаты по курсам






// import Template from "../../../../public/static/partner/templates/template.html";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TableQuality',
  components: {
    Sidebar: _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_1__["default"],
    CourseResults: _pages_CourseResults__WEBPACK_IMPORTED_MODULE_2__["default"],
    JobtronButton: _ui_Button__WEBPACK_IMPORTED_MODULE_4__["default"],
    JobtronTable: _ui_Table__WEBPACK_IMPORTED_MODULE_5__["default"],
    JobtronSwitch: _ui_Switch__WEBPACK_IMPORTED_MODULE_6__["default"]
  },
  props: {
    groups: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    individual_type: {
      type: Object,
      "default": null
    },
    individual_type_id: {
      type: Number,
      "default": null
    },
    active_group: {
      type: String,
      "default": ''
    },
    check: {
      type: String,
      "default": ''
    }
  },
  data: function data() {
    var now = new Date();
    return {
      sendNotifications: false,
      auth_user: this.user,
      currentGroup: this.active_group,
      showChecklist: false,
      checklists: {},
      fields: [],
      checklist_fields: [],
      monthFields: [],
      recordFields: [],
      filters: {
        currentEmployee: 0,
        fromDate: this.$moment().format('YYYY-MM-DD'),
        toDate: this.$moment().format('YYYY-MM-DD')
      },
      can_add_records: false,
      // like kaspi
      script_id: null,
      dialer_id: null,
      fieldsNumber: 15,
      pageNumber: 1,
      currentDay: now.getDate(),
      avgDay: 0,
      avgMonth: 0,
      showCritWindow: false,
      showSettings: false,
      newRecord: {
        id: 0,
        employee_id: 0,
        name: '',
        segment: '1-5',
        segment_id: 1,
        interlocutor: 'Клиент',
        phone: '',
        dayOfDelay: this.$moment().format('YYYY-MM-DD'),
        date: this.$moment().format('YYYY-MM-DD'),
        param1: 0,
        param2: 0,
        param3: 100,
        param4: 0,
        param5: 0,
        comments: '',
        changed: true
      },
      records_unique: 0,
      records: {
        data: []
      },
      deletingElementIndex: 0,
      groupName: 'Контроль качества',
      monthInfo: {},
      user_ids: {},
      currentYear: now.getFullYear(),
      hasPermission: false,
      dataLoaded: true,
      segment: {
        1: '1-5',
        2: 'Нап',
        3: '3160',
        4: '6190',
        5: 'ОВД',
        6: '1-5 RED',
        7: 'Нап RED',
        10: 'ОВД RED',
        11: '6_30 RED',
        12: '6_30'
      },
      loader: null,
      fill: {
        gradient: ['#1890ff', '#28a745']
      },
      items: [],
      params: [],
      pagination: {
        current_page: 1,
        first_page_url: '',
        from: 1,
        last_page: 1,
        last_page_url: '',
        next_page_url: '',
        per_page: 100,
        prev_page_url: null,
        to: 100,
        total: 4866
      },
      individual_request: true,
      viewStaticButton: {
        weekCheck: true,
        montheCheck: false
      },
      active: 1,
      selected_active: 1,
      flagGroup: 'index',
      checklist_tab: false,
      tabIndex: 0
    };
  },
  computed: _objectSpread(_objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_8__.mapState)(_stores_Portal__WEBPACK_IMPORTED_MODULE_0__.usePortalStore, ['portal'])), (0,vuex__WEBPACK_IMPORTED_MODULE_9__.mapGetters)(['user'])), {}, {
    years: function years() {
      if (!this.portal.created_at) return [new Date().getFullYear()];
      return (0,_composables_yearOptions__WEBPACK_IMPORTED_MODULE_3__.useYearOptions)(new Date(this.portal.created_at).getFullYear());
    },
    hasSettingsPermisstion: function hasSettingsPermisstion() {
      return this.user.is_admin === 1;
    },
    recordFieldsFull: function recordFieldsFull() {
      return [{
        key: 'name',
        label: 'Сотрудник',
        tdClass: 'b-table-sticky-column text-left t-name wd',
        thClass: 'b-table-sticky-column text-left t-name'
      }].concat(_toConsumableArray(this.recordFields), [{
        key: 'save',
        label: '',
        tdClass: 'actions',
        thClass: 'actions'
      }, {
        key: 'remove',
        label: '',
        tdClass: 'actions',
        thClass: 'actions'
      }]);
    }
  }),
  watch: {
    groups: function groups() {
      this.init();
    }
  },
  created: function created() {
    if (this.groups) {
      this.init();
    }
  },
  methods: {
    init: function init() {
      var _this = this;
      this.$nextTick( /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var _yield$fetchSettings, settings;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _this.currentGroup = _this.active_group;
                _this.auth_user = _this.user;
                _this.fetchData();
                _context.next = 5;
                return (0,_stores_api_js__WEBPACK_IMPORTED_MODULE_7__.fetchSettings)('okk_send_notifications');
              case 5:
                _yield$fetchSettings = _context.sent;
                settings = _yield$fetchSettings.settings;
                _this.sendNotifications = settings.custom_okk_send_notifications === '1';
              case 8:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      })));
    },
    saveChecklist: function saveChecklist() {
      var _this2 = this;
      this.axios.post('/checklist/save-checklist', {
        checklists: this.checklists
      }).then(function () {
        _this2.toggle();
        _this2.$toast.success('Сохранено');
      });
    },
    showSidebar: function showSidebar(user_id, day) {
      var _this3 = this;
      this.toggle();
      var date = this.currentYear + '-' + this.monthInfo.month.padStart(2, '0') + '-' + day.padStart(2, '0');
      this.axios.post('/checklist/get-checklist-by-user', {
        user_id: user_id,
        created_date: date
      }).then(function (response) {
        _this3.checklists = response.data;
      });
    },
    toggle: function toggle() {
      this.showChecklist = !this.showChecklist;
    },
    viewStaticCheck: function viewStaticCheck(type) {
      if (type == 'w') {
        this.viewStaticButton.weekCheck = true;
        this.viewStaticButton.montheCheck = false;
      } else if (type == 'm') {
        this.viewStaticButton.weekCheck = false;
        this.viewStaticButton.montheCheck = true;
      }
    },
    watchChanges: function watchChanges(values, oldValues) {
      var index = values.findIndex(function (v, i) {
        return v !== oldValues[i];
      });
      // console.log(this.records.data[index]);
      this.records.data[index].changed = true;
    },
    getResults: function getResults() {
      var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
      this.fetchItems('/timetracking/quality-control/records?page=' + page);
    },
    fetchData: function fetchData() {
      var flag = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
      if (flag == 'selected_group') {
        this.flagGroup = 'selected_group';
      }
      var loader = this.$loading.show();
      this.setDates();
      this.fetchItems();
      loader.hide();
    },
    normalizeItems: function normalizeItems() {
      var _this4 = this;
      if (this.items.length > 0) {
        this.newRecord.employee_id = this.items[0].id;
        this.newRecord.name = this.items[0].name;
      }
      this.records.data.forEach(function (record) {
        record.segment = _this4.segment[record.segment_id];
        record.changed = false;
        _this4.params.forEach(function (param, key) {
          record['param' + key] = 0;
        });
        record.param_values.forEach(function (item) {
          _this4.params.forEach(function (param, key) {
            if (item.param_id == param.id) {
              record['param' + key] = item.value;
            }
          });
        });
      });
    },
    addParam: function addParam() {
      this.params.push({
        name: 'Новый критерий',
        id: -1,
        active: 0
      });
    },
    saveSettings: function saveSettings() {
      var _this5 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var loader;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                loader = _this5.$loading.show();
                _context2.prev = 1;
                _context2.next = 4;
                return _this5.axios.post('/timetracking/quality-control/crits/save', {
                  crits: _this5.params,
                  can_add_records: _this5.can_add_records,
                  script_id: _this5.script_id,
                  dialer_id: _this5.dialer_id,
                  group_id: _this5.currentGroup
                });
              case 4:
                _context2.next = 6;
                return (0,_stores_api_js__WEBPACK_IMPORTED_MODULE_7__.updateSettings)({
                  type: 'okk_send_notifications',
                  custom_okk_send_notifications: _this5.sendNotifications
                });
              case 6:
                _this5.$toast.success('Сохранено!!');
                _this5.showSettings = false;
                _this5.fetchData();
                _context2.next = 14;
                break;
              case 11:
                _context2.prev = 11;
                _context2.t0 = _context2["catch"](1);
                alert(_context2.t0);
              case 14:
                loader.hide();
              case 15:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[1, 11]]);
      }))();
    },
    fetchItems: function fetchItems() {
      var _this6 = this;
      var $url = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '/timetracking/quality-control/records';
      var loader = this.$loading.show();

      // console.log(this.individual_type_id,'this.individual_type_id')
      // console.log(this.individual_type,'this.individual_type')
      // console.log(this.flagGroup,'this.flagGroup')
      // console.log(this.currentGroup,'this.currentGroup')

      if (this.individual_type_id != null) {
        if (this.flagGroup == 'index') {
          if (this.individual_type == 2 || this.individual_type == 3) {
            this.currentGroup = this.active_group;
          }
          // this.currentGroup = this.individual_type_id
        }
      }

      this.axios.post($url, {
        day: this.currentDay,
        month: this.monthInfo.month,
        year: this.currentYear,
        employee_id: this.filters.currentEmployee,
        group_id: this.currentGroup,
        individual_type: this.individual_type,
        individual_type_id: this.individual_type_id
      }).then(function (response) {
        _this6.currentGroup = response.data['individual_current'];
        if (response.data.error && response.data.error == 'access') {
          _this6.hasPermission = false;
          loader.hide();
          return;
        }
        _this6.check_result = response.data.check_users;
        _this6.hasPermission = true;
        _this6.items = response.data.items;
        _this6.records = response.data.records;
        _this6.records_unique = response.data.records_unique;
        _this6.avgDay = response.data.avg_day;
        _this6.avgMonth = response.data.avg_month;
        _this6.records = response.data.records;
        _this6.can_add_records = response.data.can_add_records;
        _this6.params = response.data.params;
        _this6.script_id = response.data.script_id;
        _this6.dialer_id = response.data.dialer_id;
        _this6.$toast.success('Записи загружены');
        _this6.normalizeItems();
        _this6.createUserIdList();
        _this6.setChecklistWeekTable();
        _this6.setWeeksTable();
        _this6.setMonthsTable();
        _this6.setRecordsTable();
        _this6.calcTotalWeekField();
        loader.hide();
      });
    },
    chooseEmployee: function chooseEmployee(record) {
      var name = this.items.filter(function (item) {
        return record.employee_id == item.id;
      });
      record['name'] = name[0]['name'];
    },
    setDates: function setDates() {
      this.setYear();
      this.setMonth();
    },
    filterRecords: function filterRecords() {
      this.fetchItems();
    },
    setChecklistWeekTable: function setChecklistWeekTable() {
      this.setChecklistWeeksTableFields();
    },
    setWeeksTable: function setWeeksTable() {
      this.setWeeksTableFields();
    },
    setMonthsTable: function setMonthsTable() {
      this.setMonthsTableFields();
    },
    statusChanged: function statusChanged(record) {
      record.changed = true;
    },
    createUserIdList: function createUserIdList() {
      var _this7 = this;
      this.items.forEach(function (item) {
        _this7.user_ids[item.id] = item.name;
      });
    },
    editRecordModal: function editRecordModal(record) {
      this.newRecord.id = record.id;
      this.newRecord.name = record.name;
      this.newRecord.interlocutor = record.interlocutor;
      this.newRecord.employee_id = record.employee_id;
      this.newRecord.phone = record.phone;
      this.newRecord.dayOfDelay = record.dayOfDelay;
      this.newRecord.date = record.date;
      this.newRecord.param1 = record.param1;
      this.newRecord.param2 = record.param2;
      this.newRecord.param3 = record.param3;
      this.newRecord.param4 = record.param4;
      this.newRecord.param5 = record.param5;
      this.newRecord.total = record.total;
      this.newRecord.comments = record.comments;
      this.$bvModal.show('bv-modal');
    },
    addRecord: function addRecord() {
      if (this.filters.currentEmployee == 0) return this.$toast.info('Выберите сотрудника!');
      if (this.records.data.length != 0) this.records.data[0].editable = false;
      var obj = {
        id: 0,
        employee_id: this.filters.currentEmployee,
        name: this.user_ids[this.filters.currentEmployee],
        segment_id: 1,
        phone: '',
        interlocutor: "".concat(this.user.last_name, " ").concat(this.user.name),
        dayOfDelay: 0,
        date: this.$moment().format('YYYY-MM-DD')
      };
      var param_values = [];
      this.params.forEach(function (param, key) {
        param_values.push({
          param_id: param.id,
          value: 0,
          record_id: 0
        });
        obj['param' + key] = 0;
      });
      obj['param_values'] = param_values;
      obj['comments'] = '';
      obj['changed'] = true;
      obj['editable'] = true;
      this.records.data.unshift(obj);
    },
    saveRecord: function saveRecord(record) {
      var _this8 = this;
      var loader = this.$loading.show();
      if (record.phone.length == 0) {
        this.$toast.error('Укажите телефон!!!');
        loader.hide();
        return;
      }
      var obj = {
        id: record.id,
        employee_id: record.employee_id,
        segment_id: record.segment_id,
        phone: record.phone,
        interlocutor: record.interlocutor,
        dayOfDelay: record.dayOfDelay,
        date: record.date,
        param_values: record.param_values.map(function (param) {
          return _objectSpread(_objectSpread({}, param), {}, {
            value: param.value || 0
          });
        }),
        is_send_notification: this.sendNotifications
      };

      // this.params.forEach((param, key) => {
      //     obj['param' + key] = 0;
      // });

      obj['comments'] = record.comments;
      obj['group_id'] = this.currentGroup;
      this.axios.post('/timetracking/quality-control/save', obj).then(function (response) {
        if (response.data.method == 'save') {
          record.id = response.data.id;
          record.total = response.data.total;
          record.segment = _this8.segment[record.segment_id];
          record.name = _this8.user_ids[record.employee_id];
          // this.records.data.shift()
          // this.records.data.unshift(record)
          _this8.$toast.success('Сохранено');
        }
        if (response.data.method == 'update') {
          _this8.$toast.success('Изменено');
        }
        record.changed = false;
        _this8.$bvModal.hide('bv-modal');
        loader.hide();
        _this8.fetchItems();
      })["catch"](function (e) {
        loader.hide();
        alert(e);
      });
    },
    deleteRecordModal: function deleteRecordModal(record, index) {
      this.deletingElementIndex = index;
      this.newRecord.id = record.id;
      this.newRecord.name = record.name;
      this.newRecord.interlocutor = record.interlocutor;
      this.newRecord.employee_id = record.employee_id;
      this.newRecord.phone = record.phone;
      this.newRecord.dayOfDelay = record.dayOfDelay;
      this.newRecord.date = record.date;
      this.newRecord.param1 = record.param1;
      this.newRecord.param2 = record.param2;
      this.newRecord.param3 = record.param3;
      this.newRecord.param4 = record.param4;
      this.newRecord.param5 = record.param5;
      this.newRecord.total = record.total;
      this.newRecord.comments = record.comments;
      this.$bvModal.show('delete-modal');
    },
    deleteRecord: function deleteRecord() {
      var _this9 = this;
      var loader = this.$loading.show();
      this.axios.post('/timetracking/quality-control/delete', {
        id: this.newRecord.id
      }).then(function () {
        _this9.$toast.info('Запись #' + _this9.newRecord.id + ' удалена');
        _this9.$bvModal.hide('delete-modal');

        // ES6 Func
        var index = _this9.records.data.findIndex(function (x) {
          return x.id === _this9.newRecord.id;
        });
        _this9.records.data.splice(index, 1);
        _this9.newRecord.id = 0;
        loader.hide();
      });
    },
    setRecordsTable: function setRecordsTable() {
      this.setRecordsTableFields();
      if (this.records.data.length > 0) this.records.data[0].editable = true;
    },
    editMode: function editMode(item) {
      this.records.data.forEach(function (record) {
        record.editable = false;
      });
      item.editable = true;
    },
    setRecordsTableFields: function setRecordsTableFields() {
      var fieldsArray = [];
      var order = 1;
      if (this.currentGroup == 42) {
        fieldsArray.push({
          key: 'segment',
          label: 'Сегмент',
          type: 'select',
          order: order++,
          tdClass: 'TableQuality-input text-center segment-width',
          thClass: 'TableQuality-input text-center segment-width'
        });
      }
      fieldsArray.push({
        key: 'phone',
        label: 'Номер телефона',
        typ: 'text',
        order: order++,
        tdClass: 'TableQuality-input text-center phoner',
        thClass: 'TableQuality-input text-center phoner'
      });
      if (this.currentGroup == 42) {
        fieldsArray.push({
          key: 'dayOfDelay',
          label: 'День просрочки',
          type: 'date',
          order: order++,
          tdClass: ' text-center ',
          thClass: ' text-center '
        });
      }
      fieldsArray.push({
        key: 'date',
        label: 'Дата прослушки',
        type: 'date',
        order: order++,
        tdClass: ' text-center ',
        thClass: ' text-center '
      });
      this.params.forEach(function (param, k) {
        fieldsArray.push({
          key: 'param' + k,
          label: param.name,
          type: 'number',
          order: order++,
          tdClass: 'text-center arg number',
          thClass: 'text-center arg number'
        });
      });
      fieldsArray.push({
        key: 'total',
        label: 'Сумма оценки',
        type: 'auto',
        order: order++,
        tdClass: ' text-center number',
        thClass: ' text-center number'
      });
      fieldsArray.push({
        key: 'comments',
        label: 'Совет',
        type: 'text',
        order: order++,
        tdClass: ' text-center comments',
        thClass: ' text-center comments'
      });
      fieldsArray.push({
        key: 'interlocutor',
        label: 'Оценил',
        type: 'text',
        order: order++,
        tdClass: ' text-center ',
        thClass: ' text-center '
      });
      this.recordFields = fieldsArray;
    },
    setMonthsTableFields: function setMonthsTableFields() {
      var fieldsArray = [];
      var order = 1;
      fieldsArray.push({
        key: 'total',
        name: 'Итог',
        order: order++,
        klass: ' text-center px-1 t-total'
      });
      fieldsArray.push({
        key: 'quantity',
        name: 'N',
        order: order++,
        klass: ' text-center px-1 t-quantity'
      });
      for (var i = 1; i <= 12; i++) {
        if (i.length == 1) i = '0' + i;
        fieldsArray.push({
          key: i,
          name: this.$moment(this.currentYear + '-' + i + '-01').format('MMMM'),
          order: order++,
          klass: 'text-center px-1 month'
        });
      }
      this.monthFields = fieldsArray;
    },
    calcTotalWeekField: function calcTotalWeekField() {
      var _this10 = this;
      var weekly_totals = [];
      this.fields.forEach(function (field) {
        var total = 0;
        var count = 0;
        var key = field.key;
        _this10.items.forEach(function (item) {
          if (item.weeks[key] !== undefined && Number(item.weeks[key]) > 0) {
            total += Number(item.weeks[key]);
            count++;
          }
        });
        weekly_totals[key] = count > 0 ? Number(total / count).toFixed(0) : 0;
      });
      this.items.unshift({
        id: 0,
        name: '',
        months: {},
        weeks: weekly_totals
      });
    },
    setChecklistWeeksTableFields: function setChecklistWeeksTableFields() {
      var fieldsArray = [];
      var weekNumber = 1;
      var order = 1;
      // eslint-disable-next-line no-unused-vars
      var day = 1;
      fieldsArray.push({
        key: 'total',
        name: 'Итог',
        order: order++,
        klass: ' text-center px-1 t-total'
      });
      for (var i = 1; i <= this.monthInfo.daysInMonth; i++) {
        var m = this.monthInfo.month.toString();
        var d = i;
        if (d.toString().length == 1) d = '0' + d;
        if (m.length == 1) m = '0' + m;
        //console.log(this.currentYear + '-' + m + '-' + d)

        var date = this.$moment(this.currentYear + '-' + m + '-' + d);
        var dow = date.day();
        fieldsArray.push({
          key: i,
          name: i,
          order: order++,
          klass: 'text-center px-1',
          type: 'day'
        });
        if (dow == 0) {
          fieldsArray.push({
            key: 'avg' + weekNumber,
            name: 'Ср. ' + weekNumber,
            order: order++,
            klass: 'text-center px-1 averages',
            type: 'avg'
          });
          weekNumber++;
          // eslint-disable-next-line no-unused-vars
          day = 0;
        }
        if (dow != 0 && i == this.monthInfo.daysInMonth) {
          fieldsArray.push({
            key: 'avg' + weekNumber,
            name: 'Ср. ' + weekNumber,
            order: order++,
            klass: 'text-center px-1 averages',
            type: 'avg'
          });
        }
        // eslint-disable-next-line no-unused-vars
        day++;
      }
      this.checklist_fields = fieldsArray;
    },
    setWeeksTableFields: function setWeeksTableFields() {
      var fieldsArray = [];
      var weekNumber = 1;
      var order = 1;
      fieldsArray.push({
        key: 'total',
        name: 'Итог',
        order: order++,
        klass: ' text-center px-1 t-total'
      });
      for (var i = 1; i <= this.monthInfo.daysInMonth; i++) {
        var m = this.monthInfo.month.toString();
        var d = i;
        if (d.toString().length == 1) d = '0' + d;
        if (m.length == 1) m = '0' + m;
        //console.log(this.currentYear + '-' + m + '-' + d)

        var date = this.$moment(this.currentYear + '-' + m + '-' + d);
        var dow = date.day();
        fieldsArray.push({
          key: i,
          name: i,
          order: order++,
          klass: 'text-center px-1',
          type: 'day'
        });
        if (dow == 0) {
          fieldsArray.push({
            key: 'avg' + weekNumber,
            name: 'Ср. ' + weekNumber,
            order: order++,
            klass: 'text-center px-1 averages',
            type: 'avg'
          });
          weekNumber++;
        }
        if (dow != 0 && i == this.monthInfo.daysInMonth) {
          fieldsArray.push({
            key: 'avg' + weekNumber,
            name: 'Ср. ' + weekNumber,
            order: order++,
            klass: 'text-center px-1 averages',
            type: 'avg'
          });
        }
      }
      this.fields = fieldsArray;
    },
    updateWeekValue: function updateWeekValue(item, key) {
      var _this11 = this;
      var loader = this.$loading.show();
      this.axios.post('/timetracking/quality-control/saveweekly', {
        day: key,
        month: this.monthInfo.month,
        year: this.currentYear,
        total: item.weeks[key],
        user_id: item.id,
        group_id: this.currentGroup
      }).then(function () {
        loader.hide();
        _this11.fetchData();
        _this11.$toast.success('Сохранено');
      })["catch"](function (e) {
        loader.hide();
        alert(e);
      });
    },
    changeStat: function changeStat(record) {
      this.params.forEach(function (param, k) {
        if (record['param' + k] < 0) record['param' + k] = 0;
        if (record['param' + k] > 100) record['param' + k] = 100;
        if (record.param_values[k] !== undefined) {
          record.param_values[k].value = Number(record['param' + k]);
        } else {
          record.param_values[k] = {
            id: 0,
            param_id: param.id,
            record_id: record.id,
            value: Number(record['param' + k])
          };
        }
      });
      record.changed = true;
      var total = 0;
      this.params.forEach(function (param, k) {
        record.param_values[k].value = Number(record['param' + k]);
        total += Number(record['param' + k]);
      });
      if (Number(total) > 100) total = 100;
      record.total = Number(total);
      //if(this.params.length > 0) record.total = Number(Number(total / this.params.length).toFixed(0));
      //record.total = Number(record.param1) + Number(record.param2) + Number(record.param3) + Number(record.param4) + Number(record.param5)
    },
    setYear: function setYear() {
      this.currentYear = this.currentYear ? this.currentYear : this.$moment().format('YYYY');
    },
    setMonth: function setMonth() {
      this.monthInfo.currentMonth = this.monthInfo.currentMonth ? this.monthInfo.currentMonth : this.$moment().format('MMMM');
      this.monthInfo.month = this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M');
      var currentMonth = this.$moment(this.monthInfo.currentMonth, 'MMMM');
      //Расчет выходных дней
      this.monthInfo.monthEnd = currentMonth.endOf('month'); //Конец месяца
      this.monthInfo.weekDays = currentMonth.weekdayCalc(currentMonth.startOf('month').toString(), currentMonth.endOf('month').toString(), [6]); //Колличество выходных
      this.monthInfo.daysInMonth = new Date(this.currentYear, this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M'), 0).getDate(); //Колличество дней в месяце
      this.monthInfo.workDays = this.monthInfo.daysInMonth - this.monthInfo.weekDays; //Колличество рабочих дней
    },
    toFloat: function toFloat(number) {
      return Number(number).toFixed(0);
    },
    // ucalls or local grades
    change_type: function change_type() {
      var _this12 = this;
      var e = null;
      if (this.can_add_records) {
        e = confirm('Перевести в автоматическую оценку с U-calls?');
      } else {
        e = confirm('Перевести в ручную оценку?');
      }
      if (e) {
        var loader = this.$loading.show();
        this.axios.post('/timetracking/quality-control/change-type', {
          type: this.can_add_records ? 'ucalls' : 'local',
          group_id: this.currentGroup
        }).then(function () {
          _this12.$toast.success('Сохранено!');
          _this12.fetchData();
          loader.hide();
        })["catch"](function (e) {
          loader.hide();
          alert(e);
        });
      }
    },
    exportData: function exportData() {
      var link = '/timetracking/quality-control/export';
      link += '?group_id=' + this.currentGroup;
      link += '&day=' + this.currentDay;
      link += '&month=' + this.monthInfo.month;
      link += '&year=' + this.currentYear;
      window.location.href = link;
    },
    exportAll: function exportAll() {
      var link = '/timetracking/quality-control/exportall';
      link += '?month=' + this.monthInfo.month;
      link += '&group_id=' + this.currentGroup;
      link += '&year=' + this.currentYear;
      window.location.href = link;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'ProgressBar',
  components: {},
  props: {
    progress: {
      type: String,
      "default": '0%'
    },
    color: {
      type: String,
      "default": 'green'
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'JobtronSwitch',
  components: {},
  props: {
    value: {
      type: Boolean
    }
  },
  data: function data() {
    return {
      localValue: this.value
    };
  },
  watch: {
    value: function value() {
      this.localValue = this.value;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'JobtronTable',
  components: {},
  props: {
    fields: {
      type: Array,
      required: true
    },
    items: {
      type: Array,
      required: true
    },
    stickyHeader: {
      type: Boolean,
      "default": false
    },
    trClassFn: {
      type: Function,
      "default": function _default() {
        return '';
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ui_Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ui/Button */ "./resources/js/components/ui/Button.vue");
/* harmony import */ var _ui_ProgressBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ui/ProgressBar */ "./resources/js/components/ui/ProgressBar.vue");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"]; if (null != _i) { var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1; try { if (_x = (_i = _i.call(arr)).next, 0 === i) { if (Object(_i) !== _i) return; _n = !1; } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0) { ; } } catch (err) { _d = !0, _e = err; } finally { try { if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return; } finally { if (_d) throw _e; } } return _arr; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */



var BY_USER = 1;
var BY_GROUP = 2;
function formatProgress(num) {
  var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;
  return parseFloat(num.toFixed(precision));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'CourseResults',
  components: {
    ProgressBar: _ui_ProgressBar__WEBPACK_IMPORTED_MODULE_1__["default"],
    JobtronButton: _ui_Button__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    monthInfo: {
      type: Object,
      "default": null
    },
    currentGroup: {
      type: Object,
      "default": null
    }
  },
  data: function data() {
    return {
      data: [],
      type: BY_USER,
      first: true,
      BY_USER: BY_USER,
      BY_GROUP: BY_GROUP,
      users: {
        items: [],
        fields: []
      },
      groups: {
        items: [],
        fields: []
      },
      course2item: {
        name: 'title',
        status: 'status',
        points: 'points',
        progress: 'progress',
        progress_on_week: 'progress_on_week',
        started_at: 'started_at',
        ended_at: 'ended_at'
      },
      courses: {},
      courseItems: {}
    };
  },
  computed: {
    courseItemsTable: function courseItemsTable() {
      var _this = this;
      var result = {};
      var _loop = function _loop() {
        var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
          userId = _Object$entries$_i[0],
          userResult = _Object$entries$_i[1];
        for (var _i2 = 0, _Object$entries2 = Object.entries(userResult); _i2 < _Object$entries2.length; _i2++) {
          var _Object$entries2$_i = _slicedToArray(_Object$entries2[_i2], 2),
            courseId = _Object$entries2$_i[0],
            courseResult = _Object$entries2$_i[1];
          var course = _this.courses[courseId];
          if (!course) continue;
          if (!result[userId]) result[userId] = {};
          courseResult.forEach(function (courseItem) {
            var passedCount = courseItem.passed_stages ? courseItem.passed_stages.length : 0;
            var status = passedCount ? courseItem.stages && courseItem.stages > passedCount ? 'Начат' : 'Завершен' : 'Запланирован';
            var progress = formatProgress(passedCount / courseItem.stages * 100 || 0);
            var points = courseItem.bonuses;
            result[userId][courseItem.item_id] = {
              status: status,
              points: points,
              progress: progress,
              progress_on_week: 0,
              started_at: new Date(),
              ended_at: new Date(0)
            };
            var res = result[userId][courseItem.item_id];
            var weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
            courseItem.passed_stages.forEach(function (stage) {
              var updated = new Date(stage.updated_at);
              if (res.started_at > updated) res.started_at = updated;
              if (res.ended_at < updated) res.ended_at = updated;
              if (updated > weekAgo) res.progress_on_week += 1;
            });
            res.started_at = passedCount ? _this.$moment(res.started_at).format('DD.MM.YYYY') : '';
            res.ended_at = courseItem.stages && courseItem.stages > passedCount ? '' : _this.$moment(res.ended_at).format('DD.MM.YYYY');
            res.progress_on_week = formatProgress(res.progress_on_week / courseItem.stages * 100 || 0);
          });
        }
      };
      for (var _i = 0, _Object$entries = Object.entries(this.courseItems); _i < _Object$entries.length; _i++) {
        _loop();
      }
      return result;
    }
  },
  watch: {
    monthInfo: function monthInfo() {
      this.first = true;
      if (this.type == this.BY_GROUP) {
        this.fetchData('groups');
        this.first = false;
      } else {
        this.fetchData('users');
      }
    },
    currentGroup: function currentGroup() {
      this.first = true;
      if (this.type == this.BY_GROUP) {
        this.fetchData('groups');
        this.first = false;
      } else {
        this.fetchData('users');
      }
    },
    type: function type(val) {
      if (val == this.BY_GROUP && this.first) {
        this.fetchData('groups');
        this.first = false;
      }
    }
  },
  created: function created() {
    this.fetchData();
  },
  methods: {
    fetchData: function fetchData() {
      var _this2 = this;
      var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'users';
      var loader = this.$loading.show();
      this.axios.post('/course-results/get', {
        type: type,
        month: this.monthInfo.month,
        year: this.monthInfo.currentYear,
        group_id: this.currentGroup !== undefined ? this.currentGroup : null
      }).then(function (response) {
        if (type == 'users') {
          _this2.users = response.data.items;
        }
        if (type == 'groups') {
          _this2.groups = response.data.items;
        }
        loader.hide();
      });
    },
    fetchCourseItems: function fetchCourseItems(userId, courseId) {
      var _this3 = this;
      this.axios.get('/course/progress', {
        params: {
          userId: userId,
          courseId: courseId
        }
      }).then(function (_ref) {
        var data = _ref.data;
        if (!_this3.courseItems[userId]) _this3.$set(_this3.courseItems, userId, {});
        _this3.$set(_this3.courseItems[userId], courseId, data.data.courseItems);
        _this3.courses[data.data.course.id] = data.data.course;
      });
    },
    expandUser: function expandUser(item) {
      var _this4 = this;
      var ex = item.expanded;
      this.users.items.forEach(function (i) {
        i.expanded = false;
        if (i.courses) i.courses.forEach(function (c) {
          return _this4.$set(c, 'expanded', false);
        });
      });
      item.expanded = !ex;
    },
    expandCourse: function expandCourse(course, item) {
      var _this5 = this;
      if (course.items && course.items.length > 1) {
        if (!(this.courseItems[item.user_id] && this.courseItems[item.user_id][course.course_id])) {
          this.fetchCourseItems(item.user_id, course.course_id);
        }
        this.users.items.every(function (el) {
          // console.log('el.user_id', el.user_id, item.user_id)
          if (el.user_id !== item.user_id) return true;
          item.courses.forEach(function (c) {
            // console.log('c.course_id', c.course_id, course.course_id)
            if (c.course_id === course.course_id) {
              _this5.$set(c, 'expanded', !c.expanded);
            } else {
              _this5.$set(c, 'expanded', false);
            }
          });
        });
      }
    },
    nullify: function nullify(i, c) {
      var _this6 = this;
      if (!confirm('При обнулении курса все заработанные бонусы исчезнут и курс необходимо пройти еще раз')) {
        return;
      }
      var course = this.users.items[i].courses[c];
      // course
      // ended_at:""
      // name:"Знакомство с нашей компанией"
      // points:"185 / 762 / 24.3%"
      // progress:"30%"
      // progress_on_week:"0%"
      // started_at:"28.07.2022"
      // status:"Запланирован"
      // user_id: 5

      this.nullifyRequest({
        user_id: course.user_id,
        course_id: course.course_id
      }, function () {
        _this6.$toast.success('Прогресс по курсу Обнулен');
        course.progress = '0%';
        course.started_at = '';
        course.ended_at = '';
        course.status = 'Запланирован';
        course.points = '0 / 0 / 0%';
        course.progress_on_week = '0%';
      });
    },
    nullifyRequest: function nullifyRequest(_ref2, callback) {
      var user_id = _ref2.user_id,
        course_id = _ref2.course_id;
      var loader = this.$loading.show();
      this.axios.post('/course/regress', {
        type: 'course',
        user_id: user_id,
        course_id: course_id
      }).then(function (response) {
        callback(response);
      })["catch"](function (e) {
        return console.error(e);
      });
      loader.hide();
    },
    regress: function regress(user_id, course_id, courseItem) {
      var _this7 = this;
      if (!confirm('При обнулении курса все заработанные бонусы исчезнут и курс необходимо пройти еще раз')) return;
      var loader = this.$loading.show();
      this.axios.post('/course/regress', {
        type: 'item',
        user_id: user_id,
        course_item_id: courseItem.id
      }).then(function () {
        _this7.fetchCourseItems(user_id, course_id);
        _this7.$toast.success('Прогресс по разделу курса обнулен');
      })["catch"](function (e) {
        return console.error(e);
      });
      loader.hide();
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=style&index=0&lang=scss&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=style&index=0&lang=scss& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".TableQuality-input {\n  margin: -5px;\n}\n.TableQuality-padding {\n  padding: 5px;\n}\n.TableQuality-dialogs .JobtronTable-th,\n.TableQuality-dialogs .JobtronTable-td {\n  padding: 5px;\n}\n.TableQuality-inputNumber {\n  width: 40px;\n  margin: 0 auto;\n  -moz-appearance: textfield;\n}\n.TableQuality-inputNumber::-webkit-outer-spin-button, .TableQuality-inputNumber::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n.TableQuality-inputPhone {\n  width: 110px;\n  margin: 0 auto;\n}\n.TableQuality-inputComment {\n  min-width: 100px;\n}\n.records-table th, .records-table td {\n  padding: 5px 10px !important;\n}\n.records-table th input, .records-table th textarea, .records-table td input, .records-table td textarea {\n  padding: 0 !important;\n  text-align: center !important;\n  border: none !important;\n  background-color: transparent !important;\n  outline: none !important;\n  box-shadow: none !important;\n  max-height: 100% !important;\n  line-height: 1.1;\n}\n.records-table th textarea, .records-table td textarea {\n  text-align: left !important;\n}\n.check_list_mon {\n  color: #999999;\n  border: 1px solid #e8e8e8;\n}\n.isActiveCheck {\n  background-color: white;\n  color: rgb(24, 144, 255);\n  border: 1px solid #e8e8e8;\n}\n.quality-page.quality-page .table-container .custom-table-quality th,\n.quality-page.quality-page .table-container .custom-table-quality td {\n  min-width: 35px;\n  padding: 0 10px !important;\n  vertical-align: middle;\n}\n.quality-page.quality-page .table-container .custom-table-quality th.averages,\n.quality-page.quality-page .table-container .custom-table-quality td.averages {\n  background-color: #fef2cb;\n}\n.quality-page.quality-page .table-container .custom-table-quality th input,\n.quality-page.quality-page .table-container .custom-table-quality td input {\n  min-width: 35px;\n}\n.quality-page.quality-page .table-container .custom-table-quality th input::-webkit-outer-spin-button,\n.quality-page.quality-page .table-container .custom-table-quality th input::-webkit-inner-spin-button,\n.quality-page.quality-page .table-container .custom-table-quality td input::-webkit-outer-spin-button,\n.quality-page.quality-page .table-container .custom-table-quality td input::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n.quality-page.quality-page .table-container .custom-table-quality th input[type=number],\n.quality-page.quality-page .table-container .custom-table-quality td input[type=number] {\n  -moz-appearance: textfield;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=style&index=0&lang=scss&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=style&index=0&lang=scss& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".ProgressBar {\n  height: 10px;\n  border-radius: 999rem;\n  background: linear-gradient(243.47deg, #F1F1F5 33.3%, #E9F2FF 100%);\n}\n.ProgressBar-bar {\n  min-width: 10px;\n  max-width: 100%;\n  height: 10px;\n  border-radius: 999rem;\n}\n.ProgressBar-bar_green {\n  background: linear-gradient(270deg, #67F1C8 0%, #24E795 100%);\n}\n.ProgressBar-bar_blue {\n  background: linear-gradient(270deg, #67C8F1 0%, #2495E7 100%);\n}\n.ProgressBar-bar_yellow {\n  background: linear-gradient(270deg, #C8F167 0%, #95E724 100%);\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".JobtronSwitch {\n  display: inline-block;\n  position: relative;\n}\n.JobtronSwitch-switch {\n  display: block;\n  width: 48px;\n  height: 30px;\n  background: #8BABD8;\n  border-radius: 20px;\n  cursor: pointer;\n}\n.JobtronSwitch-switch:before {\n  content: \"\";\n  width: 20px;\n  height: 20px;\n  position: absolute;\n  z-index: 3;\n  top: 5px;\n  left: 5px;\n  background-color: #fff;\n  border-radius: 20px;\n  box-shadow: 0px 4px 4px rgba(50, 50, 71, 0.18), 0px 4px 8px rgba(50, 50, 71, 0.16);\n}\n.JobtronSwitch-input {\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  z-index: 5;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  opacity: 0;\n  cursor: pointer;\n}\n.JobtronSwitch-input:checked ~ .JobtronSwitch-switch {\n  background: #3361FF;\n}\n.JobtronSwitch-input:checked ~ .JobtronSwitch-switch:before {\n  left: auto;\n  right: 5px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".JobtronTable {\n  width: 100%;\n  max-width: 100%;\n  border-spacing: 0px;\n  border-radius: 1.2rem 1.2rem 0 0;\n  border-collapse: separate;\n  font-family: \"Inter\", sans-serif;\n  text-align: center;\n  color: #62788B;\n  background-color: transparent;\n}\n.JobtronTable-head {\n  position: relative;\n  overflow: hidden;\n  z-index: 5;\n}\n.JobtronTable-head .JobtronTable-row:first-child .JobtronTable-th:first-child {\n  border-radius: 12px 0 0 0;\n}\n.JobtronTable-head .JobtronTable-row:first-child .JobtronTable-th:first-child:before {\n  content: \"\";\n  position: absolute;\n  top: -11px;\n  left: -13px;\n  transform: skewX(326deg);\n  background-color: #fff;\n  width: 20px;\n  height: 20px;\n  border-radius: 50px;\n}\n.JobtronTable-head .JobtronTable-row:first-child .JobtronTable-th:last-child {\n  border-radius: 0 12px 0 0;\n}\n.JobtronTable-row {\n  position: relative;\n  z-index: 2;\n}\n.JobtronTable-row:last-child .JobtronTable-th,\n.JobtronTable-row:last-child .JobtronTable-td {\n  border-bottom: 1px solid #E7EAEA;\n}\n.JobtronTable-th, .JobtronTable-td {\n  padding: 12px 15px;\n  border-left: 1px solid #E7EAEA;\n  border-top: 1px solid #E7EAEA;\n  line-height: 1.2;\n  font-size: 14px;\n}\n.JobtronTable-th:last-child, .JobtronTable-td:last-child {\n  border-right: 1px solid #E7EAEA;\n}\n.JobtronTable-th {\n  background-color: #F8F9FD;\n  font-weight: 700;\n}\n.JobtronTable-td {\n  background-color: #fff;\n}\n.JobtronTable-sticky {\n  position: sticky;\n  left: 0;\n  z-index: 2;\n  border-right: 1px solid #E7EAEA;\n}\n.JobtronTable-stickyHeader {\n  position: sticky;\n  top: 0;\n  z-index: 2;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".CourseResults-progress {\n  width: 3em;\n  text-align: right;\n}\n.CourseResults .ProgressBar {\n  flex: 1;\n  min-width: 100px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".nullify[data-v-5c273322] {\n  right: -6px;\n  top: -2px;\n  z-index: 2;\n  background: aliceblue;\n  padding: 6px 4px;\n  border-radius: 50px;\n  display: none;\n  cursor: pointer;\n  position: absolute;\n}\n.nullify-wrap[data-v-5c273322] {\n  padding: 5px 10px;\n  margin: -5px -10px;\n}\n.nullify-wrap:hover .nullify[data-v-5c273322] {\n  display: block;\n}\n.expanded-course-item[data-v-5c273322] {\n  background: #d5e9f6;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQuality_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableQuality.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQuality_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQuality_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressBar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ProgressBar.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressBar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressBar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=style&index=0&lang=scss&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=style&index=0&lang=scss& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Table_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Table.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Table_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Table_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=0&lang=scss&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=0&lang=scss& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CourseResults.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_style_index_1_id_5c273322_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_style_index_1_id_5c273322_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_style_index_1_id_5c273322_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/tables/TableQuality.vue":
/*!*********************************************************!*\
  !*** ./resources/js/components/tables/TableQuality.vue ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TableQuality_vue_vue_type_template_id_70d60d60___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TableQuality.vue?vue&type=template&id=70d60d60& */ "./resources/js/components/tables/TableQuality.vue?vue&type=template&id=70d60d60&");
/* harmony import */ var _TableQuality_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TableQuality.vue?vue&type=script&lang=js& */ "./resources/js/components/tables/TableQuality.vue?vue&type=script&lang=js&");
/* harmony import */ var _TableQuality_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TableQuality.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/tables/TableQuality.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TableQuality_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TableQuality_vue_vue_type_template_id_70d60d60___WEBPACK_IMPORTED_MODULE_0__.render,
  _TableQuality_vue_vue_type_template_id_70d60d60___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/tables/TableQuality.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/ProgressBar.vue":
/*!****************************************************!*\
  !*** ./resources/js/components/ui/ProgressBar.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ProgressBar_vue_vue_type_template_id_7ea13d16___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ProgressBar.vue?vue&type=template&id=7ea13d16& */ "./resources/js/components/ui/ProgressBar.vue?vue&type=template&id=7ea13d16&");
/* harmony import */ var _ProgressBar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ProgressBar.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/ProgressBar.vue?vue&type=script&lang=js&");
/* harmony import */ var _ProgressBar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ProgressBar.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/ui/ProgressBar.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ProgressBar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ProgressBar_vue_vue_type_template_id_7ea13d16___WEBPACK_IMPORTED_MODULE_0__.render,
  _ProgressBar_vue_vue_type_template_id_7ea13d16___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/ProgressBar.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/Switch.vue":
/*!***********************************************!*\
  !*** ./resources/js/components/ui/Switch.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Switch.vue?vue&type=template&id=40141c18& */ "./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&");
/* harmony import */ var _Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Switch.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&");
/* harmony import */ var _Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Switch.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.render,
  _Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/Switch.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/Table.vue":
/*!**********************************************!*\
  !*** ./resources/js/components/ui/Table.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Table_vue_vue_type_template_id_fe6d9f84___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Table.vue?vue&type=template&id=fe6d9f84& */ "./resources/js/components/ui/Table.vue?vue&type=template&id=fe6d9f84&");
/* harmony import */ var _Table_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Table.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/Table.vue?vue&type=script&lang=js&");
/* harmony import */ var _Table_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Table.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/ui/Table.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Table_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Table_vue_vue_type_template_id_fe6d9f84___WEBPACK_IMPORTED_MODULE_0__.render,
  _Table_vue_vue_type_template_id_fe6d9f84___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/Table.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/CourseResults.vue":
/*!**********************************************!*\
  !*** ./resources/js/pages/CourseResults.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _CourseResults_vue_vue_type_template_id_5c273322_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CourseResults.vue?vue&type=template&id=5c273322&scoped=true& */ "./resources/js/pages/CourseResults.vue?vue&type=template&id=5c273322&scoped=true&");
/* harmony import */ var _CourseResults_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CourseResults.vue?vue&type=script&lang=js& */ "./resources/js/pages/CourseResults.vue?vue&type=script&lang=js&");
/* harmony import */ var _CourseResults_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CourseResults.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/CourseResults.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _CourseResults_vue_vue_type_style_index_1_id_5c273322_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss& */ "./resources/js/pages/CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;



/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _CourseResults_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CourseResults_vue_vue_type_template_id_5c273322_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _CourseResults_vue_vue_type_template_id_5c273322_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "5c273322",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/CourseResults.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/tables/TableQuality.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/components/tables/TableQuality.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQuality_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableQuality.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQuality_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/ProgressBar.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/components/ui/ProgressBar.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressBar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ProgressBar.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressBar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/components/ui/Switch.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/Table.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/components/ui/Table.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Table_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Table.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Table_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/CourseResults.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/pages/CourseResults.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CourseResults.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/tables/TableQuality.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/components/tables/TableQuality.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQuality_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableQuality.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/ui/ProgressBar.vue?vue&type=style&index=0&lang=scss&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/ui/ProgressBar.vue?vue&type=style&index=0&lang=scss& ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressBar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ProgressBar.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************!*\
  !*** ./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/ui/Table.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************!*\
  !*** ./resources/js/components/ui/Table.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Table_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Table.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/CourseResults.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************!*\
  !*** ./resources/js/pages/CourseResults.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CourseResults.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/pages/CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss& ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_style_index_1_id_5c273322_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=style&index=1&id=5c273322&scoped=true&lang=scss&");


/***/ }),

/***/ "./resources/js/components/tables/TableQuality.vue?vue&type=template&id=70d60d60&":
/*!****************************************************************************************!*\
  !*** ./resources/js/components/tables/TableQuality.vue?vue&type=template&id=70d60d60& ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQuality_vue_vue_type_template_id_70d60d60___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQuality_vue_vue_type_template_id_70d60d60___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableQuality_vue_vue_type_template_id_70d60d60___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableQuality.vue?vue&type=template&id=70d60d60& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=template&id=70d60d60&");


/***/ }),

/***/ "./resources/js/components/ui/ProgressBar.vue?vue&type=template&id=7ea13d16&":
/*!***********************************************************************************!*\
  !*** ./resources/js/components/ui/ProgressBar.vue?vue&type=template&id=7ea13d16& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressBar_vue_vue_type_template_id_7ea13d16___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressBar_vue_vue_type_template_id_7ea13d16___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProgressBar_vue_vue_type_template_id_7ea13d16___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ProgressBar.vue?vue&type=template&id=7ea13d16& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=template&id=7ea13d16&");


/***/ }),

/***/ "./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&":
/*!******************************************************************************!*\
  !*** ./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Switch_vue_vue_type_template_id_40141c18___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Switch.vue?vue&type=template&id=40141c18& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&");


/***/ }),

/***/ "./resources/js/components/ui/Table.vue?vue&type=template&id=fe6d9f84&":
/*!*****************************************************************************!*\
  !*** ./resources/js/components/ui/Table.vue?vue&type=template&id=fe6d9f84& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Table_vue_vue_type_template_id_fe6d9f84___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Table_vue_vue_type_template_id_fe6d9f84___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Table_vue_vue_type_template_id_fe6d9f84___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Table.vue?vue&type=template&id=fe6d9f84& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=template&id=fe6d9f84&");


/***/ }),

/***/ "./resources/js/pages/CourseResults.vue?vue&type=template&id=5c273322&scoped=true&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/pages/CourseResults.vue?vue&type=template&id=5c273322&scoped=true& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_template_id_5c273322_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_template_id_5c273322_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CourseResults_vue_vue_type_template_id_5c273322_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CourseResults.vue?vue&type=template&id=5c273322&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=template&id=5c273322&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=template&id=70d60d60&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableQuality.vue?vue&type=template&id=70d60d60& ***!
  \*******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.groups
    ? _c(
        "div",
        { staticClass: "quality quality-page TableQuality" },
        [
          _c("div", { staticClass: "row" }, [
            _vm.individual_request
              ? _c("div", { staticClass: "col-3" }, [
                  _c(
                    "select",
                    {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.currentGroup,
                          expression: "currentGroup",
                        },
                      ],
                      staticClass: "form-control",
                      on: {
                        change: [
                          function ($event) {
                            var $$selectedVal = Array.prototype.filter
                              .call($event.target.options, function (o) {
                                return o.selected
                              })
                              .map(function (o) {
                                var val = "_value" in o ? o._value : o.value
                                return val
                              })
                            _vm.currentGroup = $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          },
                          function ($event) {
                            return _vm.fetchData("selected_group")
                          },
                        ],
                      },
                    },
                    _vm._l(_vm.groups, function (group) {
                      return _c(
                        "option",
                        { key: group.id, domProps: { value: group.id } },
                        [
                          _vm._v(
                            "\n\t\t\t\t\t" + _vm._s(group.name) + "\n\t\t\t\t"
                          ),
                        ]
                      )
                    }),
                    0
                  ),
                ])
              : _vm._e(),
            _vm._v(" "),
            _c("div", { staticClass: "col-2" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.monthInfo.currentMonth,
                      expression: "monthInfo.currentMonth",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.monthInfo,
                          "currentMonth",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      _vm.fetchData,
                    ],
                  },
                },
                _vm._l(_vm.$moment.months(), function (month) {
                  return _c(
                    "option",
                    { key: month, domProps: { value: month } },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(month) + "\n\t\t\t\t")]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-2" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.currentYear,
                      expression: "currentYear",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.currentYear = $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      },
                      _vm.fetchData,
                    ],
                  },
                },
                _vm._l(_vm.years, function (year) {
                  return _c(
                    "option",
                    { key: year, domProps: { value: year } },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(year) + "\n\t\t\t\t")]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "col-3 d-flex align-items-start" },
              [
                _c(
                  "JobtronButton",
                  {
                    attrs: { small: "" },
                    on: {
                      click: function ($event) {
                        return _vm.fetchData()
                      },
                    },
                  },
                  [_c("i", { staticClass: "fa fa-redo-alt" })]
                ),
              ],
              1
            ),
            _vm._v(" "),
            _vm.hasSettingsPermisstion && _vm.tabIndex === 0
              ? _c(
                  "div",
                  { staticClass: "col-2 text-right" },
                  [
                    _c(
                      "JobtronButton",
                      {
                        staticClass: "ml-a",
                        attrs: { small: "", secondary: "" },
                        on: {
                          click: function ($event) {
                            _vm.showSettings = true
                          },
                        },
                      },
                      [_c("i", { staticClass: "icon-nd-settings" })]
                    ),
                  ],
                  1
                )
              : _vm._e(),
          ]),
          _vm._v(" "),
          _vm.hasPermission
            ? _c(
                "div",
                [
                  _c(
                    "b-tabs",
                    {
                      staticClass: "mt-4",
                      attrs: { type: "card", "default-active-key": 3 },
                      model: {
                        value: _vm.tabIndex,
                        callback: function ($$v) {
                          _vm.tabIndex = $$v
                        },
                        expression: "tabIndex",
                      },
                    },
                    [
                      _c(
                        "b-tab",
                        {
                          key: 1,
                          attrs: { title: "Оценка диалогов", card: "" },
                        },
                        [
                          _c(
                            "div",
                            [
                              _vm.dataLoaded
                                ? _c(
                                    "b-tabs",
                                    {
                                      staticClass: "mt-4 overflow-hidden",
                                      attrs: { type: "card" },
                                    },
                                    [
                                      _c(
                                        "b-tab",
                                        {
                                          key: 1,
                                          attrs: { title: "Неделя", card: "" },
                                        },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "table-responsive table-container mt-4",
                                            },
                                            [
                                              _c(
                                                "table",
                                                {
                                                  staticClass:
                                                    "table table-bordered custom-table-quality",
                                                },
                                                [
                                                  _c("thead", [
                                                    _c(
                                                      "tr",
                                                      [
                                                        _c(
                                                          "th",
                                                          {
                                                            staticClass:
                                                              "b-table-sticky-column text-left t-name wd",
                                                          },
                                                          [
                                                            _c("div", [
                                                              _vm._v(
                                                                "Сотрудник"
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _vm._l(
                                                          _vm.fields,
                                                          function (
                                                            field,
                                                            key
                                                          ) {
                                                            return _c(
                                                              "th",
                                                              {
                                                                key: key,
                                                                class:
                                                                  field.klass,
                                                              },
                                                              [
                                                                _c("div", [
                                                                  _vm._v(
                                                                    _vm._s(
                                                                      field.name
                                                                    )
                                                                  ),
                                                                ]),
                                                              ]
                                                            )
                                                          }
                                                        ),
                                                      ],
                                                      2
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c(
                                                    "tbody",
                                                    _vm._l(
                                                      _vm.items,
                                                      function (item, index) {
                                                        return _c(
                                                          "tr",
                                                          { key: index },
                                                          [
                                                            _c(
                                                              "td",
                                                              {
                                                                staticClass:
                                                                  "b-table-sticky-column text-left t-name wd",
                                                              },
                                                              [
                                                                _c(
                                                                  "div",
                                                                  [
                                                                    _vm._v(
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                        _vm._s(
                                                                          item.name
                                                                        ) +
                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                    ),
                                                                    item.groupName
                                                                      ? [
                                                                          item.groupName ==
                                                                          "Просрочники"
                                                                            ? _c(
                                                                                "b-badge",
                                                                                {
                                                                                  attrs:
                                                                                    {
                                                                                      variant:
                                                                                        "success",
                                                                                    },
                                                                                },
                                                                                [
                                                                                  _vm._v(
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                      _vm._s(
                                                                                        item.groupName
                                                                                      ) +
                                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                  ),
                                                                                ]
                                                                              )
                                                                            : _c(
                                                                                "b-badge",
                                                                                {
                                                                                  attrs:
                                                                                    {
                                                                                      variant:
                                                                                        "primary",
                                                                                    },
                                                                                },
                                                                                [
                                                                                  _vm._v(
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                      _vm._s(
                                                                                        item.groupName
                                                                                      ) +
                                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                  ),
                                                                                ]
                                                                              ),
                                                                        ]
                                                                      : _vm._e(),
                                                                  ],
                                                                  2
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _vm._l(
                                                              _vm.fields,
                                                              function (
                                                                field,
                                                                key
                                                              ) {
                                                                return _c(
                                                                  "td",
                                                                  {
                                                                    key: key,
                                                                    class:
                                                                      field.klass,
                                                                  },
                                                                  [
                                                                    field.type ==
                                                                      "day" &&
                                                                    _vm.can_add_records
                                                                      ? _c(
                                                                          "input",
                                                                          {
                                                                            directives:
                                                                              [
                                                                                {
                                                                                  name: "model",
                                                                                  rawName:
                                                                                    "v-model",
                                                                                  value:
                                                                                    item
                                                                                      .weeks[
                                                                                      field
                                                                                        .key
                                                                                    ],
                                                                                  expression:
                                                                                    "item.weeks[field.key]",
                                                                                },
                                                                              ],
                                                                            attrs:
                                                                              {
                                                                                type: "number",
                                                                                title:
                                                                                  field.key +
                                                                                  " :" +
                                                                                  item.name,
                                                                              },
                                                                            domProps:
                                                                              {
                                                                                value:
                                                                                  item
                                                                                    .weeks[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                              },
                                                                            on: {
                                                                              change:
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  return _vm.updateWeekValue(
                                                                                    item,
                                                                                    field.key
                                                                                  )
                                                                                },
                                                                              input:
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  if (
                                                                                    $event
                                                                                      .target
                                                                                      .composing
                                                                                  ) {
                                                                                    return
                                                                                  }
                                                                                  _vm.$set(
                                                                                    item.weeks,
                                                                                    field.key,
                                                                                    $event
                                                                                      .target
                                                                                      .value
                                                                                  )
                                                                                },
                                                                            },
                                                                          }
                                                                        )
                                                                      : _c(
                                                                          "div",
                                                                          [
                                                                            item
                                                                              .weeks[
                                                                              field
                                                                                .key
                                                                            ] !=
                                                                            0
                                                                              ? _c(
                                                                                  "div",
                                                                                  [
                                                                                    _vm._v(
                                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                        _vm._s(
                                                                                          item
                                                                                            .weeks[
                                                                                            field
                                                                                              .key
                                                                                          ]
                                                                                        ) +
                                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                    ),
                                                                                  ]
                                                                                )
                                                                              : _vm._e(),
                                                                          ]
                                                                        ),
                                                                  ]
                                                                )
                                                              }
                                                            ),
                                                          ],
                                                          2
                                                        )
                                                      }
                                                    ),
                                                    0
                                                  ),
                                                ]
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "b-tab",
                                        {
                                          key: 2,
                                          attrs: { title: "Месяц", card: "" },
                                        },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "table-responsive table-container mt-4",
                                            },
                                            [
                                              _c(
                                                "table",
                                                {
                                                  staticClass:
                                                    "table table-bordered custom-table-quality",
                                                },
                                                [
                                                  _c("thead", [
                                                    _c(
                                                      "tr",
                                                      [
                                                        _c(
                                                          "th",
                                                          {
                                                            staticClass:
                                                              "b-table-sticky-column text-left t-name wd",
                                                          },
                                                          [
                                                            _c("div", [
                                                              _vm._v(
                                                                "Сотрудник"
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _vm._l(
                                                          _vm.monthFields,
                                                          function (
                                                            field,
                                                            key
                                                          ) {
                                                            return _c(
                                                              "th",
                                                              {
                                                                key: key,
                                                                class:
                                                                  field.klass,
                                                              },
                                                              [
                                                                _c("div", [
                                                                  _vm._v(
                                                                    _vm._s(
                                                                      field.name
                                                                    )
                                                                  ),
                                                                ]),
                                                              ]
                                                            )
                                                          }
                                                        ),
                                                      ],
                                                      2
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c(
                                                    "tbody",
                                                    _vm._l(
                                                      _vm.items,
                                                      function (item, index) {
                                                        return _c(
                                                          "tr",
                                                          { key: index },
                                                          [
                                                            _c(
                                                              "td",
                                                              {
                                                                staticClass:
                                                                  "b-table-sticky-column text-left t-name wd",
                                                              },
                                                              [
                                                                _c(
                                                                  "div",
                                                                  [
                                                                    _vm._v(
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                        _vm._s(
                                                                          item.name
                                                                        ) +
                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                    ),
                                                                    item.groupName
                                                                      ? [
                                                                          item.groupName ==
                                                                          "Просрочники"
                                                                            ? _c(
                                                                                "b-badge",
                                                                                {
                                                                                  attrs:
                                                                                    {
                                                                                      variant:
                                                                                        "success",
                                                                                    },
                                                                                },
                                                                                [
                                                                                  _vm._v(
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                      _vm._s(
                                                                                        item.groupName
                                                                                      ) +
                                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                  ),
                                                                                ]
                                                                              )
                                                                            : _c(
                                                                                "b-badge",
                                                                                {
                                                                                  attrs:
                                                                                    {
                                                                                      variant:
                                                                                        "primary",
                                                                                    },
                                                                                },
                                                                                [
                                                                                  _vm._v(
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                      _vm._s(
                                                                                        item.groupName
                                                                                      ) +
                                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                  ),
                                                                                ]
                                                                              ),
                                                                        ]
                                                                      : _vm._e(),
                                                                  ],
                                                                  2
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _vm._l(
                                                              _vm.monthFields,
                                                              function (
                                                                field,
                                                                key
                                                              ) {
                                                                return _c(
                                                                  "td",
                                                                  {
                                                                    key: key,
                                                                    class:
                                                                      field.klass,
                                                                  },
                                                                  [
                                                                    _c("div", [
                                                                      _vm._v(
                                                                        _vm._s(
                                                                          item
                                                                            .months[
                                                                            field
                                                                              .key
                                                                          ]
                                                                        )
                                                                      ),
                                                                    ]),
                                                                  ]
                                                                )
                                                              }
                                                            ),
                                                          ],
                                                          2
                                                        )
                                                      }
                                                    ),
                                                    0
                                                  ),
                                                ]
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _vm.can_add_records
                                        ? _c(
                                            "b-tab",
                                            {
                                              key: "3",
                                              attrs: {
                                                title: "Оценка переговоров",
                                                card: "",
                                              },
                                            },
                                            [
                                              _c(
                                                "div",
                                                { staticClass: "row mt-4" },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "col-6 col-md-3 mb-4",
                                                    },
                                                    [
                                                      _c(
                                                        "select",
                                                        {
                                                          directives: [
                                                            {
                                                              name: "model",
                                                              rawName:
                                                                "v-model",
                                                              value:
                                                                _vm.filters
                                                                  .currentEmployee,
                                                              expression:
                                                                "filters.currentEmployee",
                                                            },
                                                          ],
                                                          staticClass:
                                                            "form-control",
                                                          on: {
                                                            change: [
                                                              function (
                                                                $event
                                                              ) {
                                                                var $$selectedVal =
                                                                  Array.prototype.filter
                                                                    .call(
                                                                      $event
                                                                        .target
                                                                        .options,
                                                                      function (
                                                                        o
                                                                      ) {
                                                                        return o.selected
                                                                      }
                                                                    )
                                                                    .map(
                                                                      function (
                                                                        o
                                                                      ) {
                                                                        var val =
                                                                          "_value" in
                                                                          o
                                                                            ? o._value
                                                                            : o.value
                                                                        return val
                                                                      }
                                                                    )
                                                                _vm.$set(
                                                                  _vm.filters,
                                                                  "currentEmployee",
                                                                  $event.target
                                                                    .multiple
                                                                    ? $$selectedVal
                                                                    : $$selectedVal[0]
                                                                )
                                                              },
                                                              _vm.filterRecords,
                                                            ],
                                                          },
                                                        },
                                                        [
                                                          _c(
                                                            "option",
                                                            {
                                                              domProps: {
                                                                value: 0,
                                                              },
                                                            },
                                                            [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\t\tВыберите сотрудника\n\t\t\t\t\t\t\t\t\t\t"
                                                              ),
                                                            ]
                                                          ),
                                                          _vm._v(" "),
                                                          _vm._l(
                                                            _vm.items,
                                                            function (item) {
                                                              return _c(
                                                                "option",
                                                                {
                                                                  key: item.id,
                                                                  domProps: {
                                                                    value:
                                                                      item.id,
                                                                  },
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        item.name
                                                                      ) +
                                                                      "\n\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              )
                                                            }
                                                          ),
                                                        ],
                                                        2
                                                      ),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "col-2 col-md-1 d-flex align-items-center mb-4",
                                                    },
                                                    [
                                                      _c(
                                                        "select",
                                                        {
                                                          directives: [
                                                            {
                                                              name: "model",
                                                              rawName:
                                                                "v-model",
                                                              value:
                                                                _vm.currentDay,
                                                              expression:
                                                                "currentDay",
                                                            },
                                                          ],
                                                          staticClass:
                                                            "form-control",
                                                          on: {
                                                            change: [
                                                              function (
                                                                $event
                                                              ) {
                                                                var $$selectedVal =
                                                                  Array.prototype.filter
                                                                    .call(
                                                                      $event
                                                                        .target
                                                                        .options,
                                                                      function (
                                                                        o
                                                                      ) {
                                                                        return o.selected
                                                                      }
                                                                    )
                                                                    .map(
                                                                      function (
                                                                        o
                                                                      ) {
                                                                        var val =
                                                                          "_value" in
                                                                          o
                                                                            ? o._value
                                                                            : o.value
                                                                        return val
                                                                      }
                                                                    )
                                                                _vm.currentDay =
                                                                  $event.target
                                                                    .multiple
                                                                    ? $$selectedVal
                                                                    : $$selectedVal[0]
                                                              },
                                                              _vm.fetchData,
                                                            ],
                                                          },
                                                        },
                                                        [
                                                          _c(
                                                            "option",
                                                            {
                                                              attrs: {
                                                                value: "0",
                                                              },
                                                            },
                                                            [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\t\tВсе дни\n\t\t\t\t\t\t\t\t\t\t"
                                                              ),
                                                            ]
                                                          ),
                                                          _vm._v(" "),
                                                          _vm._l(
                                                            _vm.monthInfo
                                                              .daysInMonth,
                                                            function (day) {
                                                              return _c(
                                                                "option",
                                                                {
                                                                  key: day,
                                                                  domProps: {
                                                                    value: day,
                                                                  },
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        day
                                                                      ) +
                                                                      "\n\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              )
                                                            }
                                                          ),
                                                        ],
                                                        2
                                                      ),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "col-4 col-md-8 d-flex align-items-center gap-5 mb-4",
                                                    },
                                                    [
                                                      _c(
                                                        "JobtronButton",
                                                        {
                                                          on: {
                                                            click:
                                                              _vm.addRecord,
                                                          },
                                                        },
                                                        [
                                                          _c("i", {
                                                            staticClass:
                                                              "fa fa-plus",
                                                          }),
                                                          _vm._v(
                                                            " Добавить запись\n\t\t\t\t\t\t\t\t\t"
                                                          ),
                                                        ]
                                                      ),
                                                      _vm._v(" "),
                                                      _c(
                                                        "JobtronButton",
                                                        {
                                                          attrs: {
                                                            success: "",
                                                          },
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.exportData()
                                                            },
                                                          },
                                                        },
                                                        [
                                                          _c("i", {
                                                            staticClass:
                                                              "far fa-file-excel",
                                                          }),
                                                          _vm._v(
                                                            " 20\n\t\t\t\t\t\t\t\t\t"
                                                          ),
                                                        ]
                                                      ),
                                                      _vm._v(" "),
                                                      _c(
                                                        "JobtronButton",
                                                        {
                                                          attrs: {
                                                            success: "",
                                                          },
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.exportAll()
                                                            },
                                                          },
                                                        },
                                                        [
                                                          _c("i", {
                                                            staticClass:
                                                              "far fa-file-excel",
                                                          }),
                                                          _vm._v(
                                                            " Экспорт\n\t\t\t\t\t\t\t\t\t"
                                                          ),
                                                        ]
                                                      ),
                                                    ],
                                                    1
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "col-12 col-md-12 d-flex mb-4 gap-5",
                                                    },
                                                    [
                                                      _c(
                                                        "p",
                                                        { staticClass: "mb-0" },
                                                        [
                                                          _vm._v(
                                                            "\n\t\t\t\t\t\t\t\t\t\tНайдено записей: "
                                                          ),
                                                          _c(
                                                            "b",
                                                            {
                                                              staticClass:
                                                                "bluish",
                                                            },
                                                            [
                                                              _vm._v(
                                                                _vm._s(
                                                                  _vm.records
                                                                    .total
                                                                )
                                                              ),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                      _vm._v(" "),
                                                      _vm.records_unique != 0
                                                        ? _c(
                                                            "p",
                                                            {
                                                              staticClass:
                                                                "mb-0",
                                                            },
                                                            [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\tКол-во сотрудников:\n\t\t\t\t\t\t\t\t\t\t"
                                                              ),
                                                              _c(
                                                                "b",
                                                                {
                                                                  staticClass:
                                                                    "bluish",
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    _vm._s(
                                                                      _vm.records_unique
                                                                    )
                                                                  ),
                                                                ]
                                                              ),
                                                            ]
                                                          )
                                                        : _vm._e(),
                                                      _vm._v(" "),
                                                      _vm.avgMonth != 0
                                                        ? _c(
                                                            "p",
                                                            {
                                                              staticClass:
                                                                "mb-0",
                                                            },
                                                            [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\tСреднее за месяц: "
                                                              ),
                                                              _c(
                                                                "b",
                                                                {
                                                                  staticClass:
                                                                    "bluish",
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    _vm._s(
                                                                      _vm.avgMonth
                                                                    )
                                                                  ),
                                                                ]
                                                              ),
                                                            ]
                                                          )
                                                        : _vm._e(),
                                                      _vm._v(" "),
                                                      _vm.avgDay != 0
                                                        ? _c(
                                                            "p",
                                                            {
                                                              staticClass:
                                                                "mb-0",
                                                            },
                                                            [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\tСреднее за день: "
                                                              ),
                                                              _c(
                                                                "b",
                                                                {
                                                                  staticClass:
                                                                    "bluish",
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    _vm._s(
                                                                      _vm.avgDay
                                                                    )
                                                                  ),
                                                                ]
                                                              ),
                                                            ]
                                                          )
                                                        : _vm._e(),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "TableQuality-dialogs table-responsive",
                                                },
                                                [
                                                  _c("JobtronTable", {
                                                    attrs: {
                                                      fields:
                                                        _vm.recordFieldsFull,
                                                      items: _vm.records.data,
                                                    },
                                                    scopedSlots: _vm._u(
                                                      [
                                                        {
                                                          key: "cell(name)",
                                                          fn: function (ref) {
                                                            var value =
                                                              ref.value
                                                            var item = ref.item
                                                            return [
                                                              _c(
                                                                "div",
                                                                {
                                                                  staticClass:
                                                                    "TableQuality-padding TableQuality-input",
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.editMode(
                                                                          item
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        value
                                                                      ) +
                                                                      "\n\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              ),
                                                            ]
                                                          },
                                                        },
                                                        {
                                                          key: "cell(segment)",
                                                          fn: function (ref) {
                                                            var value =
                                                              ref.value
                                                            var item = ref.item
                                                            return [
                                                              item.editable
                                                                ? _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "TableQuality-input",
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "select",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item.segment_id,
                                                                                expression:
                                                                                  "item.segment_id",
                                                                              },
                                                                            ],
                                                                          staticClass:
                                                                            "form-control text-center sg",
                                                                          on: {
                                                                            change:
                                                                              [
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  var $$selectedVal =
                                                                                    Array.prototype.filter
                                                                                      .call(
                                                                                        $event
                                                                                          .target
                                                                                          .options,
                                                                                        function (
                                                                                          o
                                                                                        ) {
                                                                                          return o.selected
                                                                                        }
                                                                                      )
                                                                                      .map(
                                                                                        function (
                                                                                          o
                                                                                        ) {
                                                                                          var val =
                                                                                            "_value" in
                                                                                            o
                                                                                              ? o._value
                                                                                              : o.value
                                                                                          return val
                                                                                        }
                                                                                      )
                                                                                  _vm.$set(
                                                                                    item,
                                                                                    "segment_id",
                                                                                    $event
                                                                                      .target
                                                                                      .multiple
                                                                                      ? $$selectedVal
                                                                                      : $$selectedVal[0]
                                                                                  )
                                                                                },
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  return _vm.statusChanged(
                                                                                    item
                                                                                  )
                                                                                },
                                                                              ],
                                                                          },
                                                                        },
                                                                        _vm._l(
                                                                          _vm.segment,
                                                                          function (
                                                                            segm,
                                                                            index
                                                                          ) {
                                                                            return _c(
                                                                              "option",
                                                                              {
                                                                                key: index,
                                                                                domProps:
                                                                                  {
                                                                                    value:
                                                                                      index,
                                                                                  },
                                                                              },
                                                                              [
                                                                                _vm._v(
                                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                    _vm._s(
                                                                                      segm
                                                                                    ) +
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                ),
                                                                              ]
                                                                            )
                                                                          }
                                                                        ),
                                                                        0
                                                                      ),
                                                                    ]
                                                                  )
                                                                : _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "TableQuality-padding TableQuality-input",
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.editMode(
                                                                              item
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _vm._v(
                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                                          _vm._s(
                                                                            value
                                                                          ) +
                                                                          "\n\t\t\t\t\t\t\t\t\t\t"
                                                                      ),
                                                                    ]
                                                                  ),
                                                            ]
                                                          },
                                                        },
                                                        {
                                                          key: "cell(phone)",
                                                          fn: function (ref) {
                                                            var value =
                                                              ref.value
                                                            var item = ref.item
                                                            return [
                                                              item.editable
                                                                ? _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "TableQuality-input",
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "input",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item.phone,
                                                                                expression:
                                                                                  "item.phone",
                                                                              },
                                                                            ],
                                                                          staticClass:
                                                                            "TableQuality-inputPhone text-center",
                                                                          attrs:
                                                                            {
                                                                              type: "text",
                                                                            },
                                                                          domProps:
                                                                            {
                                                                              value:
                                                                                item.phone,
                                                                            },
                                                                          on: {
                                                                            focus:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return $event.target.select()
                                                                              },
                                                                            change:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return _vm.statusChanged(
                                                                                  item
                                                                                )
                                                                              },
                                                                            input:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                if (
                                                                                  $event
                                                                                    .target
                                                                                    .composing
                                                                                ) {
                                                                                  return
                                                                                }
                                                                                _vm.$set(
                                                                                  item,
                                                                                  "phone",
                                                                                  $event
                                                                                    .target
                                                                                    .value
                                                                                )
                                                                              },
                                                                          },
                                                                        }
                                                                      ),
                                                                    ]
                                                                  )
                                                                : _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "TableQuality-padding TableQuality-input",
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.editMode(
                                                                              item
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _vm._v(
                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                                          _vm._s(
                                                                            value
                                                                          ) +
                                                                          "\n\t\t\t\t\t\t\t\t\t\t"
                                                                      ),
                                                                    ]
                                                                  ),
                                                            ]
                                                          },
                                                        },
                                                        {
                                                          key: "cell(dayOfDelay)",
                                                          fn: function (ref) {
                                                            var value =
                                                              ref.value
                                                            var item = ref.item
                                                            return [
                                                              item.editable
                                                                ? _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "TableQuality-input",
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "input",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item.dayOfDelay,
                                                                                expression:
                                                                                  "item.dayOfDelay",
                                                                              },
                                                                            ],
                                                                          staticClass:
                                                                            "TableQuality-inputNumber text-center",
                                                                          attrs:
                                                                            {
                                                                              type: "text",
                                                                            },
                                                                          domProps:
                                                                            {
                                                                              value:
                                                                                item.dayOfDelay,
                                                                            },
                                                                          on: {
                                                                            focus:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return $event.target.select()
                                                                              },
                                                                            change:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return _vm.statusChanged(
                                                                                  item
                                                                                )
                                                                              },
                                                                            input:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                if (
                                                                                  $event
                                                                                    .target
                                                                                    .composing
                                                                                ) {
                                                                                  return
                                                                                }
                                                                                _vm.$set(
                                                                                  item,
                                                                                  "dayOfDelay",
                                                                                  $event
                                                                                    .target
                                                                                    .value
                                                                                )
                                                                              },
                                                                          },
                                                                        }
                                                                      ),
                                                                    ]
                                                                  )
                                                                : _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "TableQuality-padding TableQuality-input",
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.editMode(
                                                                              item
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _vm._v(
                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                                          _vm._s(
                                                                            value
                                                                          ) +
                                                                          "\n\t\t\t\t\t\t\t\t\t\t"
                                                                      ),
                                                                    ]
                                                                  ),
                                                            ]
                                                          },
                                                        },
                                                        {
                                                          key: "cell(interlocutor)",
                                                          fn: function (ref) {
                                                            var value =
                                                              ref.value
                                                            var item = ref.item
                                                            return [
                                                              _c(
                                                                "div",
                                                                {
                                                                  staticClass:
                                                                    "TableQuality-padding TableQuality-input",
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.editMode(
                                                                          item
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        value
                                                                      ) +
                                                                      "\n\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              ),
                                                            ]
                                                          },
                                                        },
                                                        {
                                                          key: "cell(date)",
                                                          fn: function (ref) {
                                                            var value =
                                                              ref.value
                                                            var item = ref.item
                                                            return [
                                                              _c(
                                                                "div",
                                                                {
                                                                  staticClass:
                                                                    "TableQuality-padding TableQuality-input",
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.editMode(
                                                                          item
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        value
                                                                      ) +
                                                                      "\n\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              ),
                                                            ]
                                                          },
                                                        },
                                                        _vm._l(
                                                          _vm.params,
                                                          function (param, pk) {
                                                            return {
                                                              key:
                                                                "cell(param" +
                                                                pk +
                                                                ")",
                                                              fn: function (
                                                                ref
                                                              ) {
                                                                var value =
                                                                  ref.value
                                                                var item =
                                                                  ref.item
                                                                return [
                                                                  item.editable
                                                                    ? _c(
                                                                        "div",
                                                                        {
                                                                          key: pk,
                                                                          staticClass:
                                                                            "TableQuality-input",
                                                                        },
                                                                        [
                                                                          _c(
                                                                            "input",
                                                                            {
                                                                              directives:
                                                                                [
                                                                                  {
                                                                                    name: "model",
                                                                                    rawName:
                                                                                      "v-model",
                                                                                    value:
                                                                                      item[
                                                                                        "param" +
                                                                                          pk
                                                                                      ],
                                                                                    expression:
                                                                                      "item['param' + pk]",
                                                                                  },
                                                                                ],
                                                                              staticClass:
                                                                                "TableQuality-inputNumber text-center",
                                                                              attrs:
                                                                                {
                                                                                  type: "number",
                                                                                },
                                                                              domProps:
                                                                                {
                                                                                  value:
                                                                                    item[
                                                                                      "param" +
                                                                                        pk
                                                                                    ],
                                                                                },
                                                                              on: {
                                                                                focus:
                                                                                  function (
                                                                                    $event
                                                                                  ) {
                                                                                    return $event.target.select()
                                                                                  },
                                                                                change:
                                                                                  function (
                                                                                    $event
                                                                                  ) {
                                                                                    return _vm.changeStat(
                                                                                      item
                                                                                    )
                                                                                  },
                                                                                input:
                                                                                  function (
                                                                                    $event
                                                                                  ) {
                                                                                    if (
                                                                                      $event
                                                                                        .target
                                                                                        .composing
                                                                                    ) {
                                                                                      return
                                                                                    }
                                                                                    _vm.$set(
                                                                                      item,
                                                                                      "param" +
                                                                                        pk,
                                                                                      $event
                                                                                        .target
                                                                                        .value
                                                                                    )
                                                                                  },
                                                                              },
                                                                            }
                                                                          ),
                                                                        ]
                                                                      )
                                                                    : _c(
                                                                        "div",
                                                                        {
                                                                          key:
                                                                            "e" +
                                                                            pk,
                                                                          staticClass:
                                                                            "TableQuality-padding TableQuality-input",
                                                                          on: {
                                                                            click:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return _vm.editMode(
                                                                                  item
                                                                                )
                                                                              },
                                                                          },
                                                                        },
                                                                        [
                                                                          _vm._v(
                                                                            "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                                              _vm._s(
                                                                                value
                                                                              ) +
                                                                              "\n\t\t\t\t\t\t\t\t\t\t"
                                                                          ),
                                                                        ]
                                                                      ),
                                                                ]
                                                              },
                                                            }
                                                          }
                                                        ),
                                                        {
                                                          key: "cell(comments)",
                                                          fn: function (ref) {
                                                            var value =
                                                              ref.value
                                                            var item = ref.item
                                                            return [
                                                              item.editable
                                                                ? _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "TableQuality-input",
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "textarea",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item.comments,
                                                                                expression:
                                                                                  "item.comments",
                                                                              },
                                                                            ],
                                                                          staticClass:
                                                                            "TableQuality-inputComment form-control",
                                                                          attrs:
                                                                            {
                                                                              type: "text",
                                                                            },
                                                                          domProps:
                                                                            {
                                                                              value:
                                                                                item.comments,
                                                                            },
                                                                          on: {
                                                                            focus:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return $event.target.select()
                                                                              },
                                                                            change:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return _vm.statusChanged(
                                                                                  item
                                                                                )
                                                                              },
                                                                            input:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                if (
                                                                                  $event
                                                                                    .target
                                                                                    .composing
                                                                                ) {
                                                                                  return
                                                                                }
                                                                                _vm.$set(
                                                                                  item,
                                                                                  "comments",
                                                                                  $event
                                                                                    .target
                                                                                    .value
                                                                                )
                                                                              },
                                                                          },
                                                                        }
                                                                      ),
                                                                    ]
                                                                  )
                                                                : _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "TableQuality-padding TableQuality-input",
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.editMode(
                                                                              item
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _vm._v(
                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                                          _vm._s(
                                                                            value
                                                                          ) +
                                                                          "\n\t\t\t\t\t\t\t\t\t\t"
                                                                      ),
                                                                    ]
                                                                  ),
                                                            ]
                                                          },
                                                        },
                                                        {
                                                          key: "cell(save)",
                                                          fn: function (ref) {
                                                            var item = ref.item
                                                            return [
                                                              _c(
                                                                "div",
                                                                {
                                                                  staticClass:
                                                                    "TableQuality-input",
                                                                },
                                                                [
                                                                  item.editable
                                                                    ? _c("i", {
                                                                        staticClass:
                                                                          "fa fa-save btn btn-success btn-icon",
                                                                        on: {
                                                                          click:
                                                                            function (
                                                                              $event
                                                                            ) {
                                                                              return _vm.saveRecord(
                                                                                item
                                                                              )
                                                                            },
                                                                        },
                                                                      })
                                                                    : _vm._e(),
                                                                ]
                                                              ),
                                                            ]
                                                          },
                                                        },
                                                        {
                                                          key: "cell(remove)",
                                                          fn: function (ref) {
                                                            var item = ref.item
                                                            var index =
                                                              ref.index
                                                            return [
                                                              _c(
                                                                "div",
                                                                {
                                                                  staticClass:
                                                                    "TableQuality-input",
                                                                },
                                                                [
                                                                  _c("i", {
                                                                    staticClass:
                                                                      "fa fa-trash btn btn-danger btn-icon",
                                                                    on: {
                                                                      click:
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          return _vm.deleteRecordModal(
                                                                            item,
                                                                            index
                                                                          )
                                                                        },
                                                                    },
                                                                  }),
                                                                ]
                                                              ),
                                                            ]
                                                          },
                                                        },
                                                      ],
                                                      null,
                                                      true
                                                    ),
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "div",
                                                { staticClass: "mt-4" },
                                                [
                                                  _c("b-pagination", {
                                                    attrs: {
                                                      limit: 3,
                                                      "total-rows":
                                                        _vm.records.total,
                                                    },
                                                    on: {
                                                      change: _vm.getResults,
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                            ]
                                          )
                                        : _vm._e(),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                            ],
                            1
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "b-tab",
                        {
                          key: 2,
                          attrs: { title: "Прогресс по курсам", card: "" },
                        },
                        [
                          _c("CourseResults", {
                            attrs: {
                              "month-info": _vm.monthInfo,
                              "current-group": _vm.currentGroup,
                            },
                          }),
                        ],
                        1
                      ),
                      _vm._v(" "),
                       false
                        ? 0
                        : _vm._e(),
                    ],
                    1
                  ),
                ],
                1
              )
            : _c("div", [_c("p", [_vm._v("У вас нет доступа к этой группе")])]),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: { id: "delete-modal", "hide-footer": "" },
              scopedSlots: _vm._u(
                [
                  {
                    key: "modal-title",
                    fn: function () {
                      return [_vm._v("\n\t\t\tПодтвердите удаление\n\t\t")]
                    },
                    proxy: true,
                  },
                ],
                null,
                false,
                3671095489
              ),
            },
            [
              _vm._v(" "),
              _c("div", {}, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12" }, [
                    _c("div", [
                      _vm._v("Вы собираетесь удалить следующую запись"),
                    ]),
                    _vm._v(" "),
                    _c("div", [_vm._v(_vm._s(_vm.newRecord))]),
                  ]),
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "d-flex" },
                  [
                    _c(
                      "b-button",
                      {
                        staticClass: "mt-3 mr-1",
                        attrs: { variant: "danger", block: "" },
                        on: { click: _vm.deleteRecord },
                      },
                      [_vm._v("\n\t\t\t\t\tУдалить\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        staticClass: "mt-3 ml-1",
                        attrs: { variant: "primary", block: "" },
                        on: {
                          click: function ($event) {
                            return _vm.$bvModal.hide("delete-modal")
                          },
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tОтмена\n\t\t\t\t")]
                    ),
                  ],
                  1
                ),
              ]),
            ]
          ),
          _vm._v(" "),
          _c(
            "Sidebar",
            {
              attrs: {
                title: "Настройки",
                open: _vm.showSettings,
                width: "50%",
              },
              on: {
                close: function ($event) {
                  _vm.showSettings = false
                },
              },
            },
            [
              _c("div", { staticClass: "row pr-4" }, [
                _c("div", { staticClass: "col-4 d-flex mb-3" }, [
                  _c("div", { staticClass: "fl" }, [
                    _vm._v("\n\t\t\t\t\tИсточник оценок\n\t\t\t\t\t"),
                    _c("i", {
                      directives: [
                        {
                          name: "b-popover",
                          rawName: "v-b-popover.hover.right.html",
                          value:
                            "Заполнять оценки диалогов и критерии на странице <b>Контроль качества</b>, либо подтягивать их по крону с cp.callibro.org",
                          expression:
                            "'Заполнять оценки диалогов и критерии на странице <b>Контроль качества</b>, либо подтягивать их по крону с cp.callibro.org'",
                          modifiers: { hover: true, right: true, html: true },
                        },
                      ],
                      staticClass: "fa fa-info-circle ml-2",
                      attrs: { title: "Оценки контроля качества" },
                    }),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-8 d-flex mb-3" }, [
                  _c(
                    "div",
                    { staticClass: "fl d-flex" },
                    [
                      _c(
                        "b-form-radio",
                        {
                          staticClass: "mr-3",
                          attrs: { name: "some-radios", value: false },
                          model: {
                            value: _vm.can_add_records,
                            callback: function ($$v) {
                              _vm.can_add_records = $$v
                            },
                            expression: "can_add_records",
                          },
                        },
                        [_vm._v("\n\t\t\t\t\t\tC U-calls\n\t\t\t\t\t")]
                      ),
                      _vm._v(" "),
                      _c(
                        "b-form-radio",
                        {
                          attrs: { name: "some-radios", value: true },
                          model: {
                            value: _vm.can_add_records,
                            callback: function ($$v) {
                              _vm.can_add_records = $$v
                            },
                            expression: "can_add_records",
                          },
                        },
                        [_vm._v("\n\t\t\t\t\t\tРучная оценка\n\t\t\t\t\t")]
                      ),
                    ],
                    1
                  ),
                ]),
                _vm._v(" "),
                !_vm.can_add_records
                  ? _c("div", { staticClass: "col-12" }, [
                      _c("div", { staticClass: "row mb-4" }, [
                        _c("div", { staticClass: "col-4" }, [
                          _vm._v("\n\t\t\t\t\t\tID диалера\n\t\t\t\t\t\t"),
                          _c("i", {
                            directives: [
                              {
                                name: "b-popover",
                                rawName: "v-b-popover.hover.right.html",
                                value:
                                  "Нужен, чтобы <b>подтягивать часы</b> или <b>оценки диалогов</b> для контроля качества.<br>С сервиса cp.callibro.org",
                                expression:
                                  "'Нужен, чтобы <b>подтягивать часы</b> или <b>оценки диалогов</b> для контроля качества.<br>С сервиса cp.callibro.org'",
                                modifiers: {
                                  hover: true,
                                  right: true,
                                  html: true,
                                },
                              },
                            ],
                            staticClass: "fa fa-info-circle ml-2",
                            attrs: { title: "Диалер в U-Calls" },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-8" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.dialer_id,
                                expression: "dialer_id",
                              },
                            ],
                            staticClass: "form-control form-control-sm",
                            attrs: { type: "text", placeholder: "ID" },
                            domProps: { value: _vm.dialer_id },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.dialer_id = $event.target.value
                              },
                            },
                          }),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "row mb-4" }, [
                        _c("div", { staticClass: "col-4" }, [
                          _vm._v("\n\t\t\t\t\t\tID скрипта\n\t\t\t\t\t"),
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col-8" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.script_id,
                                expression: "script_id",
                              },
                            ],
                            staticClass: "form-control form-control-sm",
                            attrs: {
                              type: "number",
                              placeholder: "ID скрипта",
                            },
                            domProps: { value: _vm.script_id },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.script_id = $event.target.value
                              },
                            },
                          }),
                        ]),
                      ]),
                    ])
                  : _vm._e(),
                _vm._v(" "),
                _vm.can_add_records
                  ? _c(
                      "div",
                      { staticClass: "col-12" },
                      [
                        _vm._l(_vm.params, function (crit) {
                          return _c(
                            "div",
                            { key: crit.name, staticClass: "row" },
                            [
                              _c(
                                "div",
                                { staticClass: "col-4 d-flex mb-3" },
                                [
                                  _c("b-form-checkbox", {
                                    attrs: { value: 1, "unchecked-value": 0 },
                                    model: {
                                      value: crit.active,
                                      callback: function ($$v) {
                                        _vm.$set(crit, "active", $$v)
                                      },
                                      expression: "crit.active",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c("div", { staticClass: "col-8 mb-3" }, [
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: crit.name,
                                      expression: "crit.name",
                                    },
                                  ],
                                  staticClass: "form-control form-control-sm",
                                  attrs: { type: "text" },
                                  domProps: { value: crit.name },
                                  on: {
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        crit,
                                        "name",
                                        $event.target.value
                                      )
                                    },
                                  },
                                }),
                              ]),
                            ]
                          )
                        }),
                        _vm._v(" "),
                        _c("div", { staticClass: "row mb-3" }, [
                          _c("div", { staticClass: "col-12" }, [
                            _c(
                              "button",
                              {
                                staticClass: "btn btn-default rounded",
                                staticStyle: { "font-size": "12px" },
                                on: {
                                  click: function ($event) {
                                    return _vm.addParam()
                                  },
                                },
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\tДобавить критерий\n\t\t\t\t\t\t"
                                ),
                              ]
                            ),
                          ]),
                        ]),
                      ],
                      2
                    )
                  : _vm._e(),
                _vm._v(" "),
                _c("div", { staticClass: "col-12" }, [
                  _c("div", { staticClass: "row mb-3" }, [
                    _c("div", { staticClass: "col-4" }, [
                      _vm._v(
                        "\n\t\t\t\t\t\tПоказывать советы в уведомлениях?\n\t\t\t\t\t"
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-8" },
                      [
                        _c("JobtronSwitch", {
                          model: {
                            value: _vm.sendNotifications,
                            callback: function ($$v) {
                              _vm.sendNotifications = $$v
                            },
                            expression: "sendNotifications",
                          },
                        }),
                      ],
                      1
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-12" }, [
                  _c("hr", { staticClass: "mb-4 mt-0" }),
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "col-12" },
                  [
                    _c("JobtronButton", { on: { click: _vm.saveSettings } }, [
                      _vm._v("\n\t\t\t\t\tСохранить\n\t\t\t\t"),
                    ]),
                  ],
                  1
                ),
              ]),
            ]
          ),
          _vm._v(" "),
          _c(
            "Sidebar",
            {
              attrs: {
                title: "Индивидуальный чек лист",
                open: _vm.showChecklist,
                width: "70%",
              },
              on: {
                close: function ($event) {
                  return _vm.toggle()
                },
              },
            },
            [
              _vm._l(_vm.checklists, function (val, ind) {
                return _c("div", { key: ind, staticClass: "col-10 p-0 mt-2" }, [
                  _c(
                    "div",
                    { staticClass: "mr-5" },
                    [
                      _c(
                        "b-form-checkbox",
                        {
                          attrs: { size: "sm" },
                          model: {
                            value: val.checked,
                            callback: function ($$v) {
                              _vm.$set(val, "checked", $$v)
                            },
                            expression: "val.checked",
                          },
                        },
                        [
                          _c("span", { staticStyle: { cursor: "pointer" } }, [
                            _vm._v(_vm._s(val.task.task)),
                          ]),
                        ]
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticStyle: {
                        position: "absolute",
                        right: "0px",
                        top: "0px",
                      },
                    },
                    [
                      val.url
                        ? _c(
                            "a",
                            { attrs: { href: val.url, target: "_blank" } },
                            [_vm._v(_vm._s(val.url))]
                          )
                        : _c("p", [_vm._v("\n\t\t\t\t\tнет ссылки\n\t\t\t\t")]),
                    ]
                  ),
                ])
              }),
              _vm._v(" "),
              _c("div", { staticClass: "col-md-12 mt-3" }, [
                _c("div", { staticClass: "col-md-6 p-0" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-primary",
                      attrs: { title: "Сохранить" },
                      on: {
                        click: function ($event) {
                          $event.preventDefault()
                          return _vm.saveChecklist.apply(null, arguments)
                        },
                      },
                    },
                    [_vm._v("\n\t\t\t\t\tСохранить\n\t\t\t\t")]
                  ),
                ]),
              ]),
            ],
            2
          ),
        ],
        1
      )
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=template&id=7ea13d16&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/ProgressBar.vue?vue&type=template&id=7ea13d16& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "ProgressBar" }, [
    _c("div", {
      staticClass: "ProgressBar-bar",
      class: ["ProgressBar-bar_" + _vm.color],
      style: "width: " + _vm.progress + ";",
    }),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Switch.vue?vue&type=template&id=40141c18& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("span", { staticClass: "JobtronSwitch" }, [
    _c("input", {
      staticClass: "JobtronSwitch-input",
      attrs: { type: "checkbox" },
      domProps: { checked: _vm.localValue },
      on: {
        input: function ($event) {
          return _vm.$emit("input", $event.target.checked)
        },
      },
    }),
    _vm._v(" "),
    _c("span", { staticClass: "JobtronSwitch-switch" }),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=template&id=fe6d9f84&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Table.vue?vue&type=template&id=fe6d9f84& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.fields && _vm.items
    ? _c("table", { staticClass: "JobtronTable" }, [
        _c("thead", { staticClass: "JobtronTable-head" }, [
          _c(
            "tr",
            {
              staticClass: "JobtronTable-row",
              class: {
                "JobtronTable-stickyHeader": _vm.stickyHeader,
              },
            },
            [
              _vm._l(_vm.fields, function (field) {
                return [
                  !field.hide
                    ? _c(
                        "th",
                        {
                          key: field.key,
                          staticClass: "JobtronTable-th",
                          class: field.thClass,
                          attrs: { colspan: field.colspan },
                        },
                        [
                          _vm.$scopedSlots["header(" + field.key + ")"]
                            ? _vm._t("header(" + field.key + ")", null, {
                                field: field,
                              })
                            : _vm._t(
                                "header",
                                function () {
                                  return [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t" +
                                        _vm._s(field.label) +
                                        "\n\t\t\t\t\t"
                                    ),
                                  ]
                                },
                                { field: field }
                              ),
                        ],
                        2
                      )
                    : _vm._e(),
                ]
              }),
            ],
            2
          ),
        ]),
        _vm._v(" "),
        _c(
          "tbody",
          { staticClass: "JobtronTable-body" },
          _vm._l(_vm.items, function (row, rowIndex) {
            return _c(
              "tr",
              {
                key: rowIndex,
                staticClass: "JobtronTable-row",
                class: [_vm.trClassFn(row)],
              },
              _vm._l(_vm.fields, function (field) {
                return _c(
                  "td",
                  {
                    key: field.key,
                    staticClass: "JobtronTable-td",
                    class: field.tdClass,
                  },
                  [
                    _vm.$scopedSlots["cell(" + field.key + ")"]
                      ? _vm._t("cell(" + field.key + ")", null, {
                          value: row[field.key],
                          item: row,
                          field: field,
                          index: rowIndex,
                        })
                      : _vm._t(
                          "cell",
                          function () {
                            return [
                              _vm._v(
                                "\n\t\t\t\t\t" +
                                  _vm._s(row[field.key]) +
                                  "\n\t\t\t\t"
                              ),
                            ]
                          },
                          {
                            value: row[field.key],
                            item: row,
                            field: field,
                            index: rowIndex,
                          }
                        ),
                  ],
                  2
                )
              }),
              0
            )
          }),
          0
        ),
      ])
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=template&id=5c273322&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/CourseResults.vue?vue&type=template&id=5c273322&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "course-results mt-4 CourseResults" }, [
    _c(
      "div",
      { staticClass: "d-flex mb-4 gap-5" },
      [
        _c(
          "JobtronButton",
          {
            attrs: { fade: _vm.type !== _vm.BY_USER },
            on: {
              click: function ($event) {
                _vm.type = _vm.BY_USER
              },
            },
          },
          [_vm._v("\n\t\t\tПо сотрудникам\n\t\t")]
        ),
        _vm._v(" "),
        _c(
          "JobtronButton",
          {
            attrs: { fade: _vm.type !== _vm.BY_GROUP },
            on: {
              click: function ($event) {
                _vm.type = _vm.BY_GROUP
              },
            },
          },
          [_vm._v("\n\t\t\tПо отделам\n\t\t")]
        ),
      ],
      1
    ),
    _vm._v(" "),
    _vm.type == _vm.BY_USER
      ? _c("div", { staticClass: "by_user" }, [
          _vm.users.items.length > 0
            ? _c("div", { staticClass: "table-responsive table-container" }, [
                _c("table", { staticClass: "table table-bordered" }, [
                  _c("thead", [
                    _c(
                      "tr",
                      _vm._l(_vm.users.fields, function (field, index) {
                        return _c("th", { key: index, class: field.class }, [
                          _c("div", [_vm._v(_vm._s(field.name))]),
                        ])
                      }),
                      0
                    ),
                  ]),
                  _vm._v(" "),
                  _c(
                    "tbody",
                    [
                      _vm._l(_vm.users.items, function (item, i) {
                        return [
                          _c(
                            "tr",
                            {
                              key: i,
                              staticClass: "pointer",
                              class: {
                                "expanded-title": item.expanded,
                              },
                            },
                            _vm._l(_vm.users.fields, function (field, f) {
                              return _c(
                                "td",
                                {
                                  key: f,
                                  class: field.class,
                                  on: {
                                    click: function ($event) {
                                      return _vm.expandUser(item)
                                    },
                                  },
                                },
                                [
                                  field.key == "progress"
                                    ? _c(
                                        "div",
                                        { staticClass: "d-flex jcc aic gap-2" },
                                        [
                                          _c(
                                            "p",
                                            {
                                              staticClass:
                                                "mb-0 CourseResults-progress",
                                            },
                                            [
                                              _vm._v(
                                                "\n\t\t\t\t\t\t\t\t\t\t" +
                                                  _vm._s(item[field.key]) +
                                                  "\n\t\t\t\t\t\t\t\t\t"
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c("ProgressBar", {
                                            attrs: {
                                              progress: item[field.key],
                                            },
                                          }),
                                        ],
                                        1
                                      )
                                    : _c("div", [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t" +
                                            _vm._s(item[field.key]) +
                                            "\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]),
                                ]
                              )
                            }),
                            0
                          ),
                          _vm._v(" "),
                          _vm._l(item.courses, function (course, c) {
                            return [
                              item.expanded
                                ? _c(
                                    "tr",
                                    { key: "c" + c, staticClass: "expanded" },
                                    _vm._l(
                                      _vm.users.fields,
                                      function (field, f) {
                                        return _c(
                                          "td",
                                          {
                                            key: f,
                                            class: [
                                              field.class,
                                              {
                                                pointer:
                                                  course.items &&
                                                  course.items.length > 1,
                                              },
                                            ],
                                            on: {
                                              click: function ($event) {
                                                return _vm.expandCourse(
                                                  course,
                                                  item
                                                )
                                              },
                                            },
                                          },
                                          [
                                            field.key == "progress"
                                              ? _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "d-flex jcc aic gap-2",
                                                  },
                                                  [
                                                    _c(
                                                      "p",
                                                      {
                                                        staticClass:
                                                          "mb-0 CourseResults-progress",
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                                            _vm._s(
                                                              course[field.key]
                                                            ) +
                                                            "\n\t\t\t\t\t\t\t\t\t\t"
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c("ProgressBar", {
                                                      attrs: {
                                                        progress:
                                                          course[field.key],
                                                      },
                                                    }),
                                                  ],
                                                  1
                                                )
                                              : field.key == "name"
                                              ? _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "nullify-wrap relative",
                                                  },
                                                  [
                                                    _vm._v(
                                                      "\n\t\t\t\t\t\t\t\t\t\t" +
                                                        _vm._s(
                                                          course[field.key]
                                                        ) +
                                                        "\n\t\t\t\t\t\t\t\t\t\t"
                                                    ),
                                                    _c("i", {
                                                      staticClass:
                                                        "absolute nullify fa fa-broom",
                                                      attrs: {
                                                        title:
                                                          "Обнулить прогресс",
                                                      },
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          return _vm.nullify(
                                                            i,
                                                            c
                                                          )
                                                        },
                                                      },
                                                    }),
                                                  ]
                                                )
                                              : _c("div", [
                                                  _vm._v(
                                                    "\n\t\t\t\t\t\t\t\t\t\t" +
                                                      _vm._s(
                                                        course[field.key]
                                                      ) +
                                                      "\n\t\t\t\t\t\t\t\t\t"
                                                  ),
                                                ]),
                                          ]
                                        )
                                      }
                                    ),
                                    0
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              course.items &&
                              course.items.length > 1 &&
                              course.expanded
                                ? _vm._l(
                                    course.items,
                                    function (courseItem, ci) {
                                      return _c(
                                        "tr",
                                        {
                                          key: "ci" + ci,
                                          staticClass: "expanded-course-item",
                                        },
                                        _vm._l(
                                          _vm.users.fields,
                                          function (field, f) {
                                            return _c(
                                              "td",
                                              { key: f, class: field.class },
                                              [
                                                _vm.courseItemsTable[
                                                  item.user_id
                                                ] &&
                                                _vm.courseItemsTable[
                                                  item.user_id
                                                ][courseItem.item_id]
                                                  ? [
                                                      field.key === "name"
                                                        ? _c(
                                                            "div",
                                                            {
                                                              staticClass:
                                                                "nullify-wrap relative",
                                                            },
                                                            [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                  _vm._s(
                                                                    courseItem[
                                                                      _vm
                                                                        .course2item[
                                                                        field
                                                                          .key
                                                                      ]
                                                                    ] ||
                                                                      field.key
                                                                  ) +
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                              ),
                                                              _c("i", {
                                                                staticClass:
                                                                  "absolute nullify fa fa-broom",
                                                                attrs: {
                                                                  title:
                                                                    "Обнулить прогресс",
                                                                },
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.regress(
                                                                        item.user_id,
                                                                        course.course_id,
                                                                        courseItem
                                                                      )
                                                                    },
                                                                },
                                                              }),
                                                            ]
                                                          )
                                                        : field.key ===
                                                          "progress"
                                                        ? _c(
                                                            "div",
                                                            {
                                                              staticClass:
                                                                "d-flex jcc aic gap-2",
                                                            },
                                                            [
                                                              _c(
                                                                "p",
                                                                {
                                                                  staticClass:
                                                                    "mb-0 CourseResults-progress",
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        _vm
                                                                          .courseItemsTable[
                                                                          item
                                                                            .user_id
                                                                        ][
                                                                          courseItem
                                                                            .item_id
                                                                        ][
                                                                          _vm
                                                                            .course2item[
                                                                            field
                                                                              .key
                                                                          ]
                                                                        ]
                                                                      ) +
                                                                      "%\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              ),
                                                              _vm._v(" "),
                                                              _c(
                                                                "ProgressBar",
                                                                {
                                                                  attrs: {
                                                                    progress:
                                                                      _vm
                                                                        .courseItemsTable[
                                                                        item
                                                                          .user_id
                                                                      ][
                                                                        courseItem
                                                                          .item_id
                                                                      ][
                                                                        _vm
                                                                          .course2item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      ] + "%",
                                                                  },
                                                                }
                                                              ),
                                                            ],
                                                            1
                                                          )
                                                        : field.key ===
                                                          "progress_on_week"
                                                        ? _c("div", [
                                                            _c(
                                                              "p",
                                                              {
                                                                staticClass:
                                                                  "mb-0 mr-1",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                    _vm._s(
                                                                      _vm
                                                                        .courseItemsTable[
                                                                        item
                                                                          .user_id
                                                                      ][
                                                                        courseItem
                                                                          .item_id
                                                                      ][
                                                                        _vm
                                                                          .course2item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      ]
                                                                    ) +
                                                                    "%\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            ),
                                                          ])
                                                        : [
                                                            _vm._v(
                                                              "\n\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                _vm._s(
                                                                  _vm
                                                                    .courseItemsTable[
                                                                    item.user_id
                                                                  ][
                                                                    courseItem
                                                                      .item_id
                                                                  ][
                                                                    _vm
                                                                      .course2item[
                                                                      field.key
                                                                    ]
                                                                  ]
                                                                ) +
                                                                "\n\t\t\t\t\t\t\t\t\t\t\t"
                                                            ),
                                                          ],
                                                    ]
                                                  : _vm._e(),
                                              ],
                                              2
                                            )
                                          }
                                        ),
                                        0
                                      )
                                    }
                                  )
                                : _vm._e(),
                            ]
                          }),
                        ]
                      }),
                    ],
                    2
                  ),
                ]),
              ])
            : _vm._e(),
        ])
      : _c("div", { staticClass: "by_group" }, [
          _vm.groups.items.length > 0
            ? _c("div", { staticClass: "table-responsive table-container" }, [
                _c("table", { staticClass: "table table-bordered" }, [
                  _c("thead", [
                    _c(
                      "tr",
                      _vm._l(_vm.groups.fields, function (field, index) {
                        return _c("th", { key: index, class: field.class }, [
                          _c("div", [_vm._v(_vm._s(field.name))]),
                        ])
                      }),
                      0
                    ),
                  ]),
                  _vm._v(" "),
                  _c(
                    "tbody",
                    [
                      _vm._l(_vm.groups.items, function (item, i) {
                        return [
                          _c(
                            "tr",
                            { key: i },
                            _vm._l(_vm.groups.fields, function (field, f) {
                              return _c(
                                "td",
                                {
                                  key: f,
                                  class: field.class,
                                  on: {
                                    click: function ($event) {
                                      return _vm.expandUser(item)
                                    },
                                  },
                                },
                                [_c("div", [_vm._v(_vm._s(item[field.key]))])]
                              )
                            }),
                            0
                          ),
                        ]
                      }),
                    ],
                    2
                  ),
                ]),
              ])
            : _vm._e(),
        ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);