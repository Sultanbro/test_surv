"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["UserlistPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'BitMaskCheckGroup',
  components: {},
  props: {
    value: {
      type: Number,
      "default": 0
    },
    options: {
      type: Array,
      "default": function _default() {
        return [{
          value: 1,
          title: 'Пн'
        }, {
          value: 2,
          title: 'Вт'
        }, {
          value: 4,
          title: 'Ср'
        }, {
          value: 8,
          title: 'Чт'
        }, {
          value: 16,
          title: 'Пт'
        }, {
          value: 32,
          title: 'Сб'
        }, {
          value: 64,
          title: 'Вс'
        }];
      }
    },
    red: {
      type: Boolean
    }
  },
  methods: {
    onChange: function onChange(value) {
      this.$emit('input', this.value ^ value);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _pages_professions_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/pages/professions.vue */ "./resources/js/pages/professions.vue");
/* harmony import */ var _pages_groups_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/pages/groups.vue */ "./resources/js/pages/groups.vue");
/* harmony import */ var _pages_shifts_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/pages/shifts.vue */ "./resources/js/pages/shifts.vue");
/* harmony import */ var _composables_asyncPageData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/composables/asyncPageData */ "./resources/js/composables/asyncPageData.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'PageCompany',
  components: {
    Professions: _pages_professions_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    Groups: _pages_groups_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    Shifts: _pages_shifts_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      tabs: [{
        id: 2,
        htmlId: 'nav-home',
        path: '/timetracking/settings?tab=2#nav-home',
        title: 'Должности',
        access: ['positions_view', 'settings_view']
      }, {
        id: 3,
        htmlId: 'nav-profile',
        path: '/timetracking/settings?tab=3#nav-profile',
        title: 'Отделы',
        access: ['groups_view', 'settings_view']
      }, {
        id: 4,
        htmlId: 'nav-shift',
        path: '???',
        title: 'Смены',
        access: ['settings_view']
      }],
      activeTab: 2,
      pageData: {}
    };
  },
  computed: {
    activeTabItem: function activeTabItem() {
      var _this = this;
      return this.tabs.find(function (item) {
        return item.id === _this.activeTab;
      });
    }
  },
  watch: {
    activeTab: function activeTab() {
      this.updatePageData();
    }
  },
  mounted: function mounted() {
    this.updatePageData();
    this.activeTab = Number(this.$route.query.tabswitch ? this.$route.query.tabswitch : 2);
  },
  methods: {
    can: function can(access) {
      var _this2 = this;
      if (access === 'is_admin') return this.$laravel.is_admin;
      if (typeof access === 'string') return this.$can(access);
      return access.some(function (item) {
        return _this2.$can(item);
      });
    },
    updatePageData: function updatePageData() {
      var _this3 = this;
      this.pageData = {};
      (0,_composables_asyncPageData__WEBPACK_IMPORTED_MODULE_3__.useAsyncPageData)("/timetracking/settings?tab=".concat(this.activeTab, "#").concat(this.activeTabItem.htmlId)).then(function (data) {
        _this3.pageData = data;
      })["catch"](function (error) {
        console.error('useAsyncPageData', error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _composables_shifts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/composables/shifts */ "./resources/js/composables/shifts.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'CompanyGroups',
  props: {
    statuseses: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    archived_groupss: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activeuserid: {
      type: Number,
      "default": 0
    }
  },
  data: function data() {
    return {
      isBp: window.location.hostname.split('.')[0] === 'bp',
      addNewGroup: false,
      message: null,
      activebtn: null,
      statuses: [],
      activities: [],
      restore_group: null,
      new_status: '',
      value: [],
      // selected users
      options: [],
      // users options
      workChart: null,
      workChartId: null,
      archived_groups: [],
      payment_terms: '',
      // Условия оплаты труда в группе
      timeon: '09:00',
      timeoff: '18:00',
      dialer_id: null,
      script_id: null,
      talk_minutes: null,
      talk_hours: null,
      // time edit
      time_address: 0,
      editable_time: 0,
      time_address_text: 'Не выбран',
      time_variants: [],
      workdays: 5,
      quality: 'local',
      time_exceptions: [],
      time_exceptions_options: [],
      showEditTimeAddress: false,
      paid_internship: 0,
      show_payment_terms: 0,
      zarplata: '0',
      showKPI: false,
      showDeleteButton: false,
      showArchiveModal: false,
      showAfterEdit: false,
      group_id: 0,
      zoom_link: 'empty',
      // Ссылка zoom для обучения стажеров
      bp_link: 'empty',
      searchUsers: '',
      units: [{
        title: 'За единицу',
        value: 'one'
      }, {
        title: 'За все, первому',
        value: 'first'
      }, {
        title: 'За все, каждому',
        value: 'all'
      }],
      dayparts: [{
        title: 'Весь день',
        value: 0
      }, {
        title: '09:00 - 13:00',
        value: 1
      }, {
        title: '14:00 - 19:00',
        value: 2
      }, {
        title: '12:00 - 16:00',
        value: 3
      }, {
        title: '17:00 - 21:00',
        value: 4
      }]
    };
  },
  computed: {
    filteredUsers: function filteredUsers() {
      var _this = this;
      return this.searchUsers ? this.value.filter(function (v) {
        return v.email.toLowerCase().includes(_this.searchUsers.toLowerCase());
      }) : this.value;
    }
  },
  watch: {
    activeuserid: function activeuserid() {
      this.init();
    }
  },
  created: function created() {
    var _this2 = this;
    this.axios.get('/work-chart').then(function (res) {
      _this2.workChart = res.data.data;
    });
    if (this.activeuserid) {
      this.init();
    }
  },
  methods: {
    resetState: function resetState() {
      this.message = null;
      this.activebtn = null;
      this.activities = [];
      this.restore_group = null;
      this.new_status = '';
      this.value = [];
      this.options = [];
      this.payment_terms = '';
      this.timeon = '09:00';
      this.timeoff = '18:00';
      this.dialer_id = null;
      this.script_id = null;
      this.talk_minutes = null;
      this.talk_hours = null;
      this.time_address = 0;
      this.editable_time = 0;
      this.time_address_text = 'Не выбран';
      this.time_variants = [];
      this.workdays = 5;
      this.quality = 'local';
      this.time_exceptions = [];
      this.time_exceptions_options = [];
      this.showEditTimeAddress = false;
      this.paid_internship = 0;
      this.show_payment_terms = 0;
      this.zarplata = '0';
      this.showKPI = false;
      this.showDeleteButton = false;
      this.showArchiveModal = false;
      this.showAfterEdit = false;
      this.group_id = 0;
    },
    removeValue: function removeValue(index) {
      this.value.splice(index, 1);
      this.searchUsers = '';
    },
    init: function init() {
      var _this3 = this;
      Object.keys(this.statuseses).forEach(function (item) {
        _this3.statuses.push({
          id: item,
          group: _this3.statuseses[item]
        });
      });
      this.archived_groups = this.archived_groupss;
    },
    addTag: function addTag(newTag) {
      var tag = {
        email: newTag,
        ID: newTag
      };
      this.options.push(tag);
      this.value.push(tag);
    },
    addExceptionTag: function addExceptionTag(newTag) {
      var tag = {
        email: newTag,
        ID: newTag
      };
      this.time_exceptions_options.push(tag);
      this.time_exceptions.push(tag);
    },
    messageoff: function messageoff() {
      var _this4 = this;
      setTimeout(function () {
        _this4.message = null;
      }, 3000);
    },
    selectGroup: function selectGroup(value) {
      var _this5 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var loader;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                loader = _this5.$loading.show();
                _context.next = 3;
                return _this5.axios.post('/timetracking/users-new', {
                  id: value.id
                }).then(function (response) {
                  var _response$data;
                  if ((_response$data = response.data) !== null && _response$data !== void 0 && _response$data.data) {
                    var data = response.data.data;
                    _this5.workChartId = data.work_chart_id;
                    _this5.new_status = data.name;
                    _this5.value = data.users;
                    _this5.options = data.users;
                    _this5.timeon = data.timeon;
                    _this5.timeoff = data.timeoff;
                    _this5.group_id = data.group_id;
                    _this5.zoom_link = data.zoom_link;
                    _this5.bp_link = data.bp_link;
                    _this5.dialer_id = data.dialer_id;
                    _this5.talk_minutes = data.talk_minutes;
                    _this5.talk_hours = data.talk_hours;
                    _this5.script_id = data.script_id;
                    _this5.quality = data.quality;
                    _this5.activities = data.activities;
                    _this5.payment_terms = data.payment_terms;
                    _this5.time_address = data.time_address;
                    _this5.workdays = data.workdays;
                    _this5.paid_internship = data.paid_internship;
                    _this5.show_payment_terms = data.show_payment_terms;
                    _this5.editable_time = data.editable_time;
                    if (_this5.time_address != -1 || _this5.time_address != 0) _this5.time_address_text = 'Из аналитики';
                    if (_this5.time_address == -1) _this5.time_address_text = 'Из U-calls';
                    if (_this5.time_address == 0) _this5.time_address_text = 'Не выбран';
                    loader.hide();
                  } else {
                    _this5.value = [];
                  }
                });
              case 3:
                _this5.addNewGroup = false;
              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    addGroup: function addGroup() {
      if (this.$refs.groupsMultiselect) {
        this.$refs.groupsMultiselect.toggle();
      }
      this.addNewGroup = true;
      this.resetState();
    },
    saveusers: function saveusers() {
      var _this6 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var loader;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (_this6.new_status.length) {
                  _context2.next = 2;
                  break;
                }
                return _context2.abrupt("return", _this6.$toast.error('Введите название группы'));
              case 2:
                if (_this6.workChartId) {
                  _context2.next = 4;
                  break;
                }
                return _context2.abrupt("return", _this6.$toast.error('Выберите график работы'));
              case 4:
                // save group data
                loader = _this6.$loading.show();
                if (!_this6.addNewGroup) {
                  _context2.next = 8;
                  break;
                }
                _context2.next = 8;
                return _this6.axios.post('/timetracking/group/save-new', {
                  name: _this6.new_status
                }).then(function (response) {
                  if (response.data.status == 200) {
                    var dataPush = {
                      id: response.data.data.id,
                      group: response.data.data.name
                    };
                    _this6.statuses.push(dataPush);
                    _this6.activebtn = dataPush;
                  } else {
                    _this6.$toast.error('Название "' + _this6.new_status + '" не свободно, выберите другое имя для группы!');
                    loader.hide();
                  }
                });
              case 8:
                _context2.next = 10;
                return _this6.axios.post('/work-chart/group/add', {
                  group_id: _this6.activebtn.id,
                  work_chart_id: _this6.workChartId
                });
              case 10:
                _context2.next = 12;
                return _this6.axios.post('/timetracking/users/group/save-new', {
                  group_id: _this6.activebtn.id,
                  users: _this6.value,
                  group_info: {
                    work_start: _this6.timeon,
                    work_end: _this6.timeoff,
                    name: _this6.new_status,
                    zoom_link: _this6.zoom_link,
                    workdays: _this6.workdays,
                    payment_terms: _this6.payment_terms || null,
                    editable_time: _this6.editable_time,
                    paid_internship: _this6.paid_internship,
                    quality: _this6.quality,
                    show_payment_terms: _this6.show_payment_terms,
                    bp_link: _this6.bp_link
                  },
                  script_id: _this6.script_id,
                  dialer_id: _this6.dialer_id,
                  talk_hours: _this6.talk_hours,
                  talk_minutes: _this6.talk_minutes
                }).then(function () {
                  // this.statuses = response.data.groups;
                  // this.activebtn = response.data.group;
                  _this6.$toast.info('Успешно сохранено');
                  _this6.messageoff();
                  loader.hide();
                })["catch"](function (error) {
                  console.error(error.response);
                  _this6.$toast.info(error.response);
                  loader.hide();
                });
              case 12:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    deleted: function deleted() {
      var _this7 = this;
      if (confirm('Вы уверены что хотите удалить группу?')) {
        this.axios.post('/timetracking/group/delete-new', {
          group: this.activebtn.id
        }).then(function () {
          _this7.$toast.info('Удалена');
        });
        var ind = this.statuses.findIndex(function (item) {
          return item.id === _this7.activebtn.id;
        });
        this.statuses.splice(ind, 1);
        this.activebtn = null;
      }
    },
    showAlert: function showAlert() {
      if (confirm('Вы уверены что хотите удалить всех пользователей?')) {
        this.value = [];
      }
    },
    editTimeAddress: function editTimeAddress() {
      var _this8 = this;
      this.showEditTimeAddress = true;
      this.axios.post('/timetracking/settings/get_time_addresses', {
        group_id: this.activebtn.id
      }).then(function (response) {
        _this8.time_variants = response.data.time_variants;
        _this8.time_exceptions_options = response.data.time_exceptions_options;
        _this8.time_exceptions = response.data.time_exceptions;
      })["catch"](function (error) {
        alert(error);
      });
    },
    restoreGroup: function restoreGroup() {
      var _this9 = this;
      if (!confirm('Вы уверены что хотите восстановить группу?')) {
        return '';
      }
      var loader = this.$loading.show();
      this.axios.post('/timetracking/groups/restore-new', {
        id: this.restore_group.id
      }).then(function () {
        _this9.$toast.success('Восстановлен!');
        var valueSelect = {
          id: _this9.restore_group.id,
          group: _this9.restore_group.name
        };
        _this9.selectGroup(valueSelect);
        _this9.activebtn = valueSelect;
        _this9.restore_group = null;
        _this9.showArchiveModal = false;
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        _this9.$toast.error('Ошибка!');
        alert(error);
      });
    },
    saveTimeAddress: function saveTimeAddress() {
      var _this10 = this;
      this.axios.post('/timetracking/settings/save_time_addresses', {
        group_id: this.activebtn,
        time_address: this.time_address,
        time_exceptions: this.time_exceptions
      }).then(function () {
        if (_this10.time_address != -1 || _this10.time_address != 0) _this10.time_address_text = 'Из аналитики';
        if (_this10.time_address == -1) _this10.time_address_text = 'Из U-calls';
        if (_this10.time_address == 0) _this10.time_address_text = 'Не выбран';
        _this10.time_address_text = _this10.time_variants !== undefined ? _this10.time_variants[_this10.time_address] : 'Не выбран';
      })["catch"](function (error) {
        return alert(error);
      });
      this.showEditTimeAddress = false;
    },
    getShiftDays: _composables_shifts__WEBPACK_IMPORTED_MODULE_0__.getShiftDays
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase, vue/require-prop-types */

// если в БД таблица position пустая, то в props: ['positions'] прилетает пустой массив
// если есть, то прилетает объект, где ключи - id (число), а значение - position (название дложности)

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'CompanyProfessions',
  props: ['positions'],
  data: function data() {
    return {
      data: [],
      new_position: '',
      addNew: false,
      position_id: 0,
      indexation: 0,
      sum: 0,
      activebtn: null,
      isHead: false,
      isSpec: false,
      desc: {
        require: '',
        actions: '',
        time: '',
        salary: '',
        knowledge: '',
        next_step: '',
        show: 0
      },
      isBP: ['bp', 'test'].includes(location.hostname.split('.')[0])
    };
  },
  watch: {
    positions: function positions(value) {
      var _this = this;
      // конвертирую прилетевший объект в массив для работы vue-multiselect
      // если данных нет, то в this.data будет пустой массив
      Object.keys(value).forEach(function (item) {
        _this.data.push({
          id: item,
          position: value[item]
        });
      });
    }
  },
  methods: {
    resetState: function resetState() {
      this.new_position = '';
      this.position_id = 0;
      this.indexation = 0;
      this.sum = 0;
      this.isHead = 0;
      this.isSpec = 0;
      this.activebtn = null;
      this.desc = {
        require: '',
        actions: '',
        time: '',
        salary: '',
        knowledge: '',
        next_step: '',
        show: 0
      };
    },
    addNewPosition: function addNewPosition() {
      if (this.$refs.positionMultiselect) {
        this.$refs.positionMultiselect.toggle();
      }
      this.addNew = true;
      this.resetState();
    },
    selectPosition: function selectPosition(value) {
      var _this2 = this;
      this.addNew = false;
      this.axios.post('/timetracking/settings/positions/get-new', {
        name: value.id
      }).then(function (response) {
        var _response$data;
        //this.$toast.info('Добавлена');
        var data = (_response$data = response.data) === null || _response$data === void 0 ? void 0 : _response$data.data;
        if (!data[0]) return console.error(response);
        _this2.new_position = data[0].position;
        _this2.position_id = data[0].id;
        _this2.indexation = data[0].indexation;
        _this2.isHead = data[0].is_head;
        _this2.isSpec = data[0].is_spec;
        _this2.sum = data[0].sum;
        _this2.desc = {
          require: data[0].require,
          actions: data[0].actions,
          time: data[0].time,
          salary: data[0].salary,
          knowledge: data[0].knowledge,
          next_step: data[0].next_step,
          show: data[0].show
        };
      })["catch"](function (error) {
        console.error(error.response);
      });
    },
    addPosition: function addPosition() {
      var _this3 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var responseAdd, data, dataPush;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _this3.axios.post('/timetracking/settings/positions/add-new', {
                  position: _this3.new_position,
                  is_head: _this3.isHead,
                  is_spec: _this3.isSpec
                });
              case 2:
                responseAdd = _context.sent;
                if (!(responseAdd.data.code === 201)) {
                  _context.next = 5;
                  break;
                }
                return _context.abrupt("return", _this3.$toast.error('Должность с таким названием уже существует!'));
              case 5:
                data = responseAdd.data.data;
                dataPush = {
                  id: data.id,
                  position: data.position
                };
                _this3.position_id = data.id;
                _this3.new_position = data.position;
                _this3.activebtn = dataPush;
                _this3.data.push(dataPush);
                localStorage.setItem('event.updatePositions', JSON.stringify({
                  command: 'addPosition'
                }));
                localStorage.removeItem('event.updatePositions');
              case 13:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    savePosition: function savePosition() {
      var _this4 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var responseSave;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;
                if (_this4.new_position.length) {
                  _context2.next = 3;
                  break;
                }
                return _context2.abrupt("return", _this4.$toast.error('Введите нзвание должности!'));
              case 3:
                if (!_this4.addNew) {
                  _context2.next = 6;
                  break;
                }
                _context2.next = 6;
                return _this4.addPosition();
              case 6:
                _context2.next = 8;
                return _this4.axios.post('/timetracking/settings/positions/save-new', {
                  id: _this4.activebtn.id,
                  new_name: _this4.new_position,
                  indexation: _this4.indexation,
                  sum: _this4.sum,
                  desc: _this4.desc,
                  is_head: _this4.isHead,
                  is_spec: _this4.isSpec
                });
              case 8:
                responseSave = _context2.sent;
                if (!(responseSave.data.status !== 200)) {
                  _context2.next = 11;
                  break;
                }
                return _context2.abrupt("return", _this4.$toast.error('Упс! Что-то пошло не так'));
              case 11:
                _this4.$toast.success(_this4.addNew ? 'Новая должность создана!' : 'Изменения сохранены');
                _this4.addNew = false;
                localStorage.setItem('event.updatePositions', JSON.stringify({
                  command: 'savePosition'
                }));
                localStorage.removeItem('event.updatePositions');
                _context2.next = 20;
                break;
              case 17:
                _context2.prev = 17;
                _context2.t0 = _context2["catch"](0);
                console.error(_context2.t0.message);
              case 20:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[0, 17]]);
      }))();
    },
    deletePosition: function deletePosition() {
      var _this5 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var ind;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!confirm('Вы уверены что хотите удалить должность?')) {
                  _context3.next = 10;
                  break;
                }
                _context3.next = 3;
                return _this5.axios.post('/timetracking/settings/positions/delete', {
                  position: +_this5.activebtn.id
                });
              case 3:
                _this5.$toast.info('Удалена');
                ind = _this5.data.findIndex(function (item) {
                  return item.id === _this5.activebtn.id;
                });
                _this5.data.splice(ind, 1);
                _this5.addNew = false;
                _this5.resetState();
                localStorage.setItem('event.updatePositions', JSON.stringify({
                  command: 'deletePosition'
                }));
                localStorage.removeItem('event.updatePositions');
              case 10:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ui_BitMaskCheckGroup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ui/BitMaskCheckGroup */ "./resources/js/components/ui/BitMaskCheckGroup.vue");
/* harmony import */ var _composables_shifts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/composables/shifts */ "./resources/js/composables/shifts.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



function flipbits(v, digits) {
  return ~v & Math.pow(2, digits) - 1;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'CompanyShifts',
  components: {
    BitMaskCheckGroup: _ui_BitMaskCheckGroup__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      modal: false,
      shiftsData: [],
      workType: 1,
      sidebarName: 'Создание новой смены',
      showSidebar: false,
      editShiftId: null,
      form: {
        name: null,
        workStartTime: null,
        workEndTime: null,
        type: 1,
        restTime: 0,
        workdays: 0,
        dayoffs: 0,
        usualSchedule: 0,
        floatingDayoffs: 0
      },
      typeOptions: [{
        value: 1,
        text: 'Обычная рабочая неделя'
      }, {
        value: 2,
        text: 'Смены'
      }]
    };
  },
  computed: {
    workdays: function workdays() {
      var filled = +this.form.dayoffs || 0;
      return Array(30 - filled).fill(0).map(function (value, index) {
        return index + 1;
      });
    },
    dayoffs: function dayoffs() {
      var filled = +this.form.workdays || 0;
      return Array(30 - filled).fill(0).map(function (value, index) {
        return index + 1;
      });
    }
  },
  mounted: function mounted() {
    this.fetchData();
  },
  methods: {
    fetchData: function fetchData() {
      var _this = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var loader, response;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _this.shiftsData = [];
                loader = _this.$loading.show();
                _context.next = 4;
                return _this.axios.get('/work-chart');
              case 4:
                response = _context.sent;
                if (response.data) {
                  _this.shiftsData = response.data.data || [];
                  _this.shiftsData.forEach(function (shift) {
                    shift.workdays = flipbits(+shift.workdays, 7);
                  });
                  loader.hide();
                }
              case 6:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    createNewShift: function createNewShift() {
      this.resetForm();
      this.showSidebar = true;
      this.sidebarName = 'Создание новой смены';
    },
    openModal: function openModal(id) {
      this.editShiftId = id;
      this.modal = true;
    },
    editShift: function editShift(shift) {
      var splitted = shift.name.split('-');
      var type = typeof shift.work_charts_type === 'number' ? shift.work_charts_type : shift.work_charts_type.id;
      this.editShiftId = shift.id;
      this.form.name = shift.text_name;
      this.form.workStartTime = shift.start_time;
      this.form.workEndTime = shift.end_time;
      this.form.restTime = shift.rest_time || 0;
      this.form.type = type;
      this.form.workdays = splitted[0];
      this.form.dayoffs = splitted[1];
      this.form.usualSchedule = shift.workdays;
      this.form.floatingDayoffs = shift.floating_dayoffs;
      this.sidebarName = "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 ".concat(shift.name);
      this.showSidebar = true;
    },
    deleteShift: function deleteShift() {
      var _this2 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var loader;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                loader = _this2.$loading.show();
                _context2.next = 3;
                return _this2.axios["delete"]('/work-chart/' + _this2.editShiftId);
              case 3:
                _this2.modal = false;
                loader.hide();
                _this2.resetForm();
                _this2.fetchData();
                _this2.$toast.success('Смена удалена');
              case 8:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    resetForm: function resetForm() {
      this.editShiftId = null;
      this.form.name = null;
      this.form.workStartTime = null;
      this.form.workEndTime = null;
      this.form.type = 1;
      this.form.restTime = 0;
      this.form.workdays = 0;
      this.form.dayoffs = 0;
      this.form.usualSchedule = 0;
      this.form.floatingDayoffs = 0;
    },
    onSubmit: function onSubmit() {
      var _this3 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var loader, request, _yield$_this3$axios, data;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (_this3.form.name) {
                  _context3.next = 3;
                  break;
                }
                _this3.$toast.error('Заполните название графика');
                return _context3.abrupt("return");
              case 3:
                if (_this3.form.workStartTime) {
                  _context3.next = 6;
                  break;
                }
                _this3.$toast.error('Заполните рабочее время');
                return _context3.abrupt("return");
              case 6:
                if (_this3.form.workEndTime) {
                  _context3.next = 9;
                  break;
                }
                _this3.$toast.error('Заполните рабочее время');
                return _context3.abrupt("return");
              case 9:
                if (!(_this3.form.type == 2 && (!_this3.form.workdays || !_this3.form.dayoffs))) {
                  _context3.next = 12;
                  break;
                }
                _this3.$toast.error('Выберите график');
                return _context3.abrupt("return");
              case 12:
                if (!(_this3.form.floatingDayoffs > 6)) {
                  _context3.next = 15;
                  break;
                }
                _this3.$toast.error('Укажите корректное кол-во плавающих выходных');
                return _context3.abrupt("return");
              case 15:
                if (_this3.form.type === 2) {
                  _this3.form.floatingDayoffs = 0;
                }
                loader = _this3.$loading.show();
                /* eslint-disable camelcase */
                request = {
                  name: _this3.form.name,
                  start_time: _this3.form.workStartTime,
                  end_time: _this3.form.workEndTime,
                  rest_time: _this3.form.restTime,
                  work_charts_type: _this3.form.type,
                  chart_workdays: _this3.form.workdays,
                  chart_dayoffs: _this3.form.dayoffs,
                  floating_dayoffs: _this3.form.floatingDayoffs,
                  usual_schedule: flipbits(_this3.form.usualSchedule, 7).toString(2).padStart(7, '0')
                };
                /* eslint-enable camelcase */
                _context3.next = 20;
                return _this3.axios[_this3.editShiftId ? 'put' : 'post']("/work-chart/".concat(_this3.editShiftId || ''), request);
              case 20:
                _yield$_this3$axios = _context3.sent;
                data = _yield$_this3$axios.data;
                if (data) {
                  _context3.next = 26;
                  break;
                }
                _this3.$toast.error("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C ".concat(_this3.editShiftId ? 'обновить' : 'добавить', " \u0441\u043C\u0435\u043D\u0443"));
                loader.hide();
                return _context3.abrupt("return");
              case 26:
                if (_this3.editShiftId) {
                  _this3.fetchData();
                  _this3.$toast.success('Смена обновлена');
                } else {
                  _this3.shiftsData.push(_objectSpread(_objectSpread({}, data.data), {}, {
                    workdays: flipbits(+data.data.workdays, 7)
                  }));
                  _this3.$toast.success('Смена добавлена');
                }
                loader.hide();
                _this3.closeSidebar();
              case 29:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    closeSidebar: function closeSidebar() {
      this.showSidebar = false;
      this.resetForm();
    },
    getShiftDays: _composables_shifts__WEBPACK_IMPORTED_MODULE_1__.getShiftDays
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'PageUserlist',
  props: {
    // eslint-disable-next-line vue/prop-name-casing
    is_admin: {
      type: Boolean,
      "default": false
    },
    subdomain: {
      type: String,
      "default": 'nosub'
    },
    positions: {
      type: Array,
      "default": function _default() {
        return [];
      }
    }
  },
  data: function data() {
    return {
      myPositions: [],
      position: 0,
      jobFilters: [{
        text: 'Должность',
        value: 0
      }],
      sel: false,
      newtime: '',
      auth_token: '',
      showFilterModal: false,
      /// Фильтры
      showModal: false,
      /// Какие поля показывать
      showFields: {},
      errors: [],
      useractive: {
        name: '',
        day: '',
        time: ''
      },
      tableFilter: 'active',
      segments: {
        0: 'Нет сегмента',
        1: 'Таргет',
        2: 'HH',
        3: 'promo',
        4: 'messenger',
        5: 'Гарантия труд',
        6: 'HH',
        7: 'Муса',
        8: 'Алина',
        9: 'Салтанат',
        10: 'Акжол',
        11: 'Дархан',
        12: 'Салтанат',
        13: 'Сайт BP',
        14: 'Вход. обр.'
      },
      tableFilters: {
        'all': 'Все',
        'active': 'Работающие',
        'deactivated': 'Уволенные',
        'trainees': 'Стажеры',
        'nonfilled': 'Незаполненные'
      },
      mount: 'Январь',
      items: [],
      fields: [{
        key: 'index',
        label: '№'
      }, {
        key: 'id',
        label: 'id'
      }, {
        key: 'email',
        label: 'Email'
      }, {
        key: 'last_name',
        label: 'Фамилия',
        sortable: true
      }, {
        key: 'name',
        label: 'Имя',
        sortable: true
      }, {
        key: 'groups',
        label: 'Отделы',
        sortable: true
      }, {
        key: 'created_at',
        label: 'Дата регистрации',
        sortable: true
      }, {
        key: 'deleted_at',
        label: 'Дата увольнения',
        sortable: true
      }, {
        key: 'fire_cause',
        label: 'Причина увольнения',
        sortable: true
      }, {
        key: 'user_type',
        label: 'Тип',
        sortable: true
      }, {
        key: 'segment',
        label: 'Сегмент',
        sortable: true
      }, {
        key: 'applied',
        label: 'Дата принятия',
        sortable: true
      }, {
        key: 'full_time',
        label: 'Full/Part',
        sortable: true
      }],
      groups: {
        0: 'Выберите отдел'
      },
      currentGroup: 0,
      currentPage: 1,
      perPage: 20,
      pageOptions: [5, 10, 15],
      sortBy: 'created_at',
      sortDesc: true,
      sortDirection: 'desc',
      can_login_users: [],
      currentUser: null,
      filter: {
        email: '',
        group: 0,
        start_date: null,
        end_date: '2030-01-01',
        start_date_deactivate: '2015-01-01',
        end_date_deactivate: '2030-01-01',
        start_date_applied: '2015-01-01',
        end_date_applied: '2030-01-01',
        segment: 0
      },
      active: {
        date: false,
        date_deactivate: false,
        date_applied: false
      },
      filterOn: [],
      value: [],
      options: [],
      infoModal: {
        id: 'info-modal',
        title: '',
        content: ''
      }
    };
  },
  computed: {
    sortOptions: function sortOptions() {
      return this.fields.filter(function (f) {
        return f.sortable;
      }).map(function (f) {
        return {
          text: f.label,
          value: f.key
        };
      });
    },
    searchText: function searchText() {
      return this.filter.email.toLowerCase();
    },
    filtered: function filtered() {
      var _this = this;
      if (!this.items) return [];
      return this.items.filter(function (el) {
        if (el.FULLNAME == null) el.FULLNAME = '';
        if (el.FULLNAME2 == null) el.FULLNAME2 = '';
        if (el.fullname == null) el.fullname = '';
        if (el.fullname2 == null) el.fullname2 = '';
        if (el.last_name == null) el.last_name = '';
        if (el.name == null) el.name = '';
        if (Number(_this.filter.group) !== 0) {
          return el.groups.includes(Number(_this.filter.group)) && (el.email.toLowerCase().indexOf(_this.searchText) > -1 || el.FULLNAME.toLowerCase().indexOf(_this.searchText) > -1 || el.FULLNAME2.toLowerCase().indexOf(_this.searchText) > -1 || el.fullname.toLowerCase().indexOf(_this.searchText) > -1 || el.fullname2.toLowerCase().indexOf(_this.searchText) > -1 || el.last_name.toLowerCase().indexOf(_this.searchText) > -1 || el.name.toLowerCase().indexOf(_this.searchText) > -1 || el.id.toString().indexOf(_this.searchText) > -1);
        } else {
          return el.email.toLowerCase().indexOf(_this.searchText) > -1 || el.FULLNAME.toLowerCase().indexOf(_this.searchText) > -1 || el.FULLNAME2.toLowerCase().indexOf(_this.searchText) > -1 || el.fullname.toLowerCase().indexOf(_this.searchText) > -1 || el.fullname2.toLowerCase().indexOf(_this.searchText) > -1 || el.last_name.toLowerCase().indexOf(_this.searchText) > -1 || el.name.toLowerCase().indexOf(_this.searchText) > -1 || el.id.toString().indexOf(_this.searchText) > -1;
        }
      });
    },
    staff_res: function staff_res() {
      var res = 0;
      this.filtered.forEach(function (xx) {
        if (xx.full_time == 1) {
          res += 1;
        } else {
          res += 0.5;
        }
      });
      return res;
    },
    totalRows: function totalRows() {
      return this.filtered.length || 0;
    },
    isBP: function isBP() {
      return ['test', 'bp'].includes(location.hostname.split('.')[0]);
    }
  },
  watch: {
    showFields: {
      handler: function handler(val) {
        localStorage.showFields = JSON.stringify(val);
      },
      deep: true
    },
    positions: function positions() {
      this.init();
    }
  },
  created: function created() {
    if (this.positions) {
      this.init();
    }
  },
  mounted: function mounted() {},
  methods: {
    init: function init() {
      var _this2 = this;
      this.myPositions = this.positions;
      this.myPositions.forEach(function (value) {
        _this2.jobFilters.push({
          text: value.position,
          value: value.id
        });
      });
      this.getUsers();
      this.setDefaultShowFields();
    },
    setDefaultShowFields: function setDefaultShowFields() {
      if (localStorage.showFields) {
        this.showFields = JSON.parse(localStorage.getItem('showFields'));
      } else {
        this.showFields = {
          // Какие поля показывать
          number: true,
          id: true,
          email: true,
          name: true,
          last_name: true,
          groups: true,
          register_date: true,
          fire_date: true,
          fire_cause: false,
          user_type: false,
          segment: false,
          applied: false,
          full_time: false
        };
      }
    },
    resetInfoModal: function resetInfoModal() {
      this.infoModal.title = '';
      this.infoModal.content = '';
    },
    applyFilter: function applyFilter() {
      this.showFilterModal = !this.showFilterModal;
      //this.$refs.table.refresh()
      this.getUsers();
    },
    getUsers: function getUsers() {
      var _this3 = this;
      //if(this.filter.start_date.length > 10 || this.filter.end_date.length > 10) return ;
      //if(this.filter.start_date[0] == '0' || this.filter.end_date[0] == '0' || this.filter.end_date[0] == '1')  return ;
      var filter = {
        filter: this.tableFilter,
        segment: this.filter.segment,
        job: this.position
      };
      if (this.active.date) {
        filter.start_date = this.filter.start_date;
        filter.end_date = this.filter.end_date;
      }
      if (this.active.date_deactivate && this.tableFilter != 'active') {
        filter.start_date_deactivate = this.filter.start_date_deactivate;
        filter.end_date_deactivate = this.filter.end_date_deactivate;
      }
      if (this.active.date_applied && this.tableFilter != 'trainees') {
        filter.start_date_applied = this.filter.start_date_applied;
        filter.end_date_applied = this.filter.end_date_applied;
      }
      this.axios.post('/timetracking/get-persons', filter).then(function (response) {
        _this3.items = response.data.users;
        _this3.groups = response.data.groups;
        _this3.segments = response.data.segments;
        _this3.can_login_users = response.data.can_login_users;
        _this3.auth_token = response.data.auth_token;
        _this3.currentUser = response.data.currentUser;
        if (_this3.filter.start_date == null) {
          _this3.filter.start_date = response.data.start_date;
          _this3.filter.end_date = response.data.end_date;
          _this3.filter.start_date_deactivate = response.data.start_date;
          _this3.filter.end_date_deactivate = response.data.end_date;
          _this3.filter.start_date_applied = response.data.start_date;
          _this3.filter.end_date_applied = response.data.end_date;
        }
      });
    },
    exportData: function exportData() {
      var link = '/timetracking/get-persons';
      link += '?filter=' + this.tableFilter;
      if (this.active.date) {
        link += '&start_date=' + this.filter.start_date;
        link += '&end_date=' + this.filter.end_date;
      }
      if (this.active.date_deactivate && this.tableFilter != 'active') {
        link += '&start_date_deactivate=' + this.filter.start_date_deactivate;
        link += '&end_date_deactivate=' + this.filter.end_date_deactivate;
      }
      if (this.active.date_applied && this.tableFilter != 'trainees') {
        link += '&start_date_applied=' + this.filter.start_date_applied;
        link += '&end_date_applied=' + this.filter.end_date_applied;
      }
      link += '&segment=' + this.filter.segment;
      link += '&excel=1';
      window.location.href = link;
    },
    toggleActive: function toggleActive(item) {
      this.active[item] = !this.active[item];
    },
    onFiltered: function onFiltered() {
      this.currentPage = 1;
    }
  }
});

/***/ }),

/***/ "./resources/js/composables/shifts.js":
/*!********************************************!*\
  !*** ./resources/js/composables/shifts.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getBitCount": () => (/* binding */ getBitCount),
/* harmony export */   "getShiftDays": () => (/* binding */ getShiftDays)
/* harmony export */ });
function getShiftDays(shift) {
  if (!shift.work_charts_type) return 'Смена: ' + shift.name;
  var type = typeof shift.work_charts_type === 'number' ? shift.work_charts_type : shift.work_charts_type.id;
  if (type === 2) return 'Смена: ' + shift.name;
  // const dayoffs = getBitCount(+shift.workdays)
  // return `Неделя: ${7 - dayoffs}-${dayoffs}`
  return "\u041D\u0435\u0434\u0435\u043B\u044F: ".concat(shift.name);
}
function getBitCount(num) {
  var size = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 7;
  var count = 0;
  var mask = 1;
  for (var i = 0; i <= size; ++i) {
    if ((mask & num) != 0) {
      count++;
    }
    mask <<= 1;
  }
  return count;
}

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".BitMaskCheckGroup {\n  display: flex;\n  flex-flow: row nowrap;\n}\n.BitMaskCheckGroup_red .BitMaskCheckGroup-item_checked {\n  background-color: #F6264C;\n}\n.BitMaskCheckGroup_red .BitMaskCheckGroup-item_checked:hover {\n  background-color: #F6264C;\n}\n.BitMaskCheckGroup-item {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 1rem;\n  padding: 1.3rem;\n  border: 1px solid #8DA0C1;\n  border-left: none;\n  font-size: 1.2rem;\n  color: #8DA0C1;\n  background-color: #fff;\n  cursor: pointer;\n}\n.BitMaskCheckGroup-item:first-child {\n  border-left: 1px solid #8DA0C1;\n  border-radius: 0.5rem 0 0 0.5rem;\n}\n.BitMaskCheckGroup-item:last-child {\n  border-radius: 0 0.5rem 0.5rem 0;\n}\n.BitMaskCheckGroup-item:hover {\n  background-color: #EDF6FF;\n}\n.BitMaskCheckGroup-item_checked {\n  background-color: #3361FF;\n  color: #fff;\n}\n.BitMaskCheckGroup-item_checked:hover {\n  background-color: #3361FF;\n  color: #fff;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=0&lang=scss&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=0&lang=scss& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".PageCompany .img-info {\n  vertical-align: middle;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".nav-item[data-v-432e62f8] {\n  position: relative;\n}\n.beta[data-v-432e62f8] {\n  position: absolute;\n  top: -13px;\n  right: -15px;\n  padding: 2px 5px;\n  border-radius: 2px;\n  background-color: #45b44d;\n  color: #fff;\n  font-weight: 700;\n  font-size: 12px;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=style&index=1&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=style&index=1&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".groups-title-new {\n  color: rgb(0, 128, 0);\n  display: inline-block;\n  padding: 5px 20px;\n  border-radius: 6px;\n  background-color: rgba(0, 128, 0, 0.2);\n}\n.groups-card {\n  border: 1px solid #ddd;\n}\n.groups-card .card-header, .groups-card .card-footer {\n  padding: 5px 20px;\n}\n.groups-card .card-body {\n  padding: 10px 20px;\n}\n.groups-card.staff-list .card-header {\n  padding: 10px 20px;\n  background-color: #fff;\n  border-bottom: 1px solid #ddd;\n  display: flex;\n  align-items: center;\n}\n.groups-card.staff-list .card-header span {\n  white-space: nowrap;\n  margin-left: 20px;\n}\n.groups-card.staff-list .card-body {\n  padding: 10px 0;\n  max-height: 500px;\n  overflow: auto;\n}\n.groups-card.staff-list .card-body .employee {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 3px 20px;\n  line-height: 1.2;\n}\n.groups-card.staff-list .card-body .employee:hover {\n  background-color: #f2f2f2;\n}\n.groups-card.staff-list .card-body .employee span {\n  font-size: 16px;\n  margin-right: 20px;\n}\n.groups-card.staff-list .card-body .employee .btn-icon {\n  width: 25px;\n  height: 25px;\n  min-width: 25px;\n  font-size: 12px;\n}\n.groups-card textarea.form-control {\n  padding: 5px 20px !important;\n  min-height: 165px !important;\n}\n.ant-tabs {\n  overflow: visible;\n}\n.listprof {\n  display: flex;\n  flex-wrap: wrap;\n  margin-top: 20px;\n}\n.profitem {\n  margin-right: 10px;\n  margin-bottom: 5px;\n}\n.add-grade {\n  display: flex;\n  max-width: 500px;\n}\n.dialerlist {\n  display: flex;\n  align-items: center;\n  margin: 0 0 20px 0;\n}\n.dialerlist .fl {\n  flex: 1;\n  display: flex;\n  align-items: center;\n}\n.group-select {\n  border-radius: 0;\n  max-width: 100%;\n}\np.choose {\n  line-height: 31px;\n  margin-right: 15px;\n}\nspan.before {\n  padding: 0 10px;\n}\n.multiselect__tags {\n  border-radius: 0 !important;\n}\n.multiselect__tag {\n  display: block !important;\n  max-width: -moz-max-content !important;\n  max-width: max-content !important;\n}\n.blu .multiselect__tag {\n  background: #017cff !important;\n}\n@media (min-width: 1000px) {\n.groups .multiselect__tags-wrap {\n    flex-wrap: wrap;\n    display: flex !important;\n}\n.groups .multiselect__tag {\n    flex: 0 0 49%;\n    /* margin-left: 1% !important; */\n    margin-right: 1% !important;\n    max-width: 49% !important;\n}\n}\n@media (min-width: 1300px) {\n.groups .multiselect__tag {\n    flex: 0 0 32%;\n    /* margin-left: 1% !important; */\n    margin-right: 1% !important;\n    max-width: 32% !important;\n}\n}\n@media (min-width: 1700px) {\n.groups .multiselect__tag {\n    flex: 0 0 24%;\n    /* margin-left: 1% !important; */\n    margin-right: 1% !important;\n    max-width: 24% !important;\n}\n}\n.custom-table-permissions .groups .multiselect__tag {\n  flex: 0 0 auto !important;\n  max-width: 100% !important;\n  margin-right: 5px !important;\n}\n.scscsc {\n  margin-left: 15px;\n}\n.sssz button {\n  margin-top: 1px;\n}\n.add-grade input {\n  border-radius: 0;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".position-card[data-v-467c86c4] {\n  border: 1px solid #ddd;\n}\n.position-card .card-header[data-v-467c86c4], .position-card .card-body[data-v-467c86c4] {\n  padding: 10px 20px;\n}\n.position-card textarea.form-control[data-v-467c86c4] {\n  padding: 5px 20px !important;\n  min-height: 80px !important;\n}\n.position-title-new[data-v-467c86c4] {\n  color: rgb(0, 128, 0);\n  display: inline-block;\n  padding: 5px 20px;\n  border-radius: 6px;\n  background-color: rgba(0, 128, 0, 0.2);\n}\n.listprof[data-v-467c86c4] {\n  display: flex;\n  margin-top: 20px;\n}\n.profitem[data-v-467c86c4] {\n  margin-right: 10px;\n}\n.add-grade[data-v-467c86c4] {\n  display: flex;\n  max-width: 500px;\n}\n.ant-tabs[data-v-467c86c4] {\n  overflow: visible;\n}\n.listprof[data-v-467c86c4] {\n  display: flex;\n  flex-wrap: wrap;\n  margin-top: 20px;\n}\n.profitem[data-v-467c86c4] {\n  margin-right: 10px;\n  margin-bottom: 5px;\n}\n.add-grade[data-v-467c86c4] {\n  display: flex;\n  max-width: 500px;\n}\n.dialerlist[data-v-467c86c4] {\n  display: flex;\n  align-items: center;\n  margin: 0;\n}\n.dialerlist.bg[data-v-467c86c4] {\n  background: #f1f1f1;\n  padding-left: 15px;\n}\n.dialerlist .fl[data-v-467c86c4] {\n  flex: 1;\n  display: flex;\n  align-items: center;\n}\n.group-select[data-v-467c86c4] {\n  border-radius: 0;\n  max-width: 100%;\n}\np.choose[data-v-467c86c4] {\n  line-height: 31px;\n  margin-right: 15px;\n}\nspan.before[data-v-467c86c4] {\n  padding: 0 10px;\n}\n.multiselect__tags[data-v-467c86c4] {\n  border-radius: 0 !important;\n}\n.multiselect__tag[data-v-467c86c4] {\n  display: block !important;\n  max-width: -moz-max-content !important;\n  max-width: max-content !important;\n}\n.blu .multiselect__tag[data-v-467c86c4] {\n  background: #017cff !important;\n}\n.pos-desc td[data-v-467c86c4] {\n  padding: 0;\n}\n.pos-desc td textarea[data-v-467c86c4] {\n  font-size: 12px;\n  resize: none;\n  overflow: auto;\n  min-height: 350px;\n}\n@media (min-width: 1000px) {\n.multiselect__tags-wrap[data-v-467c86c4] {\n    flex-wrap: wrap;\n    display: flex !important;\n}\n.multiselect__tag[data-v-467c86c4] {\n    flex: 0 0 49%;\n    /* margin-left: 1% !important; */\n    margin-right: 1% !important;\n    max-width: 49% !important;\n}\n}\n@media (min-width: 1300px) {\n.multiselect__tag[data-v-467c86c4] {\n    flex: 0 0 32%;\n    /* margin-left: 1% !important; */\n    margin-right: 1% !important;\n    max-width: 32% !important;\n}\n}\n@media (min-width: 1700px) {\n.multiselect__tag[data-v-467c86c4] {\n    flex: 0 0 24%;\n    /* margin-left: 1% !important; */\n    margin-right: 1% !important;\n    max-width: 24% !important;\n}\n}\n.scscsc[data-v-467c86c4] {\n  margin-left: 15px;\n}\n.sssz button[data-v-467c86c4] {\n  margin-top: 1px;\n}\n.add-grade input[data-v-467c86c4] {\n  border-radius: 0;\n}\n.p[data-v-467c86c4] {\n  font-size: 14px;\n  width: 200px;\n  color: #5a5a5a;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".label-style[data-v-cb8bcb4c] {\n  color: #8DA0C1;\n  margin-top: 5px;\n}\n.table-shifts tbody td[data-v-cb8bcb4c], .table-shifts tbody th[data-v-cb8bcb4c] {\n  padding: 5px 10px !important;\n  vertical-align: middle;\n}\n.table-shifts tbody .td-actions[data-v-cb8bcb4c] {\n  padding: 3px 10px !important;\n}\n.table-shifts .weekdays[data-v-cb8bcb4c] {\n  display: flex;\n  align-items: center;\n  justify-content: flex-start;\n}\n.table-shifts .weekdays .weekday[data-v-cb8bcb4c] {\n  width: 25px;\n  height: 25px;\n  font-size: 14px;\n  border-radius: 6px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  margin-right: 5px;\n  background-color: green;\n  color: #fff;\n}\n.table-shifts .weekdays .weekday[data-v-cb8bcb4c]:last-child {\n  margin-right: 0;\n}\n#edit-shift-sidebar form[data-v-cb8bcb4c] {\n  padding-right: 10px;\n}\n#edit-shift-sidebar .work-schedule .form-inline[data-v-cb8bcb4c] {\n  margin-left: -7px;\n}\n#edit-shift-sidebar .col-form-label[data-v-cb8bcb4c] {\n  color: #8DA0C1 !important;\n  font-size: 16px;\n}\n#edit-shift-sidebar .weekdays-container[data-v-cb8bcb4c] {\n  display: flex;\n  align-items: center;\n}\n#edit-shift-sidebar .weekdays-container .weekday[data-v-cb8bcb4c] {\n  width: 35px;\n  height: 35px;\n  border-radius: 6px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  margin-right: 5px;\n  cursor: pointer;\n  color: #333;\n  border: 1px solid #ddd;\n}\n#edit-shift-sidebar .weekdays-container .weekday.active[data-v-cb8bcb4c] {\n  background-color: green;\n  color: #fff;\n  border: 1px solid green;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".ul table {\n  border-radius: 3px;\n  border-left: 1px solid #dee2e6;\n  border-right: 1px solid #dee2e6;\n  border-bottom: 1px solid #dee2e6;\n}\n.ant-btn.ant-btn-primary {\n  display: inline;\n}\n.ant-btn {\n  display: none;\n}\ntable.hide-1 td:nth-child(1),\ntable.hide-1 th:nth-child(1) {\n  display: none;\n}\ntable.hide-2 td:nth-child(2),\ntable.hide-2 th:nth-child(2) {\n  display: none;\n}\ntable.hide-3 td:nth-child(3),\ntable.hide-3 th:nth-child(3) {\n  display: none;\n}\ntable.hide-4 td:nth-child(4),\ntable.hide-4 th:nth-child(4) {\n  display: none;\n}\ntable.hide-5 td:nth-child(5),\ntable.hide-5 th:nth-child(5) {\n  display: none;\n}\ntable.hide-6 td:nth-child(6),\ntable.hide-6 th:nth-child(6) {\n  display: none;\n}\ntable.hide-7 td:nth-child(7),\ntable.hide-7 th:nth-child(7) {\n  display: none;\n}\ntable.hide-8 td:nth-child(8),\ntable.hide-8 th:nth-child(8) {\n  display: none;\n}\ntable.hide-9 td:nth-child(9),\ntable.hide-9 th:nth-child(9) {\n  display: none;\n}\ntable.hide-10 td:nth-child(10),\ntable.hide-10 th:nth-child(10) {\n  display: none;\n}\ntable.hide-11 td:nth-child(11),\ntable.hide-11 th:nth-child(11) {\n  display: none;\n}\ntable.hide-12 td:nth-child(12),\ntable.hide-12 th:nth-child(12) {\n  display: none;\n}\ntable.hide-13 td:nth-child(13),\ntable.hide-13 th:nth-child(13) {\n  display: none;\n}\n.fz14 {\n  font-size: 14px;\n}\n.relative.ooooo {\n  position: relative;\n  transition: 0.5s ease all;\n  height: 0;\n  overflow: hidden;\n}\n.relative.ooooo.active {\n  height: auto;\n  overflow: initial;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-multiselect/dist/vue-multiselect.min.css?vue&type=style&index=0&lang=css&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-multiselect/dist/vue-multiselect.min.css?vue&type=style&index=0&lang=css& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "fieldset[disabled] .multiselect{pointer-events:none}.multiselect__spinner{position:absolute;right:1px;top:1px;width:48px;height:35px;background:#fff;display:block}.multiselect__spinner:after,.multiselect__spinner:before{position:absolute;content:\"\";top:50%;left:50%;margin:-8px 0 0 -8px;width:16px;height:16px;border-radius:100%;border:2px solid transparent;border-top-color:#41b883;box-shadow:0 0 0 1px transparent}.multiselect__spinner:before{animation:spinning 2.4s cubic-bezier(.41,.26,.2,.62);animation-iteration-count:infinite}.multiselect__spinner:after{animation:spinning 2.4s cubic-bezier(.51,.09,.21,.8);animation-iteration-count:infinite}.multiselect__loading-enter-active,.multiselect__loading-leave-active{transition:opacity .4s ease-in-out;opacity:1}.multiselect__loading-enter,.multiselect__loading-leave-active{opacity:0}.multiselect,.multiselect__input,.multiselect__single{font-family:inherit;font-size:16px;touch-action:manipulation}.multiselect{box-sizing:content-box;display:block;position:relative;width:100%;min-height:40px;text-align:left;color:#35495e}.multiselect *{box-sizing:border-box}.multiselect:focus{outline:none}.multiselect--disabled{background:#ededed;pointer-events:none;opacity:.6}.multiselect--active{z-index:50}.multiselect--active:not(.multiselect--above) .multiselect__current,.multiselect--active:not(.multiselect--above) .multiselect__input,.multiselect--active:not(.multiselect--above) .multiselect__tags{border-bottom-left-radius:0;border-bottom-right-radius:0}.multiselect--active .multiselect__select{transform:rotate(180deg)}.multiselect--above.multiselect--active .multiselect__current,.multiselect--above.multiselect--active .multiselect__input,.multiselect--above.multiselect--active .multiselect__tags{border-top-left-radius:0;border-top-right-radius:0}.multiselect__input,.multiselect__single{position:relative;display:inline-block;min-height:20px;line-height:20px;border:none;border-radius:5px;background:#fff;padding:0 0 0 5px;width:100%;transition:border .1s ease;box-sizing:border-box;margin-bottom:8px;vertical-align:top}.multiselect__input::-moz-placeholder{color:#35495e}.multiselect__input::placeholder{color:#35495e}.multiselect__tag~.multiselect__input,.multiselect__tag~.multiselect__single{width:auto}.multiselect__input:hover,.multiselect__single:hover{border-color:#cfcfcf}.multiselect__input:focus,.multiselect__single:focus{border-color:#a8a8a8;outline:none}.multiselect__single{padding-left:5px;margin-bottom:8px}.multiselect__tags-wrap{display:inline}.multiselect__tags{min-height:40px;display:block;padding:8px 40px 0 8px;border-radius:5px;border:1px solid #e8e8e8;background:#fff;font-size:14px}.multiselect__tag{position:relative;display:inline-block;padding:4px 26px 4px 10px;border-radius:5px;margin-right:10px;color:#fff;line-height:1;background:#41b883;margin-bottom:5px;white-space:nowrap;overflow:hidden;max-width:100%;text-overflow:ellipsis}.multiselect__tag-icon{cursor:pointer;margin-left:7px;position:absolute;right:0;top:0;bottom:0;font-weight:700;font-style:normal;width:22px;text-align:center;line-height:22px;transition:all .2s ease;border-radius:5px}.multiselect__tag-icon:after{content:\"\\D7\";color:#266d4d;font-size:14px}.multiselect__tag-icon:focus,.multiselect__tag-icon:hover{background:#369a6e}.multiselect__tag-icon:focus:after,.multiselect__tag-icon:hover:after{color:#fff}.multiselect__current{min-height:40px;overflow:hidden;padding:8px 30px 0 12px;white-space:nowrap;border-radius:5px;border:1px solid #e8e8e8}.multiselect__current,.multiselect__select{line-height:16px;box-sizing:border-box;display:block;margin:0;text-decoration:none;cursor:pointer}.multiselect__select{position:absolute;width:40px;height:38px;right:1px;top:1px;padding:4px 8px;text-align:center;transition:transform .2s ease}.multiselect__select:before{position:relative;right:0;top:65%;color:#999;margin-top:4px;border-color:#999 transparent transparent;border-style:solid;border-width:5px 5px 0;content:\"\"}.multiselect__placeholder{color:#adadad;display:inline-block;margin-bottom:10px;padding-top:2px}.multiselect--active .multiselect__placeholder{display:none}.multiselect__content-wrapper{position:absolute;display:block;background:#fff;width:100%;max-height:240px;overflow:auto;border:1px solid #e8e8e8;border-top:none;border-bottom-left-radius:5px;border-bottom-right-radius:5px;z-index:50;-webkit-overflow-scrolling:touch}.multiselect__content{list-style:none;display:inline-block;padding:0;margin:0;min-width:100%;vertical-align:top}.multiselect--above .multiselect__content-wrapper{bottom:100%;border-bottom-left-radius:0;border-bottom-right-radius:0;border-top-left-radius:5px;border-top-right-radius:5px;border-bottom:none;border-top:1px solid #e8e8e8}.multiselect__content::webkit-scrollbar{display:none}.multiselect__element{display:block}.multiselect__option{display:block;padding:12px;min-height:40px;line-height:16px;text-decoration:none;text-transform:none;vertical-align:middle;position:relative;cursor:pointer;white-space:nowrap}.multiselect__option:after{top:0;right:0;position:absolute;line-height:40px;padding-right:12px;padding-left:20px;font-size:13px}.multiselect__option--highlight{background:#41b883;outline:none;color:#fff}.multiselect__option--highlight:after{content:attr(data-select);background:#41b883;color:#fff}.multiselect__option--selected{background:#f3f3f3;color:#35495e;font-weight:700}.multiselect__option--selected:after{content:attr(data-selected);color:silver}.multiselect__option--selected.multiselect__option--highlight{background:#ff6a6a;color:#fff}.multiselect__option--selected.multiselect__option--highlight:after{background:#ff6a6a;content:attr(data-deselect);color:#fff}.multiselect--disabled .multiselect__current,.multiselect--disabled .multiselect__select{background:#ededed;color:#a6a6a6}.multiselect__option--disabled{background:#ededed!important;color:#a6a6a6!important;cursor:text;pointer-events:none}.multiselect__option--group{background:#ededed;color:#35495e}.multiselect__option--group.multiselect__option--highlight{background:#35495e;color:#fff}.multiselect__option--group.multiselect__option--highlight:after{background:#35495e}.multiselect__option--disabled.multiselect__option--highlight{background:#dedede}.multiselect__option--group-selected.multiselect__option--highlight{background:#ff6a6a;color:#fff}.multiselect__option--group-selected.multiselect__option--highlight:after{background:#ff6a6a;content:attr(data-deselect);color:#fff}.multiselect-enter-active,.multiselect-leave-active{transition:all .15s ease}.multiselect-enter,.multiselect-leave-active{opacity:0}.multiselect__strong{margin-bottom:8px;line-height:20px;display:inline-block;vertical-align:top}[dir=rtl] .multiselect{text-align:right}[dir=rtl] .multiselect__select{right:auto;left:1px}[dir=rtl] .multiselect__tags{padding:8px 8px 0 40px}[dir=rtl] .multiselect__content{text-align:right}[dir=rtl] .multiselect__option:after{right:auto;left:0}[dir=rtl] .multiselect__clear{right:auto;left:12px}[dir=rtl] .multiselect__spinner{right:auto;left:1px}@keyframes spinning{0%{transform:rotate(0)}to{transform:rotate(2turn)}}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_BitMaskCheckGroup_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_BitMaskCheckGroup_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_BitMaskCheckGroup_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Company.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_style_index_1_id_432e62f8_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_style_index_1_id_432e62f8_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_style_index_1_id_432e62f8_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=style&index=1&lang=scss&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=style&index=1&lang=scss& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_groups_vue_vue_type_style_index_1_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./groups.vue?vue&type=style&index=1&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=style&index=1&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_groups_vue_vue_type_style_index_1_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_groups_vue_vue_type_style_index_1_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_professions_vue_vue_type_style_index_0_id_467c86c4_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_professions_vue_vue_type_style_index_0_id_467c86c4_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_professions_vue_vue_type_style_index_0_id_467c86c4_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_shifts_vue_vue_type_style_index_0_id_cb8bcb4c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_shifts_vue_vue_type_style_index_0_id_cb8bcb4c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_shifts_vue_vue_type_style_index_0_id_cb8bcb4c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=style&index=0&lang=scss&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=style&index=0&lang=scss& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_userlist_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./userlist.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_userlist_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_userlist_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-multiselect/dist/vue-multiselect.min.css?vue&type=style&index=0&lang=css&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-multiselect/dist/vue-multiselect.min.css?vue&type=style&index=0&lang=css& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_vue_loader_lib_loaders_stylePostLoader_js_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_vue_multiselect_min_css_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../vue-loader/lib/loaders/stylePostLoader.js!../../postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./vue-multiselect.min.css?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-multiselect/dist/vue-multiselect.min.css?vue&type=style&index=0&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_vue_loader_lib_loaders_stylePostLoader_js_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_vue_multiselect_min_css_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_vue_loader_lib_loaders_stylePostLoader_js_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_vue_multiselect_min_css_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/ui/BitMaskCheckGroup.vue":
/*!**********************************************************!*\
  !*** ./resources/js/components/ui/BitMaskCheckGroup.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _BitMaskCheckGroup_vue_vue_type_template_id_25844040___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BitMaskCheckGroup.vue?vue&type=template&id=25844040& */ "./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=template&id=25844040&");
/* harmony import */ var _BitMaskCheckGroup_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BitMaskCheckGroup.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=script&lang=js&");
/* harmony import */ var _BitMaskCheckGroup_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _BitMaskCheckGroup_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _BitMaskCheckGroup_vue_vue_type_template_id_25844040___WEBPACK_IMPORTED_MODULE_0__.render,
  _BitMaskCheckGroup_vue_vue_type_template_id_25844040___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/BitMaskCheckGroup.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Company.vue":
/*!****************************************!*\
  !*** ./resources/js/pages/Company.vue ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Company_vue_vue_type_template_id_432e62f8_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Company.vue?vue&type=template&id=432e62f8&scoped=true& */ "./resources/js/pages/Company.vue?vue&type=template&id=432e62f8&scoped=true&");
/* harmony import */ var _Company_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Company.vue?vue&type=script&lang=js& */ "./resources/js/pages/Company.vue?vue&type=script&lang=js&");
/* harmony import */ var _Company_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Company.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/Company.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _Company_vue_vue_type_style_index_1_id_432e62f8_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true& */ "./resources/js/pages/Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;



/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _Company_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Company_vue_vue_type_template_id_432e62f8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _Company_vue_vue_type_template_id_432e62f8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "432e62f8",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Company.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/groups.vue":
/*!***************************************!*\
  !*** ./resources/js/pages/groups.vue ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _groups_vue_vue_type_template_id_7366467d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./groups.vue?vue&type=template&id=7366467d& */ "./resources/js/pages/groups.vue?vue&type=template&id=7366467d&");
/* harmony import */ var _groups_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./groups.vue?vue&type=script&lang=js& */ "./resources/js/pages/groups.vue?vue&type=script&lang=js&");
/* harmony import */ var vue_multiselect_dist_vue_multiselect_min_css_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-multiselect/dist/vue-multiselect.min.css?vue&type=style&index=0&lang=css& */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.css?vue&type=style&index=0&lang=css&");
/* harmony import */ var _groups_vue_vue_type_style_index_1_lang_scss___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./groups.vue?vue&type=style&index=1&lang=scss& */ "./resources/js/pages/groups.vue?vue&type=style&index=1&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;



/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _groups_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _groups_vue_vue_type_template_id_7366467d___WEBPACK_IMPORTED_MODULE_0__.render,
  _groups_vue_vue_type_template_id_7366467d___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/groups.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/professions.vue":
/*!********************************************!*\
  !*** ./resources/js/pages/professions.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _professions_vue_vue_type_template_id_467c86c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./professions.vue?vue&type=template&id=467c86c4&scoped=true& */ "./resources/js/pages/professions.vue?vue&type=template&id=467c86c4&scoped=true&");
/* harmony import */ var _professions_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./professions.vue?vue&type=script&lang=js& */ "./resources/js/pages/professions.vue?vue&type=script&lang=js&");
/* harmony import */ var _professions_vue_vue_type_style_index_0_id_467c86c4_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss& */ "./resources/js/pages/professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _professions_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _professions_vue_vue_type_template_id_467c86c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _professions_vue_vue_type_template_id_467c86c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "467c86c4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/professions.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/shifts.vue":
/*!***************************************!*\
  !*** ./resources/js/pages/shifts.vue ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _shifts_vue_vue_type_template_id_cb8bcb4c_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./shifts.vue?vue&type=template&id=cb8bcb4c&scoped=true& */ "./resources/js/pages/shifts.vue?vue&type=template&id=cb8bcb4c&scoped=true&");
/* harmony import */ var _shifts_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shifts.vue?vue&type=script&lang=js& */ "./resources/js/pages/shifts.vue?vue&type=script&lang=js&");
/* harmony import */ var _shifts_vue_vue_type_style_index_0_id_cb8bcb4c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true& */ "./resources/js/pages/shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _shifts_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _shifts_vue_vue_type_template_id_cb8bcb4c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _shifts_vue_vue_type_template_id_cb8bcb4c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "cb8bcb4c",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/shifts.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/userlist.vue":
/*!*****************************************!*\
  !*** ./resources/js/pages/userlist.vue ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _userlist_vue_vue_type_template_id_9e444e5c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./userlist.vue?vue&type=template&id=9e444e5c& */ "./resources/js/pages/userlist.vue?vue&type=template&id=9e444e5c&");
/* harmony import */ var _userlist_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./userlist.vue?vue&type=script&lang=js& */ "./resources/js/pages/userlist.vue?vue&type=script&lang=js&");
/* harmony import */ var _userlist_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./userlist.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/userlist.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _userlist_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _userlist_vue_vue_type_template_id_9e444e5c___WEBPACK_IMPORTED_MODULE_0__.render,
  _userlist_vue_vue_type_template_id_9e444e5c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/userlist.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BitMaskCheckGroup_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./BitMaskCheckGroup.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BitMaskCheckGroup_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/Company.vue?vue&type=script&lang=js&":
/*!*****************************************************************!*\
  !*** ./resources/js/pages/Company.vue?vue&type=script&lang=js& ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Company.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/groups.vue?vue&type=script&lang=js&":
/*!****************************************************************!*\
  !*** ./resources/js/pages/groups.vue?vue&type=script&lang=js& ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_groups_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./groups.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_groups_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/professions.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/pages/professions.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_professions_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./professions.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_professions_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/shifts.vue?vue&type=script&lang=js&":
/*!****************************************************************!*\
  !*** ./resources/js/pages/shifts.vue?vue&type=script&lang=js& ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shifts_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./shifts.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shifts_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/userlist.vue?vue&type=script&lang=js&":
/*!******************************************************************!*\
  !*** ./resources/js/pages/userlist.vue?vue&type=script&lang=js& ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_userlist_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./userlist.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_userlist_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************!*\
  !*** ./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_BitMaskCheckGroup_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/Company.vue?vue&type=style&index=0&lang=scss&":
/*!**************************************************************************!*\
  !*** ./resources/js/pages/Company.vue?vue&type=style&index=0&lang=scss& ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Company.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/pages/Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true& ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_style_index_1_id_432e62f8_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=style&index=1&id=432e62f8&lang=scss&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/groups.vue?vue&type=style&index=1&lang=scss&":
/*!*************************************************************************!*\
  !*** ./resources/js/pages/groups.vue?vue&type=style&index=1&lang=scss& ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_groups_vue_vue_type_style_index_1_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./groups.vue?vue&type=style&index=1&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=style&index=1&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/pages/professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss& ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_professions_vue_vue_type_style_index_0_id_467c86c4_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=style&index=0&id=467c86c4&scoped=true&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/pages/shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true& ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_shifts_vue_vue_type_style_index_0_id_cb8bcb4c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=style&index=0&id=cb8bcb4c&lang=scss&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/userlist.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************!*\
  !*** ./resources/js/pages/userlist.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_userlist_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./userlist.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./node_modules/vue-multiselect/dist/vue-multiselect.min.css?vue&type=style&index=0&lang=css&":
/*!****************************************************************************************************!*\
  !*** ./node_modules/vue-multiselect/dist/vue-multiselect.min.css?vue&type=style&index=0&lang=css& ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _style_loader_dist_cjs_js_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_vue_loader_lib_loaders_stylePostLoader_js_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_vue_multiselect_min_css_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../style-loader/dist/cjs.js!../../css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../vue-loader/lib/loaders/stylePostLoader.js!../../postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./vue-multiselect.min.css?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-multiselect/dist/vue-multiselect.min.css?vue&type=style&index=0&lang=css&");


/***/ }),

/***/ "./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=template&id=25844040&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=template&id=25844040& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_BitMaskCheckGroup_vue_vue_type_template_id_25844040___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_BitMaskCheckGroup_vue_vue_type_template_id_25844040___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_BitMaskCheckGroup_vue_vue_type_template_id_25844040___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./BitMaskCheckGroup.vue?vue&type=template&id=25844040& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=template&id=25844040&");


/***/ }),

/***/ "./resources/js/pages/Company.vue?vue&type=template&id=432e62f8&scoped=true&":
/*!***********************************************************************************!*\
  !*** ./resources/js/pages/Company.vue?vue&type=template&id=432e62f8&scoped=true& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_template_id_432e62f8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_template_id_432e62f8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Company_vue_vue_type_template_id_432e62f8_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Company.vue?vue&type=template&id=432e62f8&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=template&id=432e62f8&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/groups.vue?vue&type=template&id=7366467d&":
/*!**********************************************************************!*\
  !*** ./resources/js/pages/groups.vue?vue&type=template&id=7366467d& ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_groups_vue_vue_type_template_id_7366467d___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_groups_vue_vue_type_template_id_7366467d___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_groups_vue_vue_type_template_id_7366467d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./groups.vue?vue&type=template&id=7366467d& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=template&id=7366467d&");


/***/ }),

/***/ "./resources/js/pages/professions.vue?vue&type=template&id=467c86c4&scoped=true&":
/*!***************************************************************************************!*\
  !*** ./resources/js/pages/professions.vue?vue&type=template&id=467c86c4&scoped=true& ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_professions_vue_vue_type_template_id_467c86c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_professions_vue_vue_type_template_id_467c86c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_professions_vue_vue_type_template_id_467c86c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./professions.vue?vue&type=template&id=467c86c4&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=template&id=467c86c4&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/shifts.vue?vue&type=template&id=cb8bcb4c&scoped=true&":
/*!**********************************************************************************!*\
  !*** ./resources/js/pages/shifts.vue?vue&type=template&id=cb8bcb4c&scoped=true& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_shifts_vue_vue_type_template_id_cb8bcb4c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_shifts_vue_vue_type_template_id_cb8bcb4c_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_shifts_vue_vue_type_template_id_cb8bcb4c_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./shifts.vue?vue&type=template&id=cb8bcb4c&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=template&id=cb8bcb4c&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/userlist.vue?vue&type=template&id=9e444e5c&":
/*!************************************************************************!*\
  !*** ./resources/js/pages/userlist.vue?vue&type=template&id=9e444e5c& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_userlist_vue_vue_type_template_id_9e444e5c___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_userlist_vue_vue_type_template_id_9e444e5c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_userlist_vue_vue_type_template_id_9e444e5c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./userlist.vue?vue&type=template&id=9e444e5c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=template&id=9e444e5c&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=template&id=25844040&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/BitMaskCheckGroup.vue?vue&type=template&id=25844040& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "BitMaskCheckGroup",
      class: {
        BitMaskCheckGroup_red: _vm.red,
      },
    },
    _vm._l(_vm.options, function (option) {
      return _c(
        "div",
        {
          key: option.value,
          staticClass: "BitMaskCheckGroup-item",
          class: {
            "BitMaskCheckGroup-item_checked": _vm.value & option.value,
          },
          on: {
            click: function ($event) {
              return _vm.onChange(option.value)
            },
          },
        },
        [_vm._v("\n\t\t" + _vm._s(option.title) + "\n\t")]
      )
    }),
    0
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=template&id=432e62f8&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Company.vue?vue&type=template&id=432e62f8&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "default-tab PageCompany" }, [
    _c("nav", { staticClass: "normal mt-4" }, [
      _c(
        "ul",
        {
          staticClass: "nav nav-tabs set-tabs",
          attrs: { id: "nav-tab", role: "tablist" },
        },
        [
          _vm._l(_vm.tabs, function (tab) {
            return [
              _c(
                "li",
                {
                  key: tab.htmlId,
                  staticClass: "nav-item",
                  attrs: { id: tab.htmlId + "-tab" },
                },
                [
                  _c(
                    "span",
                    {
                      staticClass: "nav-link",
                      class: { active: tab.id === _vm.activeTab },
                      on: {
                        click: function ($event) {
                          _vm.activeTab = tab.id
                        },
                      },
                    },
                    [_vm._v(_vm._s(tab.title) + "\n\t\t\t\t\t")]
                  ),
                  _vm._v(" "),
                  tab.id === 4
                    ? _c("span", { staticClass: "beta" }, [_vm._v("beta")])
                    : _vm._e(),
                ]
              ),
            ]
          }),
        ],
        2
      ),
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "tab-content", attrs: { id: "nav-tabContent" } }, [
      _vm.activeTab === 2 && _vm.can(["positions_view", "settings_view"])
        ? _c(
            "div",
            {
              staticClass: "tab-pane fade show active py-3",
              attrs: {
                id: "nav-home",
                role: "tabpanel",
                "aria-labelledby": "nav-home-tab",
              },
            },
            [
              _c("Professions", {
                attrs: { positions: _vm.pageData.positions },
              }),
            ],
            1
          )
        : _vm._e(),
      _vm._v(" "),
      _vm.activeTab === 3 && _vm.can(["groups_view", "settings_view"])
        ? _c(
            "div",
            {
              staticClass: "tab-pane fade show active py-3",
              attrs: {
                id: "nav-profile",
                role: "tabpanel",
                "aria-labelledby": "nav-profile-tab",
              },
            },
            [
              _c("Groups", {
                attrs: {
                  statuseses: _vm.pageData.statuseses,
                  archived_groupss: _vm.pageData.archived_groupss,
                  activeuserid: _vm.pageData.activeuserid,
                  book_groups: _vm.pageData.book_groups,
                  corpbooks: _vm.pageData.corpbooks,
                },
              }),
            ],
            1
          )
        : _vm._e(),
      _vm._v(" "),
      _vm.activeTab === 4 && _vm.can(["settings_view"])
        ? _c(
            "div",
            {
              staticClass: "tab-pane fade show active py-3",
              attrs: {
                id: "nav-shift",
                role: "tabpanel",
                "aria-labelledby": "nav-profile-tab",
              },
            },
            [_c("Shifts")],
            1
          )
        : _vm._e(),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=template&id=7366467d&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/groups.vue?vue&type=template&id=7366467d& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.activeuserid
    ? _c(
        "div",
        { staticClass: "groups" },
        [
          _vm.message != null
            ? _c("b-alert", { attrs: { variant: "info" } }, [
                _vm._v("\n\t\t" + _vm._s(_vm.message) + "\n\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          _c(
            "b-row",
            { staticClass: "align-items-center" },
            [
              _c(
                "b-col",
                {
                  staticClass: "d-flex align-items-start",
                  attrs: { cols: "12", lg: "4", md: "5" },
                },
                [
                  _c(
                    "b-form-group",
                    { staticClass: "w-100" },
                    [
                      _c("multiselect", {
                        ref: "groupsMultiselect",
                        attrs: {
                          options: _vm.statuses,
                          placeholder: "Выберите отдел из списка",
                          "track-by": "group",
                          label: "group",
                        },
                        on: { select: _vm.selectGroup },
                        scopedSlots: _vm._u(
                          [
                            {
                              key: "afterList",
                              fn: function () {
                                return [
                                  _c(
                                    "li",
                                    { staticClass: "multiselect-add-li" },
                                    [
                                      _c(
                                        "span",
                                        {
                                          staticClass: "multiselect-add-btn",
                                          on: { click: _vm.addGroup },
                                        },
                                        [_vm._v("Добавить новый отдел")]
                                      ),
                                    ]
                                  ),
                                ]
                              },
                              proxy: true,
                            },
                          ],
                          null,
                          false,
                          1514377534
                        ),
                        model: {
                          value: _vm.activebtn,
                          callback: function ($$v) {
                            _vm.activebtn = $$v
                          },
                          expression: "activebtn",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-info rounded add-s ml-4",
                      attrs: { title: "Восстановить из архива" },
                      on: {
                        click: function ($event) {
                          _vm.showArchiveModal = true
                        },
                      },
                    },
                    [_c("i", { staticClass: "fa fa-archive" })]
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _vm.activebtn != null || _vm.addNewGroup
            ? _c("hr", { staticClass: "my-4" })
            : _vm._e(),
          _vm._v(" "),
          _vm.addNewGroup
            ? _c("h4", { staticClass: "groups-title-new mb-5" }, [
                _vm._v("\n\t\tСоздание новой группы\n\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          _vm.activebtn != null || _vm.addNewGroup
            ? _c("div", { staticClass: "row" }, [
                _c(
                  "div",
                  { staticClass: "col-lg-6 mb-3" },
                  [
                    _c(
                      "b-form-group",
                      {
                        staticClass: "mb-4",
                        attrs: { label: "Название отдела", "label-cols": "6" },
                      },
                      [
                        _c("b-form-input", {
                          staticClass: "form-control",
                          attrs: { type: "text" },
                          model: {
                            value: _vm.new_status,
                            callback: function ($$v) {
                              _vm.new_status = $$v
                            },
                            expression: "new_status",
                          },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _vm.workChart
                      ? _c("div", { staticClass: "dialerlist" }, [
                          _c("div", { staticClass: "fl" }, [
                            _vm._v("\n\t\t\t\t\tГрафик работы\n\t\t\t\t\t"),
                            _c("img", {
                              directives: [
                                {
                                  name: "b-popover",
                                  rawName: "v-b-popover.hover.right",
                                  value:
                                    "Начало и окончание рабочего дня всего отдела, индивидуальное время выставляется в профиле",
                                  expression:
                                    "'Начало и окончание рабочего дня всего отдела, индивидуальное время выставляется в профиле'",
                                  modifiers: { hover: true, right: true },
                                },
                              ],
                              staticClass: "img-info",
                              attrs: { src: "/images/dist/profit-info.svg" },
                            }),
                          ]),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "fl" },
                            [
                              _c(
                                "b-form-select",
                                {
                                  model: {
                                    value: _vm.workChartId,
                                    callback: function ($$v) {
                                      _vm.workChartId = $$v
                                    },
                                    expression: "workChartId",
                                  },
                                },
                                [
                                  _c(
                                    "b-form-select-option",
                                    { attrs: { disabled: "", value: "null" } },
                                    [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\tВыберите график работы\n\t\t\t\t\t\t"
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _vm._l(_vm.workChart, function (chart) {
                                    return [
                                      _c(
                                        "b-form-select-option",
                                        {
                                          key: chart.id,
                                          attrs: { value: chart.id },
                                        },
                                        [
                                          _vm._v(
                                            "\n\t\t\t\t\t\t\t\t" +
                                              _vm._s(_vm.getShiftDays(chart)) +
                                              " (с " +
                                              _vm._s(chart.start_time) +
                                              " по " +
                                              _vm._s(chart.end_time) +
                                              ") - " +
                                              _vm._s(chart.text_name) +
                                              "\n\t\t\t\t\t\t\t"
                                          ),
                                        ]
                                      ),
                                    ]
                                  }),
                                ],
                                2
                              ),
                            ],
                            1
                          ),
                        ])
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.isBp
                      ? _c("div", { staticClass: "dialerlist" }, [
                          _c("div", { staticClass: "fl" }, [
                            _vm._v("\n\t\t\t\t\tПодтягивать время\n\t\t\t\t\t"),
                            _c("i", {
                              staticClass: "icon-nd-settings ml-2",
                              on: {
                                click: function ($event) {
                                  return _vm.editTimeAddress()
                                },
                              },
                            }),
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "fl" }, [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.time_address_text,
                                  expression: "time_address_text",
                                },
                              ],
                              staticClass: "form-control",
                              staticStyle: { background: "#fff" },
                              attrs: { type: "text", disabled: "" },
                              domProps: { value: _vm.time_address_text },
                              on: {
                                input: function ($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.time_address_text = $event.target.value
                                },
                              },
                            }),
                          ]),
                        ])
                      : _vm._e(),
                    _vm._v(" "),
                     false
                      ? 0
                      : _vm._e(),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "dialerlist" },
                      [
                        _c(
                          "b-form-checkbox",
                          {
                            attrs: {
                              value: 1,
                              "unchecked-value": 0,
                              switch: "",
                            },
                            model: {
                              value: _vm.editable_time,
                              callback: function ($$v) {
                                _vm.editable_time = $$v
                              },
                              expression: "editable_time",
                            },
                          },
                          [_vm._v("\n\t\t\t\t\tТабель редактируется\n\t\t\t\t")]
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "dialerlist" },
                      [
                        _c(
                          "b-form-checkbox",
                          {
                            attrs: {
                              value: 1,
                              "unchecked-value": 0,
                              switch: "",
                            },
                            model: {
                              value: _vm.paid_internship,
                              callback: function ($$v) {
                                _vm.paid_internship = $$v
                              },
                              expression: "paid_internship",
                            },
                          },
                          [
                            _vm._v(
                              "\n\t\t\t\t\tОплачиваемая стажировка\n\t\t\t\t\t"
                            ),
                            _c("img", {
                              directives: [
                                {
                                  name: "b-popover",
                                  rawName: "v-b-popover.hover.right",
                                  value:
                                    "Стажировочные дни будут оплачиваться в размере 50% от дневного оклада",
                                  expression:
                                    "'Стажировочные дни будут оплачиваться в размере 50% от дневного оклада'",
                                  modifiers: { hover: true, right: true },
                                },
                              ],
                              staticClass: "img-info",
                              attrs: { src: "/images/dist/profit-info.svg" },
                            }),
                          ]
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "card groups-card mt-4" }, [
                      _c(
                        "div",
                        { staticClass: "card-header" },
                        [
                          _c(
                            "b-form-checkbox",
                            {
                              staticClass: "mt-3",
                              attrs: {
                                value: 1,
                                "unchecked-value": 0,
                                switch: "",
                              },
                              model: {
                                value: _vm.show_payment_terms,
                                callback: function ($$v) {
                                  _vm.show_payment_terms = $$v
                                },
                                expression: "show_payment_terms",
                              },
                            },
                            [
                              _vm._v(
                                "\n\t\t\t\t\t\tПоказывать в профиле\n\t\t\t\t\t"
                              ),
                            ]
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "card-body" },
                        [
                          _c(
                            "b-form-group",
                            { attrs: { label: "Условия оплаты труда" } },
                            [
                              _c("b-textarea", {
                                staticStyle: { "min-height": "150px" },
                                model: {
                                  value: _vm.payment_terms,
                                  callback: function ($$v) {
                                    _vm.payment_terms = $$v
                                  },
                                  expression: "payment_terms",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ]),
                  ],
                  1
                ),
                _vm._v(" "),
                _c("div", { staticClass: "col-lg-6 mb-3 sssz" }, [
                  _vm.value.length
                    ? _c(
                        "div",
                        { staticClass: "card groups-card staff-list" },
                        [
                          _c(
                            "div",
                            { staticClass: "card-header" },
                            [
                              _c("b-form-input", {
                                attrs: { placeholder: "Поиск по сотрудникам" },
                                model: {
                                  value: _vm.searchUsers,
                                  callback: function ($$v) {
                                    _vm.searchUsers = $$v
                                  },
                                  expression: "searchUsers",
                                },
                              }),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v(
                                  "Сотрудников: " + _vm._s(_vm.value.length)
                                ),
                              ]),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "card-body" },
                            _vm._l(
                              _vm.filteredUsers,
                              function (employee, index) {
                                return _c(
                                  "div",
                                  { key: employee.id, staticClass: "employee" },
                                  [
                                    _c("span", [
                                      _vm._v(_vm._s(employee.email)),
                                    ]),
                                    _vm._v(" "),
                                    _c("i", {
                                      staticClass:
                                        "fa fa-trash btn btn-icon btn-danger",
                                      on: {
                                        click: function ($event) {
                                          return _vm.removeValue(index)
                                        },
                                      },
                                    }),
                                  ]
                                )
                              }
                            ),
                            0
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "card-footer" },
                            [
                              _c(
                                "b-button",
                                {
                                  attrs: { variant: "danger" },
                                  on: { click: _vm.showAlert },
                                },
                                [
                                  _vm._v(
                                    "\n\t\t\t\t\t\tУдалить всех сотрудников\n\t\t\t\t\t"
                                  ),
                                ]
                              ),
                            ],
                            1
                          ),
                        ]
                      )
                    : _c("div", [
                        _vm._v(
                          "\n\t\t\t\tПока нет ни одного сотрудника в группе\n\t\t\t"
                        ),
                      ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-lg-12 mb-3" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-success mr-2 rounded",
                      on: { click: _vm.saveusers },
                    },
                    [_vm._v("\n\t\t\t\tСохранить\n\t\t\t")]
                  ),
                  _vm._v(" "),
                  !_vm.addNewGroup
                    ? _c(
                        "button",
                        {
                          staticClass: "btn btn-danger mr-2 rounded",
                          on: {
                            click: function ($event) {
                              $event.stopPropagation()
                              return _vm.deleted.apply(null, arguments)
                            },
                          },
                        },
                        [
                          _c("i", { staticClass: "fa fa-trash" }),
                          _vm._v(" Удалить группу\n\t\t\t"),
                        ]
                      )
                    : _vm._e(),
                ]),
              ])
            : _vm._e(),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              staticClass: "modalle",
              attrs: { title: "Подтягивать часы", size: "lg" },
              on: {
                ok: function ($event) {
                  return _vm.saveTimeAddress()
                },
              },
              model: {
                value: _vm.showEditTimeAddress,
                callback: function ($$v) {
                  _vm.showEditTimeAddress = $$v
                },
                expression: "showEditTimeAddress",
              },
            },
            [
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-5 mt-1" }, [
                  _c("p", {}, [
                    _vm._v("\n\t\t\t\t\tИсточник часов\n\t\t\t\t\t"),
                    _c("i", {
                      directives: [
                        {
                          name: "b-popover",
                          rawName: "v-b-popover.hover.right.html",
                          value:
                            "При смене источника, новые данные в табеле будут только со дня смены источника",
                          expression:
                            "'При смене источника, новые данные в табеле будут только со дня смены источника'",
                          modifiers: { hover: true, right: true, html: true },
                        },
                      ],
                      staticClass: "fa fa-info-circle",
                    }),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-7" }, [
                  _c(
                    "select",
                    {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.time_address,
                          expression: "time_address",
                        },
                      ],
                      staticClass: "form-control form-control-sm",
                      on: {
                        change: function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.time_address = $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        },
                      },
                    },
                    _vm._l(_vm.time_variants, function (time, key) {
                      return _c(
                        "option",
                        { key: key, domProps: { value: key } },
                        [
                          _vm._v(
                            "\n\t\t\t\t\t\t" + _vm._s(time) + "\n\t\t\t\t\t"
                          ),
                        ]
                      )
                    }),
                    0
                  ),
                ]),
              ]),
              _vm._v(" "),
              _vm.time_address == -1
                ? _c("div", { staticClass: "row" }, [
                    _c("div", { staticClass: "col-5 mt-1" }, [
                      _c("div", { staticClass: "fl" }, [
                        _vm._v("\n\t\t\t\t\tID диалера\n\t\t\t\t\t"),
                        _c("i", {
                          directives: [
                            {
                              name: "b-popover",
                              rawName: "v-b-popover.hover.right.html",
                              value:
                                "Нужен, чтобы <b>подтягивать часы</b> или <b>оценки диалогов</b> для контроля качества.<br>С сервиса cp.callibro.org",
                              expression:
                                "'Нужен, чтобы <b>подтягивать часы</b> или <b>оценки диалогов</b> для контроля качества.<br>С сервиса cp.callibro.org'",
                              modifiers: {
                                hover: true,
                                right: true,
                                html: true,
                              },
                            },
                          ],
                          staticClass: "fa fa-info-circle ml-2",
                          attrs: { title: "Диалер в U-Calls" },
                        }),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-7 mt-1" }, [
                      _c("div", { staticClass: "fl d-flex" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.dialer_id,
                              expression: "dialer_id",
                            },
                          ],
                          staticClass: "form-control scscsc",
                          attrs: { type: "text", placeholder: "ID" },
                          domProps: { value: _vm.dialer_id },
                          on: {
                            input: function ($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.dialer_id = $event.target.value
                            },
                          },
                        }),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.script_id,
                              expression: "script_id",
                            },
                          ],
                          staticClass: "form-control scscsc",
                          attrs: { type: "number", placeholder: "ID скрипта" },
                          domProps: { value: _vm.script_id },
                          on: {
                            input: function ($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.script_id = $event.target.value
                            },
                          },
                        }),
                      ]),
                    ]),
                  ])
                : _vm._e(),
              _vm._v(" "),
              _vm.time_address == -1
                ? _c("div", { staticClass: "row" }, [
                    _c("div", { staticClass: "col-5 mt-1" }, [
                      _c("div", { staticClass: "fl" }, [
                        _vm._v(
                          "\n\t\t\t\t\tСколько минут считать, за полный рабочий день\n\t\t\t\t\t"
                        ),
                        _c("i", {
                          directives: [
                            {
                              name: "b-popover",
                              rawName: "v-b-popover.hover.right.html",
                              value:
                                "Запишите сколько минут разговора с сервиса cp.callibro.org считать, за полный рабочий день. <br>Пример: 250 минут считается как 8 часов",
                              expression:
                                "'Запишите сколько минут разговора с сервиса cp.callibro.org считать, за полный рабочий день. <br>Пример: 250 минут считается как 8 часов'",
                              modifiers: {
                                hover: true,
                                right: true,
                                html: true,
                              },
                            },
                          ],
                          staticClass: "fa fa-info-circle ml-2",
                          attrs: { title: "Ставить полный рабочий день" },
                        }),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-7 mt-1" }, [
                      _c("div", { staticClass: "fl d-flex" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.talk_minutes,
                              expression: "talk_minutes",
                            },
                          ],
                          staticClass: "form-control scscsc",
                          attrs: { type: "text", placeholder: "ID" },
                          domProps: { value: _vm.talk_minutes },
                          on: {
                            input: function ($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.talk_minutes = $event.target.value
                            },
                          },
                        }),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.talk_hours,
                              expression: "talk_hours",
                            },
                          ],
                          staticClass: "form-control scscsc",
                          attrs: { type: "number", placeholder: "ID скрипта" },
                          domProps: { value: _vm.talk_hours },
                          on: {
                            input: function ($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.talk_hours = $event.target.value
                            },
                          },
                        }),
                      ]),
                    ]),
                  ])
                : _vm._e(),
              _vm._v(" "),
              _c("div", { staticClass: "row mt-1" }, [
                _c("div", { staticClass: "col-12" }, [
                  _c("p", {}, [
                    _vm._v("\n\t\t\t\t\tИсключения\n\n\t\t\t\t\t"),
                    _c("i", {
                      directives: [
                        {
                          name: "b-popover",
                          rawName: "v-b-popover.hover.right.html",
                          value:
                            "Часы выбранных сотрудников, не будут копироваться из аналитики в табель",
                          expression:
                            "'Часы выбранных сотрудников, не будут копироваться из аналитики в табель'",
                          modifiers: { hover: true, right: true, html: true },
                        },
                      ],
                      staticClass: "fa fa-info-circle",
                    }),
                  ]),
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "col-12 mt-1" },
                  [
                    _c("multiselect", {
                      attrs: {
                        options: _vm.time_exceptions_options,
                        multiple: true,
                        "close-on-select": false,
                        "clear-on-select": false,
                        "preserve-search": true,
                        placeholder: "Выберите, кого не связывать",
                        label: "email",
                        "track-by": "email",
                        taggable: true,
                      },
                      on: { tag: _vm.addExceptionTag },
                      model: {
                        value: _vm.time_exceptions,
                        callback: function ($$v) {
                          _vm.time_exceptions = $$v
                        },
                        expression: "time_exceptions",
                      },
                    }),
                  ],
                  1
                ),
              ]),
            ]
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              staticClass: "modalle",
              attrs: { size: "md", title: "Восстановить из архива" },
              on: {
                ok: function ($event) {
                  return _vm.restoreGroup()
                },
              },
              model: {
                value: _vm.showArchiveModal,
                callback: function ($$v) {
                  _vm.showArchiveModal = $$v
                },
                expression: "showArchiveModal",
              },
            },
            [
              _c(
                "div",
                [
                  _c("b-form-group", [
                    _c(
                      "select",
                      {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.restore_group,
                            expression: "restore_group",
                          },
                        ],
                        staticClass: "form-control",
                        on: {
                          change: function ($event) {
                            var $$selectedVal = Array.prototype.filter
                              .call($event.target.options, function (o) {
                                return o.selected
                              })
                              .map(function (o) {
                                var val = "_value" in o ? o._value : o.value
                                return val
                              })
                            _vm.restore_group = $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          },
                        },
                      },
                      _vm._l(
                        _vm.archived_groups,
                        function (archived_group, key) {
                          return _c(
                            "option",
                            { key: key, domProps: { value: archived_group } },
                            [
                              _vm._v(
                                "\n\t\t\t\t\t\t" +
                                  _vm._s(archived_group.name) +
                                  "\n\t\t\t\t\t"
                              ),
                            ]
                          )
                        }
                      ),
                      0
                    ),
                  ]),
                ],
                1
              ),
            ]
          ),
        ],
        1
      )
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=template&id=467c86c4&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/professions.vue?vue&type=template&id=467c86c4&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.positions
    ? _c(
        "div",
        [
          _c(
            "b-row",
            { staticClass: "align-items-center" },
            [
              _c(
                "b-col",
                { attrs: { cols: "12", lg: "3", md: "4" } },
                [
                  _vm.data.length
                    ? _c(
                        "b-form-group",
                        [
                          _c("multiselect", {
                            ref: "positionMultiselect",
                            attrs: {
                              options: _vm.data,
                              placeholder: "Выберите должность",
                              "track-by": "position",
                              label: "position",
                            },
                            on: { select: _vm.selectPosition },
                            scopedSlots: _vm._u(
                              [
                                {
                                  key: "afterList",
                                  fn: function () {
                                    return [
                                      _c(
                                        "li",
                                        { staticClass: "multiselect-add-li" },
                                        [
                                          _c(
                                            "span",
                                            {
                                              staticClass:
                                                "multiselect-add-btn",
                                              on: { click: _vm.addNewPosition },
                                            },
                                            [_vm._v("Добавить новую должность")]
                                          ),
                                        ]
                                      ),
                                    ]
                                  },
                                  proxy: true,
                                },
                              ],
                              null,
                              false,
                              565128982
                            ),
                            model: {
                              value: _vm.activebtn,
                              callback: function ($$v) {
                                _vm.activebtn = $$v
                              },
                              expression: "activebtn",
                            },
                          }),
                        ],
                        1
                      )
                    : _c(
                        "button",
                        {
                          staticClass: "btn btn-success",
                          on: { click: _vm.addNewPosition },
                        },
                        [_vm._v("\n\t\t\t\tДобавить новую должность\n\t\t\t")]
                      ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _vm.activebtn != null || _vm.addNew
            ? [
                _c("hr", { staticClass: "my-4" }),
                _vm._v(" "),
                _vm.addNew
                  ? _c("h4", { staticClass: "position-title-new" }, [
                      _vm._v("\n\t\t\tСоздание новой должности\n\t\t"),
                    ])
                  : _vm._e(),
                _vm._v(" "),
                _c(
                  "b-row",
                  { staticClass: "align-items-center mt-4" },
                  [
                    _c(
                      "b-col",
                      { attrs: { cols: "12", md: "4" } },
                      [
                        _c(
                          "b-form-group",
                          {
                            staticClass: "add-grade",
                            attrs: { label: "Название должности" },
                          },
                          [
                            _c("b-form-input", {
                              attrs: { type: "text" },
                              model: {
                                value: _vm.new_position,
                                callback: function ($$v) {
                                  _vm.new_position = $$v
                                },
                                expression: "new_position",
                              },
                            }),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "b-row",
                  { staticClass: "align-items-center mt-4" },
                  [
                    _c(
                      "b-col",
                      { attrs: { cols: "12", md: "4" } },
                      [
                        _c(
                          "b-form-group",
                          [
                            _c(
                              "b-form-checkbox",
                              {
                                attrs: {
                                  value: 1,
                                  "unchecked-value": 0,
                                  switch: "",
                                },
                                model: {
                                  value: _vm.isHead,
                                  callback: function ($$v) {
                                    _vm.isHead = $$v
                                  },
                                  expression: "isHead",
                                },
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\tРуководящая должность\n\t\t\t\t\t\t"
                                ),
                                _c("img", {
                                  directives: [
                                    {
                                      name: "b-popover",
                                      rawName: "v-b-popover.hover.right",
                                      value:
                                        "Сотрудника с такой должностью можно будет назначить руководителем отдела",
                                      expression:
                                        "'Сотрудника с такой должностью можно будет назначить руководителем отдела'",
                                      modifiers: { hover: true, right: true },
                                    },
                                  ],
                                  staticClass: "img-info",
                                  attrs: {
                                    src: "/images/dist/profit-info.svg",
                                  },
                                }),
                              ]
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _vm.isBP
                  ? _c(
                      "b-row",
                      { staticClass: "align-items-center mt-4" },
                      [
                        _c(
                          "b-col",
                          { attrs: { cols: "12", md: "4" } },
                          [
                            _c(
                              "b-form-group",
                              [
                                _c(
                                  "b-form-checkbox",
                                  {
                                    attrs: {
                                      value: 1,
                                      "unchecked-value": 0,
                                      switch: "",
                                    },
                                    model: {
                                      value: _vm.isSpec,
                                      callback: function ($$v) {
                                        _vm.isSpec = $$v
                                      },
                                      expression: "isSpec",
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\tСтарший специалист\n\t\t\t\t\t\t"
                                    ),
                                    _c("img", {
                                      directives: [
                                        {
                                          name: "b-popover",
                                          rawName: "v-b-popover.hover.right",
                                          value:
                                            "Сотрудника с такой должностью будут оценивать сотрудники отдела",
                                          expression:
                                            "'Сотрудника с такой должностью будут оценивать сотрудники отдела'",
                                          modifiers: {
                                            hover: true,
                                            right: true,
                                          },
                                        },
                                      ],
                                      staticClass: "img-info",
                                      attrs: {
                                        src: "/images/dist/profit-info.svg",
                                      },
                                    }),
                                  ]
                                ),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                _c(
                  "b-row",
                  { staticClass: "align-items-center" },
                  [
                    _c(
                      "b-col",
                      { attrs: { cols: "12", md: "4" } },
                      [
                        _c(
                          "b-form-group",
                          { attrs: { label: "Сумма индексации" } },
                          [
                            _vm.indexation
                              ? _c("b-form-input", {
                                  staticClass: "form-control group-select",
                                  attrs: { type: "text" },
                                  model: {
                                    value: _vm.sum,
                                    callback: function ($$v) {
                                      _vm.sum = $$v
                                    },
                                    expression: "sum",
                                  },
                                })
                              : _c("b-form-input", {
                                  staticClass: "form-control group-select",
                                  attrs: { type: "text", disabled: "" },
                                  model: {
                                    value: _vm.sum,
                                    callback: function ($$v) {
                                      _vm.sum = $$v
                                    },
                                    expression: "sum",
                                  },
                                }),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-col",
                      { attrs: { cols: "12", md: "4" } },
                      [
                        _c(
                          "b-form-group",
                          { staticClass: "mt-5" },
                          [
                            _c(
                              "b-form-checkbox",
                              {
                                attrs: {
                                  value: 1,
                                  "unchecked-value": 0,
                                  switch: "",
                                },
                                model: {
                                  value: _vm.indexation,
                                  callback: function ($$v) {
                                    _vm.indexation = $$v
                                  },
                                  expression: "indexation",
                                },
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\tИндексация зарплаты\n\t\t\t\t\t\t"
                                ),
                                _c("img", {
                                  directives: [
                                    {
                                      name: "b-popover",
                                      rawName: "v-b-popover.hover.right",
                                      value:
                                        "Каждые 90 дней оклад сотрудника будет увеличиваться сумму индексации",
                                      expression:
                                        "'Каждые 90 дней оклад сотрудника будет увеличиваться сумму индексации'",
                                      modifiers: { hover: true, right: true },
                                    },
                                  ],
                                  staticClass: "img-info",
                                  attrs: {
                                    src: "/images/dist/profit-info.svg",
                                  },
                                }),
                              ]
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c("div", { staticClass: "card position-card mt-4" }, [
                  _c(
                    "div",
                    { staticClass: "card-header" },
                    [
                      _c(
                        "b-form-checkbox",
                        {
                          attrs: { value: 1, switch: "", "unchecked-value": 0 },
                          model: {
                            value: _vm.desc.show,
                            callback: function ($$v) {
                              _vm.$set(_vm.desc, "show", $$v)
                            },
                            expression: "desc.show",
                          },
                        },
                        [
                          _vm._v(
                            "\n\t\t\t\t\tПоказывать в профиле\n\t\t\t\t\t"
                          ),
                          _c("img", {
                            directives: [
                              {
                                name: "b-popover",
                                rawName: "v-b-popover.hover.right",
                                value:
                                  "Активировав эту функцию, у сотрудников данной должности в профиле будет показан данный блок",
                                expression:
                                  "'Активировав эту функцию, у сотрудников данной должности в профиле будет показан данный блок'",
                                modifiers: { hover: true, right: true },
                              },
                            ],
                            staticClass: "img-info",
                            attrs: { src: "/images/dist/profit-info.svg" },
                          }),
                        ]
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "card-body" },
                    [
                      _c(
                        "b-row",
                        [
                          _c(
                            "b-col",
                            { attrs: { cols: "12", lg: "6" } },
                            [
                              _c(
                                "b-form-group",
                                {
                                  attrs: {
                                    label: "Следующая ступень карьерного роста",
                                  },
                                },
                                [
                                  _c("b-textarea", {
                                    model: {
                                      value: _vm.desc.next_step,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.desc, "next_step", $$v)
                                      },
                                      expression: "desc.next_step",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-col",
                            { attrs: { cols: "12", lg: "6" } },
                            [
                              _c(
                                "b-form-group",
                                { attrs: { label: "Требования к кандидату" } },
                                [
                                  _c("b-textarea", {
                                    model: {
                                      value: _vm.desc.require,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.desc, "require", $$v)
                                      },
                                      expression: "desc.require",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-col",
                            { attrs: { cols: "12", lg: "6" } },
                            [
                              _c(
                                "b-form-group",
                                { attrs: { label: "Что нужно делать" } },
                                [
                                  _c("b-textarea", {
                                    model: {
                                      value: _vm.desc.actions,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.desc, "actions", $$v)
                                      },
                                      expression: "desc.actions",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-col",
                            { attrs: { cols: "12", lg: "6" } },
                            [
                              _c(
                                "b-form-group",
                                { attrs: { label: "График работы" } },
                                [
                                  _c("b-textarea", {
                                    model: {
                                      value: _vm.desc.time,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.desc, "time", $$v)
                                      },
                                      expression: "desc.time",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-col",
                            { attrs: { cols: "12", lg: "6" } },
                            [
                              _c(
                                "b-form-group",
                                { attrs: { label: "Заработная плата" } },
                                [
                                  _c("b-textarea", {
                                    model: {
                                      value: _vm.desc.salary,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.desc, "salary", $$v)
                                      },
                                      expression: "desc.salary",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-col",
                            { attrs: { cols: "12", lg: "6" } },
                            [
                              _c(
                                "b-form-group",
                                {
                                  attrs: {
                                    label:
                                      "Нужные знания для перехода на следующую должность",
                                  },
                                },
                                [
                                  _c("b-textarea", {
                                    model: {
                                      value: _vm.desc.knowledge,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.desc, "knowledge", $$v)
                                      },
                                      expression: "desc.knowledge",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "text-right mt-3" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-success mr-2",
                      on: { click: _vm.savePosition },
                    },
                    [_vm._v("\n\t\t\t\tСохранить\n\t\t\t")]
                  ),
                  _vm._v(" "),
                  !_vm.addNew
                    ? _c(
                        "button",
                        {
                          staticClass: "btn btn-danger mr-2",
                          on: {
                            click: function ($event) {
                              $event.stopPropagation()
                              return _vm.deletePosition.apply(null, arguments)
                            },
                          },
                        },
                        [
                          _c("i", { staticClass: "fa fa-trash mr-2" }),
                          _vm._v(" Удалить\n\t\t\t"),
                        ]
                      )
                    : _vm._e(),
                ]),
              ]
            : _vm._e(),
        ],
        2
      )
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=template&id=cb8bcb4c&scoped=true&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/shifts.vue?vue&type=template&id=cb8bcb4c&scoped=true& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "settings-company-shifts" },
    [
      _c(
        "b-button",
        {
          staticClass: "mb-2",
          attrs: { variant: "success" },
          on: { click: _vm.createNewShift },
        },
        [_vm._v("\n\t\tСоздать новую смену\n\t")]
      ),
      _vm._v(" "),
      _vm.shiftsData.length
        ? _c(
            "div",
            { staticClass: "table-container" },
            [
              _c(
                "b-table-simple",
                {
                  staticClass: "table-shifts",
                  attrs: { id: "awards-table", bordered: "", hover: false },
                },
                [
                  _c(
                    "b-thead",
                    [
                      _c(
                        "b-tr",
                        [
                          _c("b-th", [_vm._v("№")]),
                          _vm._v(" "),
                          _c("b-th", [_vm._v("Название")]),
                          _vm._v(" "),
                          _c("b-th", [_vm._v("График")]),
                          _vm._v(" "),
                          _c("b-th", [_vm._v("Рабочие часы")]),
                          _vm._v(" "),
                          _c("b-th", [_vm._v("Время отдыха")]),
                          _vm._v(" "),
                          _c("b-th", [_vm._v("Дата создания")]),
                          _vm._v(" "),
                          _c("b-th", { staticClass: "w-100px" }),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "b-tbody",
                    _vm._l(_vm.shiftsData, function (shift, index) {
                      return _c(
                        "b-tr",
                        { key: index },
                        [
                          _c("b-td", [_vm._v(_vm._s(index + 1))]),
                          _vm._v(" "),
                          _c("b-td", [_vm._v(_vm._s(shift.text_name))]),
                          _vm._v(" "),
                          _c("b-td", [_vm._v(_vm._s(_vm.getShiftDays(shift)))]),
                          _vm._v(" "),
                          _c("b-td", [
                            _vm._v(
                              "с " +
                                _vm._s(shift.start_time) +
                                " по " +
                                _vm._s(shift.end_time)
                            ),
                          ]),
                          _vm._v(" "),
                          _c("b-td", [
                            _vm._v(_vm._s(shift.rest_time || 0) + " минут"),
                          ]),
                          _vm._v(" "),
                          _c("b-td", [
                            _vm._v(
                              _vm._s(
                                _vm
                                  .$moment(shift.created_at)
                                  .format("YYYY-MM-DD")
                              )
                            ),
                          ]),
                          _vm._v(" "),
                          _c("b-td", { staticClass: "td-actions" }, [
                            _c(
                              "div",
                              { staticClass: "d-flex mx-2" },
                              [
                                _c(
                                  "b-button",
                                  {
                                    staticClass: "btn btn-primary btn-icon",
                                    on: {
                                      click: function ($event) {
                                        return _vm.editShift(shift)
                                      },
                                    },
                                  },
                                  [_c("i", { staticClass: "fa fa-pen" })]
                                ),
                                _vm._v(" "),
                                _c(
                                  "b-button",
                                  {
                                    staticClass: "btn btn-danger btn-icon",
                                    on: {
                                      click: function ($event) {
                                        return _vm.openModal(shift.id)
                                      },
                                    },
                                  },
                                  [_c("i", { staticClass: "fa fa-trash" })]
                                ),
                              ],
                              1
                            ),
                          ]),
                        ],
                        1
                      )
                    }),
                    1
                  ),
                ],
                1
              ),
            ],
            1
          )
        : _c("div", { staticClass: "mt-4" }, [
            _c("h4", [_vm._v("Нет ни одной смены")]),
          ]),
      _vm._v(" "),
      _c(
        "sidebar",
        {
          attrs: {
            id: "edit-shift-sidebar",
            title: _vm.sidebarName ? _vm.sidebarName : "Сертификат",
            open: _vm.showSidebar,
            width: "600px",
          },
          on: { close: _vm.closeSidebar },
        },
        [
          _c(
            "b-form",
            {
              on: {
                submit: function ($event) {
                  $event.preventDefault()
                  return _vm.onSubmit.apply(null, arguments)
                },
              },
            },
            [
              _c("div", { staticClass: "form-group row" }, [
                _c(
                  "label",
                  {
                    staticClass: "col-sm-4 col-form-label",
                    attrs: { for: "chartName" },
                  },
                  [_vm._v("Название")]
                ),
                _vm._v(" "),
                _c("div", { staticClass: "col-sm-8 form-inline" }, [
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.form.name,
                        expression: "form.name",
                      },
                    ],
                    staticClass: "form-control",
                    attrs: { id: "chartName" },
                    domProps: { value: _vm.form.name },
                    on: {
                      input: function ($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.form, "name", $event.target.value)
                      },
                    },
                  }),
                ]),
              ]),
              _vm._v(" "),
              _c(
                "div",
                {
                  staticClass: "form-group work-schedule row",
                  attrs: { id: "workShedule" },
                },
                [
                  _c(
                    "label",
                    {
                      staticClass: "col-sm-4 col-form-label",
                      attrs: { for: "workStartTime" },
                    },
                    [
                      _vm._v("\n\t\t\t\t\tРабочий график\n\t\t\t\t\t"),
                      _c("img", {
                        directives: [
                          {
                            name: "b-popover",
                            rawName: "v-b-popover.hover.left",
                            value:
                              "Укажите во сколько начинается и заканчивается рабочий день всей группы по умолчанию (индивидуально устанавливается в профиле сотрудника)",
                            expression:
                              "'Укажите во сколько начинается и заканчивается рабочий день всей группы по умолчанию (индивидуально устанавливается в профиле сотрудника)'",
                            modifiers: { hover: true, left: true },
                          },
                        ],
                        staticClass: "img-info",
                        attrs: { src: "/images/dist/profit-info.svg" },
                      }),
                    ]
                  ),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-sm-8 form-inline" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.workStartTime,
                          expression: "form.workStartTime",
                        },
                      ],
                      staticClass: "form-control mr-2 work-start-time",
                      attrs: {
                        id: "workStartTime",
                        name: "work_start_time",
                        type: "time",
                      },
                      domProps: { value: _vm.form.workStartTime },
                      on: {
                        input: function ($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(
                            _vm.form,
                            "workStartTime",
                            $event.target.value
                          )
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c(
                      "label",
                      {
                        staticClass: "col-form-label mx-3",
                        attrs: { for: "workEndTime" },
                      },
                      [_vm._v("До ")]
                    ),
                    _vm._v(" "),
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.form.workEndTime,
                          expression: "form.workEndTime",
                        },
                      ],
                      staticClass: "form-control mx-2 work-end-time",
                      attrs: {
                        id: "workEndTime",
                        name: "work_start_end",
                        type: "time",
                      },
                      domProps: { value: _vm.form.workEndTime },
                      on: {
                        input: function ($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.$set(_vm.form, "workEndTime", $event.target.value)
                        },
                      },
                    }),
                  ]),
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "form-group row" }, [
                _c(
                  "label",
                  {
                    staticClass: "col-sm-4 col-form-label",
                    attrs: { for: "chartRest" },
                  },
                  [
                    _vm._v("\n\t\t\t\t\tВремя отдыха\n\t\t\t\t\t"),
                    _c("img", {
                      directives: [
                        {
                          name: "b-popover",
                          rawName: "v-b-popover.hover.left",
                          value:
                            "Укажите сколько времени в минутах положено отдыха (обед и т.п.). Это время будет не оплачиваемым",
                          expression:
                            "'Укажите сколько времени в минутах положено отдыха (обед и т.п.). Это время будет не оплачиваемым'",
                          modifiers: { hover: true, left: true },
                        },
                      ],
                      staticClass: "img-info",
                      attrs: { src: "/images/dist/profit-info.svg" },
                    }),
                  ]
                ),
                _vm._v(" "),
                _c("div", { staticClass: "col-sm-8 form-inline" }, [
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.form.restTime,
                        expression: "form.restTime",
                      },
                    ],
                    staticClass: "form-control",
                    attrs: { id: "chartRest", type: "number" },
                    domProps: { value: _vm.form.restTime },
                    on: {
                      input: function ($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.form, "restTime", $event.target.value)
                      },
                    },
                  }),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "form-group row" }, [
                _c(
                  "label",
                  {
                    staticClass: "col-sm-4 col-form-label",
                    attrs: { for: "workStartTime" },
                  },
                  [_vm._v("Смены или дни")]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "col-sm-8" },
                  [
                    _c("b-select", {
                      attrs: { options: _vm.typeOptions },
                      model: {
                        value: _vm.form.type,
                        callback: function ($$v) {
                          _vm.$set(_vm.form, "type", $$v)
                        },
                        expression: "form.type",
                      },
                    }),
                  ],
                  1
                ),
              ]),
              _vm._v(" "),
              _vm.form.type === 1
                ? _c("div", { staticClass: "form-group row" }, [
                    _c(
                      "label",
                      {
                        staticClass: "col-sm-4 col-form-label",
                        attrs: { for: "chartRest" },
                      },
                      [
                        _vm._v("\n\t\t\t\t\tПлавающие выходные\n\t\t\t\t\t"),
                        _c("img", {
                          directives: [
                            {
                              name: "b-popover",
                              rawName: "v-b-popover.hover.left",
                              value:
                                "В любой из рабочих дней человек сможет отдохнуть то количество которое вы указали в поле",
                              expression:
                                "'В любой из рабочих дней человек сможет отдохнуть то количество которое вы указали в поле'",
                              modifiers: { hover: true, left: true },
                            },
                          ],
                          staticClass: "img-info",
                          attrs: { src: "/images/dist/profit-info.svg" },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-sm-8 form-inline" }, [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.form.floatingDayoffs,
                            expression: "form.floatingDayoffs",
                          },
                        ],
                        staticClass: "form-control",
                        attrs: { id: "chartRest", type: "number" },
                        domProps: { value: _vm.form.floatingDayoffs },
                        on: {
                          input: function ($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.form,
                              "floatingDayoffs",
                              $event.target.value
                            )
                          },
                        },
                      }),
                    ]),
                  ])
                : _vm._e(),
              _vm._v(" "),
              _vm.form.type === 2
                ? _c(
                    "b-form-group",
                    { attrs: { label: "График", "label-cols": "4" } },
                    [
                      _c(
                        "b-row",
                        [
                          _c(
                            "b-col",
                            { attrs: { cols: "5" } },
                            [
                              _c("b-form-select", {
                                attrs: { options: _vm.workdays },
                                model: {
                                  value: _vm.form.workdays,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form, "workdays", $$v)
                                  },
                                  expression: "form.workdays",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "b-col",
                            {
                              staticClass: "col-form-label",
                              attrs: { cols: "2" },
                            },
                            [_vm._v("\n\t\t\t\t\t\tна\n\t\t\t\t\t")]
                          ),
                          _vm._v(" "),
                          _c(
                            "b-col",
                            { attrs: { cols: "5" } },
                            [
                              _c("b-form-select", {
                                attrs: { options: _vm.dayoffs },
                                model: {
                                  value: _vm.form.dayoffs,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form, "dayoffs", $$v)
                                  },
                                  expression: "form.dayoffs",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.form.type === 1
                ? _c("div", { staticClass: "form-group row" }, [
                    _c(
                      "label",
                      {
                        staticClass: "col-sm-4 col-form-label",
                        attrs: { for: "workStartTime" },
                      },
                      [
                        _vm._v("\n\t\t\t\t\tОтметьте выходные дни\n\t\t\t\t\t"),
                        _c("img", {
                          directives: [
                            {
                              name: "b-popover",
                              rawName: "v-b-popover.hover.left",
                              value:
                                "Отметив выходные дни сотрудник не сможет начать рабочй день в эти дни",
                              expression:
                                "'Отметив выходные дни сотрудник не сможет начать рабочй день в эти дни'",
                              modifiers: { hover: true, left: true },
                            },
                          ],
                          staticClass: "img-info",
                          attrs: { src: "/images/dist/profit-info.svg" },
                        }),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "col-sm-8" },
                      [
                        _c("BitMaskCheckGroup", {
                          attrs: { red: "" },
                          model: {
                            value: _vm.form.usualSchedule,
                            callback: function ($$v) {
                              _vm.$set(_vm.form, "usualSchedule", $$v)
                            },
                            expression: "form.usualSchedule",
                          },
                        }),
                      ],
                      1
                    ),
                  ])
                : _vm._e(),
              _vm._v(" "),
              _c("hr", { staticClass: "my-4" }),
              _vm._v(" "),
              _c(
                "b-button",
                { attrs: { type: "submit", variant: "success" } },
                [_vm._v("\n\t\t\t\tСохранить\n\t\t\t")]
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: { centered: "", title: "Удалить смену" },
          scopedSlots: _vm._u([
            {
              key: "modal-footer",
              fn: function () {
                return [
                  _c(
                    "b-button",
                    {
                      attrs: { variant: "danger" },
                      on: { click: _vm.deleteShift },
                    },
                    [_vm._v("\n\t\t\t\tУдалить\n\t\t\t")]
                  ),
                  _vm._v(" "),
                  _c(
                    "b-button",
                    {
                      attrs: { variant: "secondary" },
                      on: {
                        click: function ($event) {
                          _vm.modal = false
                        },
                      },
                    },
                    [_vm._v("\n\t\t\t\tОтмена\n\t\t\t")]
                  ),
                ]
              },
              proxy: true,
            },
          ]),
          model: {
            value: _vm.modal,
            callback: function ($$v) {
              _vm.modal = $$v
            },
            expression: "modal",
          },
        },
        [
          _c("p", { staticClass: "my-4" }, [
            _vm._v("\n\t\t\tВы уверены, что хотите удалить смену?\n\t\t"),
          ]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=template&id=9e444e5c&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/userlist.vue?vue&type=template&id=9e444e5c& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.positions
    ? _c(
        "div",
        [
          _c("div", { staticClass: "row mb-2" }, [
            _c(
              "div",
              { staticClass: "col-3 text-left" },
              [
                _c(
                  "b-input-group",
                  { attrs: { size: "sm" } },
                  [
                    _c("b-form-input", {
                      attrs: {
                        id: "filterInput",
                        type: "search",
                        placeholder: "Поиск",
                      },
                      model: {
                        value: _vm.filter.email,
                        callback: function ($$v) {
                          _vm.$set(_vm.filter, "email", $$v)
                        },
                        expression: "filter.email",
                      },
                    }),
                    _vm._v(" "),
                    _c("b-input-group-append"),
                  ],
                  1
                ),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "col-2" },
              [
                _c("b-form-select", {
                  attrs: { options: _vm.groups, size: "sm" },
                  model: {
                    value: _vm.filter.group,
                    callback: function ($$v) {
                      _vm.$set(_vm.filter, "group", $$v)
                    },
                    expression: "filter.group",
                  },
                }),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "col-2  d-flex align-items-center" },
              [
                _c("b-form-select", {
                  attrs: { options: _vm.tableFilters, size: "sm" },
                  on: {
                    change: function ($event) {
                      return _vm.getUsers()
                    },
                  },
                  model: {
                    value: _vm.tableFilter,
                    callback: function ($$v) {
                      _vm.tableFilter = $$v
                    },
                    expression: "tableFilter",
                  },
                }),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "col-2  d-flex align-items-center" },
              [
                _c("b-form-select", {
                  attrs: { options: _vm.jobFilters, size: "sm" },
                  on: {
                    change: function ($event) {
                      return _vm.getUsers()
                    },
                  },
                  model: {
                    value: _vm.position,
                    callback: function ($$v) {
                      _vm.position = $$v
                    },
                    expression: "position",
                  },
                }),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass:
                  "col-3 justify-content-end d-flex align-items-start",
              },
              [
                _c(
                  "a",
                  {
                    staticClass: "btn btn-success rounded",
                    attrs: { href: "/timetracking/create-person" },
                  },
                  [_vm._v("Пригласить")]
                ),
                _vm._v(" "),
                _c(
                  "b-button",
                  {
                    staticClass: "btn-primary rounded ml-1",
                    attrs: { title: "Показывать поля" },
                    on: {
                      click: function ($event) {
                        _vm.showModal = !_vm.showModal
                      },
                    },
                  },
                  [
                    _c("i", {
                      staticClass: "fa fa-eye",
                      attrs: { "aria-hidden": "true" },
                    }),
                  ]
                ),
                _vm._v(" "),
                _c(
                  "b-button",
                  {
                    staticClass: "btn-primary rounded ml-1",
                    attrs: { title: "Дополнительные фильтры таблицы" },
                    on: {
                      click: function ($event) {
                        _vm.showFilterModal = !_vm.showFilterModal
                      },
                    },
                  },
                  [
                    _c("i", {
                      staticClass: "fa fa-filter",
                      attrs: { "aria-hidden": "true" },
                    }),
                  ]
                ),
              ],
              1
            ),
            _vm._v(" "),
            _c("div", { staticClass: "col-12" }, [
              _c("p", { staticClass: "mt-2 mr-2 fz14 mb-0" }, [
                _c("b", [_vm._v(" Все:")]),
                _vm._v(" " + _vm._s(_vm.filtered.length) + "  "),
                _c("b", [_vm._v("Рес:")]),
                _vm._v(" " + _vm._s(_vm.staff_res) + "\n\t\t\t"),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticStyle: { clear: "both" } }),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "table-responsive ul table-container" },
            [
              _c("b-table", {
                ref: "table",
                class: {
                  "hide-1": !_vm.showFields.number,
                  "hide-2": !_vm.showFields.id,
                  "hide-3": !_vm.showFields.email,
                  "hide-4": !_vm.showFields.name,
                  "hide-5": !_vm.showFields.last_name,
                  "hide-6": !_vm.showFields.groups,
                  "hide-7": !_vm.showFields.register_date,
                  "hide-8": !_vm.showFields.fire_date,
                  "hide-9": !_vm.showFields.fire_cause,
                  "hide-10": !_vm.showFields.user_type,
                  "hide-11": !_vm.showFields.segment,
                  "hide-12": !_vm.showFields.applied,
                  "hide-13": !_vm.showFields.full_time,
                },
                attrs: {
                  id: "table",
                  bordered: "",
                  "show-empty": "",
                  stacked: "md",
                  items: _vm.filtered,
                  fields: _vm.fields,
                  "current-page": _vm.currentPage,
                  "per-page": _vm.perPage,
                  filter: _vm.filter,
                  "filter-included-fields": _vm.filterOn,
                  "sort-by": _vm.sortBy,
                  "sort-desc": _vm.sortDesc,
                  "sort-direction": _vm.sortDirection,
                  "empty-filtered-text": "Еще не найдено ни одной записи",
                  "empty-text": "Не найдено ни одной записи",
                },
                on: {
                  "update:sortBy": function ($event) {
                    _vm.sortBy = $event
                  },
                  "update:sort-by": function ($event) {
                    _vm.sortBy = $event
                  },
                  "update:sortDesc": function ($event) {
                    _vm.sortDesc = $event
                  },
                  "update:sort-desc": function ($event) {
                    _vm.sortDesc = $event
                  },
                  filtered: _vm.onFiltered,
                },
                scopedSlots: _vm._u(
                  [
                    {
                      key: "cell(index)",
                      fn: function (row) {
                        return [
                          _vm._v(
                            "\n\t\t\t\t" + _vm._s(row.index + 1) + "\n\t\t\t"
                          ),
                        ]
                      },
                    },
                    {
                      key: "cell(id)",
                      fn: function (data) {
                        return [
                          _vm.is_admin && _vm.subdomain == "bp"
                            ? _c(
                                "a",
                                {
                                  attrs: {
                                    href:
                                      "https://test.jobtron.org/login-as-employee/" +
                                      data.item.id +
                                      "?auth=" +
                                      _vm.auth_token,
                                    target: "_blank",
                                  },
                                },
                                [
                                  _vm._v(
                                    "\n\t\t\t\t\t" +
                                      _vm._s(data.value) +
                                      "\n\t\t\t\t"
                                  ),
                                ]
                              )
                            : _c(
                                "a",
                                {
                                  attrs: {
                                    href:
                                      "/timetracking/edit-person?id=" +
                                      data.item.id,
                                    target: "_blank",
                                  },
                                },
                                [
                                  _vm._v(
                                    "\n\t\t\t\t\t" +
                                      _vm._s(data.value) +
                                      "\n\t\t\t\t"
                                  ),
                                ]
                              ),
                        ]
                      },
                    },
                    {
                      key: "cell(email)",
                      fn: function (data) {
                        return [
                          _c(
                            "a",
                            {
                              attrs: {
                                href:
                                  "/timetracking/edit-person?id=" +
                                  data.item.id,
                                target: "_blank",
                              },
                            },
                            [_vm._v(_vm._s(data.value))]
                          ),
                        ]
                      },
                    },
                    {
                      key: "cell(segment)",
                      fn: function (data) {
                        return [
                          _c("div", [
                            _vm.segments.hasOwnProperty(data.value)
                              ? _c("div", [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t" +
                                      _vm._s(_vm.segments[data.value]) +
                                      "\n\t\t\t\t\t"
                                  ),
                                ])
                              : _c("div", [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t" +
                                      _vm._s(data.value) +
                                      "\n\t\t\t\t\t"
                                  ),
                                ]),
                          ]),
                        ]
                      },
                    },
                    {
                      key: "cell(groups)",
                      fn: function (data) {
                        return _vm._l(data.value, function (group_id) {
                          return _c(
                            "b-badge",
                            {
                              key: group_id,
                              staticClass: "mr-1",
                              attrs: { variant: "primary" },
                            },
                            [
                              _vm._v(
                                "\n\t\t\t\t\t" +
                                  _vm._s(_vm.groups[group_id]) +
                                  "\n\t\t\t\t"
                              ),
                            ]
                          )
                        })
                      },
                    },
                    {
                      key: "cell(created_at)",
                      fn: function (row) {
                        return [
                          _vm._v(
                            "\n\t\t\t\t" +
                              _vm._s(
                                _vm.$moment(row.value).format("DD.MM.YYYY")
                              ) +
                              "\n\t\t\t"
                          ),
                        ]
                      },
                    },
                    {
                      key: "cell(full_time)",
                      fn: function (data) {
                        return [
                          data.value == 1
                            ? _c("div", [_vm._v("\n\t\t\t\t\tFull\n\t\t\t\t")])
                            : _c("div", [_vm._v("\n\t\t\t\t\tPart\n\t\t\t\t")]),
                        ]
                      },
                    },
                    {
                      key: "cell(fire_cause)",
                      fn: function (data) {
                        return [
                          _vm.tableFilter != "active"
                            ? _c("div", [
                                _vm._v(
                                  "\n\t\t\t\t\t" +
                                    _vm._s(data.value) +
                                    "\n\t\t\t\t"
                                ),
                              ])
                            : _vm._e(),
                        ]
                      },
                    },
                  ],
                  null,
                  false,
                  2326223223
                ),
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "my-2 d-flex align-items-center justify-content-end",
            },
            [
              _vm.currentUser === 18 && _vm.isBP
                ? _c(
                    "a",
                    {
                      staticClass:
                        "btn btn-success btn-sm mr-a rounded d-block",
                      attrs: { href: "javasctipt:void(0)" },
                      on: {
                        click: function ($event) {
                          $event.preventDefault()
                          return _vm.exportData()
                        },
                      },
                    },
                    [
                      _c("i", { staticClass: "far fa-file-excel" }),
                      _vm._v(" Экспорт\n\t\t"),
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              _c(
                "div",
                [
                  _c("b-pagination", {
                    staticClass: "my-0 p-0",
                    attrs: {
                      "total-rows": _vm.totalRows,
                      "per-page": _vm.perPage,
                      align: "fill",
                      size: "sm",
                    },
                    model: {
                      value: _vm.currentPage,
                      callback: function ($$v) {
                        _vm.currentPage = $$v
                      },
                      expression: "currentPage",
                    },
                  }),
                ],
                1
              ),
            ]
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                title: "Настройка списка «Сотрудники»",
                "ok-text": "Закрыть",
                size: "lg",
              },
              on: {
                ok: function ($event) {
                  _vm.showModal = !_vm.showModal
                },
              },
              model: {
                value: _vm.showModal,
                callback: function ($$v) {
                  _vm.showModal = $$v
                },
                expression: "showModal",
              },
            },
            [
              _vm._l(_vm.errors, function (error) {
                return [
                  _c(
                    "b-alert",
                    { key: error, attrs: { show: "", variant: "danger" } },
                    [_vm._v("\n\t\t\t\t" + _vm._s(error) + "\n\t\t\t")]
                  ),
                ]
              }),
              _vm._v(" "),
              _c("div", { staticClass: "row" }, [
                _c(
                  "div",
                  { staticClass: "col-md-4 mb-2" },
                  [
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.number,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "number", $$v)
                          },
                          expression: "showFields.number",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tНомер\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.id,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "id", $$v)
                          },
                          expression: "showFields.id",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tid\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.email,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "email", $$v)
                          },
                          expression: "showFields.email",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tEmail\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.name,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "name", $$v)
                          },
                          expression: "showFields.name",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tИмя\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.full_time,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "full_time", $$v)
                          },
                          expression: "showFields.full_time",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tFull / Part-time\n\t\t\t\t")]
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "col-md-4 mb-2" },
                  [
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.last_name,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "last_name", $$v)
                          },
                          expression: "showFields.last_name",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tФамилия\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.groups,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "groups", $$v)
                          },
                          expression: "showFields.groups",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tОтделы\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.register_date,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "register_date", $$v)
                          },
                          expression: "showFields.register_date",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tДата регистрации\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.fire_date,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "fire_date", $$v)
                          },
                          expression: "showFields.fire_date",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tДата увольнения\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.fire_cause,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "fire_cause", $$v)
                          },
                          expression: "showFields.fire_cause",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tПричина увольнения\n\t\t\t\t")]
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "col-md-4 mb-2" },
                  [
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.user_type,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "user_type", $$v)
                          },
                          expression: "showFields.user_type",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tRemote/Office\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.segment,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "segment", $$v)
                          },
                          expression: "showFields.segment",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tСегмент\n\t\t\t\t")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-form-checkbox",
                      {
                        attrs: { value: true, "unchecked-value": false },
                        model: {
                          value: _vm.showFields.applied,
                          callback: function ($$v) {
                            _vm.$set(_vm.showFields, "applied", $$v)
                          },
                          expression: "showFields.applied",
                        },
                      },
                      [_vm._v("\n\t\t\t\t\tДата принятия\n\t\t\t\t")]
                    ),
                  ],
                  1
                ),
              ]),
            ],
            2
          ),
          _vm._v(" "),
          _c(
            "b-modal",
            {
              attrs: {
                title: "Фильтр «Сотрудники»",
                "ok-text": "Применить",
                size: "md",
              },
              on: { ok: _vm.applyFilter },
              model: {
                value: _vm.showFilterModal,
                callback: function ($$v) {
                  _vm.showFilterModal = $$v
                },
                expression: "showFilterModal",
              },
            },
            [
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col-md-6 mb-2" }, [
                  _c("div", { staticClass: "d-flex align-items-center" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.active.date,
                          expression: "active.date",
                        },
                      ],
                      staticClass: "mr-3",
                      attrs: { type: "checkbox" },
                      domProps: {
                        checked: Array.isArray(_vm.active.date)
                          ? _vm._i(_vm.active.date, null) > -1
                          : _vm.active.date,
                      },
                      on: {
                        change: function ($event) {
                          var $$a = _vm.active.date,
                            $$el = $event.target,
                            $$c = $$el.checked ? true : false
                          if (Array.isArray($$a)) {
                            var $$v = null,
                              $$i = _vm._i($$a, $$v)
                            if ($$el.checked) {
                              $$i < 0 &&
                                _vm.$set(_vm.active, "date", $$a.concat([$$v]))
                            } else {
                              $$i > -1 &&
                                _vm.$set(
                                  _vm.active,
                                  "date",
                                  $$a.slice(0, $$i).concat($$a.slice($$i + 1))
                                )
                            }
                          } else {
                            _vm.$set(_vm.active, "date", $$c)
                          }
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c(
                      "p",
                      {
                        staticClass: "mb-0 pointer",
                        on: {
                          click: function ($event) {
                            return _vm.toggleActive("date")
                          },
                        },
                      },
                      [_vm._v("\n\t\t\t\t\t\tДата регистрации\n\t\t\t\t\t")]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6" }, [
                  _c(
                    "div",
                    {
                      staticClass: "relative ooooo",
                      class: { active: _vm.active.date },
                    },
                    [
                      _c("div", { staticClass: "d-flex align-items-center" }, [
                        _c(
                          "label",
                          { staticClass: " mr-2 mb-0", attrs: { for: "" } },
                          [_vm._v("От")]
                        ),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.filter.start_date,
                              expression: "filter.start_date",
                            },
                          ],
                          staticClass: "form-control mb-1 form-control-sm",
                          attrs: { type: "date" },
                          domProps: { value: _vm.filter.start_date },
                          on: {
                            input: function ($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.filter,
                                "start_date",
                                $event.target.value
                              )
                            },
                          },
                        }),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "d-flex align-items-center" }, [
                        _c(
                          "label",
                          { staticClass: " mr-2 mb-0", attrs: { for: "" } },
                          [_vm._v("До")]
                        ),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.filter.end_date,
                              expression: "filter.end_date",
                            },
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "date" },
                          domProps: { value: _vm.filter.end_date },
                          on: {
                            input: function ($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.filter,
                                "end_date",
                                $event.target.value
                              )
                            },
                          },
                        }),
                      ]),
                    ]
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "row mt-2" }, [
                _c("div", { staticClass: "col-md-6 mb-2" }, [
                  _c("div", { staticClass: "d-flex align-items-center" }, [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.active.date_deactivate,
                          expression: "active.date_deactivate",
                        },
                      ],
                      staticClass: "mr-3",
                      attrs: { type: "checkbox" },
                      domProps: {
                        checked: Array.isArray(_vm.active.date_deactivate)
                          ? _vm._i(_vm.active.date_deactivate, null) > -1
                          : _vm.active.date_deactivate,
                      },
                      on: {
                        change: function ($event) {
                          var $$a = _vm.active.date_deactivate,
                            $$el = $event.target,
                            $$c = $$el.checked ? true : false
                          if (Array.isArray($$a)) {
                            var $$v = null,
                              $$i = _vm._i($$a, $$v)
                            if ($$el.checked) {
                              $$i < 0 &&
                                _vm.$set(
                                  _vm.active,
                                  "date_deactivate",
                                  $$a.concat([$$v])
                                )
                            } else {
                              $$i > -1 &&
                                _vm.$set(
                                  _vm.active,
                                  "date_deactivate",
                                  $$a.slice(0, $$i).concat($$a.slice($$i + 1))
                                )
                            }
                          } else {
                            _vm.$set(_vm.active, "date_deactivate", $$c)
                          }
                        },
                      },
                    }),
                    _vm._v(" "),
                    _c(
                      "p",
                      {
                        staticClass: "mb-0 pointer",
                        on: {
                          click: function ($event) {
                            return _vm.toggleActive("date_deactivate")
                          },
                        },
                      },
                      [_vm._v("\n\t\t\t\t\t\tДата увольнения\n\t\t\t\t\t")]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6" }, [
                  _c(
                    "div",
                    {
                      staticClass: "relative ooooo",
                      class: { active: _vm.active.date_deactivate },
                    },
                    [
                      _c("div", { staticClass: "d-flex align-items-center" }, [
                        _c(
                          "label",
                          { staticClass: " mr-2 mb-0", attrs: { for: "" } },
                          [_vm._v("От")]
                        ),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.filter.start_date_deactivate,
                              expression: "filter.start_date_deactivate",
                            },
                          ],
                          staticClass: "form-control mb-1 form-control-sm",
                          attrs: { type: "date" },
                          domProps: { value: _vm.filter.start_date_deactivate },
                          on: {
                            input: function ($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.filter,
                                "start_date_deactivate",
                                $event.target.value
                              )
                            },
                          },
                        }),
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "d-flex align-items-center" }, [
                        _c(
                          "label",
                          { staticClass: " mr-2 mb-0", attrs: { for: "" } },
                          [_vm._v("До")]
                        ),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.filter.end_date_deactivate,
                              expression: "filter.end_date_deactivate",
                            },
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: { type: "date" },
                          domProps: { value: _vm.filter.end_date_deactivate },
                          on: {
                            input: function ($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.$set(
                                _vm.filter,
                                "end_date_deactivate",
                                $event.target.value
                              )
                            },
                          },
                        }),
                      ]),
                    ]
                  ),
                ]),
              ]),
              _vm._v(" "),
              _vm.tableFilter != "trainees"
                ? _c("div", { staticClass: "row mt-2" }, [
                    _c("div", { staticClass: "col-md-6 mb-2" }, [
                      _c("div", { staticClass: "d-flex align-items-center" }, [
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.active.date_applied,
                              expression: "active.date_applied",
                            },
                          ],
                          staticClass: "mr-3",
                          attrs: { type: "checkbox" },
                          domProps: {
                            checked: Array.isArray(_vm.active.date_applied)
                              ? _vm._i(_vm.active.date_applied, null) > -1
                              : _vm.active.date_applied,
                          },
                          on: {
                            change: function ($event) {
                              var $$a = _vm.active.date_applied,
                                $$el = $event.target,
                                $$c = $$el.checked ? true : false
                              if (Array.isArray($$a)) {
                                var $$v = null,
                                  $$i = _vm._i($$a, $$v)
                                if ($$el.checked) {
                                  $$i < 0 &&
                                    _vm.$set(
                                      _vm.active,
                                      "date_applied",
                                      $$a.concat([$$v])
                                    )
                                } else {
                                  $$i > -1 &&
                                    _vm.$set(
                                      _vm.active,
                                      "date_applied",
                                      $$a
                                        .slice(0, $$i)
                                        .concat($$a.slice($$i + 1))
                                    )
                                }
                              } else {
                                _vm.$set(_vm.active, "date_applied", $$c)
                              }
                            },
                          },
                        }),
                        _vm._v(" "),
                        _c(
                          "p",
                          {
                            staticClass: "mb-0 pointer",
                            on: {
                              click: function ($event) {
                                return _vm.toggleActive("date_applied")
                              },
                            },
                          },
                          [_vm._v("\n\t\t\t\t\t\tДата принятия\n\t\t\t\t\t")]
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-6" }, [
                      _c(
                        "div",
                        {
                          staticClass: "relative ooooo",
                          class: { active: _vm.active.date_applied },
                        },
                        [
                          _c(
                            "div",
                            { staticClass: "d-flex align-items-center" },
                            [
                              _c(
                                "label",
                                {
                                  staticClass: " mr-2 mb-0",
                                  attrs: { for: "" },
                                },
                                [_vm._v("От")]
                              ),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.filter.start_date_applied,
                                    expression: "filter.start_date_applied",
                                  },
                                ],
                                staticClass:
                                  "form-control mb-1 form-control-sm",
                                attrs: { type: "date" },
                                domProps: {
                                  value: _vm.filter.start_date_applied,
                                },
                                on: {
                                  input: function ($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.filter,
                                      "start_date_applied",
                                      $event.target.value
                                    )
                                  },
                                },
                              }),
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "d-flex align-items-center" },
                            [
                              _c(
                                "label",
                                {
                                  staticClass: " mr-2 mb-0",
                                  attrs: { for: "" },
                                },
                                [_vm._v("До")]
                              ),
                              _vm._v(" "),
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.filter.end_date_applied,
                                    expression: "filter.end_date_applied",
                                  },
                                ],
                                staticClass: "form-control form-control-sm",
                                attrs: { type: "date" },
                                domProps: {
                                  value: _vm.filter.end_date_applied,
                                },
                                on: {
                                  input: function ($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.filter,
                                      "end_date_applied",
                                      $event.target.value
                                    )
                                  },
                                },
                              }),
                            ]
                          ),
                        ]
                      ),
                    ]),
                  ])
                : _vm._e(),
              _vm._v(" "),
              _c("div", { staticClass: "row mt-2" }, [
                _c("div", { staticClass: "col-md-6 mb-2" }, [
                  _c("p", [_vm._v("Сегмент")]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col-6" }, [
                  _c("div", { staticClass: "d-flex align-items-center" }, [
                    _c(
                      "select",
                      {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.filter.segment,
                            expression: "filter.segment",
                          },
                        ],
                        staticClass: "form-control mb-1 form-control-sm",
                        on: {
                          change: function ($event) {
                            var $$selectedVal = Array.prototype.filter
                              .call($event.target.options, function (o) {
                                return o.selected
                              })
                              .map(function (o) {
                                var val = "_value" in o ? o._value : o.value
                                return val
                              })
                            _vm.$set(
                              _vm.filter,
                              "segment",
                              $event.target.multiple
                                ? $$selectedVal
                                : $$selectedVal[0]
                            )
                          },
                        },
                      },
                      [
                        _c("option", { attrs: { value: "0" } }, [
                          _vm._v("\n\t\t\t\t\t\t\tВсе сегменты\n\t\t\t\t\t\t"),
                        ]),
                        _vm._v(" "),
                        _c("option", { attrs: { value: "1" } }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t\tКандидаты на вакансию (таргет)\n\t\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("option", { attrs: { value: "2" } }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t\tКандидаты на вакансию (hh, nur, job)\n\t\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("option", { attrs: { value: "3" } }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t\tКандидаты на вакансию (promo акции)\n\t\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("option", { attrs: { value: "4" } }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t\tКандидаты на вакансию (месенджеры)\n\t\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("option", { attrs: { value: "5" } }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t\tКандидаты на вакансию (Гарантия трудоустройства)\n\t\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("option", { attrs: { value: "6" } }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t\tКандидаты на вакансию (Участники семинаров, форумов, встреч)\n\t\t\t\t\t\t"
                          ),
                        ]),
                      ]
                    ),
                  ]),
                ]),
              ]),
            ]
          ),
        ],
        1
      )
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);