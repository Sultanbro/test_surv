"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["TableComingPage"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_Portal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/Portal */ "./resources/js/stores/Portal.js");
/* harmony import */ var _composables_yearOptions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../composables/yearOptions */ "./resources/js/composables/yearOptions.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TableComing',
  props: {
    groups: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activeuserid: {
      type: String,
      "default": ''
    }
  },
  data: function data() {
    return {
      data: {},
      openSidebar: false,
      sidebarTitle: '',
      sidebarContent: {},
      items: [],
      fields: [],
      errors: [],
      comment: '',
      dayInfoText: '',
      hasPremission: false,
      dateInfo: {
        currentMonth: null,
        currentYear: new Date().getFullYear(),
        monthEnd: 0,
        workDays: 0,
        weekDays: 0,
        daysInMonth: 0
      },
      dataLoaded: false,
      currentGroup: null,
      currentTime: null,
      maxScrollWidth: 0,
      currentEditingCell: null,
      scrollLeft: 0,
      modalVisible: false,
      userType: ''
    };
  },
  computed: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_2__.mapState)(_stores_Portal__WEBPACK_IMPORTED_MODULE_0__.usePortalStore, ['portal'])), {}, {
    years: function years() {
      if (!this.portal.created_at) return [new Date().getFullYear()];
      return (0,_composables_yearOptions__WEBPACK_IMPORTED_MODULE_1__.useYearOptions)(new Date(this.portal.created_at).getFullYear());
    }
  }),
  watch: {
    // эта функция запускается при любом изменении данных
    data: function data(newData, oldData) {
      if (oldData) {
        this.loadItems();
      }
    },
    scrollLeft: function scrollLeft(value) {
      var container = document.querySelector('.table-responsive');
      container.scrollLeft = value;
    },
    groups: function groups() {
      this.init();
    },
    userType: function userType() {
      this.fetchData();
    }
  },
  created: function created() {
    if (this.groups) {
      this.init();
    }
  },
  methods: {
    init: function init() {
      this.dateInfo.currentMonth = this.dateInfo.currentMonth ? this.dateInfo.currentMonth : this.$moment().format('MMMM');
      var currentMonth = this.$moment(this.dateInfo.currentMonth, 'MMMM');

      //Расчет выходных дней
      this.dateInfo.monthEnd = currentMonth.endOf('month'); //Конец месяца
      this.dateInfo.weekDays = currentMonth.weekdayCalc(this.dateInfo.monthEnd, [6]); //Колличество выходных
      this.dateInfo.daysInMonth = currentMonth.daysInMonth(); //Колличество дней в месяце
      this.dateInfo.workDays = this.dateInfo.daysInMonth - this.dateInfo.weekDays; //Колличество рабочих дней

      //Текущая группа
      this.currentGroup = this.currentGroup ? this.currentGroup : this.groups[0]['id'];
      this.fetchData();
    },
    //Установка выбранного года
    setYear: function setYear() {
      this.dateInfo.currentYear = this.dateInfo.currentYear ? this.dateInfo.currentYear : this.$moment().format('YYYY');
    },
    //Установка выбранного месяца
    setMonth: function setMonth() {
      var year = this.dateInfo.currentYear;
      this.dateInfo.currentMonth = this.dateInfo.currentMonth ? this.dateInfo.currentMonth : this.$moment().format('MMMM');
      this.dateInfo.date = "".concat(this.dateInfo.currentMonth, " ").concat(year);
      var currentMonth = this.$moment(this.dateInfo.currentMonth, 'MMMM');
      //Расчет выходных дней
      this.dateInfo.monthEnd = currentMonth.endOf('month'); //Конец месяца
      this.dateInfo.weekDays = currentMonth.weekdayCalc(this.dateInfo.monthEnd, [6]); //Колличество выходных
      this.dateInfo.daysInMonth = currentMonth.daysInMonth(); //Колличество дней в месяце
      this.dateInfo.workDays = this.dateInfo.daysInMonth - this.dateInfo.weekDays; //Колличество рабочих дней
    },
    //Установка заголовока таблицы
    setFields: function setFields() {
      var fields = [];
      fields = [{
        key: 'name',
        stickyColumn: true,
        label: 'Имя',
        sortable: true,
        "class": 'text-left px-3 t-name'
      }];
      var days = this.dateInfo.daysInMonth;
      for (var i = 1; i <= days; i++) {
        var dayName = this.$moment("".concat(i, " ").concat(this.dateInfo.date), 'D MMMM YYYY').locale('en').format('ddd');
        fields.push({
          key: "".concat(i),
          label: "".concat(i),
          sortable: true,
          "class": "day ".concat(dayName)
        });
      }
      this.fields = fields;
    },
    //Загрузка данных для таблицы
    fetchData: function fetchData() {
      var _this = this;
      var loader = this.$loading.show();
      this.axios.post('/timetracking/reports/enter-report', {
        month: this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M'),
        year: this.dateInfo.currentYear,
        group_id: this.currentGroup,
        filter: this.userType
      }).then(function (response) {
        if (response.data.error && response.data.error == 'access') {
          console.error(response.data.error);
          _this.hasPremission = false;
          loader.hide();
          return;
        }
        _this.hasPremission = true;
        _this.data = response.data;
        _this.setYear();
        _this.setMonth();
        _this.setFields();
        _this.loadItems();
        _this.dataLoaded = true;
        setTimeout(function () {
          var container = document.querySelector('.table-responsive');
          _this.maxScrollWidth = container.scrollWidth - container.offsetWidth;
        }, 1000);
        loader.hide();
      });
    },
    changeTimeInCell: function changeTimeInCell(_ref) {
      var target = _ref.target;
      this.currentTime = target.value;
    },
    setCurrentEditingCell: function setCurrentEditingCell(data) {
      this.currentTime = null;
      this.currentEditingCell = data;
    },
    openModal: function openModal() {
      this.modalVisible = true;
    },
    setTimeManually: function setTimeManually() {
      var _this2 = this;
      var loader = this.$loading.show();
      if (this.comment.length > 0) {
        this.axios.post('/timetracking/reports/enter-report/setmanual', {
          month: this.$moment(this.dateInfo.currentMonth, 'MMMM').format('M'),
          year: this.dateInfo.currentYear,
          day: this.currentEditingCell.field.key,
          group_id: this.currentGroup,
          time: this.currentTime,
          comment: this.comment,
          user_id: this.currentEditingCell.item.user_id
        }).then(function () {
          _this2.currentEditingCell = null;
          _this2.currentTime = null;
          _this2.modalVisible = false;
          _this2.comment = '';
          loader.hide();
        });
      } else {
        this.errors = ['Комментарий обязателен'];
      }
    },
    //Добавление загруженных данных в таблицу
    loadItems: function loadItems() {
      this.items = this.data;
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".table-custom-table-coming th, .table-custom-table-coming td {\n  padding: 0 15px !important;\n  height: 40px;\n  vertical-align: middle !important;\n}\n.table-custom-table-coming thead th:not(.b-table-sticky-column), .table-custom-table-coming thead td:not(.b-table-sticky-column) {\n  text-align: center;\n}\n.table-coming .fine {\n  background-color: #f58c94;\n  width: calc(100% + 30px);\n  margin: 0 -15px;\n  height: 40px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\ninput[type=time]::-webkit-calendar-picker-indicator {\n  background: none;\n  display: none;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableComing_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableComing.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableComing_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableComing_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/pages/TableComing.vue":
/*!********************************************!*\
  !*** ./resources/js/pages/TableComing.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TableComing_vue_vue_type_template_id_5d2989b6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TableComing.vue?vue&type=template&id=5d2989b6& */ "./resources/js/pages/TableComing.vue?vue&type=template&id=5d2989b6&");
/* harmony import */ var _TableComing_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TableComing.vue?vue&type=script&lang=js& */ "./resources/js/pages/TableComing.vue?vue&type=script&lang=js&");
/* harmony import */ var _TableComing_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TableComing.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/TableComing.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TableComing_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TableComing_vue_vue_type_template_id_5d2989b6___WEBPACK_IMPORTED_MODULE_0__.render,
  _TableComing_vue_vue_type_template_id_5d2989b6___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/TableComing.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/TableComing.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/pages/TableComing.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableComing_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableComing.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableComing_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/TableComing.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************!*\
  !*** ./resources/js/pages/TableComing.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableComing_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableComing.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/TableComing.vue?vue&type=template&id=5d2989b6&":
/*!***************************************************************************!*\
  !*** ./resources/js/pages/TableComing.vue?vue&type=template&id=5d2989b6& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableComing_vue_vue_type_template_id_5d2989b6___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableComing_vue_vue_type_template_id_5d2989b6___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableComing_vue_vue_type_template_id_5d2989b6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableComing.vue?vue&type=template&id=5d2989b6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=template&id=5d2989b6&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=template&id=5d2989b6&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/TableComing.vue?vue&type=template&id=5d2989b6& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.groups
    ? _c("div", { staticClass: "mt-2 px-3" }, [
        _c("div", { staticClass: "mb-0" }, [
          _c("div", { staticClass: "row mb-3" }, [
            _c("div", { staticClass: "col-3" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.currentGroup,
                      expression: "currentGroup",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.currentGroup = $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      },
                      function ($event) {
                        return _vm.fetchData()
                      },
                    ],
                  },
                },
                _vm._l(_vm.groups, function (group) {
                  return _c(
                    "option",
                    { key: group.id, domProps: { value: group.id } },
                    [
                      _vm._v(
                        "\n\t\t\t\t\t\t" + _vm._s(group.name) + "\n\t\t\t\t\t"
                      ),
                    ]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-3" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.dateInfo.currentMonth,
                      expression: "dateInfo.currentMonth",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.dateInfo,
                          "currentMonth",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      function ($event) {
                        return _vm.fetchData()
                      },
                    ],
                  },
                },
                _vm._l(_vm.$moment.months(), function (month) {
                  return _c(
                    "option",
                    { key: month, domProps: { value: month } },
                    [_vm._v("\n\t\t\t\t\t\t" + _vm._s(month) + "\n\t\t\t\t\t")]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-2" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.dateInfo.currentYear,
                      expression: "dateInfo.currentYear",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.dateInfo,
                          "currentYear",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      function ($event) {
                        return _vm.fetchData()
                      },
                    ],
                  },
                },
                _vm._l(_vm.years, function (year) {
                  return _c(
                    "option",
                    { key: year, domProps: { value: year } },
                    [_vm._v("\n\t\t\t\t\t\t" + _vm._s(year) + "\n\t\t\t\t\t")]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-1" }, [
              _c(
                "div",
                {
                  staticClass: "btn btn-primary",
                  on: {
                    click: function ($event) {
                      return _vm.fetchData()
                    },
                  },
                },
                [_c("i", { staticClass: "fa fa-redo-alt" })]
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-2" }),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row mb-3" }, [
            _c(
              "div",
              { staticClass: "col-12 d-flex gap-4" },
              [
                _c(
                  "b-form-radio",
                  {
                    attrs: { value: "" },
                    model: {
                      value: _vm.userType,
                      callback: function ($$v) {
                        _vm.userType = $$v
                      },
                      expression: "userType",
                    },
                  },
                  [_vm._v("\n\t\t\t\t\tДействующие\n\t\t\t\t")]
                ),
                _vm._v(" "),
                _c(
                  "b-form-radio",
                  {
                    attrs: { value: "deactivated" },
                    model: {
                      value: _vm.userType,
                      callback: function ($$v) {
                        _vm.userType = $$v
                      },
                      expression: "userType",
                    },
                  },
                  [_vm._v("\n\t\t\t\t\tУволенные\n\t\t\t\t")]
                ),
                _vm._v(" "),
                _c(
                  "b-form-radio",
                  {
                    attrs: { value: "trainees" },
                    model: {
                      value: _vm.userType,
                      callback: function ($$v) {
                        _vm.userType = $$v
                      },
                      expression: "userType",
                    },
                  },
                  [_vm._v("\n\t\t\t\t\tСтажеры\n\t\t\t\t")]
                ),
              ],
              1
            ),
          ]),
          _vm._v(" "),
          _vm.hasPremission
            ? _c(
                "div",
                [
                  _c(
                    "b-modal",
                    {
                      attrs: {
                        "ok-text": "Да",
                        "cancel-text": "Нет",
                        title: "Вы уверены?",
                        size: "md",
                      },
                      on: { ok: _vm.setTimeManually },
                      model: {
                        value: _vm.modalVisible,
                        callback: function ($$v) {
                          _vm.modalVisible = $$v
                        },
                        expression: "modalVisible",
                      },
                    },
                    [
                      _vm._l(_vm.errors, function (error) {
                        return [
                          _c(
                            "b-alert",
                            {
                              key: error,
                              attrs: { show: "", variant: "danger" },
                            },
                            [
                              _vm._v(
                                "\n\t\t\t\t\t\t" +
                                  _vm._s(error) +
                                  "\n\t\t\t\t\t"
                              ),
                            ]
                          ),
                        ]
                      }),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: { placeholder: "Комментарий", required: true },
                        model: {
                          value: _vm.comment,
                          callback: function ($$v) {
                            _vm.comment = $$v
                          },
                          expression: "comment",
                        },
                      }),
                    ],
                    2
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "table-container table-coming" },
                    [
                      _c("b-table", {
                        staticClass:
                          "text-nowrap text-right table-custom-table-coming",
                        attrs: {
                          id: "comingTable",
                          responsive: "",
                          "sticky-header": true,
                          small: true,
                          bordered: true,
                          items: _vm.items,
                          fields: _vm.fields,
                          "show-empty": "",
                          "empty-text": "Нет данных",
                        },
                        scopedSlots: _vm._u(
                          [
                            {
                              key: "cell(name)",
                              fn: function (nameData) {
                                return [
                                  _c(
                                    "div",
                                    [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t" +
                                          _vm._s(nameData.value) +
                                          "\n\t\t\t\t\t\t\t"
                                      ),
                                      nameData.field.key == "name" &&
                                      nameData.value
                                        ? _c(
                                            "b-badge",
                                            {
                                              attrs: {
                                                pill: "",
                                                variant: "success",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "\n\t\t\t\t\t\t\t\t" +
                                                  _vm._s(
                                                    nameData.item.user_type
                                                  ) +
                                                  "\n\t\t\t\t\t\t\t"
                                              ),
                                            ]
                                          )
                                        : _vm._e(),
                                    ],
                                    1
                                  ),
                                ]
                              },
                            },
                            {
                              key: "cell()",
                              fn: function (cellData) {
                                return [
                                  _c(
                                    "div",
                                    {
                                      class: {
                                        fine:
                                          cellData.item.fines[
                                            cellData.field.key.toString()
                                          ].length > 0,
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.setCurrentEditingCell(
                                            cellData
                                          )
                                        },
                                      },
                                    },
                                    [
                                      _c("input", {
                                        staticClass: "cell-input",
                                        attrs: {
                                          type: "time",
                                          readonly: true,
                                          ondblclick: "this.readOnly='';",
                                        },
                                        domProps: { value: cellData.value },
                                        on: {
                                          mouseover: function ($event) {
                                            return $event.preventDefault()
                                          },
                                          change: _vm.changeTimeInCell,
                                          keyup: function ($event) {
                                            if (
                                              !$event.type.indexOf("key") &&
                                              _vm._k(
                                                $event.keyCode,
                                                "enter",
                                                13,
                                                $event.key,
                                                "Enter"
                                              )
                                            ) {
                                              return null
                                            }
                                            return _vm.openModal.apply(
                                              null,
                                              arguments
                                            )
                                          },
                                        },
                                      }),
                                    ]
                                  ),
                                ]
                              },
                            },
                          ],
                          null,
                          false,
                          1695721361
                        ),
                      }),
                    ],
                    1
                  ),
                ],
                1
              )
            : _c("div", [_c("p", [_vm._v("У вас нет доступа к этой группе")])]),
        ]),
      ])
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);