"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["TableActivityNew"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/ui/Sidebar */ "./resources/js/components/ui/Sidebar.vue");
/* harmony import */ var _ui_PopupMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ui/PopupMenu */ "./resources/js/components/ui/PopupMenu.vue");
/* harmony import */ var _ui_Select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ui/Select */ "./resources/js/components/ui/Select.vue");
/* harmony import */ var _ui_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ui/Button */ "./resources/js/components/ui/Button.vue");
/* harmony import */ var _ui_Cup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ui/Cup */ "./resources/js/components/ui/Cup.vue");
/* harmony import */ var _ui_Overlay__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ui/Overlay */ "./resources/js/components/ui/Overlay.vue");
/* harmony import */ var _ui_AccessSelect_AccessSelect_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ui/AccessSelect/AccessSelect.vue */ "./resources/js/components/ui/AccessSelect/AccessSelect.vue");
/* harmony import */ var _components_imports_ActivityExcelImport__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/components/imports/ActivityExcelImport */ "./resources/js/components/imports/ActivityExcelImport.vue");
/* harmony import */ var _stores_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/stores/api */ "./resources/js/stores/api.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */








 // импорт в активности


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'TableActivityNew',
  components: {
    Sidebar: _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_0__["default"],
    PopupMenu: _ui_PopupMenu__WEBPACK_IMPORTED_MODULE_1__["default"],
    JobtronSelect: _ui_Select__WEBPACK_IMPORTED_MODULE_2__["default"],
    JobtronButton: _ui_Button__WEBPACK_IMPORTED_MODULE_3__["default"],
    JobtronCup: _ui_Cup__WEBPACK_IMPORTED_MODULE_4__["default"],
    AccessSelect: _ui_AccessSelect_AccessSelect_vue__WEBPACK_IMPORTED_MODULE_6__["default"],
    JobtronOverlay: _ui_Overlay__WEBPACK_IMPORTED_MODULE_5__["default"],
    ActivityExcelImport: _components_imports_ActivityExcelImport__WEBPACK_IMPORTED_MODULE_7__["default"]
  },
  props: {
    month: {
      type: Object,
      "default": null
    },
    activity: {
      type: Object,
      "default": null
    },
    group_id: {
      type: Number,
      "default": 0
    },
    color_invert: {
      type: Boolean,
      "default": false
    },
    work_days: {
      type: Number,
      "default": 5
    },
    // 5 или 6 дней в неделю
    editable: {
      type: Boolean,
      "default": true
    },
    show_headers: {
      type: Boolean,
      "default": true
    },
    hiddenUsers: {
      type: Array,
      "default": function _default() {}
    }
  },
  data: function data() {
    return {
      holidays: [],
      items: [],
      sorts: {},
      sortField: '',
      sortDir: 'asc',
      filtered: [],
      local_activity: {},
      fields: [],
      itemsArray: [],
      avgOfAverage: 0,
      totalCountDays: 0,
      currentAction: 'avg',
      sum: {},
      avg: {},
      counts: {},
      // elements for avg
      percentage: [],
      records: [],
      totalRowName: '',
      accountsNumber: 0,
      user_types: 0,
      userTypeOptions: [{
        value: 0,
        title: 'Действующие'
      }, {
        value: 1,
        title: 'Уволенные'
      }, {
        value: 2,
        title: 'Стажеры'
      }],
      userShift: 0,
      userShiftOptions: [{
        value: 0,
        title: 'Все'
      }, {
        value: 1,
        title: 'Full-Time'
      }, {
        value: 2,
        title: 'Part-Time'
      }],
      filter: {
        group1: 0,
        group2: 0,
        fulltime: 0,
        parttime: 0
      },
      plan_units: {
        // activity
        minutes: 'Сумма показателей',
        percent: 'Среднее значение',
        less_sum: 'Не более, сумма',
        less_avg: 'Не более, сред. зн.'
      },
      showEditModal: false,
      showExcelImport: false,
      tenant: location.hostname.split('.')[0],
      isFilters: false,
      isControls: false,
      showHideUsersOverlay: false,
      activityUsersToShowForm: []
    };
  },
  computed: {
    isImportable: function isImportable() {
      if (this.tenant !== 'bp') return false;
      return this.group_id == 42 || this.group_id == 88 || this.group_id == 71 && this.activity.id == 149 || this.group_id == 71 && this.activity.id == 151 || this.group_id == 136 && this.activity.id == 293 || this.group_id == 136 && this.activity.id == 295;
    },
    accessDictionaries: function accessDictionaries() {
      return {
        users: this.activity.records.reduce(function (result, user) {
          if (!user.email) return result;
          result.push({
            id: user.id,
            name: user.fullname,
            position: ''
          });
          return result;
        }, []),
        profile_groups: [],
        positions: []
      };
    },
    usersToHide: function usersToHide() {
      var _this = this;
      return this.accessDictionaries.users.filter(function (user) {
        var isShowed = _this.activityUsersToShowForm.find(function (u) {
          return u.id === user.id;
        });
        return !isShowed;
      });
    }
  },
  watch: {
    activity: function activity() {
      this.fetchData();
    },
    filter: {
      handler: function handler() {
        this.filterTable();
      },
      deep: true
    }
    // user_types() {
    // 	this.fetchData()
    // },
  },
  created: function created() {
    this.getWeekends();
    this.fetchData();
    this.local_activity = this.activity;
  },
  methods: {
    getWeekends: function getWeekends() {
      var d = new Date(this.month.currentYear + '-' + this.month.month + '-01');
      for (var i = 1; i <= this.month.daysInMonth; i++) {
        var newDate = new Date(d.getFullYear(), d.getMonth(), i);
        if (newDate.getDay() == 0) {
          //if Sunday
          this.holidays.push(i);
        }
        if (newDate.getDay() == 6) {
          //if Saturday
          this.holidays.push(i);
        }
      }
    },
    setFirstRowAsTotals: function setFirstRowAsTotals() {
      this.totalRowName = 'Итого';
      this.records.unshift({
        is_date: false,
        name: this.totalRowName
      });
    },
    addCellVariantsArrayToRecords: function addCellVariantsArrayToRecords() {
      var _this2 = this;
      this.itemsArray.forEach(function (element, key) {
        _this2.itemsArray[key]['_cellVariants'] = [];
      });
    },
    updateAvgValuesOfRecords: function updateAvgValuesOfRecords() {
      var _this3 = this;
      this.itemsArray.forEach(function (account, index) {
        _this3.itemsArray[index]['plan'] = account.plan;
        if (_this3.activity.plan_unit == 'minutes') {
          _this3.itemsArray[index]['avg'] = account.avg;
          _this3.itemsArray[index]['month'] = account.month;
        }
      });
    },
    setLeaders: function setLeaders() {
      var arr = this.filtered;
      if (arr > 4) {
        arr[1].show_cup = 1;
        arr[2].show_cup = 2;
        arr[3].show_cup = 3;
      }
    },
    fetchData: function fetchData() {
      var _this4 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var loader;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                loader = _this4.$loading.show();
                _this4.activityUsersToShowForm = _this4.accessDictionaries.users.reduce(function (result, user) {
                  var isHidden = _this4.hiddenUsers.find(function (id) {
                    return id === user.id;
                  });
                  if (!isHidden) result.push(_objectSpread({
                    type: 1
                  }, user));
                  return result;
                }, []);
                _this4.records = _this4.activity.records || [];
                _this4.accountsNumber = (_this4.activity.records || []).length;
                if (_this4.show_headers) _this4.setFirstRowAsTotals();
                _this4.calculateRecordsValues();
                if (_this4.show_headers) _this4.calculateTotalsRow();
                _this4.setLeaders();
                _this4.items = _this4.itemsArray;
                _this4.filtered = _this4.itemsArray;
                _this4.addCellVariantsArrayToRecords();
                _this4.setCellVariants();
                _this4.addButtonToFirstItem();
                loader.hide();
              case 14:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    switchAction: function switchAction() {
      var _this5 = this;
      if (this.items.length == 0) return;
      if (this.currentAction == 'avg') {
        this.currentAction = 'sum';
        Object.keys(this.sum).forEach(function (key) {
          _this5.items[0][key] = parseFloat(_this5.sum[key]) === parseInt(_this5.sum[key]) ? parseInt(_this5.sum[key]) : parseFloat(_this5.sum[key]).toFixed(2);
        });
      } else if (this.currentAction == 'sum') {
        this.currentAction = 'avg';
        Object.keys(this.sum).forEach(function (key) {
          _this5.items[0][key] = _this5.percentage[key] > 0 ? Number(_this5.sum[key] / _this5.percentage[key]).toFixed(2) : 0;
        });
      }
      this.filterTable();
    },
    addButtonToFirstItem: function addButtonToFirstItem() {
      if (this.itemsArray.length == 0) return;
      this.itemsArray[0].name = 'SPECIAL_BTN';
    },
    updateTable: function updateTable(items) {
      var loader = this.$loading.show();
      this.records = items;
      this.calculateRecordsValues();
      if (this.show_headers) this.calculateTotalsRow();
      this.updateAvgValuesOfRecords();
      this.items = this.itemsArray;
      this.addCellVariantsArrayToRecords();
      this.setCellVariants();
      loader.hide();
    },
    setAvgCell: function setAvgCell() {},
    filterTable: function filterTable() {
      var _this6 = this;
      this.filtered = this.items.filter(function (el) {
        var a = true;
        var b = false;
        var pass_b = true;
        var c = false;
        var pass_c = true;
        if (_this6.filter.group1 == 1) {
          b = b || el.group == 'Напоминание';
          pass_b = false;
        }
        if (_this6.filter.group2 == 1) {
          b = b || el.group == 'Просрочники';
          pass_b = false;
        }
        if (!pass_b) a = a && b;
        if (_this6.filter.fulltime == 1) {
          c = c || el.full_time == 1;
          pass_c = false;
        }
        if (_this6.filter.parttime == 1) {
          c = c || el.full_time == 0;
          pass_c = false;
        }
        if (!pass_c) a = a && c;
        return a;
      });
    },
    calculateTotalsRow: function calculateTotalsRow() {
      // вот здесь я считаю итоговые суммы минут по всем сотрудникам, и мне их видимо придется сохранить в бд

      var total = 0;
      // let quantity = 0;

      for (var key in this.sum) {
        if (this.sum.hasOwnProperty(key)) {
          var sum = isNaN(parseFloat(this.sum[key])) ? 0 : parseFloat(this.sum[key]);
          var percentage = isNaN(parseFloat(this.percentage[key])) ? 0 : parseFloat(this.percentage[key]);
          if (this.activity.plan_unit == 'minutes') {
            this.itemsArray[0][key] = parseFloat(sum).toFixed(0);
            if (sum != 0) {
              total += sum;
              // quantity++;
            }
          } else {
            this.itemsArray[0][key] = parseFloat(sum / percentage).toFixed(1);
            if (percentage != 0 && sum != 0) {
              total += parseFloat(sum / percentage);
              // quantity++;
            }
          }
        } else {
          this.itemsArray[0][key] = 0;
        }
      }
      if (this.activity.plan_unit == 'minutes') {
        this.itemsArray[0]['plan'] = Number(total).toFixed(0);
      }
      if (this.activity.plan_unit == 'less_sum') {
        this.itemsArray[0]['plan'] = Number(total).toFixed(0);
      }
    },
    setCellVariants: function setCellVariants() {
      var _this7 = this;
      if (_typeof(this.activity) === 'object') {
        var minutes = this.filtered;
        if (this.activity.plan_unit != 'less_sum') {
          minutes.forEach(function (account, index) {
            if (index > 0 || !_this7.show_headers) {
              for (var key in account) {
                if (_this7.activity.plan_unit != 'less_avg') {
                  if (key >= 1 && key <= 31 && account[key] !== undefined && account[key] !== null) {
                    if (account[key] >= _this7.activity.daily_plan) {
                      _this7.filtered[index]._cellVariants[key] = 'success';
                    } else {
                      _this7.filtered[index]._cellVariants[key] = 'danger';
                    }
                  }
                } else {
                  if (key >= 1 && key <= 31 && account[key] !== undefined && account[key] !== null) {
                    if (account[key] > _this7.activity.daily_plan) {
                      _this7.filtered[index]._cellVariants[key] = 'danger';
                    } else {
                      _this7.filtered[index]._cellVariants[key] = 'success';
                    }
                  }
                }
              }
            }
          });
        }
      }
    },
    editMode: function editMode(item) {
      this.filtered.forEach(function (account) {
        account.editable = false;
      });
      item.editable = item.name == 'Итого' ? false : true;
    },
    viewMode: function viewMode(item) {
      item.editable = false;
    },
    updateSettings: function updateSettings(e, data, index, key) {
      data.editable = false;
      var clearedValue = e.target.value.replace(',', '.');
      var value = null;
      if (this.activity.plan_unit == 'minutes') value = parseFloat(clearedValue);
      if (this.activity.plan_unit == 'less_sum') value = parseFloat(clearedValue);
      if (this.activity.plan_unit == 'percent') value = parseFloat(clearedValue).toFixed(1);
      if (this.activity.plan_unit == 'less_avg') value = parseFloat(clearedValue).toFixed(1);
      if (value < 0) this.filtered[index][key] = 0;
      if (value > 999) this.filtered[index][key] = 999;
      this.filtered[index][key] = Number(this.filtered[index][key]);
      var employee_id = data.id;
      var filtered = this.filtered;
      var loader = this.$loading.show();
      // let yesar = new Date().getFullYear();

      this.updateTable(filtered);
      this.axios.post('/timetracking/analytics/update-stat', {
        month: this.month.month,
        year: this.month.currentYear,
        group_id: this.activity.group_id,
        employee_id: employee_id,
        id: this.activity.id,
        day: key,
        value: '' + (value || 0)
      }).then(function () {
        loader.hide();
      });
    },
    exportData: function exportData() {
      this.isControls = false;
      var link = '/timetracking/analytics/activity/exportxx';
      link += '?month=' + this.$moment("".concat(this.month.currentMonth), 'MMMM YYYY').format('MM');
      link += '&year=' + new Date().getFullYear();
      link += '&group_id=' + this.activity.group_id;
      if (this.filter.group1 == 1 && this.filter.group2 == 0) link += '&only_nap=1';
      if (this.filter.group1 == 0 && this.filter.group2 == 1) link += '&only_pros=1';
      if (this.filter.fulltime == 1 && this.filter.parttime == 0) link += '&only_full=1';
      if (this.filter.fulltime == 0 && this.filter.parttime == 1) link += '&only_part=1';
      window.location.href = link;
    },
    calculateRecordsValues: function calculateRecordsValues() {
      var _this8 = this;
      this.sum = {};
      if (this.show_headers) {
        this.itemsArray = [{
          'plan': '',
          'avg': ''
        }];
      } else {
        this.itemsArray = [];
      }
      this.totalCountDays = 0;
      this.avgOfAverage = 0;
      this.percentage = [];

      // let row0_avg = 0;
      // let row0_avg_items = 0;

      var avg_of_column = 0;
      var quan_of_column = 0;
      this.records.forEach(function (account) {
        if (_this8.hiddenUsers.includes(account.id)) return;
        var countWorkedDays = 0;
        var cellValues = [];
        if (account.name != _this8.totalRowName) {
          var sumForOne = 0;
          for (var key in account) {
            var value = account[key];
            if (key >= 1 && key <= 31) {
              cellValues[key] = Number(value);
              if (isNaN(_this8.sum[key])) _this8.sum[key] = 0;
              if (isNaN(_this8.percentage[key])) _this8.percentage[key] = 0;
              _this8.sum[key] = _this8.sum[key] + (Number(account[key]) || 0); // vertical sum

              if (Number(account[key]) > 0) {
                _this8.percentage[key] = _this8.percentage[key] + 1;
                sumForOne += Number(account[key]) || 0; // horizontal sum
                countWorkedDays++;
                _this8.totalCountDays++;
              }
            }
          }
          cellValues['plan_unit'] = _this8.activity.plan_unit;
          var daily_plan = Number(_this8.activity.daily_plan);
          if (_this8.activity.plan_unit == 'minutes') {
            if (!account.fullTime) daily_plan = Number(daily_plan / 2);
            cellValues['plan'] = sumForOne;
            var average = (sumForOne / countWorkedDays).toFixed(2);
            var finishAverage = !isNaN(average) ? average : 0;
            cellValues['avg'] = finishAverage;
            if (finishAverage != 0) {
              quan_of_column++;
              avg_of_column += Number(finishAverage);
            }
            var wd = Number(_this8.activity.workdays) || 0;
            cellValues['month'] = account.appliedFrom ? Number(account.appliedFrom) * daily_plan : Number(wd) * daily_plan;
            cellValues['percent'] = _this8.toFloat(Number(sumForOne) / (Number(cellValues['month']) / 100)) + '%';
            cellValues['_percent'] = Number(Number(sumForOne) / (Number(cellValues['month']) / 100));
            _this8.avgOfAverage = parseFloat(_this8.avgOfAverage) + parseFloat(finishAverage);
            cellValues['plan'] = Number(sumForOne).toFixed(2);
          }
          if (_this8.activity.plan_unit == 'percent') {
            var _average = (sumForOne / countWorkedDays).toFixed(2);
            var _finishAverage = !isNaN(_average) ? _average : 0;
            cellValues['month'] = daily_plan;
            cellValues['plan'] = _finishAverage;
            cellValues['avg'] = _finishAverage;
            if (_finishAverage != 0) {
              quan_of_column++;
              avg_of_column += Number(_finishAverage);
            }
            _this8.avgOfAverage = parseFloat(_this8.avgOfAverage) + parseFloat(_finishAverage);
          }
          if (_this8.activity.plan_unit == 'less_avg') {
            var _average2 = (sumForOne / countWorkedDays).toFixed(2);
            var _finishAverage2 = !isNaN(_average2) ? _average2 : 0;
            cellValues['month'] = daily_plan;
            cellValues['plan'] = _finishAverage2;
            _this8.avgOfAverage = parseFloat(_this8.avgOfAverage) + parseFloat(_finishAverage2);
            if (_finishAverage2 != 0) {
              quan_of_column++;
              avg_of_column += Number(_finishAverage2);
            }
          }
          if (_this8.activity.plan_unit == 'less_sum') {
            cellValues['month'] = daily_plan;
            cellValues['plan'] = Number(sumForOne).toFixed(0);
            _this8.avgOfAverage = parseFloat(_this8.avgOfAverage) + Number(sumForOne);
          }
        }
        if (_this8.user_types == 1 && account.fired == 1 && !account.isTrainee || _this8.user_types == 0 && account.fired == 0 && !account.isTrainee || _this8.user_types == 2 && account.isTrainee) {
          _this8.itemsArray.push(_objectSpread({
            name: account.name,
            lastname: account.lastname,
            fullname: account.fullname,
            id: account.id,
            editable: false,
            group: account.group,
            fired: account.fired,
            show_cup: 0,
            appliedFrom: account.appliedFrom,
            fullTime: account.fullTime,
            email: account.email
          }, cellValues));
        }
      });
      var avg = quan_of_column > 0 ? avg_of_column / quan_of_column : '';
      if (this.show_headers) {
        if (this.activity.plan_unit == 'minutes') {
          this.itemsArray[0]['avg'] = Number(avg).toFixed(0);
        } else {
          this.itemsArray[0]['plan'] = Number(avg).toFixed(2);
        }
      }
      // this.records.forEach(account => {
      // 	if(parseFloat(account['plan']) != 0 && account['plan'] != undefined) {

      // 		row0_avg += parseFloat(account['plan']);
      // 		row0_avg_items++;
      // 	}
      // })
    },
    toFloat: function toFloat(number) {
      return Number(number).toFixed(2);
    },
    editActivity: function editActivity() {
      this.isControls = false;
      this.showEditModal = true;
    },
    saveActivity: function saveActivity() {
      var _this9 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var loader;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                loader = _this9.$loading.show();
                _context2.prev = 1;
                _context2.next = 4;
                return _this9.axios.post('/timetracking/analytics/edit-activity', {
                  month: _this9.month.month,
                  year: _this9.month.currentYear,
                  activity: _this9.local_activity
                });
              case 4:
                _context2.next = 6;
                return (0,_stores_api__WEBPACK_IMPORTED_MODULE_8__.hideAnalyticsActivityUsers)({
                  group_id: _this9.group_id,
                  groups: _defineProperty({}, _this9.activity.id, _this9.usersToHide.map(function (user) {
                    return user.id;
                  }))
                });
              case 6:
                _this9.$toast.success('Обновите, чтобы посмотреть новую таблицу!');
                _context2.next = 13;
                break;
              case 9:
                _context2.prev = 9;
                _context2.t0 = _context2["catch"](1);
                _this9.$toast.error('Ошибка!');
                alert(_context2.t0);
              case 13:
                loader.hide();
              case 14:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[1, 9]]);
      }))();
    },
    sort: function sort(field) {
      if (this.sorts[field] === undefined) {
        this.sorts[field] = 'asc';
      }
      this.sortField = field;
      this.sortDir = this.sorts[field];
      var item = this.items[0];
      this.items.shift();
      if (this.sorts[field] === 'desc') {
        if (field == 'name') {
          this.items.sort(function (a, b) {
            return a[field] > b[field] ? 1 : -1;
          });
        } else {
          this.items.sort(function (a, b) {
            return Number(a[field]) > Number(b[field]) ? 1 : -1;
          });
        }
        this.sorts[field] = 'asc';
      } else {
        if (field == 'name') {
          this.items.sort(function (a, b) {
            return a[field] < b[field] ? 1 : -1;
          });
        } else {
          this.items.sort(function (a, b) {
            return Number(a[field]) < Number(b[field]) ? 1 : -1;
          });
        }
        this.sorts[field] = 'desc';
      }
      this.items.unshift(item);
    },
    onClickImport: function onClickImport() {
      this.isControls = false;
      this.showExcelImport = !this.showExcelImport;
    },
    onClickFilters: function onClickFilters() {
      this.isFilters = true;
      this.isControls = false;
    },
    onClickFiltersOutside: function onClickFiltersOutside() {
      this.isFilters = false;
    },
    onClickControls: function onClickControls() {
      this.isControls = true;
      this.isFilters = false;
    },
    onClickControlsOutside: function onClickControlsOutside() {
      this.isControls = false;
    },
    onClickFilter: function onClickFilter() {
      this.isFilters = false;
      this.fetchData();
      switch (+this.userShift) {
        case 0:
          this.filter.fulltime = 0;
          this.filter.parttime = 0;
          break;
        case 1:
          this.filter.fulltime = 1;
          this.filter.parttime = 0;
          break;
        case 2:
          this.filter.fulltime = 0;
          this.filter.parttime = 1;
          break;
      }
      this.filterTable();
    },
    onSubmitHideUsers: function onSubmitHideUsers(users) {
      var _this10 = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _this10.activityUsersToShowForm = users;
                _this10.showHideUsersOverlay = false;
              case 2:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

// На данный момент работает только с объектами {value, title}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'JobtronSelect',
  components: {},
  props: {
    value: {
      required: true,
      validator: function validator(v) {
        return typeof v !== 'undefined';
      }
    },
    options: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    compact: {
      type: Boolean,
      "default": false
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".my-table.m2 tr .badge {\n  opacity: 1;\n}\n.day-minute {\n  padding: 0 10px !important;\n  text-align: center;\n  vertical-align: middle;\n}\n.day-minute div {\n  font-size: 0.8rem;\n}\n.day-minute.table-success {\n  background-color: #01c601 !important;\n}\n.day-minute.table-danger {\n  background-color: #ff7669 !important;\n}\n.inverted .day-minute.table-success {\n  background-color: #ff7669 !important;\n}\n.inverted .day-minute.table-danger {\n  background-color: #01c601 !important;\n}\n.table td,\n.table th,\n.table thead th {\n  vertical-align: middle;\n  min-width: 42px;\n  text-align: center;\n}\n.table.b-table.table-sm > thead > tr > [aria-sort]:not(.b-table-sort-icon-left),\n.table.b-table.table-sm > tfoot > tr > [aria-sort]:not(.b-table-sort-icon-left) {\n  background-image: none !important;\n  min-width: 32px;\n}\n.table .stat {\n  background-color: #d9edff;\n  border: 1px solid #bbd3e9 !important;\n}\n.table {\n  position: relative;\n}\n.b-table-sticky-column {\n  position: sticky;\n  left: 0;\n  z-index: 2;\n}\n.wd {\n  font-size: 0.75rem;\n  width: -moz-max-content;\n  width: max-content;\n  font-weight: 500;\n}\n.table .stat.plan {\n  background-color: #779bbb;\n  color: #fff;\n}\n.cell-input {\n  background: none;\n  border: none;\n  text-align: center;\n  -moz-appearance: textfield;\n  font-size: 0.8rem;\n  font-weight: normal;\n  padding: 0;\n  color: #000;\n  border-radius: 0;\n}\n.cell-input:focus {\n  outline: none;\n}\n.cell-input::-webkit-outer-spin-button, .cell-input::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n.text-white {\n  color: #fff;\n}\n.table-primary, .table-primary > td, .table-primary > th {\n  background-color: #dddfe5;\n}\n.mywarning {\n  background-color: #f7f2a6;\n}\n.TableActivityNew {\n  min-height: 300px;\n}\n.TableActivityNew-contlors {\n  position: relative;\n}\n.TableActivityNew-filters {\n  position: relative;\n}\n.TableActivityNew-filtersPopup {\n  width: 250px;\n  padding: 10px;\n}\n.TableActivityNew-filtersIcon {\n  width: 14px;\n  filter: invert(27%) sepia(73%) saturate(2928%) hue-rotate(209deg) brightness(96%) contrast(89%);\n}\n.TableActivityNew-data {\n  width: 42px !important;\n  max-width: 42px !important;\n  padding: 0 !important;\n}\n.TableActivityNew-data .cell-input {\n  width: 42px !important;\n  border: none !important;\n  background-color: transparent !important;\n}\n.TableActivityNew-data .cell-input:focus {\n  border: none !important;\n  background-color: transparent !important;\n  box-shadow: none !important;\n}\n.TableActivityNew-toHide {\n  display: flex;\n  flex-flow: row wrap;\n  align-items: center;\n  justify-content: flex-start;\n  gap: 5px;\n  min-height: 35px;\n  padding: 0 20px;\n  border: 1px solid #e8e8e8;\n  border-radius: 6px;\n  font-size: 14px;\n  line-height: 1.3;\n  background-color: #F7FAFC;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".JobtronSelect {\n  position: relative;\n}\n.JobtronSelect-select {\n  display: block;\n  width: 100%;\n  padding: 15px 30px 15px 20px;\n  border: 0;\n  outline: 0;\n  -webkit-appearance: none;\n  -moz-appearance: none;\n  appearance: none;\n  font-family: \"Inter\", sans-serif;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 14px;\n  line-height: 20px;\n  color: #8DA0C1;\n  background-color: #F7FAFC;\n  border-radius: 6px;\n  cursor: pointer;\n}\n.JobtronSelect-clear {\n  width: 25px;\n  height: 25px;\n  position: absolute;\n  right: 18px;\n  top: 14px;\n  background: transparent;\n  cursor: pointer;\n}\n.JobtronSelect_selected .JobtronSelect:after {\n  content: url(\"/icon/news/birthday/close.svg\");\n}\n.JobtronSelect:after {\n  content: url(\"/icon/news/inputs/select-arrow.svg\");\n  display: block;\n  margin-top: -10px;\n  pointer-events: none;\n  position: absolute;\n  z-index: 1;\n  top: 50%;\n  right: 1.5rem;\n}\n.JobtronSelect_compact .JobtronSelect-select {\n  padding: 5px 15px 5px 10px;\n  line-height: 18px;\n}\n.JobtronSelect_compact:after {\n  right: 0.5rem;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityNew_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableActivityNew.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityNew_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityNew_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Select_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Select.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Select_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Select_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/components/tables/TableActivityNew.vue":
/*!*************************************************************!*\
  !*** ./resources/js/components/tables/TableActivityNew.vue ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _TableActivityNew_vue_vue_type_template_id_2b8ad6f2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TableActivityNew.vue?vue&type=template&id=2b8ad6f2& */ "./resources/js/components/tables/TableActivityNew.vue?vue&type=template&id=2b8ad6f2&");
/* harmony import */ var _TableActivityNew_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TableActivityNew.vue?vue&type=script&lang=js& */ "./resources/js/components/tables/TableActivityNew.vue?vue&type=script&lang=js&");
/* harmony import */ var _TableActivityNew_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TableActivityNew.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/tables/TableActivityNew.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TableActivityNew_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TableActivityNew_vue_vue_type_template_id_2b8ad6f2___WEBPACK_IMPORTED_MODULE_0__.render,
  _TableActivityNew_vue_vue_type_template_id_2b8ad6f2___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/tables/TableActivityNew.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/ui/Select.vue":
/*!***********************************************!*\
  !*** ./resources/js/components/ui/Select.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Select_vue_vue_type_template_id_dc156888___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Select.vue?vue&type=template&id=dc156888& */ "./resources/js/components/ui/Select.vue?vue&type=template&id=dc156888&");
/* harmony import */ var _Select_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Select.vue?vue&type=script&lang=js& */ "./resources/js/components/ui/Select.vue?vue&type=script&lang=js&");
/* harmony import */ var _Select_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Select.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/components/ui/Select.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Select_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Select_vue_vue_type_template_id_dc156888___WEBPACK_IMPORTED_MODULE_0__.render,
  _Select_vue_vue_type_template_id_dc156888___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/ui/Select.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/tables/TableActivityNew.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/tables/TableActivityNew.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityNew_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableActivityNew.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityNew_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/ui/Select.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/components/ui/Select.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Select_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Select.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Select_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/tables/TableActivityNew.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/components/tables/TableActivityNew.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityNew_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableActivityNew.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/ui/Select.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************!*\
  !*** ./resources/js/components/ui/Select.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Select_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Select.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/components/tables/TableActivityNew.vue?vue&type=template&id=2b8ad6f2&":
/*!********************************************************************************************!*\
  !*** ./resources/js/components/tables/TableActivityNew.vue?vue&type=template&id=2b8ad6f2& ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityNew_vue_vue_type_template_id_2b8ad6f2___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityNew_vue_vue_type_template_id_2b8ad6f2___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TableActivityNew_vue_vue_type_template_id_2b8ad6f2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./TableActivityNew.vue?vue&type=template&id=2b8ad6f2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=template&id=2b8ad6f2&");


/***/ }),

/***/ "./resources/js/components/ui/Select.vue?vue&type=template&id=dc156888&":
/*!******************************************************************************!*\
  !*** ./resources/js/components/ui/Select.vue?vue&type=template&id=dc156888& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Select_vue_vue_type_template_id_dc156888___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Select_vue_vue_type_template_id_dc156888___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Select_vue_vue_type_template_id_dc156888___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Select.vue?vue&type=template&id=dc156888& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=template&id=dc156888&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=template&id=2b8ad6f2&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/tables/TableActivityNew.vue?vue&type=template&id=2b8ad6f2& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "TableActivityNew mb-3" },
    [
      _vm.show_headers
        ? _c(
            "div",
            {
              staticClass: "d-flex align-items-center justify-content-end mb-2",
            },
            [
              _c(
                "div",
                {
                  directives: [
                    {
                      name: "click-outside",
                      rawName: "v-click-outside",
                      value: _vm.onClickFiltersOutside,
                      expression: "onClickFiltersOutside",
                    },
                  ],
                  staticClass: "TableActivityNew-filters ml-3",
                },
                [
                  _c(
                    "JobtronButton",
                    {
                      staticClass: "ChatIcon-parent",
                      attrs: { fade: "", small: "" },
                      on: { click: _vm.onClickFilters },
                    },
                    [
                      _c("img", {
                        staticClass: "TableActivityNew-filtersIcon",
                        attrs: {
                          src: "/icon/news/filter/filter.svg",
                          alt: "filters",
                        },
                      }),
                    ]
                  ),
                  _vm._v(" "),
                  _vm.isFilters
                    ? _c(
                        "PopupMenu",
                        { staticClass: "TableActivityNew-filtersPopup" },
                        [
                          _c("JobtronSelect", {
                            staticClass: "mb-3",
                            attrs: {
                              options: _vm.userTypeOptions,
                              compact: "",
                            },
                            model: {
                              value: _vm.user_types,
                              callback: function ($$v) {
                                _vm.user_types = $$v
                              },
                              expression: "user_types",
                            },
                          }),
                          _vm._v(" "),
                          _c("JobtronSelect", {
                            staticClass: "mb-3",
                            attrs: {
                              options: _vm.userShiftOptions,
                              compact: "",
                            },
                            model: {
                              value: _vm.userShift,
                              callback: function ($$v) {
                                _vm.userShift = $$v
                              },
                              expression: "userShift",
                            },
                          }),
                          _vm._v(" "),
                          _c(
                            "JobtronButton",
                            {
                              attrs: { small: "" },
                              on: { click: _vm.onClickFilter },
                            },
                            [_vm._v("\n\t\t\t\t\tНайти\n\t\t\t\t")]
                          ),
                        ],
                        1
                      )
                    : _vm._e(),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "div",
                {
                  directives: [
                    {
                      name: "click-outside",
                      rawName: "v-click-outside",
                      value: _vm.onClickControlsOutside,
                      expression: "onClickControlsOutside",
                    },
                  ],
                  staticClass: "TableActivityNew-contlors ml-3",
                },
                [
                  _c(
                    "JobtronButton",
                    {
                      staticClass: "ChatIcon-parent",
                      attrs: { fade: "", small: "" },
                      on: { click: _vm.onClickControls },
                    },
                    [
                      _c("i", {
                        staticClass: "fa fa-bars",
                        staticStyle: { "font-size": "14px" },
                      }),
                    ]
                  ),
                  _vm._v(" "),
                  _vm.isControls
                    ? _c("PopupMenu", [
                        _c(
                          "div",
                          {
                            staticClass: "PopupMenu-item wsnw",
                            on: {
                              click: function ($event) {
                                return _vm.editActivity()
                              },
                            },
                          },
                          [
                            _c("i", { staticClass: "icon-nd-settings" }),
                            _vm._v("\n\t\t\t\t\tНастройка таблицы\n\t\t\t\t"),
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          {
                            staticClass: "PopupMenu-item wsnw",
                            on: {
                              click: function ($event) {
                                return _vm.exportData()
                              },
                            },
                          },
                          [
                            _c("i", { staticClass: "far fa-file-excel" }),
                            _vm._v("\n\t\t\t\t\tЭкспорт\n\t\t\t\t"),
                          ]
                        ),
                        _vm._v(" "),
                        _vm.isImportable
                          ? _c(
                              "div",
                              {
                                staticClass: "PopupMenu-item wsnw",
                                on: { click: _vm.onClickImport },
                              },
                              [
                                _c("i", { staticClass: "fa fa-upload" }),
                                _vm._v("\n\t\t\t\t\tИмпорт\n\t\t\t\t"),
                              ]
                            )
                          : _vm._e(),
                      ])
                    : _vm._e(),
                ],
                1
              ),
            ]
          )
        : _vm._e(),
      _vm._v(" "),
      _c("div", { staticClass: "table-container whitespace-no-wrap" }, [
        _c(
          "table",
          {
            staticClass: "table b-table table-bordered table-responsive",
            class: { inverted: _vm.color_invert },
          },
          [
            _c("thead", [
              _c(
                "tr",
                [
                  _c(
                    "th",
                    {
                      staticClass:
                        "b-table-sticky-column text-left px-1 t-name bg-white",
                    },
                    [
                      _c("div", { staticClass: "wd" }, [
                        _vm._v("\n\t\t\t\t\t\t\tСотрудник  "),
                        _vm.show_headers
                          ? _c("i", {
                              staticClass: "fa fa-sort ml-2",
                              on: {
                                click: function ($event) {
                                  return _vm.sort("fullname")
                                },
                              },
                            })
                          : _vm._e(),
                      ]),
                    ]
                  ),
                  _vm._v(" "),
                  _vm.activity.plan_unit == "minutes"
                    ? [
                        _c(
                          "th",
                          { staticClass: "text-center px-1 day-minute" },
                          [
                            _vm._v("\n\t\t\t\t\t\t\tСр.\n\t\t\t\t\t\t\t"),
                            _vm.show_headers
                              ? _c("i", {
                                  staticClass: "fa fa-sort ml-2",
                                  on: {
                                    click: function ($event) {
                                      return _vm.sort("avg")
                                    },
                                  },
                                })
                              : _vm._e(),
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "th",
                          { staticClass: "text-center px-1 day-minute" },
                          [
                            _vm._v("\n\t\t\t\t\t\t\tПлан\n\t\t\t\t\t\t\t"),
                            _vm.show_headers
                              ? _c("i", {
                                  staticClass: "fa fa-sort ml-2",
                                  on: {
                                    click: function ($event) {
                                      return _vm.sort("month")
                                    },
                                  },
                                })
                              : _vm._e(),
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "th",
                          { staticClass: "text-center px-1 day-minute plan" },
                          [
                            _vm._v("\n\t\t\t\t\t\t\tВып.\n\t\t\t\t\t\t\t"),
                            _vm.show_headers
                              ? _c("i", {
                                  staticClass: "fa fa-sort ml-2",
                                  on: {
                                    click: function ($event) {
                                      return _vm.sort("plan")
                                    },
                                  },
                                })
                              : _vm._e(),
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "th",
                          { staticClass: "text-center px-1 day-minute" },
                          [
                            _vm._v("\n\t\t\t\t\t\t\t%\n\t\t\t\t\t\t\t"),
                            _vm.show_headers
                              ? _c("i", {
                                  staticClass: "fa fa-sort ml-2",
                                  on: {
                                    click: function ($event) {
                                      return _vm.sort("_percent")
                                    },
                                  },
                                })
                              : _vm._e(),
                          ]
                        ),
                      ]
                    : [
                        _c(
                          "th",
                          { staticClass: "text-center px-1 day-minute" },
                          [
                            _vm._v("\n\t\t\t\t\t\t\tПлан\n\t\t\t\t\t\t\t"),
                            _vm.show_headers
                              ? _c("i", {
                                  staticClass: "fa fa-sort ml-2",
                                  on: {
                                    click: function ($event) {
                                      return _vm.sort("month")
                                    },
                                  },
                                })
                              : _vm._e(),
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "th",
                          { staticClass: "text-center px-1 day-minute" },
                          [
                            _vm._v("\n\t\t\t\t\t\t\tВып.\n\t\t\t\t\t\t\t"),
                            _vm.show_headers
                              ? _c("i", {
                                  staticClass: "fa fa-sort ml-2",
                                  on: {
                                    click: function ($event) {
                                      return _vm.sort("plan")
                                    },
                                  },
                                })
                              : _vm._e(),
                          ]
                        ),
                      ],
                  _vm._v(" "),
                  _vm._l(_vm.month.daysInMonth, function (day) {
                    return _c(
                      "th",
                      { key: day, staticClass: "text-center px-1" },
                      [_vm._v("\n\t\t\t\t\t\t" + _vm._s(day) + "\n\t\t\t\t\t")]
                    )
                  }),
                ],
                2
              ),
            ]),
            _vm._v(" "),
            _c(
              "tbody",
              _vm._l(_vm.filtered, function (item, index) {
                return _c(
                  "tr",
                  { key: index },
                  [
                    item.name == "SPECIAL_BTN"
                      ? _c(
                          "td",
                          { staticClass: "b-table-sticky-column text-left" },
                          [
                            _c(
                              "button",
                              {
                                staticClass: "btn btn-light rounded btn-sm",
                                on: { click: _vm.switchAction },
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\tСумма\\Среднее\n\t\t\t\t\t\t"
                                ),
                              ]
                            ),
                          ]
                        )
                      : _c(
                          "td",
                          {
                            staticClass:
                              "table-primary b-table-sticky-column text-left px-2 t-name",
                            attrs: { title: item.id + " " + item.email },
                          },
                          [
                            _c(
                              "div",
                              { staticClass: "wd d-flex" },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t" +
                                    _vm._s(item.lastname) +
                                    " " +
                                    _vm._s(item.name) +
                                    "\n\t\t\t\t\t\t\t"
                                ),
                                item.group
                                  ? _c(
                                      "b-badge",
                                      {
                                        attrs: {
                                          variant:
                                            item.group == "Просрочники"
                                              ? "success"
                                              : "primary",
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t" +
                                            _vm._s(item.group) +
                                            "\n\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _c("JobtronCup", {
                                  attrs: {
                                    place:
                                      _vm.sortDir === "asc"
                                        ? index
                                        : _vm.filtered.length - index,
                                    rotate: "",
                                  },
                                }),
                              ],
                              1
                            ),
                          ]
                        ),
                    _vm._v(" "),
                    _vm.activity.plan_unit == "minutes"
                      ? [
                          _c("td", { staticClass: "px-2 stat da" }, [
                            _c("div", [_vm._v(_vm._s(item.avg))]),
                          ]),
                          _vm._v(" "),
                          _c("td", { staticClass: "px-2 stat da" }, [
                            _c(
                              "div",
                              {
                                attrs: {
                                  title:
                                    _vm.activity.daily_plan +
                                    " * " +
                                    item.appliedFrom,
                                },
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t\t" +
                                    _vm._s(item.month) +
                                    "\n\t\t\t\t\t\t\t"
                                ),
                              ]
                            ),
                          ]),
                          _vm._v(" "),
                          _c("td", { staticClass: "px-2 stat da plan" }, [
                            _c("div", [_vm._v(_vm._s(item.plan))]),
                          ]),
                          _vm._v(" "),
                          _c("td", { staticClass: "px-2 stat da" }, [
                            _c("div", [_vm._v(_vm._s(item.percent))]),
                          ]),
                        ]
                      : [
                          _c("td", { staticClass: "px-2 stat day-minute " }, [
                            _c("div", [_vm._v(_vm._s(item.month))]),
                          ]),
                          _vm._v(" "),
                          _c("td", { staticClass: "px-2 stat day-minute" }, [
                            _c("div", [_vm._v(_vm._s(item.plan))]),
                          ]),
                        ],
                    _vm._v(" "),
                    _vm._l(_vm.month.daysInMonth, function (day) {
                      return [
                        item.editable && _vm.editable
                          ? _c(
                              "td",
                              {
                                key: day,
                                staticClass:
                                  "TableActivityNew-data px-0 day-minute text-center Fri",
                                class: "table-" + item._cellVariants[day],
                              },
                              [
                                _c("div", [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: item[day],
                                        expression: "item[day]",
                                      },
                                    ],
                                    staticClass: "form-control cell-input",
                                    attrs: { type: "number" },
                                    domProps: { value: item[day] },
                                    on: {
                                      change: function ($event) {
                                        return _vm.updateSettings(
                                          $event,
                                          item,
                                          index,
                                          day
                                        )
                                      },
                                      focusout: function ($event) {
                                        return _vm.viewMode(item)
                                      },
                                      input: function ($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(item, day, $event.target.value)
                                      },
                                    },
                                  }),
                                ]),
                              ]
                            )
                          : _vm.holidays.includes(day) && item[day] > 0
                          ? _c(
                              "td",
                              {
                                key: day + "a",
                                staticClass:
                                  "TableActivityNew-data px-0 day-minute text-center Fri",
                                class: "table-" + item._cellVariants[day],
                                on: {
                                  click: function ($event) {
                                    return _vm.editMode(item)
                                  },
                                },
                              },
                              [
                                item[day]
                                  ? _c("div", [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t" +
                                          _vm._s(item[day]) +
                                          _vm._s(_vm.activity.unit) +
                                          "\n\t\t\t\t\t\t\t"
                                      ),
                                    ])
                                  : _vm._e(),
                              ]
                            )
                          : _vm.holidays.includes(day)
                          ? _c(
                              "td",
                              {
                                key: day + "b",
                                staticClass:
                                  "TableActivityNew-data day-minute text-center Fri mywarning",
                                on: {
                                  click: function ($event) {
                                    return _vm.editMode(item)
                                  },
                                },
                              },
                              [
                                item[day]
                                  ? _c("div", [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t" +
                                          _vm._s(item[day]) +
                                          _vm._s(_vm.activity.unit) +
                                          "\n\t\t\t\t\t\t\t"
                                      ),
                                    ])
                                  : _vm._e(),
                              ]
                            )
                          : _c(
                              "td",
                              {
                                key: day + "c",
                                staticClass:
                                  "TableActivityNew-data px-0 day-minute text-center Fri",
                                class: [
                                  item[day] > 0 || _vm.holidays.includes(day)
                                    ? " table-" + item._cellVariants[day]
                                    : "table-text-center",
                                ],
                                on: {
                                  click: function ($event) {
                                    return _vm.editMode(item)
                                  },
                                },
                              },
                              [
                                item[day]
                                  ? _c("div", [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t" +
                                          _vm._s(item[day]) +
                                          _vm._s(_vm.activity.unit) +
                                          "\n\t\t\t\t\t\t\t"
                                      ),
                                    ])
                                  : _vm._e(),
                              ]
                            ),
                      ]
                    }),
                  ],
                  2
                )
              }),
              0
            ),
          ]
        ),
      ]),
      _vm._v(" "),
      _vm.showExcelImport
        ? _c(
            "Sidebar",
            {
              attrs: {
                open: _vm.showExcelImport,
                title: "Импорт EXCEL",
                width: "75%",
              },
              on: {
                close: function ($event) {
                  _vm.showExcelImport = false
                },
              },
            },
            [
              _c("ActivityExcelImport", {
                attrs: {
                  group_id: _vm.group_id,
                  table: "minutes",
                  activity_id: _vm.activity.id,
                },
                on: {
                  close: function ($event) {
                    _vm.showExcelImport = false
                  },
                },
              }),
            ],
            1
          )
        : _vm._e(),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          staticClass: "modalle",
          attrs: {
            title: "Настройки активности",
            size: "lg",
            "no-enforce-focus": "",
          },
          on: {
            ok: function ($event) {
              return _vm.saveActivity()
            },
          },
          model: {
            value: _vm.showEditModal,
            callback: function ($$v) {
              _vm.showEditModal = $$v
            },
            expression: "showEditModal",
          },
        },
        [
          _c("div", { staticClass: "row mb-3" }, [
            _c("div", { staticClass: "col-5" }, [
              _c("p", {}, [
                _vm._v("\n\t\t\t\t\tНазвание активности\n\t\t\t\t"),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-7" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.local_activity.name,
                    expression: "local_activity.name",
                  },
                ],
                staticClass: "form-control form-control-sm",
                attrs: { type: "text" },
                domProps: { value: _vm.local_activity.name },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.local_activity, "name", $event.target.value)
                  },
                },
              }),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row mb-3" }, [
            _c("div", { staticClass: "col-5" }, [
              _c("p", {}, [_vm._v("\n\t\t\t\t\tМетод\n\t\t\t\t")]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-7" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.local_activity.plan_unit,
                      expression: "local_activity.plan_unit",
                    },
                  ],
                  staticClass: "form-control form-control-sm",
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.$set(
                        _vm.local_activity,
                        "plan_unit",
                        $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      )
                    },
                  },
                },
                _vm._l(_vm.plan_units, function (value, key) {
                  return _c("option", { key: key, domProps: { value: key } }, [
                    _vm._v("\n\t\t\t\t\t\t" + _vm._s(value) + "\n\t\t\t\t\t"),
                  ])
                }),
                0
              ),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row mb-3" }, [
            _c("div", { staticClass: "col-5" }, [
              _c("p", {}, [
                _vm._v("\n\t\t\t\t\tПлан (Если сумма, на день)\n\t\t\t\t"),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-7" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.local_activity.daily_plan,
                    expression: "local_activity.daily_plan",
                  },
                ],
                staticClass: "form-control form-control-sm",
                attrs: { type: "number" },
                domProps: { value: _vm.local_activity.daily_plan },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.local_activity,
                      "daily_plan",
                      $event.target.value
                    )
                  },
                },
              }),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row mb-3" }, [
            _c("div", { staticClass: "col-5" }, [
              _c("p", {}, [
                _vm._v("\n\t\t\t\t\tКол-во рабочих дней в неделе\n\t\t\t\t"),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-7" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.local_activity.weekdays,
                    expression: "local_activity.weekdays",
                  },
                ],
                staticClass: "form-control form-control-sm",
                attrs: { type: "number", min: "1", max: "7" },
                domProps: { value: _vm.local_activity.weekdays },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.local_activity,
                      "weekdays",
                      $event.target.value
                    )
                  },
                },
              }),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row mb-3" }, [
            _c("div", { staticClass: "col-5" }, [
              _c("p", {}, [
                _vm._v(
                  "\n\t\t\t\t\tЕд. измерения (Символ в конце показателя)\n\t\t\t\t"
                ),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-7" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.local_activity.unit,
                    expression: "local_activity.unit",
                  },
                ],
                staticClass: "form-control form-control-sm",
                attrs: { type: "text" },
                domProps: { value: _vm.local_activity.unit },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.local_activity, "unit", $event.target.value)
                  },
                },
              }),
            ]),
          ]),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "row mb-3",
              on: {
                click: function ($event) {
                  _vm.showHideUsersOverlay = true
                },
              },
            },
            [
              _c("div", { staticClass: "col-5" }, [
                _c("p", {}, [
                  _vm._v("\n\t\t\t\t\tКого не показывать в таблице\n\t\t\t\t"),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-7" }, [
                _c(
                  "div",
                  { staticClass: "TableActivityNew-toHide form-control" },
                  [
                    _vm._l(_vm.usersToHide, function (user, index) {
                      return _c("b-badge", { key: index }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(user.name) + "\n\t\t\t\t\t"
                        ),
                      ])
                    }),
                    _vm._v("\n\t\t\t\t\t \n\t\t\t\t"),
                  ],
                  2
                ),
              ]),
            ]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "row" }, [
            _c(
              "div",
              { staticClass: "col-7 offset-5 d-flex align-items-center" },
              [
                _c("div", { staticClass: "custom-control custom-checkbox" }, [
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.local_activity.editable,
                        expression: "local_activity.editable",
                      },
                    ],
                    staticClass: "custom-control-input",
                    attrs: { id: "checkbox-edit", type: "checkbox" },
                    domProps: {
                      checked: Array.isArray(_vm.local_activity.editable)
                        ? _vm._i(_vm.local_activity.editable, null) > -1
                        : _vm.local_activity.editable,
                    },
                    on: {
                      change: function ($event) {
                        var $$a = _vm.local_activity.editable,
                          $$el = $event.target,
                          $$c = $$el.checked ? true : false
                        if (Array.isArray($$a)) {
                          var $$v = null,
                            $$i = _vm._i($$a, $$v)
                          if ($$el.checked) {
                            $$i < 0 &&
                              _vm.$set(
                                _vm.local_activity,
                                "editable",
                                $$a.concat([$$v])
                              )
                          } else {
                            $$i > -1 &&
                              _vm.$set(
                                _vm.local_activity,
                                "editable",
                                $$a.slice(0, $$i).concat($$a.slice($$i + 1))
                              )
                          }
                        } else {
                          _vm.$set(_vm.local_activity, "editable", $$c)
                        }
                      },
                    },
                  }),
                  _vm._v(" "),
                  _c(
                    "label",
                    {
                      staticClass: "custom-control-label",
                      attrs: { for: "checkbox-edit" },
                    },
                    [_vm._v("\n\t\t\t\t\t\tРедактируемый\n\t\t\t\t\t")]
                  ),
                ]),
              ]
            ),
          ]),
        ]
      ),
      _vm._v(" "),
      _vm.showHideUsersOverlay
        ? _c(
            "JobtronOverlay",
            {
              attrs: { z: 10000 },
              on: {
                close: function ($event) {
                  _vm.showHideUsersOverlay = false
                },
              },
            },
            [
              _c("AccessSelect", {
                staticClass: "TableActivityNew-accessSelect",
                attrs: {
                  value: _vm.activityUsersToShowForm,
                  tabs: ["Сотрудники"],
                  "search-position": "beforeTabs",
                  "submit-button": "Сохранить",
                  "access-dictionaries": _vm.accessDictionaries,
                  absolute: "",
                },
                on: { submit: _vm.onSubmitHideUsers },
              }),
            ],
            1
          )
        : _vm._e(),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=template&id=dc156888&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/ui/Select.vue?vue&type=template&id=dc156888& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "JobtronSelect",
      class: {
        JobtronSelect_compact: _vm.compact,
      },
    },
    [
      _c(
        "select",
        {
          staticClass: "JobtronSelect-select",
          domProps: { value: _vm.value },
          on: {
            change: function ($event) {
              return _vm.$emit("input", $event.target.value)
            },
          },
        },
        _vm._l(_vm.options, function (opt) {
          return _c(
            "option",
            { key: opt.value, domProps: { value: opt.value } },
            [_vm._v("\n\t\t\t" + _vm._s(opt.title) + "\n\t\t")]
          )
        }),
        0
      ),
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);