(self["webpackChunk"] = self["webpackChunk"] || []).push([["KpiPages"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jw-vue-pagination */ "./node_modules/jw-vue-pagination/lib/JwPagination.js");
/* harmony import */ var jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pages_kpi_SuperFilter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/pages/kpi/SuperFilter */ "./resources/js/pages/kpi/SuperFilter.vue");
/* harmony import */ var _components_SuperSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/SuperSelect */ "./resources/js/components/SuperSelect.vue");
/* harmony import */ var _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/ui/Sidebar */ "./resources/js/components/ui/Sidebar.vue");
/* harmony import */ var _bonuses_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./bonuses.js */ "./resources/js/pages/kpi/bonuses.js");
/* harmony import */ var _bonuses_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_bonuses_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./helpers.js */ "./resources/js/pages/kpi/helpers.js");
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_helpers_js__WEBPACK_IMPORTED_MODULE_5__);
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */


 // filter like bitrix

 // сайдбар table



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KPIBonuses',
  components: {
    JwPagination: (jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0___default()),
    SuperFilter: _pages_kpi_SuperFilter__WEBPACK_IMPORTED_MODULE_1__["default"],
    SuperSelect: _components_SuperSelect__WEBPACK_IMPORTED_MODULE_2__["default"],
    Sidebar: _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  props: {},
  data: function data() {
    return {
      my_items: [],
      new_target: null,
      bonus: null,
      groupsArray: [],
      counter: 0,
      newBonusesArray: [],
      newBonusExpanded: false,
      addNewBonus: false,
      active: 1,
      activeItem: null,
      uri: 'bonus',
      showSidebar: false,
      show_fields: [],
      fields: [],
      all_fields: _bonuses_js__WEBPACK_IMPORTED_MODULE_4__.fields,
      groups: [],
      searchText: '',
      modalAdjustVisibleFields: false,
      page_items: [],
      pageSize: 20,
      paginationKey: 1,
      items: [],
      // after filter changes
      all_items: [],
      activities: [],
      source_key: 1,
      dayparts: {
        0: 'Полный день',
        1: 'Период'
      },
      units: {
        one: 'За каждую единицу',
        all: 'За все',
        first: 'Первый кто достигнет',
        percent: '% с продаж'
      },
      sources: _helpers_js__WEBPACK_IMPORTED_MODULE_5__.sources,
      non_editable_fields: ['created_at', 'updated_at', 'created_by', 'updated_by'],
      requestInProgress: false,
      timeout: null,
      filters: null
    };
  },
  watch: {
    show_fields: {
      handler: function handler(val) {
        localStorage.bonus_show_fields = JSON.stringify(val);
        this.prepareFields();
      },
      deep: true
    },
    pageSize: {
      handler: function handler(val) {
        if (val < 1) {
          val = 1;
          return;
        }
        if (val > 100) {
          val = 100;
          return;
        }
        this.paginationKey++;
      }
    },
    newBonusesArray: function newBonusesArray(after) {
      if (after.length == 0) {
        this.counter = 0;
        this.new_target = null;
      }
    },
    searchText: function searchText() {
      this.onSearchQuery();
    }
  },
  created: function created() {
    this.setDefaultShowFields();
    this.prepareFields();
    this.addStatusToItems();
  },
  mounted: function mounted() {
    var _this = this;
    this.fetch();
    this.$watch('$refs.child.searchText', function (new_value) {
      return _this.searchText = new_value;
    });
  },
  methods: {
    changeStatus: function changeStatus(item, e) {
      var _this2 = this;
      if (this.requestInProgress) return;
      this.requestInProgress = true;
      this.axios.post('/bonus/set/status', {
        bonus_id: item.id,
        is_active: e
      }).then(function () {
        _this2.$toast.success('Статус изменен');
        _this2.requestInProgress = false;
      })["catch"](function () {
        _this2.$toast.error('Статус не изменен');
        _this2.requestInProgress = false;
      });
    },
    onChangeUnit: function onChangeUnit(item) {
      if (item.unit === 'percent') {
        item.quantity = null;
      }
    },
    addBonusGroup: function addBonusGroup(page) {
      page.items.push((0,_bonuses_js__WEBPACK_IMPORTED_MODULE_4__.newBonus)());
      page.items[page.items.length - 1].target = {
        id: page.id,
        type: page.type
      };
    },
    saveNewBonusArray: function saveNewBonusArray() {
      var _this3 = this;
      var item = this.newBonusesArray[this.newBonusesArray.length - 1];
      item.target = this.new_target;
      /**
      	 * validate item
      	 */

      var not_validated_msg = this.validateMsg(item);
      if (not_validated_msg != '') {
        this.$toast.error(not_validated_msg);
        return;
      }

      /**
      	 * prepare fields
      	 */
      var loader = this.$loading.show();
      var method = item.id == 0 ? 'save' : 'update';
      var titles = [];
      var sums = [];
      var activity_ids = [];
      var units = [];
      var quantities = [];
      var dayparts = [];
      var froms = [];
      var tos = [];
      var texts = [];
      this.newBonusesArray.forEach(function (bonus) {
        titles.push(bonus.title);
        sums.push(bonus.sum);
        activity_ids.push(bonus.activity_id);
        units.push(bonus.unit);
        quantities.push(bonus.quantity);
        dayparts.push(bonus.daypart);
        froms.push(bonus.from);
        tos.push(bonus.to);
        texts.push(bonus.text);
      });
      var fields = _objectSpread(_objectSpread({}, item), {}, {
        targetable_id: item.target.id,
        targetable_type: (0,_helpers_js__WEBPACK_IMPORTED_MODULE_5__.findModel)(item.target.type)
      });
      var req = item.id == 0 ? this.axios.post(this.uri + '/' + method, {
        bonuses: [_objectSpread(_objectSpread({}, fields), {}, {
          targetable_type: item.target.type
        })]
      }) : this.axios.put(this.uri + '/' + method, fields);
      /**
       * request
       */
      req.then(function () {
        if (method == 'save') {
          _this3.fetch();
          // const bonus = response.data.bonus;
          // item.id = bonus.id;
          // this.items.unshift(item);

          // const i = this.all_items.findIndex(el => el.type == item.target.type && el.id == item.target.id);
          // if (i != -1) {
          // 	this.all_items[i].items.unshift(item);
          // } else {
          // 	this.all_items.unshift({
          // 		id: item.target.id,
          // 		type: item.target.type,
          // 		name: item.target.name,
          // 		items: [item],
          // 		expanded: false
          // 	});
          // }
          _this3.showSidebar = false;
        }
        _this3.$toast.info('Сохранено');
        _this3.newBonusesArray = [];
        loader.hide();
      })["catch"](function (error) {
        var m = error;
        if (error.message == 'Request failed with status code 409') {
          m = 'Выберите другую цель "Кому"';
        }
        loader.hide();
        alert(m);
      });
      return false;
    },
    addBonus: function addBonus() {
      this.newBonusesArray.unshift((0,_bonuses_js__WEBPACK_IMPORTED_MODULE_4__.newBonus)());
      this.newBonusesArray[this.newBonusArray.length - 1].bonus.target = this.new_target;
    },
    addItemRow: function addItemRow() {
      if (this.counter == 0) {
        this.newBonusesArray.push((0,_bonuses_js__WEBPACK_IMPORTED_MODULE_4__.newBonus)());
        this.bonus = this.newBonusesArray[0];
        this.counter++;
      }
      this.addNewBonus = true;
    },
    swapFields: function swapFields() {
      var temp = this.fields[4];
      var temp2 = this.fields[6];
      this.fields[6] = temp;
      this.fields[4] = temp2;
    },
    expand: function expand(i) {
      this.page_items[i].expanded = !this.page_items[i].expanded;
    },
    onChangePage: function onChangePage(page_items) {
      this.page_items = page_items;
    },
    fetch: function fetch() {
      var _this4 = this;
      var filter = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
      var loader = this.$loading.show();
      this.filters = filter;
      this.axios.post(this.uri + '/get', {
        filters: _objectSpread(_objectSpread({}, filter), {}, {
          query: this.searchText
        })
      }).then(function (response) {
        _this4.all_items = response.data.bonuses;
        _this4.items = response.data.bonuses;
        _this4.activities = response.data.activities;
        _this4.groups = response.data.groups;
        _this4.defineSourcesAndGroups('t');
        _this4.items.forEach(function (el) {
          return el.expanded = false;
        });
        _this4.page_items = _this4.items.slice(0, _this4.pageSize);
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    openSidebar: function openSidebar(p, i) {
      this.activeItem = this.page_items[p].items[i];
      this.showSidebar = true;
    },
    closeSidebar: function closeSidebar() {
      this.showSidebar = false;
      this.activeItem = null;
    },
    setDefaultShowFields: function setDefaultShowFields() {
      var obj = {}; // Какие поля показывать
      _bonuses_js__WEBPACK_IMPORTED_MODULE_4__.fields.forEach(function (field) {
        return obj[field.key] = true;
      });
      if (localStorage.bonus_show_fields) {
        this.show_fields = JSON.parse(localStorage.getItem('bonus_show_fields'));
        if (this.show_fields == null) this.show_fields = obj;
      } else {
        this.show_fields = obj;
      }
    },
    adjustFields: function adjustFields() {
      this.modalAdjustVisibleFields = true;
    },
    addStatusToItems: function addStatusToItems() {
      this.items.forEach(function (el) {
        el.on_edit = false;
        el.source = 0;
        el.group_id = 0;
        el.selected = false;
      });
    },
    prepareFields: function prepareFields() {
      var _this5 = this;
      var visible_fields = [];
      _bonuses_js__WEBPACK_IMPORTED_MODULE_4__.fields.forEach(function (field) {
        if (_this5.show_fields[field.key] != undefined && _this5.show_fields[field.key]) {
          visible_fields.push(field);
        }
      });
      this.fields = visible_fields;
      this.swapFields();
    },
    addItem: function addItem() {
      this.activeItem = (0,_bonuses_js__WEBPACK_IMPORTED_MODULE_4__.newBonus)();
      this.showSidebar = true;
    },
    validateMsg: function validateMsg(item) {
      var msg = '';
      if (item.target == null) msg = 'Выберите Кому назначить';
      if (item.title.length <= 1) msg = 'Заполните название';

      // activity id
      var a;
      if (item.source == 1) {
        a = this.activities.findIndex(function (el) {
          return el.source == item.source && el.group_id == item.group_id && el.id == item.activity_id;
        });
      } else {
        a = this.activities.findIndex(function (el) {
          return el.source == item.source && el.id == item.activity_id;
        });
      }
      if ((item.activity_id == 0 || item.activity_id == undefined || a == -1) && item.source != 0) {
        msg = 'Выберите показатель';
        return false;
      }
      // another
      if (item.quantity <= 0 && item.unit !== 'percent') msg = 'Кол-во должно быть больше нуля';
      if (item.sum <= 0) msg = 'Вознаграждение должно быть больше нуля';
      return msg;
    },
    save: function save(item, index) {
      var _this6 = this;
      /**
      	 * validate item
      	 */

      var not_validated_msg = this.validateMsg(item);
      if (not_validated_msg != '') {
        this.$toast.error(not_validated_msg);
        return;
      }

      /**
      	 * prepare fields
      	 */
      var loader = this.$loading.show();
      var method = item.id == 0 ? 'save' : 'update';
      var fields = _objectSpread(_objectSpread({}, item), {}, {
        targetable_id: item.target.id,
        targetable_type: (0,_helpers_js__WEBPACK_IMPORTED_MODULE_5__.findModel)(item.target.type)
      });
      var req = item.id == 0 ? this.axios.post(this.uri + '/' + method, {
        bonuses: [_objectSpread(_objectSpread({}, fields), {}, {
          targetable_type: item.target.type
        })]
      }) : this.axios.put(this.uri + '/' + method, fields);
      /**
       * request
       */
      req.then(function () {
        if (method == 'save') {
          _this6.fetch();
          // const bonus = response.data.bonus;
          // item.id = bonus.id;
          // // this.items.unshift(item);

          // const i = this.all_items.findIndex(el => el.type == item.target.type && el.id == item.target.id);
          // if (i != -1) {
          // 	this.all_items[i].items.unshift(item);
          // } else {
          // 	this.all_items.unshift({
          // 		id: item.target.id,
          // 		type: item.target.type,
          // 		name: item.target.name,
          // 		items: [item],
          // 		expanded: false
          // 	});
          // }
          _this6.showSidebar = false;
        } else {
          item.updated_at = _this6.$moment(Date.now()).format('DD.MM.YYYY HH:mm');
        }
        _this6.$toast.info('Сохранено');
        _this6.newBonusesArray.splice(index, 1);
        loader.hide();
      })["catch"](function (error) {
        var m = error;
        if (error.message == 'Request failed with status code 409') {
          m = 'Выберите другую цель "Кому"';
        }
        loader.hide();
        alert(m);
      });
      return false;
    },
    deletee: function deletee(id, p, i) {
      var _this7 = this;
      var loader = this.$loading.show();
      this.axios["delete"](this.uri + '/delete/' + id).then(function () {
        _this7.deleteEvery(id, p, i);
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    deleteEvery: function deleteEvery(id, p, i) {
      // let a = this.all_items.findIndex(el => el.id == id)
      // if(a != -1) this.all_items.splice(a, 1);
      this.all_items[p].items.splice(i, 1);
      if (this.all_items[p].items.length == 0) this.all_items.splice(p, 1);
      // this.onSearch();
      this.$toast.info('Удалено');
    },
    saveItem: function saveItem() {
      this.save(this.activeItem);
    },
    saveItemFromTable: function saveItemFromTable(p, i) {
      this.save(this.page_items[p].items[i]);
    },
    saveAll: function saveAll(p) {
      var _this8 = this;
      /**
       * validate item
       */
      if (this.requestInProgress) return;
      this.requestInProgress = true;
      var tosave = [];
      var toupdate = [];
      var not_validated_msg = '';
      this.page_items[p].items.every(function (item) {
        not_validated_msg = _this8.validateMsg(item);
        if (not_validated_msg) return false;
        if (item.id) {
          toupdate.push(_objectSpread(_objectSpread({}, item), {}, {
            targetable_id: item.target.id,
            targetable_type: (0,_helpers_js__WEBPACK_IMPORTED_MODULE_5__.findModel)(item.target.type)
          }));
        } else {
          tosave.push(_objectSpread(_objectSpread({}, item), {}, {
            targetable_id: item.target.id,
            targetable_type: item.target.type
          }));
        }
        return true;
      });
      if (not_validated_msg) {
        this.requestInProgress = false;
        return this.$toast.error(not_validated_msg);
      }
      var loader = this.$loading.show();
      var requests = [];
      var errors = [];
      requests.push(this.axios.post(this.uri + '/save', {
        bonuses: tosave
      })["catch"](function (error) {
        var msg = error.message == 'Request failed with status code 409' ? 'Выберите другую цель "Кому"' : error;
        errors.push(msg);
      }));
      toupdate.forEach(function (item) {
        requests.push(_this8.axios.put(_this8.uri + '/update', item)["catch"](function (error) {
          var msg = error.message == 'Request failed with status code 409' ? 'Выберите другую цель "Кому"' : error;
          errors.push(msg);
        }));
      });
      Promise.allSettled(requests).then(function () {
        var msg = errors.length ? errors.length === requests.length ? 'Ошибка при сохранении\n\n' + errors.join('\n') : 'Частично сохранено\n\n' + errors.join('\n') : 'Сохранено';
        _this8.fetch();
        _this8.$toast[errors.length ? 'error' : 'info'](msg);
        _this8.requestInProgress = false;
        loader.hide();
      });
      return false;
    },
    deleteItem: function deleteItem(p, i) {
      var item = this.page_items[p].items[i];
      if (!confirm('Вы уверены?')) {
        return;
      }
      if (item.id == 0) {
        this.deleteEvery(item.id, p, i);
        return;
      }
      this.deletee(item.id, p, i);
    },
    showStat: function showStat() {
      this.$toast.info('Показать статистику');
    },
    onSearch: function onSearch() {
      var text = this.searchText.toLowerCase();
      if (this.searchText == '') {
        this.items = this.all_items;
      } else {
        this.items = this.all_items.filter(function (el) {
          var has = false;
          if (el.name.toLowerCase().indexOf(text) > -1) {
            has = true;
          }
          return has;
        });
      }
      this.page_items = this.items.slice(0, this.pageSize);
    },
    validate: function validate(value, field) {
      value = Math.abs(Number(value));
      if (isNaN(value) || isFinite(value)) {
        value = 0;
      }
      if (['lower_limit', 'upper_limit'].includes(field) && value > 100) {
        value = 100;
      }
    },
    defineSourcesAndGroups: function defineSourcesAndGroups() {
      var _this9 = this;
      this.items.forEach(function (p) {
        p.items.forEach(function (el) {
          el.source = 0;
          el.group_id = 0;
          if (el.activity_id != 0) {
            var i = _this9.activities.findIndex(function (a) {
              return a.id == el.activity_id;
            });
            if (i != -1) {
              el.source = _this9.activities[i].source;
              if (el.source == 1) el.group_id = _this9.activities[i].group_id;
            }
          }
        });
      });
    },
    grouped_activities: function grouped_activities(source, group_id) {
      if (source == 1) {
        return this.activities.filter(function (el) {
          return el.source == source && el.group_id == group_id;
        });
      } else {
        group_id = 0;
        return this.activities.filter(function (el) {
          return el.source == source;
        });
      }
    },
    saveNewBonus: function saveNewBonus(b) {
      this.newBonusesArray[b].target = this.new_target;
      this.save(this.newBonusesArray[b], b);
      if (this.newBonusesArray.length == 0) {
        this.counter = 0;
      }
    },
    deleteNewBonus: function deleteNewBonus(b) {
      this.newBonusesArray.splice(b, 1);
      if (this.newBonusesArray.length == 0) {
        this.counter = 0;
      }
    },
    onSearchQuery: function onSearchQuery() {
      var _this10 = this;
      if (this.timeout) clearTimeout(this.timeout);
      this.timeout = setTimeout(function () {
        _this10.fetch(_objectSpread(_objectSpread({}, _this10.filters), {}, {
          query: _this10.searchText
        }));
      }, 300);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Indicators.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Indicators.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jw-vue-pagination */ "./node_modules/jw-vue-pagination/lib/JwPagination.js");
/* harmony import */ var jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _indicators_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./indicators.js */ "./resources/js/pages/kpi/indicators.js");
/* harmony import */ var _indicators_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_indicators_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./helpers.js */ "./resources/js/pages/kpi/helpers.js");
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_helpers_js__WEBPACK_IMPORTED_MODULE_2__);
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KPIIndicators',
  components: {
    JwPagination: (jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0___default())
  },
  props: {},
  data: function data() {
    return {
      active: 1,
      activeItem: null,
      uri: 'activities',
      show_fields: [],
      fields: [],
      all_fields: _indicators_js__WEBPACK_IMPORTED_MODULE_1__.fields,
      groups: [],
      searchText: '',
      modalAdjustVisibleFields: false,
      page_items: [],
      pageSize: 100,
      paginationKey: 1,
      items: [],
      // after filter changes
      all_items: [],
      activities: [],
      source_key: 1,
      sources: _helpers_js__WEBPACK_IMPORTED_MODULE_2__.sources,
      methods: _helpers_js__WEBPACK_IMPORTED_MODULE_2__.methods,
      views: _helpers_js__WEBPACK_IMPORTED_MODULE_2__.views,
      non_editable_fields: ['created_at', 'updated_at', 'created_by', 'updated_by']
    };
  },
  watch: {
    show_fields: {
      handler: function handler(val) {
        localStorage.activities_show_fields = JSON.stringify(val);
        this.prepareFields();
      },
      deep: true
    },
    pageSize: {
      handler: function handler(val) {
        if (val < 1) {
          val = 1;
          return;
        }
        if (val > 100) {
          val = 100;
          return;
        }
        this.paginationKey++;
      }
    }
  },
  created: function created() {
    this.setDefaultShowFields();
    this.prepareFields();
  },
  mounted: function mounted() {
    this.fetch();
  },
  methods: {
    onChangePage: function onChangePage(page_items) {
      this.page_items = page_items;
    },
    fetch: function fetch() {
      var _this = this;
      var filter = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
      var loader = this.$loading.show();
      this.axios.post(this.uri + '/get', {
        filters: filter
      }).then(function (response) {
        _this.all_items = response.data.items;
        _this.items = response.data.items;
        _this.groups = response.data.groups;
        _this.page_items = _this.items.slice(0, _this.pageSize);
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    setDefaultShowFields: function setDefaultShowFields() {
      var obj = {}; // Какие поля показывать
      _indicators_js__WEBPACK_IMPORTED_MODULE_1__.fields.forEach(function (field) {
        return obj[field.key] = true;
      });
      if (localStorage.activities_show_fields) {
        this.show_fields = JSON.parse(localStorage.getItem('activities_show_fields'));
        if (this.show_fields == null) this.show_fields = obj;
      } else {
        this.show_fields = obj;
      }
    },
    adjustFields: function adjustFields() {
      this.modalAdjustVisibleFields = true;
    },
    prepareFields: function prepareFields() {
      var _this2 = this;
      var visible_fields = [];
      _indicators_js__WEBPACK_IMPORTED_MODULE_1__.fields.forEach(function (field) {
        if (_this2.show_fields[field.key] != undefined && _this2.show_fields[field.key]) {
          visible_fields.push(field);
        }
      });
      this.fields = visible_fields;
    },
    validateMsg: function validateMsg(item) {
      var msg = '';
      if (item.name.length <= 1) msg = 'Заполните название';
      if (item.weekdays > 7 && item.weekdays < 1) msg = 'Рабочие дни от 1 до 7 дней';
      // if(item.source == 1 && group_id == 0) msg = 'Выберите отдел'

      return msg;
    },
    save: function save(item) {
      var _this3 = this;
      /**
                * validate item
                */
      var not_validated_msg = this.validateMsg(item);
      if (not_validated_msg != '') {
        this.$toast.error(not_validated_msg);
        return;
      }

      /**
                * prepare fields
                */
      var loader = this.$loading.show();
      var method = item.id == 0 ? 'save' : 'update';
      var fields = _objectSpread({}, item);
      var req = item.id == 0 ? this.axios.post(this.uri + '/' + method, fields) : this.axios.put(this.uri + '/' + method, fields);

      /**
                * request
                */
      req.then(function (response) {
        if (method == 'save') {
          var indicator = response.data.indicator;
          item.id = indicator.id;
          _this3.all_items.unshift(item);
        }
        _this3.$toast.info('Сохранено');
        loader.hide();
      })["catch"](function (error) {
        var m = error;
        loader.hide();
        alert(m);
      });
    },
    deletee: function deletee(id, i) {
      var _this4 = this;
      var loader = this.$loading.show();
      this.axios["delete"](this.uri + '/delete/' + id).then(function () {
        _this4.deleteEvery(id, i);
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    deleteEvery: function deleteEvery(id) {
      var a = this.all_items.findIndex(function (el) {
        return el.id == id;
      });
      if (a != -1) this.all_items.splice(a, 1);
      this.onSearch();
      this.$toast.info('Удалено');
    },
    onSearch: function onSearch() {
      var text = this.searchText;
      if (this.searchText == '') {
        this.items = this.all_items;
      } else {
        var groups = this.groups;
        var group_ids = Object.keys(groups).filter(function (key) {
          return groups[key].toLowerCase().indexOf(text.toLowerCase()) > -1;
        });
        this.items = this.all_items.filter(function (el) {
          var has = false;
          if (el.name.toLowerCase().indexOf(text.toLowerCase()) > -1) {
            has = true;
          }
          if (group_ids.includes[el.group_id]) {
            has = true;
          }
          if (el.creator != null && (el.creator.name.toLowerCase().indexOf(text.toLowerCase()) > -1 || el.creator.last_name.toLowerCase().indexOf(text.toLowerCase()) > -1)) {
            has = true;
          }
          if (el.updater != null && (el.updater.name.toLowerCase().indexOf(text.toLowerCase()) > -1 || el.updater.last_name.toLowerCase().indexOf(text.toLowerCase()) > -1)) {
            has = true;
          }
          return has;
        });
      }
      this.page_items = this.items.slice(0, this.pageSize);
    },
    validate: function validate(value, field) {
      value = Math.abs(Number(value));
      if (isNaN(value) || isFinite(value)) {
        value = 0;
      }
      if (['lower_limit', 'upper_limit'].includes(field) && value > 100) {
        value = 100;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jw-vue-pagination */ "./node_modules/jw-vue-pagination/lib/JwPagination.js");
/* harmony import */ var jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pages_kpi_SuperFilter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/pages/kpi/SuperFilter */ "./resources/js/pages/kpi/SuperFilter.vue");
/* harmony import */ var _pages_kpi_KpiItems__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/pages/kpi/KpiItems */ "./resources/js/pages/kpi/KpiItems.vue");
/* harmony import */ var _components_SuperSelect__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/SuperSelect */ "./resources/js/components/SuperSelect.vue");
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./kpis.js */ "./resources/js/pages/kpi/kpis.js");
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_kpis_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./helpers.js */ "./resources/js/pages/kpi/helpers.js");
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_helpers_js__WEBPACK_IMPORTED_MODULE_5__);
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */


 // filter like bitrix




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KPI',
  components: {
    JwPagination: (jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0___default()),
    SuperFilter: _pages_kpi_SuperFilter__WEBPACK_IMPORTED_MODULE_1__["default"],
    SuperSelect: _components_SuperSelect__WEBPACK_IMPORTED_MODULE_3__["default"],
    KpiItems: _pages_kpi_KpiItems__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  props: {},
  data: function data() {
    return {
      active: 1,
      show_fields: [],
      all_fields: _kpis_js__WEBPACK_IMPORTED_MODULE_4__.kpi_fields,
      fields: [],
      uri: 'kpi',
      groups: [],
      searchText: '',
      modalAdjustVisibleFields: false,
      page_items: [],
      pageSize: 100,
      paginationKey: 1,
      items: [],
      all_items: [],
      activities: [],
      non_editable_fields: ['created_at', 'updated_at', 'created_by', 'updated_by'],
      statusRequest: false,
      timeout: null,
      filters: null
    };
  },
  watch: {
    show_fields: {
      handler: function handler(val) {
        localStorage.kpi_show_fields = JSON.stringify(val);
        this.prepareFields();
      },
      deep: true
    },
    pageSize: {
      handler: function handler(val) {
        if (val < 1) {
          val = 1;
          return;
        }
        if (val > 100) {
          val = 100;
          return;
        }
        this.paginationKey++;
      }
    },
    searchText: function searchText() {
      this.onSearchQuery();
    }
  },
  created: function created() {
    this.fetchKPI();
    this.setDefaultShowFields();
    this.prepareFields();
    this.addStatusToItems();
  },
  mounted: function mounted() {
    var _this = this;
    this.$watch('$refs.child.searchText',
    // WTF!?!?!?
    function (new_value) {
      return _this.searchText = new_value;
    });
  },
  methods: {
    changeStatus: function changeStatus(item, e) {
      var _this2 = this;
      if (this.statusRequest) return;
      this.statusRequest = true;
      this.axios.post('/kpi/set/status', {
        id: item.id,
        is_active: e
      }).then(function () {
        _this2.$toast.success('Статус изменен');
        _this2.statusRequest = false;
      })["catch"](function () {
        _this2.$toast.error('Статус не изменен');
        _this2.statusRequest = false;
      });
    },
    expand: function expand(i) {
      this.page_items[i].expanded = !this.page_items[i].expanded;
    },
    getUserGourpsString: function getUserGourpsString(user) {
      return user.groups.map(function (group) {
        return group.name;
      }).join(', ');
    },
    onChangePage: function onChangePage(page_items) {
      this.page_items = page_items;
    },
    fetchKPI: function fetchKPI() {
      var _this3 = this;
      var filter = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
      var loader = this.$loading.show();
      this.filters = filter;
      this.axios.post(this.uri + '/' + 'get', {
        filters: _objectSpread(_objectSpread({}, filter), {}, {
          query: this.searchText
        })
      }).then(function (response) {
        _this3.items = response.data.kpis;
        _this3.all_items = response.data.kpis;
        _this3.activities = response.data.activities;
        _this3.groups = response.data.groups;
        _this3.page_items = _this3.items.slice(0, _this3.pageSize);
        _this3.addStatusToItems();
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    setDefaultShowFields: function setDefaultShowFields() {
      var obj = {}; // Какие поля показывать
      _kpis_js__WEBPACK_IMPORTED_MODULE_4__.kpi_fields.forEach(function (field) {
        return obj[field.key] = true;
      });
      if (localStorage.kpi_show_fields) {
        this.show_fields = JSON.parse(localStorage.getItem('kpi_show_fields'));
        if (this.show_fields == null) this.show_fields = obj;
      } else {
        this.show_fields = obj;
      }
    },
    adjustFields: function adjustFields() {
      this.modalAdjustVisibleFields = true;
    },
    addStatusToItems: function addStatusToItems() {
      this.items.forEach(function (el) {
        el.items.forEach(function (a) {
          a.source = 0;
          a.group_id = 0;
        });
        el.on_edit = false;
      });
    },
    prepareFields: function prepareFields() {
      var _this4 = this;
      var visible_fields = [];
      _kpis_js__WEBPACK_IMPORTED_MODULE_4__.kpi_fields.forEach(function (field) {
        if (_this4.show_fields[field.key] != undefined && _this4.show_fields[field.key]) {
          visible_fields.push(field);
        }
      });
      this.fields = visible_fields;
    },
    addKpi: function addKpi() {
      this.items.unshift((0,_kpis_js__WEBPACK_IMPORTED_MODULE_4__.newKpi)());
      //this.page_items.unshift(newKpi());
      // this.page_items = this.items.slice(0, this.pageSize);
      this.$toast.info('Добавлен KPI');
    },
    validateMsg: function validateMsg(item) {
      var msg = '';
      if (item.target == null) msg = 'Выберите Кому назначить';

      // wtf share ???
      // eslint-disable-next-line no-unused-vars
      var share = 0;
      if (item.items != undefined) {
        item.items.every(function (el, i) {
          if (!(el.deleted !== undefined && el.deleted)) share += Math.abs(el.share);
          if (el.name.length <= 1) {
            msg = 'Заполните название активности #' + (i + 1);
            return false;
          }
          if ((el.activity_id == 0 || el.activity_id == undefined) && el.source != 0) {
            msg = 'Выберите показатель #' + (i + 1);
            return false;
          }

          // if(Number(el.plan) <= 0) {
          //     msg = 'План должен быть больше 0 #' + (i+1);
          //     return false;
          // }

          return true;
        });
      }
      return msg;
    },
    saveKpi: function saveKpi(i) {
      var _this5 = this;
      var item = this.items[i];
      var method = this.items[i].id == 0 ? 'save' : 'update';

      /**
       * validate item
       */
      var not_validated_msg = this.validateMsg(item);
      if (not_validated_msg != '') {
        this.$toast.error(not_validated_msg);
        return;
      }
      var loader = this.$loading.show();
      var fields = {
        id: item.id,
        targetable_id: item.target.id,
        targetable_type: (0,_helpers_js__WEBPACK_IMPORTED_MODULE_5__.findModel)(item.target.type),
        completed_80: item.completed_80,
        completed_100: item.completed_100,
        upper_limit: item.upper_limit,
        lower_limit: item.lower_limit,
        items: item.items
      };
      var req = this.items[i].id == 0 ? this.axios.post(this.uri + '/' + method, fields) : this.axios.put(this.uri + '/' + method, fields);
      req.then(function (_ref) {
        var data = _ref.data;
        item.id = data.id;
        item.items.forEach(function (el, index) {
          el.id = data.items[index];
        });
        _this5.removeDeletedItems(item.items);
        _this5.$toast.info('KPI Сохранен');
        loader.hide();
      })["catch"](function (error) {
        var m = error;
        if (error.message == 'Request failed with status code 409') {
          m = 'Выберите другую цель "Кому". Этому объекту уже назначен KPI';
        }
        loader.hide();
        alert(m);
      });
    },
    removeDeletedItems: function removeDeletedItems(items) {
      var indexes = [];
      var counter = 0;
      items.forEach(function (el, index) {
        if (el.deleted != undefined && el.deleted) {
          indexes.push(index);
        }
      });
      indexes.forEach(function (index) {
        items.splice(index - counter, 1);
        counter++;
      });
    },
    deleteKpi: function deleteKpi(i) {
      var _this6 = this;
      var item = this.items[i];
      var a = this.all_items.findIndex(function (el) {
        return el.id == item.id;
      });
      if (!confirm('Вы уверены?')) {
        return;
      }
      if (item.id == 0) {
        if (a != -1) this.all_items.splice(a, 1);
        // this.onSearch();
        this.$toast.info('KPI Удален!');
        return;
      }
      var loader = this.$loading.show();
      this.axios["delete"](this.uri + '/delete/' + item.id).then(function () {
        if (a != -1) _this6.all_items.splice(a, 1);
        // this.onSearch();

        _this6.$toast.info('KPI Удален!');
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    showStat: function showStat() {
      this.$toast.info('Показать статистику');
    },
    onSearch: function onSearch() {
      var text = this.searchText.toLowerCase();
      if (this.searchText == '') {
        this.items = this.all_items;
      } else {
        this.items = this.all_items.filter(function (el) {
          var has = false;
          if (el.target != null && el.target.name.toLowerCase().indexOf(text) > -1) {
            has = true;
          }
          if (el.title.toLowerCase().indexOf(text) > -1) {
            has = true;
          }
          if (el.creator != null && (el.creator.name.toLowerCase().indexOf(text) > -1 || el.creator.last_name.toLowerCase().indexOf(text) > -1)) {
            has = true;
          }
          if (el.updater != null && (el.updater.name.toLowerCase().indexOf(text) > -1 || el.updater.last_name.toLowerCase().indexOf(text) > -1)) {
            has = true;
          }
          return has;
        });
      }
      this.page_items = this.items.slice(0, this.pageSize);
    },
    validate: function validate(value, field) {
      value = Math.abs(Number(value));
      if (isNaN(value) || isFinite(value)) {
        value = 0;
      }
      if (['lower_limit', 'upper_limit'].includes(field) && value > 100) {
        value = 100;
      }
    },
    onSearchQuery: function onSearchQuery() {
      var _this7 = this;
      if (this.timeout) clearTimeout(this.timeout);
      this.timeout = setTimeout(function () {
        _this7.fetchKPI(_objectSpread(_objectSpread({}, _this7.filters), {}, {
          query: _this7.searchText
        }));
      }, 300);
    },
    countAvg: function countAvg() {
      this.items.forEach(function (kpi) {
        var kpi_sum = 0;
        var kpi_count = 0;
        kpi.users.forEach(function (user) {
          var count = 0;
          var sum = 0;
          var avg = 0;
          user.items.forEach(function (item) {
            sum += Number(item.percent);
            count++;
          });

          /**
          * count avg of user items
          */
          avg = count > 0 ? Number(sum / count).toFixed(2) : 0;
          user.avg = avg;

          // all kpi sum
          kpi_sum += Number(avg);
          kpi_count++;
        });
        /**
        * count avg completed percent of kpi by users
        */
        kpi.avg = kpi_count > 0 ? Number(Number(kpi_sum / kpi_count * 100).toFixed(2)) : 0;
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItems.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItems.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./kpis.js */ "./resources/js/pages/kpi/kpis.js");
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_kpis_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helpers.js */ "./resources/js/pages/kpi/helpers.js");
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_helpers_js__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable vue/no-mutating-props */
/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KpiItems',
  props: {
    my_sum: {
      type: Number,
      "default": 0
    },
    kpi_id: {
      type: Number,
      "default": 0
    },
    expanded: {
      type: Boolean,
      "default": false
    },
    items: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activities: {
      type: Object,
      "default": function _default() {
        return {};
      }
    },
    groups: {
      type: Object,
      "default": function _default() {
        return {};
      }
    },
    completed_80: {
      type: Number,
      "default": 0
    },
    completed_100: {
      type: Number,
      "default": 0
    },
    lower_limit: {
      type: Number,
      "default": 80
    },
    upper_limit: {
      type: Number,
      "default": 100
    },
    editable: {
      type: Boolean,
      "default": false
    },
    kpi_page: {
      type: Boolean,
      "default": false
    },
    allow_overfulfillment: {
      type: Boolean,
      "default": false
    },
    date: {
      type: Object,
      "default": null
    }
  },
  data: function data() {
    return {
      active: 1,
      methods: _helpers_js__WEBPACK_IMPORTED_MODULE_1__.methods,
      sources: _helpers_js__WEBPACK_IMPORTED_MODULE_1__.sources,
      refreshItemsKey: 1,
      source_key: 1,
      show_description: false
    };
  },
  computed: {},
  watch: {
    items: {
      handler: function handler() {
        this.recalc();
        this.getSum();
      },
      deep: true
    },
    lower_limit: {
      handler: function handler() {
        this.recalc();
      }
    },
    upper_limit: {
      handler: function handler() {
        this.recalc();
      }
    },
    completed_80: {
      handler: function handler() {
        this.recalc();
      }
    },
    completed_100: {
      handler: function handler() {
        this.recalc();
      }
    }
  },
  created: function created() {
    this.fillSelectOptions();
    this.defineSourcesAndGroups('with_sources_and_group_id');
    this.recalc();
    this.getSum();
    if (!this.editable) {
      this.items.forEach(function (el) {
        return el.expanded = true;
      });
    }
  },
  mounted: function mounted() {},
  methods: {
    toggle: function toggle() {
      this.show_description = false;
    },
    showDescription: function showDescription() {
      this.show_description = !this.show_description;
    },
    recalc: function recalc() {
      var _this = this;
      this.items.forEach(function (el) {
        // if(
        //     [1,3,5].includes(el.method)
        //     && !this.kpi_page
        //     && el.common != 1
        //     && el.source == 1
        //     && el.activity != null
        //     && el.activity.view != 7
        // ) {
        //     el.plan = el.daily_plan * numberize(el.workdays);
        // }
        el.percent = (0,_kpis_js__WEBPACK_IMPORTED_MODULE_0__.calcCompleted)(el);
        el.sum = (0,_kpis_js__WEBPACK_IMPORTED_MODULE_0__.calcSum)(el, {
          lower_limit: _this.lower_limit,
          upper_limit: _this.upper_limit,
          completed_80: _this.completed_80,
          completed_100: _this.completed_100,
          allow_overfulfillment: _this.allow_overfulfillment
        }, _this.kpi_page ? 1 : el.percent / 100.0);
      });
    },
    deleteItem: function deleteItem(i) {
      this.items[i].deleted = true;
      if (this.kpi_id == 0) this.items.splice(i, 1);
      this.refreshItemsKey++;
    },
    restoreItem: function restoreItem(i) {
      this.items[i].deleted = false;
      this.refreshItemsKey++;
    },
    addItem: function addItem() {
      this.items.push((0,_kpis_js__WEBPACK_IMPORTED_MODULE_0__.newKpiItem)());
    },
    getActivity: function getActivity(id) {
      return this.activities.find(function (el) {
        return el.id == id;
      });
    },
    fillSelectOptions: function fillSelectOptions() {},
    groupBy: function groupBy(xs, key) {
      return xs.reduce(function (rv, x) {
        (rv[x[key]] = rv[x[key]] || []).push(x);
        return rv;
      }, {});
    },
    defineSourcesAndGroups: function defineSourcesAndGroups() {
      var _this2 = this;
      this.items.forEach(function (el) {
        el.source = 0;
        el.group_id = 0;
        if (el.activity_id != 0) {
          var i = _this2.activities.findIndex(function (a) {
            return a.id == el.activity_id;
          });
          if (i != -1) {
            el.source = _this2.activities[i].source;
            if (el.source == 1) el.group_id = _this2.activities[i].group_id;
          }
        }
      });
    },
    grouped_activities: function grouped_activities(source, group_id) {
      if (source == 1) {
        return this.activities.filter(function (el) {
          return el.source == source && el.group_id == group_id;
        });
      } else {
        group_id = 0;
        return this.activities.filter(function (el) {
          return el.source == source;
        });
      }
    },
    isCell: function isCell(activity_id) {
      var i = this.activities.findIndex(function (el) {
        return el.id == activity_id;
      });
      return i != -1 && this.activities[i].view == 7;
    },
    updateStat: function updateStat(i) {
      var _this3 = this;
      var loader = this.$loading.show();
      var item = this.items[i];
      var date = this.date != null ? this.date : this.$moment(Date.now()).format('YYYY-MM-DD');
      var value = [1, 3, 5].includes(item.method) ? item.fact : item.avg;
      this.axios.post('/statistics/update-stat', {
        user_id: this.kpi_id,
        kpi_item_id: item.id,
        activity_id: item.activity_id,
        value: value,
        date: date
      }).then(function () {
        _this3.$toast.success('Изменено');
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    getSum: function getSum() {
      var sum = 0;
      this.items.forEach(function (item) {
        sum += item.sum;
      });
      this.$emit('getSum', sum);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./kpis.js */ "./resources/js/pages/kpi/kpis.js");
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_kpis_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helpers.js */ "./resources/js/pages/kpi/helpers.js");
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_helpers_js__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable vue/no-mutating-props */
/* eslint-disable camelcase */
/* eslint-disable vue/prop-name-casing */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KpiItemsV2',
  props: {
    my_sum: {
      type: Number,
      "default": 0
    },
    kpi_id: {
      type: Number,
      "default": 0
    },
    expanded: {
      type: Boolean,
      "default": false
    },
    items: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    activities: {
      type: Object,
      "default": function _default() {
        return {};
      }
    },
    groups: {
      type: Object,
      "default": function _default() {
        return {};
      }
    },
    completed_80: {
      type: Number,
      "default": 0
    },
    completed_100: {
      type: Number,
      "default": 0
    },
    lower_limit: {
      type: Number,
      "default": 80
    },
    upper_limit: {
      type: Number,
      "default": 100
    },
    editable: {
      type: Boolean,
      "default": false
    },
    kpi_page: {
      type: Boolean,
      "default": false
    },
    allow_overfulfillment: {
      type: Boolean,
      "default": false
    },
    date: {
      type: Object,
      "default": null
    }
  },
  data: function data() {
    return {
      active: 1,
      methods: _helpers_js__WEBPACK_IMPORTED_MODULE_1__.methods,
      sources: _helpers_js__WEBPACK_IMPORTED_MODULE_1__.sources,
      refreshItemsKey: 1,
      source_key: 1,
      show_description: false
    };
  },
  computed: {},
  watch: {
    items: {
      handler: function handler() {
        this.recalc();
        this.getSum();
      },
      deep: true
    },
    lower_limit: {
      handler: function handler() {
        this.recalc();
      }
    },
    upper_limit: {
      handler: function handler() {
        this.recalc();
      }
    },
    completed_80: {
      handler: function handler() {
        this.recalc();
      }
    },
    completed_100: {
      handler: function handler() {
        this.recalc();
      }
    }
  },
  created: function created() {
    this.fillSelectOptions();
    this.defineSourcesAndGroups('with_sources_and_group_id');
    this.recalc();
    this.getSum();
    if (!this.editable) {
      this.items.forEach(function (el) {
        return el.expanded = true;
      });
    }
  },
  mounted: function mounted() {},
  methods: {
    toggle: function toggle() {
      this.show_description = false;
    },
    showDescription: function showDescription() {
      this.show_description = !this.show_description;
    },
    recalc: function recalc() {
      var _this = this;
      this.items.forEach(function (el) {
        // if(
        //     [1,3,5].includes(el.method)
        //     && !this.kpi_page
        //     && el.common != 1
        //     && el.source == 1
        //     && el.activity != null
        //     && el.activity.view != 7
        // ) {
        //     el.plan = el.daily_plan * numberize(el.workdays);
        // }
        el.percent = (0,_kpis_js__WEBPACK_IMPORTED_MODULE_0__.calcCompleted)(el);
        el.sum = (0,_kpis_js__WEBPACK_IMPORTED_MODULE_0__.calcSum)(el, {
          lower_limit: _this.lower_limit,
          upper_limit: _this.upper_limit,
          completed_80: _this.completed_80,
          completed_100: _this.completed_100,
          allow_overfulfillment: _this.allow_overfulfillment
        }, _this.kpi_page ? 1 : el.percent / 100.0);
      });
    },
    deleteItem: function deleteItem(i) {
      this.items[i].deleted = true;
      if (this.kpi_id == 0) this.items.splice(i, 1);
      this.refreshItemsKey++;
    },
    restoreItem: function restoreItem(i) {
      this.items[i].deleted = false;
      this.refreshItemsKey++;
    },
    addItem: function addItem() {
      this.items.push((0,_kpis_js__WEBPACK_IMPORTED_MODULE_0__.newKpiItem)());
    },
    getActivity: function getActivity(id) {
      return this.activities.find(function (el) {
        return el.id == id;
      });
    },
    fillSelectOptions: function fillSelectOptions() {},
    groupBy: function groupBy(xs, key) {
      return xs.reduce(function (rv, x) {
        (rv[x[key]] = rv[x[key]] || []).push(x);
        return rv;
      }, {});
    },
    defineSourcesAndGroups: function defineSourcesAndGroups() {
      var _this2 = this;
      this.items.forEach(function (el) {
        el.source = 0;
        el.group_id = 0;
        if (el.activity_id != 0) {
          var i = _this2.activities.findIndex(function (a) {
            return a.id == el.activity_id;
          });
          if (i != -1) {
            el.source = _this2.activities[i].source;
            if (el.source == 1) el.group_id = _this2.activities[i].group_id;
          }
        }
      });
    },
    grouped_activities: function grouped_activities(source, group_id) {
      if (source == 1) {
        return this.activities.filter(function (el) {
          return el.source == source && el.group_id == group_id;
        });
      } else {
        group_id = 0;
        return this.activities.filter(function (el) {
          return el.source == source;
        });
      }
    },
    isCell: function isCell(activity_id) {
      var i = this.activities.findIndex(function (el) {
        return el.id == activity_id;
      });
      return i != -1 && this.activities[i].view == 7;
    },
    updateStat: function updateStat(i) {
      var _this3 = this;
      var loader = this.$loading.show();
      var item = this.items[i];
      var date = this.date != null ? this.date : this.$moment(Date.now()).format('YYYY-MM-DD');
      var value = [1, 3, 5].includes(item.method) ? item.fact : item.avg;
      this.axios.post('/statistics/update-stat', {
        user_id: this.kpi_id,
        kpi_item_id: item.id,
        activity_id: item.activity_id,
        value: value,
        date: date
      }).then(function () {
        _this3.$toast.success('Изменено');
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    getSum: function getSum() {
      var sum = 0;
      this.items.forEach(function (item) {
        sum += item.sum;
      });
      this.$emit('getSum', sum);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _pages_kpi_Kpi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/pages/kpi/Kpi */ "./resources/js/pages/kpi/Kpi.vue");
/* harmony import */ var _pages_kpi_Bonuses_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/pages/kpi/Bonuses.vue */ "./resources/js/pages/kpi/Bonuses.vue");
/* harmony import */ var _pages_kpi_QuartalPremium__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/pages/kpi/QuartalPremium */ "./resources/js/pages/kpi/QuartalPremium.vue");
/* harmony import */ var _pages_kpi_StatsV2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/pages/kpi/StatsV2 */ "./resources/js/pages/kpi/StatsV2.vue");
/* harmony import */ var _pages_kpi_Indicators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/pages/kpi/Indicators */ "./resources/js/pages/kpi/Indicators.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




var Stats = __webpack_require__.e(/*! import() | KPIStatsV1 */ "KPIStatsV1").then(__webpack_require__.bind(__webpack_require__, /*! @/pages/kpi/Stats */ "./resources/js/pages/kpi/Stats.vue"));
// import Stats from '@/pages/kpi/Stats'


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KPIPages',
  components: {
    KPI: _pages_kpi_Kpi__WEBPACK_IMPORTED_MODULE_0__["default"],
    Bonuses: _pages_kpi_Bonuses_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    QuartalPremium: _pages_kpi_QuartalPremium__WEBPACK_IMPORTED_MODULE_2__["default"],
    Stats: Stats,
    StatsV2: _pages_kpi_StatsV2__WEBPACK_IMPORTED_MODULE_3__["default"],
    Indicators: _pages_kpi_Indicators__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  props: {
    page: {
      type: String,
      "default": 'kpi'
    },
    access: {
      type: String,
      "default": 'view'
    }
  },
  data: function data() {
    return {
      active: 0,
      tenant: window.location.hostname.split('.')[0]
    };
  },
  watch: {
    page: function page() {
      this.init();
    }
  },
  created: function created() {},
  mounted: function mounted() {
    var uri = window.location.search.substring(1);
    var params = new URLSearchParams(uri);
    if (params.get('target')) {
      // может быть проблемой для spa
      window.history.pushState({}, document.title, '/' + 'kpi');
    }
  },
  methods: {
    init: function init() {
      // this.fetchData()
      var uri = window.location.search.substring(1);
      var params = new URLSearchParams(uri);
      this.active = params.get('target') ? 3 : 0;
    },
    changeStatus: function changeStatus(item, e) {
      var _this = this;
      /* eslint-disable camelcase */
      this.axios.post('/bonus/set/status', {
        premium_id: item.id,
        is_active: e
      }).then(function () {
        _this.$toast.success('Статус изменен');
      })["catch"](function () {
        _this.$toast.error('Статус не изменен');
      });
      /* eslint-enable camelcase */
    },
    fetchData: function fetchData() {
      var loader = this.$loading.show();
      this.axios.post('/kpi/' + this.page, {
        month: this.$moment(this.monthInfo.currentMonth, 'MMMM').format('M')
      }).then(function () {
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/QuartalPremium.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/QuartalPremium.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jw-vue-pagination */ "./node_modules/jw-vue-pagination/lib/JwPagination.js");
/* harmony import */ var jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pages_kpi_SuperFilter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/pages/kpi/SuperFilter */ "./resources/js/pages/kpi/SuperFilter.vue");
/* harmony import */ var _components_SuperSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/SuperSelect */ "./resources/js/components/SuperSelect.vue");
/* harmony import */ var _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/ui/Sidebar */ "./resources/js/components/ui/Sidebar.vue");
/* harmony import */ var _quartal_premiums_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./quartal_premiums.js */ "./resources/js/pages/kpi/quartal_premiums.js");
/* harmony import */ var _quartal_premiums_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_quartal_premiums_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./helpers.js */ "./resources/js/pages/kpi/helpers.js");
/* harmony import */ var _helpers_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_helpers_js__WEBPACK_IMPORTED_MODULE_5__);
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */


 // filter like bitrix

 // сайдбар table



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'QuartalPremiums',
  components: {
    JwPagination: (jw_vue_pagination__WEBPACK_IMPORTED_MODULE_0___default()),
    SuperFilter: _pages_kpi_SuperFilter__WEBPACK_IMPORTED_MODULE_1__["default"],
    SuperSelect: _components_SuperSelect__WEBPACK_IMPORTED_MODULE_2__["default"],
    Sidebar: _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  props: {},
  data: function data() {
    return {
      new_target: null,
      counter: 0,
      premium: null,
      newPremiumArray: [],
      active: 1,
      activeItem: null,
      uri: 'quartal-premiums',
      showSidebar: false,
      show_fields: [],
      fields: [],
      all_fields: _quartal_premiums_js__WEBPACK_IMPORTED_MODULE_4__.fields,
      groups: [],
      searchText: '',
      modalAdjustVisibleFields: false,
      page_items: [],
      pageSize: 20,
      paginationKey: 1,
      items: [],
      // after filter changes
      all_items: [],
      activities: [],
      source_key: 1,
      sources: _helpers_js__WEBPACK_IMPORTED_MODULE_5__.sources,
      non_editable_fields: ['created_at', 'updated_at', 'created_by', 'updated_by'],
      statusRequest: false,
      timeout: null,
      filters: null
    };
  },
  watch: {
    show_fields: {
      handler: function handler(val) {
        localStorage.quartal_premiums_show_fields = JSON.stringify(val);
        this.prepareFields();
      },
      deep: true
    },
    pageSize: {
      handler: function handler(val) {
        if (val < 1) {
          val = 1;
          return;
        }
        if (val > 100) {
          val = 100;
          return;
        }
        this.paginationKey++;
      }
    },
    newPremiumArray: function newPremiumArray(after) {
      if (after.length == 0) {
        this.counter = 0;
        this.new_target = null;
      }
    },
    searchText: function searchText() {
      this.onSearchQuery();
    }
  },
  created: function created() {
    this.setDefaultShowFields();
    this.prepareFields();
    this.addStatusToItems();
  },
  mounted: function mounted() {
    var _this = this;
    this.fetch();
    this.$watch('$refs.child.searchText', function (new_value) {
      return _this.searchText = new_value;
    });
  },
  methods: {
    changeStatus: function changeStatus(item, e) {
      var _this2 = this;
      if (this.statusRequest) return;
      this.statusRequest = true;
      this.axios.post('/quartal-premiums/set/status', {
        premium_id: item.id,
        is_active: e
      }).then(function () {
        _this2.$toast.success('Статус изменен');
        _this2.statusRequest = false;
      })["catch"](function () {
        _this2.$toast.error('Статус не изменен');
        _this2.statusRequest = false;
      });
    },
    addPremiumGroup: function addPremiumGroup(page) {
      page.items.push((0,_quartal_premiums_js__WEBPACK_IMPORTED_MODULE_4__.newQuartalPremium)());
      page.items[page.items.length - 1].target = {
        id: page.id,
        type: page.type
      };
    },
    addPremium: function addPremium() {
      this.newPremiumArray.push((0,_quartal_premiums_js__WEBPACK_IMPORTED_MODULE_4__.newQuartalPremium)());
    },
    saveNewQuartal: function saveNewQuartal(i) {
      this.newPremiumArray[i].target = this.new_target;
      this.save(this.newPremiumArray[i], i);
    },
    deleteNewQuartal: function deleteNewQuartal(i) {
      this.newPremiumArray.splice(i, 1);
    },
    addRowItem: function addRowItem() {
      if (this.counter == 0) {
        this.newPremiumArray.push((0,_quartal_premiums_js__WEBPACK_IMPORTED_MODULE_4__.newQuartalPremium)());
        this.premium = this.newPremiumArray[0];
        this.counter++;
      }
    },
    expand: function expand(i) {
      this.page_items[i].expanded = !this.page_items[i].expanded;
    },
    onChangePage: function onChangePage(page_items) {
      this.page_items = page_items;
    },
    fetch: function fetch() {
      var _this3 = this;
      var filter = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
      var loader = this.$loading.show();
      this.filters = filter;
      this.axios.post(this.uri + '/get', {
        filters: _objectSpread(_objectSpread({}, filter), {}, {
          query: this.searchText
        })
      }).then(function (response) {
        _this3.all_items = response.data.items;
        _this3.items = response.data.items;
        _this3.activities = response.data.activities;
        _this3.groups = response.data.groups;
        _this3.defineSourcesAndGroups('t');
        _this3.items.forEach(function (el) {
          return el.expanded = false;
        });
        _this3.page_items = _this3.items.slice(0, _this3.pageSize);
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    openSidebar: function openSidebar(p, i) {
      this.activeItem = this.page_items[p].items[i];
      this.showSidebar = true;
    },
    closeSidebar: function closeSidebar() {
      this.showSidebar = false;
      this.activeItem = null;
    },
    setDefaultShowFields: function setDefaultShowFields() {
      var obj = {}; // Какие поля показывать
      _quartal_premiums_js__WEBPACK_IMPORTED_MODULE_4__.fields.forEach(function (field) {
        return obj[field.key] = true;
      });
      if (localStorage.quartal_premiums_show_fields) {
        this.show_fields = JSON.parse(localStorage.getItem('quartal_premiums_show_fields'));
        if (this.show_fields == null) this.show_fields = obj;
      } else {
        this.show_fields = obj;
      }
    },
    adjustFields: function adjustFields() {
      this.modalAdjustVisibleFields = true;
    },
    addStatusToItems: function addStatusToItems() {
      this.items.forEach(function (el) {
        el.on_edit = false;
        el.source = 0;
        el.group_id = 0;
        el.selected = false;
      });
    },
    prepareFields: function prepareFields() {
      var _this4 = this;
      var visible_fields = [];
      _quartal_premiums_js__WEBPACK_IMPORTED_MODULE_4__.fields.forEach(function (field) {
        if (_this4.show_fields[field.key] != undefined && _this4.show_fields[field.key]) {
          visible_fields.push(field);
        }
      });
      this.fields = visible_fields;
    },
    addItem: function addItem() {
      this.activeItem = (0,_quartal_premiums_js__WEBPACK_IMPORTED_MODULE_4__.newQuartalPremium)();
      this.showSidebar = true;
    },
    validateMsg: function validateMsg(item) {
      var msg = '';
      if (item.target == null) msg = 'Выберите Кому назначить';
      if (item.title.length <= 1) msg = 'Заполните название';

      // activity id
      // let a;
      // if(item.source == 1) {
      // 	a = this.activities.findIndex(el => el.source == item.source && el.group_id == item.group_id && el.id == item.activity_id);
      // } else {
      // 	a = this.activities.findIndex(el => el.source == item.source && el.id == item.activity_id);
      // }

      if (item.text.length === 0) {
        msg = 'Заполните поле Текст';
      }

      // another
      if (item.from == null) msg = 'Выберите начало периода';
      if (item.to == null) msg = 'Выберите конец периода';
      if (item.quantity <= 0) msg = 'Кол-во должно быть больше нуля';
      if (item.sum <= 0) msg = 'Вознаграждение должно быть больше нуля';
      return msg;
    },
    save: function save(item, index) {
      var _this5 = this;
      /**
       * validate item
       */
      var not_validated_msg = this.validateMsg(item);
      if (not_validated_msg != '') {
        this.$toast.error(not_validated_msg);
        return;
      }

      /**
       * prepare fields
       */
      var loader = this.$loading.show();
      var method = item.id == 0 ? 'save' : 'update';
      var fields = _objectSpread({
        targetable_id: item.target.id,
        targetable_type: (0,_helpers_js__WEBPACK_IMPORTED_MODULE_5__.findModel)(item.target.type)
      }, item);
      var req = item.id == 0 ? this.axios.post(this.uri + '/' + method, fields) : this.axios.put(this.uri + '/' + method, fields);

      /**
       * request
       */
      req.then(function (response) {
        if (method == 'save') {
          var quartal_premium = response.data.quartal_premium;
          item.id = quartal_premium.id;
          // this.items.unshift(item);

          var i = _this5.all_items.findIndex(function (el) {
            return el.type == item.target.type && el.id == item.target.id;
          });
          if (i != -1) {
            var j = _this5.all_items[i].items.findIndex(function (el) {
              return el.id === item.id;
            });
            if (j !== -1) {
              _this5.all_items[i].items.splice(j, 1, item);
            } else {
              _this5.all_items[i].items.unshift(item);
            }
          } else {
            _this5.all_items.unshift({
              id: item.target.id,
              type: item.target.type,
              name: item.target.name,
              items: [item],
              expanded: false
            });
          }
          _this5.showSidebar = false;
        } else {
          item.updated_at = _this5.$moment(Date.now()).format('DD.MM.YYYY HH:mm');
        }
        _this5.$toast.info('Сохранено');
        _this5.newPremiumArray.splice(index, 1);
        loader.hide();
      })["catch"](function (error) {
        var m = error;
        if (error.message == 'Request failed with status code 409') {
          m = 'Выберите другую цель "Кому"';
        }
        loader.hide();
        alert(m);
      });
      return req;
    },
    deletee: function deletee(id, p, i) {
      var _this6 = this;
      var loader = this.$loading.show();
      this.axios["delete"](this.uri + '/delete/' + id).then(function () {
        _this6.deleteEvery(id, p, i);
        loader.hide();
      })["catch"](function (error) {
        loader.hide();
        alert(error);
      });
    },
    deleteEvery: function deleteEvery(id, p, i) {
      // let a = this.all_items.findIndex(el => el.id == id)
      // if(a != -1) this.all_items.splice(a, 1);

      this.all_items[p].items.splice(i, 1);
      if (this.all_items[p].items.length == 0) this.all_items.splice(p, 1);
      // this.onSearch();

      this.$toast.info('Удалено');
    },
    saveItem: function saveItem() {
      this.save(this.activeItem);
    },
    saveItemFromTable: function saveItemFromTable(p, i) {
      var _this7 = this;
      var item = this.page_items[p].items[i];
      this.save(item).then(function () {
        if (item.id === 0) {
          _this7.page_items[p].splice(i, 1);
        }
      });
    },
    saveAll: function saveAll(p) {
      var _this8 = this;
      this.page_items[p].items.forEach(function (item, i) {
        _this8.saveItemFromTable(p, i);
      });
    },
    deleteItem: function deleteItem(p, i) {
      var item = this.page_items[p].items[i];
      if (!confirm('Вы уверены?')) {
        return;
      }
      if (item.id == 0) {
        this.deleteEvery(item.id, p, i);
        return;
      }
      this.deletee(item.id, p, i);
    },
    showStat: function showStat() {
      this.$toast.info('Показать статистику');
    },
    onSearch: function onSearch() {
      var text = this.searchText.toLowerCase();
      if (this.searchText == '') {
        this.items = this.all_items;
      } else {
        this.items = this.all_items.filter(function (el) {
          var has = false;
          if (el.name.toLowerCase().indexOf(text) > -1) {
            has = true;
          }
          return has;
        });
      }
      this.page_items = this.items.slice(0, this.pageSize);
    },
    validate: function validate(value, field) {
      value = Math.abs(Number(value));
      if (isNaN(value) || isFinite(value)) {
        value = 0;
      }
      if (['lower_limit', 'upper_limit'].includes(field) && value > 100) {
        value = 100;
      }
    },
    defineSourcesAndGroups: function defineSourcesAndGroups() {
      var _this9 = this;
      this.items.forEach(function (p) {
        p.items.forEach(function (el) {
          el.source = 0;
          el.group_id = 0;
          if (el.activity_id != 0) {
            var i = _this9.activities.findIndex(function (a) {
              return a.id == el.activity_id;
            });
            if (i != -1) {
              el.source = _this9.activities[i].source;
              if (el.source == 1) el.group_id = _this9.activities[i].group_id;
            }
          }
        });
      });
    },
    grouped_activities: function grouped_activities(source, group_id) {
      if (source == 1) {
        return this.activities.filter(function (el) {
          return el.source == source && el.group_id == group_id;
        });
      } else {
        group_id = 0;
        return this.activities.filter(function (el) {
          return el.source == source;
        });
      }
    },
    onSearchQuery: function onSearchQuery() {
      var _this10 = this;
      if (this.timeout) clearTimeout(this.timeout);
      this.timeout = setTimeout(function () {
        _this10.fetch(_objectSpread(_objectSpread({}, _this10.filters), {}, {
          query: _this10.searchText
        }));
      }, 300);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'StatsTableBonus',
  props: {
    groups: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    /* eslint-disable-next-line camelcase, vue/prop-name-casing */
    group_names: {
      type: Object,
      "default": null
    },
    month: {
      type: Number,
      "default": 0
    }
  },
  data: function data() {
    return {
      bonuses: [],
      obtainedBonuses: [],
      users: [],
      activities: [],
      fields: [],
      items: [],
      myGroups: []
    };
  },
  computed: {
    filteredBonuses: function filteredBonuses() {
      var _this = this;
      return this.obtainedBonuses.filter(function (bonus) {
        return bonus.user_id === _this.user.id;
      });
    }
  },
  watch: {},
  created: function created() {
    this.getActivities();
    this.generateBonuses();
  },
  mounted: function mounted() {},
  methods: {
    getTotalSum: function getTotalSum(bonusId, userId) {
      var _this2 = this;
      var sum = 0;
      var obtained = this.obtainedBonuses.filter(function (bonus) {
        return bonus.bonus_id == bonusId && bonus.user_id == userId && _this2.isCurrentMonth(bonus.date);
      });
      obtained.forEach(function (bonus) {
        sum += bonus.comment.substring(bonus.comment.indexOf(':') + 1, bonus.comment.lastIndexOf(';')) * bonus.amount;
      });
      return sum;
    },
    isCurrentMonth: function isCurrentMonth(date) {
      var from = date.split('-');
      if (from[1] == parseInt(this.month)) return true;else return false;
    },
    getActivities: function getActivities() {
      var _this3 = this;
      this.axios.get('/statistics/activities').then(function (response) {
        _this3.activities = response.data;
      });
    },
    generateBonuses: function generateBonuses() {
      var _this4 = this;
      this.groups.forEach(function (group) {
        if (group[0]) {
          group[0].bonuses.forEach(function (bonus1) {
            if (!_this4.bonuses.some(function (bonus2) {
              return bonus2.id === bonus1.id;
            })) _this4.bonuses.push(bonus1);
          });
          group[0].users.forEach(function (user) {
            var myObtainedBonuses = user.obtained_bonuses.filter(function (bonus) {
              return bonus.amount > 0 && _this4.isCurrentMonth(bonus.date);
            });
            _this4.obtainedBonuses = _this4.obtainedBonuses.concat(myObtainedBonuses);
            if (myObtainedBonuses.length > 0) {
              /* eslint-disable camelcase */
              _this4.users.push({
                id: user.id,
                name: user.full_name,
                group_id: group[0].id,
                bonus_totals: _this4.bonuses.filter(function (bonus) {
                  return bonus.targetable_id == group[0].id;
                }).map(function (res) {
                  return {
                    bonus_id: res.id,
                    sum: _this4.getTotalSum(res.id, user.id)
                  };
                }),
                expanded: false
              });
              /* eslint-enable camelcase */
            }
          });

          var item = _this4.myGroups.filter(function (item) {
            return item.id === group[0].id;
          });
          if (!item.length) {
            /* eslint-disable camelcase */
            _this4.myGroups.push({
              id: group[0].id,
              name: group[0].name,
              activity_id: group[0].activity_id,
              expanded: false
            });
            /* eslint-enable camelcase */
          }
        }
      });

      this.myGroups.forEach(function (group) {
        var myUsers = _this4.users.filter(function (user) {
          return user.group_id == group.id;
        });
        _this4.items.push({
          id: group.id,
          activity: group.activity_id,
          name: group.name,
          users: myUsers,
          expanded: false
        });
      });
    },
    adjustFields: function adjustFields() {},
    expand: function expand(item) {
      item.expanded = !item.expanded;
    },
    /*bonuses(data){
              var bonuses = [];
              data.forEach(bonus => {
                  bonuses.push({
                      amount: bonus.amount,
                      bonus_id: bonus.bonus_id,
                      comment: bonus.comment,
                      date: bonus.date,
                      id: bonus.id,
                      user_id: bonus.user_id
                  });
              });
                return bonuses;
          },*/
    calculatedBonuses: function calculatedBonuses(obtainedBonuses) {
      var bonusTitles = [];
      var bonusPrices = [];
      obtainedBonuses.forEach(function (bonus) {
        if (!bonusTitles.some(function (s) {
          return s === bonus.comment;
        })) {
          bonusTitles.push(bonus.comment);
          bonusPrices.push({
            title: bonus.comment,
            sum: bonus.amount,
            date: bonus.date
          });
        } else {
          bonusPrices.filter(function (p) {
            return p.title === bonus.title;
          })[0].quantity += bonus.quantity;
        }
      });
      return bonusPrices;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable vue/no-mutating-props */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'StatsTableQuartal',
  props: {
    users: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    groups: {
      type: Array,
      "default": function _default() {
        return [];
      }
    },
    searchText: {
      type: String,
      "default": ''
    }
  },
  data: function data() {
    return {};
  },
  computed: {},
  watch: {},
  created: function created() {},
  mounted: function mounted() {},
  methods: {
    expandUser: function expandUser(i) {
      this.users[i].expanded = !this.users[i].expanded;
    },
    expandGroup: function expandGroup(i) {
      this.groups[i].expanded = !this.groups[i].expanded;
    },
    expandGroupUser: function expandGroupUser(i, p) {
      this.groups[p][i].expended = !this.groups[p][i].expended;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_Portal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/Portal */ "./resources/js/stores/Portal.js");
/* harmony import */ var _pages_kpi_KpiItemsV2__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/pages/kpi/KpiItemsV2 */ "./resources/js/pages/kpi/KpiItemsV2.vue");
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./kpis.js */ "./resources/js/pages/kpi/kpis.js");
/* harmony import */ var _kpis_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_kpis_js__WEBPACK_IMPORTED_MODULE_2__);
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase, vue/require-prop-types */





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'StatsTableV2',
  components: {
    KpiItemsV2: _pages_kpi_KpiItemsV2__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  props: {
    searchText: {
      "default": ''
    },
    items: {
      "default": []
    },
    activities: {
      "default": []
    },
    groups: {
      "default": []
    },
    editable: {
      "default": false
    },
    date: {
      "default": null
    },
    filters: {
      type: Object,
      "default": function _default() {
        return {};
      }
    }
  },
  data: function data() {
    return {
      show_fields: [],
      all_fields: _kpis_js__WEBPACK_IMPORTED_MODULE_2__.kpi_fields,
      fields: [],
      non_editable_fields: ['created_at', 'updated_at', 'created_by', 'updated_by'],
      types: {
        "App\\User": 1,
        'App\\ProfileGroup': 2,
        'App\\Position': 3
      },
      kpis: {
        1: {},
        2: {},
        3: {}
      },
      loading: {
        1: {},
        2: {},
        3: {}
      }
    };
  },
  computed: {
    reversedItems: function reversedItems() {
      return this.items.slice().reverse();
    }
  },
  watch: {
    show_fields: {
      handler: function handler(val) {
        localStorage.kpi_show_fields = JSON.stringify(val);
        this.prepareFields();
      },
      deep: true
    },
    items: function items() {
      this.resetKPI();
    }
  },
  created: function created() {
    this.prepareFields();
    this.countAvg();
  },
  mounted: function mounted() {},
  methods: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_3__.mapActions)(_stores_Portal__WEBPACK_IMPORTED_MODULE_0__.usePortalStore, ['getBacklightForValue'])), {}, {
    fetchKPI: function fetchKPI(id, ttype) {
      var _this = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var type, _data$kpi, _yield$_this$axios$po, data;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                type = _this.types[ttype];
                _this.$set(_this.loading[type], id, true);
                _context.prev = 2;
                _context.next = 5;
                return _this.axios.post("/statistics/kpi/groups-and-users/".concat(id), {
                  filters: _objectSpread(_objectSpread({}, _this.filters), {}, {
                    query: _this.searchText
                  })
                }, {
                  params: {
                    type: type
                  }
                });
              case 5:
                _yield$_this$axios$po = _context.sent;
                data = _yield$_this$axios$po.data;
                if (data !== null && data !== void 0 && (_data$kpi = data.kpi) !== null && _data$kpi !== void 0 && _data$kpi.users) {
                  _context.next = 9;
                  break;
                }
                return _context.abrupt("return", _this.$toast.error('Ошибка при получении данных kpi'));
              case 9:
                _this.$set(_this.kpis[type], id, (0,_kpis_js__WEBPACK_IMPORTED_MODULE_2__.parseKPI)(data === null || data === void 0 ? void 0 : data.kpi));
                _context.next = 15;
                break;
              case 12:
                _context.prev = 12;
                _context.t0 = _context["catch"](2);
                _this.$toast.error('Ошибка при получении данных kpi');
              case 15:
                _this.$delete(_this.loading[type], id);
              case 16:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[2, 12]]);
      }))();
    },
    closeKPI: function closeKPI(id, ttype) {
      var type = this.types[ttype];
      this.$delete(this.kpis[type], id);
    },
    resetKPI: function resetKPI() {
      this.kpis = {
        1: {},
        2: {},
        3: {}
      };
    },
    prepareFields: function prepareFields() {
      var _this2 = this;
      var visible_fields = [];
      _kpis_js__WEBPACK_IMPORTED_MODULE_2__.kpi_fields.forEach(function (field) {
        if (_this2.show_fields[field.key] != undefined && _this2.show_fields[field.key]) {
          visible_fields.push(field);
        }
      });
      this.fields = _kpis_js__WEBPACK_IMPORTED_MODULE_2__.kpi_fields;
    },
    countAvg: function countAvg() {
      this.items.forEach(function (kpi) {
        var kpi_sum = 0;
        var kpi_count = 0;
        kpi.users.forEach(function (user) {
          var count = 0;
          var sum = 0;
          var avg = 0;
          user.items.forEach(function (item) {
            sum += Number(item.percent);
            count++;
          });

          /**
          * count avg of user items
          */
          avg = count > 0 ? Number(sum / count).toFixed(2) : 0;
          user.avg = avg;

          // all kpi sum
          kpi_sum += Number(avg);
          kpi_count++;
        });
        /**
        * count avg completed percent of kpi by users
        */
        kpi.avg = kpi_count > 0 ? Number(Number(kpi_sum / kpi_count * 100).toFixed(2)) : 0;
      });
    }
  })
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_KPI__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/KPI */ "./resources/js/stores/KPI.js");
/* harmony import */ var _stores_Portal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/stores/Portal */ "./resources/js/stores/Portal.js");
/* harmony import */ var _composables_yearOptions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/composables/yearOptions */ "./resources/js/composables/yearOptions.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"]; if (null != _i) { var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1; try { if (_x = (_i = _i.call(arr)).next, 0 === i) { if (Object(_i) !== _i) return; _n = !1; } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0) { ; } } catch (err) { _d = !0, _e = err; } finally { try { if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return; } finally { if (_d) throw _e; } } return _arr; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





var now = new Date();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'StatsTableYear',
  components: {},
  filters: {
    nonFixedFloat: function nonFixedFloat(value) {
      if (typeof value === 'undefined') return '';
      return parseInt(value) === value ? value : value.toFixed(2);
    }
  },
  props: {
    year: {
      type: Number,
      "default": now.getFullYear()
    }
  },
  data: function data() {
    return {
      page: 1
    };
  },
  computed: _objectSpread(_objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_3__.mapState)(_stores_KPI__WEBPACK_IMPORTED_MODULE_0__.useKPIStore, ['statYear', 'isLoading'])), (0,pinia__WEBPACK_IMPORTED_MODULE_3__.mapState)(_stores_Portal__WEBPACK_IMPORTED_MODULE_1__.usePortalStore, ['portal'])), {}, {
    yearOptions: function yearOptions() {
      if (!this.portal.created_at) return [new Date().getFullYear()];
      return (0,_composables_yearOptions__WEBPACK_IMPORTED_MODULE_2__.useYearOptions)(new Date(this.portal.created_at).getFullYear());
    },
    stats: function stats() {
      var table = [];
      Object.entries(this.statYear.data).forEach(function (_ref) {
        var _ref2 = _slicedToArray(_ref, 2),
          month = _ref2[0],
          monthData = _ref2[1];
        monthData.forEach(function (kpi) {
          var id = "".concat(kpi.target.type, "-").concat(kpi.target.id);
          var index = table.findIndex(function (existsKPI) {
            return existsKPI.id == id;
          });
          if (!~index) {
            table.push({
              id: id,
              title: kpi.target.name,
              type: kpi.target.type,
              expanded: false,
              users: []
            });
            index = table.length - 1;
          }
          table[index][month] = kpi.avg;
          kpi.users.forEach(function (user) {
            var userIndex = table[index].users.findIndex(function (existsUser) {
              return existsUser.id === user.id;
            });
            if (!~userIndex) {
              table[index].users.push({
                id: user.id,
                name: "".concat(user.name)
              });
              userIndex = table[index].users.length - 1;
            }
            table[index].users[userIndex][month] = user.avg_percent;
          });
        });
      });
      table.forEach(function (row) {
        row.avg = 0;
        var monthCount = 0;
        Object.keys(row).forEach(function (month) {
          var intMonth = parseInt(month);
          if (Number.isNaN(intMonth)) return;
          if (typeof row[month] === 'undefined') return;
          row.avg += row[month];
          ++monthCount;
        });
        row.avg = monthCount ? row.avg / monthCount : 0;
        row.users.forEach(function (user) {
          user.avg = 0;
          var userMonthCount = 0;
          Object.keys(user).forEach(function (month) {
            var intUserMonth = parseInt(month);
            if (Number.isNaN(intUserMonth)) return;
            if (typeof user[month] === 'undefined') return;
            user.avg += user[month];
            ++userMonthCount;
          });
          user.avg = userMonthCount ? user.avg / userMonthCount : 0;
        });
      });
      return table;
    }
  }),
  watch: {
    'statYear.page': function statYearPage(value) {
      this.page = value;
    },
    page: function page(value) {
      this.setStatYearPage(value);
    },
    year: function year() {
      this.fetchStatYear(this.year);
    },
    'statYear.limit': function statYearLimit() {
      this.fetchStatYear(this.year);
    }
  },
  created: function created() {
    this.fetchStatYear(this.year, this.statYear.page, this.statYear.limit);
  },
  mounted: function mounted() {},
  methods: _objectSpread(_objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_3__.mapActions)(_stores_KPI__WEBPACK_IMPORTED_MODULE_0__.useKPIStore, ['fetchStatYear', 'setStatYearPage', 'setStatYearYear'])), (0,pinia__WEBPACK_IMPORTED_MODULE_3__.mapActions)(_stores_Portal__WEBPACK_IMPORTED_MODULE_1__.usePortalStore, ['getBacklightForValue'])), {}, {
    toggleKPI: function toggleKPI(kpi) {
      if (kpi.type === 1 || !kpi.users.length) return;
      this.$set(kpi, 'expanded', !kpi.expanded);
      this.$forceUpdate();
    }
  })
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsV2.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsV2.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/ui/Sidebar */ "./resources/js/components/ui/Sidebar.vue");
/* harmony import */ var _pages_kpi_SuperFilter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/pages/kpi/SuperFilter */ "./resources/js/pages/kpi/SuperFilter.vue");
/* harmony import */ var _pages_kpi_StatsTableV2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/pages/kpi/StatsTableV2 */ "./resources/js/pages/kpi/StatsTableV2.vue");
/* harmony import */ var _pages_kpi_StatsTableBonus__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/pages/kpi/StatsTableBonus */ "./resources/js/pages/kpi/StatsTableBonus.vue");
/* harmony import */ var _pages_kpi_StatsTableQuartal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/pages/kpi/StatsTableQuartal */ "./resources/js/pages/kpi/StatsTableQuartal.vue");
/* harmony import */ var _pages_kpi_StatsTableYear__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/pages/kpi/StatsTableYear */ "./resources/js/pages/kpi/StatsTableYear.vue");
/* harmony import */ var _stores_Portal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/stores/Portal */ "./resources/js/stores/Portal.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */



 // filter like bitrix






// import {formatDate} from './kpis.js';

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'KPIStatsV2',
  components: {
    SideBar: _components_ui_Sidebar__WEBPACK_IMPORTED_MODULE_0__["default"],
    SuperFilter: _pages_kpi_SuperFilter__WEBPACK_IMPORTED_MODULE_1__["default"],
    StatsTableV2: _pages_kpi_StatsTableV2__WEBPACK_IMPORTED_MODULE_2__["default"],
    StatsTableBonus: _pages_kpi_StatsTableBonus__WEBPACK_IMPORTED_MODULE_3__["default"],
    StatsTableQuartal: _pages_kpi_StatsTableQuartal__WEBPACK_IMPORTED_MODULE_4__["default"],
    StatsTableYear: _pages_kpi_StatsTableYear__WEBPACK_IMPORTED_MODULE_5__["default"]
  },
  props: {},
  data: function data() {
    return {
      searchText: new URL(location.href).searchParams.get('target') ? new URL(location.href).searchParams.get('target') : '',
      s_type_main: 1,
      month: new Date().getMonth(),
      active: 1,
      paginationKey: 1,
      pageSize: 20,
      items: [],
      all_items: [],
      page_items: [],
      groups: {},
      date: null,
      activities: [],
      bonus_items: [],
      bonus_groups: [],
      quartal_users: [],
      quartal_groups: [],
      currentPage: 1,
      totalRows: 1,
      perPage: 10,
      filters: {
        data_from: {}
      },
      isSettingsOpen: false,
      timeout: null
    };
  },
  computed: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_7__.mapState)(_stores_Portal__WEBPACK_IMPORTED_MODULE_6__.usePortalStore, ['kpiBacklight'])), {}, {
    isAdmin: function isAdmin() {
      return this.$laravel.is_admin;
    }
  }),
  watch: {
    pageSize: {
      handler: function handler(val) {
        if (val < 1) {
          val = 1;
          return;
        }
        if (val > 100) {
          val = 100;
          return;
        }
        this.paginationKey++;
      }
    },
    perPage: function perPage() {
      this.pageSize = this.perPage;
      this.fetchData(this.filters, 1, this.perPage);
    },
    currentPage: function currentPage() {
      this.fetchData(this.filters, this.currentPage, this.perPage);
    },
    searchText: function searchText() {
      this.onSearchQuery();
    }
  },
  created: function created() {
    this.fetchData({});
    this.page_items = this.items.slice(0, this.pageSize);
  },
  mounted: function mounted() {
    var _this = this;
    this.$watch('$refs.child.searchText', function (new_value) {
      return _this.searchText = new_value;
    });
    this.fetchPortal();
  },
  methods: _objectSpread(_objectSpread({}, (0,pinia__WEBPACK_IMPORTED_MODULE_7__.mapActions)(_stores_Portal__WEBPACK_IMPORTED_MODULE_6__.usePortalStore, ['fetchPortal', 'updatePortal', 'addBacklightColor', 'deleteBacklightColor', 'updateBacklightColors'])), {}, {
    onChangePage: function onChangePage(page_items) {
      this.page_items = page_items;
    },
    fetchData: function fetchData(filters) {
      var _this2 = this;
      var page = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
      var limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 10;
      var loader = this.$loading.show();
      this.s_type_main = filters.data_from ? Number(filters.data_from.s_type) : 1;
      this.month = filters.data_from ? filters.data_from.month : new Date().getMonth();
      this.filters = filters;
      if (![1, 2, 3].includes(this.s_type_main)) this.s_type_main = 1;
      if (this.s_type_main == 1) {
        this.axios.post('/statistics/kpi/groups-and-users', {
          filters: _objectSpread(_objectSpread({}, filters), {}, {
            query: this.searchText
          })
        }, {
          params: {
            page: page,
            limit: limit
          }
        }).then(function (_ref) {
          var data = _ref.data;
          // items
          _this2.items = data.paginator.data;
          _this2.totalRows = data.paginator.total;
          // this.activities = data.activities;
          _this2.groups = data.groups;

          // paginate
          _this2.page_items = _this2.items.slice(0, _this2.pageSize);
          _this2.date = filters.data_from != undefined ? new Date(filters.data_from.year, filters.data_from.month, 1).toISOString().substring(0, 10) : new Date().toISOString().substring(0, 10);
          loader.hide();
        })["catch"](function (error) {
          loader.hide();
          alert(error);
        });
      } else if (this.s_type_main == 2) {
        this.axios.get('/statistics/bonuses').then(function (response) {
          _this2.bonus_groups = response.data;
          loader.hide();
        })["catch"](function (error) {
          loader.hide();
          alert(error);
        });
      } else if (this.s_type_main == 3) {
        this.axios.get('/statistics/quartal-premiums').then(function (response) {
          _this2.quartal_users = response.data[0].map(function (res) {
            return _objectSpread(_objectSpread({}, res), {}, {
              expanded: false
            });
          });
          _this2.quartal_groups = response.data[1].map(function (res) {
            return _objectSpread(_objectSpread({}, res), {}, {
              expanded: false
            });
          });
          loader.hide();
        })["catch"](function (error) {
          loader.hide();
          alert(error);
        });
      } else {
        loader.hide();
        alert('error!');
      }
    },
    onSearchQuery: function onSearchQuery() {
      var _this3 = this;
      if (this.timeout) clearTimeout(this.timeout);
      this.timeout = setTimeout(function () {
        _this3.fetchData(_objectSpread(_objectSpread({}, _this3.filters), {}, {
          query: _this3.searchText
        }));
      }, 300);
    }
  })
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable camelcase */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'SuperFilter',
  props: {
    groups: {
      type: Array,
      "default": function _default() {
        return [];
      }
    }
  },
  data: function data() {
    return {
      show: false,
      searchText: '',
      // options
      years: [],
      dates: {},
      s_types: {},
      filters: {},
      // filters
      group_id: 0,
      s_type: 1,
      data_from: {
        month: new Date().getMonth() + 1,
        year: new Date().getFullYear(),
        s_type: 1
      },
      created_at: {
        variant: 0,
        month: new Date().getMonth() + 1,
        year: new Date().getFullYear(),
        from: null,
        to: null
      }
    };
  },
  created: function created() {
    this.prepare();
  },
  methods: {
    prepare: function prepare() {
      this.fillYears();
      this.fillFiltersObj();
      this.changeDate('data_from', 'month');
    },
    clear: function clear() {
      this.searchText = '';
    },
    fillFiltersObj: function fillFiltersObj() {
      this.group_id = 0;
      this.dates = {
        0: 'Любая дата',
        1: 'Вчера',
        2: 'Сегодня',
        3: 'Завтра',
        4: 'Текущий месяц',
        5: 'Месяц',
        6: 'Диапазон'
      };
      this.s_types = {
        1: 'KPI',
        2: 'Бонусы',
        3: 'Квартальная премия'
      };
    },
    fillYears: function fillYears() {
      var years = [];
      var currentYear = new Date().getFullYear();
      for (var i = currentYear; i > 1999; i--) {
        years.push(i);
      }
      this.years = years;
    },
    applyFilter: function applyFilter() {
      this.$emit('apply', this.filters);
      this.show = false;
    },
    change: function change(field) {
      if (field == 'group_id') {
        if (this.group_id == 0) {
          delete this.filters.group_id;
        } else {
          this.filters.group_id = this.group_id;
        }
      }
      this.data_from.s_type = field;
    },
    changeDate: function changeDate(field /* , prop */) {
      if (field == 'created_at') this.filters.created_at = this.created_at;
      if (field == 'data_from') this.filters.data_from = this.data_from;
    },
    close: function close() {
      this.show = false;
    }
  }
});

/***/ }),

/***/ "./resources/js/pages/kpi/bonuses.js":
/*!*******************************************!*\
  !*** ./resources/js/pages/kpi/bonuses.js ***!
  \*******************************************/
/***/ ((module) => {

/* eslint-disable camelcase */

var fields = [{
  name: 'Кому',
  key: 'target',
  visible: true,
  type: 'superselect',
  "class": 'text-left w-lg',
  alter_class: 'col-md-12'
}, {
  name: 'Название',
  key: 'title',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-12'
}, {
  name: 'Показатели',
  key: 'activity_id',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-12'
}, {
  name: 'За',
  key: 'unit',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-4'
}, {
  name: 'Кол-во',
  key: 'quantity',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-4'
}, {
  name: 'Вознаграждение, %',
  key: 'sum',
  visible: true,
  type: 'number',
  "class": 'text-center wsnw',
  alter_class: 'col-md-4 wsnw'
}, {
  name: 'Период',
  key: 'daypart',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Текст',
  key: 'text',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Дата создания',
  key: 'created_at',
  visible: true,
  type: 'date',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Дата изменения',
  key: 'updated_at',
  visible: true,
  type: 'date',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Постановщик',
  key: 'created_by',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Изменил',
  key: 'updated_by',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-6'
}];

// dates
function formatDate(d) {
  var day = d.getDate() + '';
  if (day.length == 1) day = '0' + day;
  var month = d.getMonth() + 1 + '';
  if (month.length == 1) month = '0' + month;
  return day + '.' + month + '.' + d.getFullYear() + ' ' + d.getHours() + ':' + d.getMinutes();
}
var datestring = formatDate(new Date());
function newBonus() {
  return {
    id: 0,
    target: null,
    title: '',
    sum: 0,
    source: 0,
    group_id: 0,
    activity_id: 0,
    unit: 'all',
    quantity: 1,
    daypart: 0,
    from: null,
    to: null,
    text: '',
    created_at: datestring,
    updated_at: datestring,
    created_by: 'Вы',
    updated_by: 'Вы',
    expanded: false,
    is_active: 1
  };
}

// eslint-disable-next-line no-undef
module.exports = {
  fields: fields,
  newBonus: newBonus
};

/***/ }),

/***/ "./resources/js/pages/kpi/helpers.js":
/*!*******************************************!*\
  !*** ./resources/js/pages/kpi/helpers.js ***!
  \*******************************************/
/***/ ((module) => {

function findModel() {
  var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
  var text = '';
  if (type == 1) text = "App\\User";
  if (type == 2) text = 'App\\ProfileGroup';
  if (type == 3) text = 'App\\Position';
  return text;
}
function groupBy(xs, key) {
  return xs.reduce(function (rv, x) {
    (rv[x[key]] = rv[x[key]] || []).push(x);
    return rv;
  }, {});
}

// sources of activities
var sources = {
  0: 'без источника',
  1: 'вкладка "Аналитика"'
};

// sources of activities OLD "Адиль сказал пока убрать все, кроме Аналитики"
// let sources = {
// 	0: 'без источника',
// 	1: 'вкладка "Аналитика"',
// 	2: 'из битрикса',
// 	3: 'из амосрм',
// 	4: 'другие',
// 	5: 'вкладка "Табель"',
// 	6: 'вкладка "HR"',
// }

// kpi methods
var methods = {
  1: 'сумма',
  2: 'сред значение',
  3: 'сумма не более',
  4: 'среднее не более',
  5: 'сумма не менее',
  6: 'среднее не менее'
};

// views of activities
var views = {
  0: 'по умолчанию',
  1: 'коллекция',
  2: 'контроль качества',
  3: 'рентабельность',
  4: 'текучка',
  5: 'кол-во сотрудников',
  6: 'конверсия'
};

// eslint-disable-next-line no-undef
module.exports = {
  findModel: findModel,
  groupBy: groupBy,
  sources: sources,
  methods: methods,
  views: views
};

/***/ }),

/***/ "./resources/js/pages/kpi/indicators.js":
/*!**********************************************!*\
  !*** ./resources/js/pages/kpi/indicators.js ***!
  \**********************************************/
/***/ ((module) => {

/* eslint-disable camelcase */

var fields = [{
  name: 'Название',
  key: 'name',
  visible: true,
  type: 'text',
  "class": 'text-left w-lg',
  alter_class: 'col-md-12'
}, {
  name: 'Источник',
  key: 'source',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-12'
}, {
  name: 'Функция',
  key: 'method',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-4'
}, {
  name: 'Дневной план',
  key: 'daily_plan',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-4'
}, {
  name: 'Ед.изм.',
  key: 'unit',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-4'
}, {
  name: 'Вид',
  key: 'view',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-3'
}, {
  name: 'Рабочие дни',
  key: 'weekdays',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-3'
}, {
  name: 'Очередь',
  key: 'order',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-3'
}, {
  name: 'Редактируемый',
  key: 'editable',
  visible: true,
  type: 'checkbox',
  "class": 'text-center',
  alter_class: 'col-md-3'
}, {
  name: 'Дата создания',
  key: 'created_at',
  visible: true,
  type: 'date',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Дата изменения',
  key: 'updated_at',
  visible: true,
  type: 'date',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Постановщик',
  key: 'created_by',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Изменил',
  key: 'updated_by',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-6'
}];

// dates
function formatDate(d) {
  var day = d.getDate() + '';
  if (day.length == 1) day = '0' + day;
  var month = d.getMonth() + 1 + '';
  if (month.length == 1) month = '0' + month;
  return d.getDate() + '.' + month + '.' + d.getFullYear() + ' ' + d.getHours() + ':' + d.getMinutes();
}
var datestring = formatDate(new Date());
function newItem() {
  return {
    id: 0,
    name: '',
    source: 0,
    method: 1,
    daily_plan: 0,
    unit: '',
    view: 0,
    weekdays: 5,
    order: 0,
    group_id: 0,
    editable: true,
    created_at: datestring,
    updated_at: datestring,
    created_by: 'Вы',
    updated_by: 'Вы'
  };
}

// eslint-disable-next-line no-undef
module.exports = {
  fields: fields,
  newItem: newItem
};

/***/ }),

/***/ "./resources/js/pages/kpi/quartal_premiums.js":
/*!****************************************************!*\
  !*** ./resources/js/pages/kpi/quartal_premiums.js ***!
  \****************************************************/
/***/ ((module) => {

/* eslint-disable camelcase */

var fields = [{
  name: 'Кому',
  key: 'target',
  visible: true,
  type: 'superselect',
  "class": 'text-left w-230',
  alter_class: 'col-md-12'
}, {
  name: 'Название',
  key: 'title',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-12'
}, {
  name: 'Показатели',
  key: 'activity_id',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-12'
}, {
  name: 'План',
  key: 'plan',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-2'
}, {
  name: 'Вознаграждение',
  key: 'sum',
  visible: true,
  type: 'number',
  "class": 'text-center',
  alter_class: 'col-md-2'
}, {
  name: 'Период с',
  key: 'from',
  visible: true,
  type: 'date',
  "class": 'text-center',
  alter_class: 'col-md-4'
}, {
  name: 'Период по',
  key: 'to',
  visible: true,
  type: 'date',
  "class": 'text-center',
  alter_class: 'col-md-4'
}, {
  name: 'Текст',
  key: 'text',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-12'
}, {
  name: 'Дата создания',
  key: 'created_at',
  visible: true,
  type: 'date',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Дата изменения',
  key: 'updated_at',
  visible: true,
  type: 'date',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Постановщик',
  key: 'created_by',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-6'
}, {
  name: 'Изменил',
  key: 'updated_by',
  visible: true,
  type: 'text',
  "class": 'text-center',
  alter_class: 'col-md-6'
}];

// dates
function formatDate(d) {
  var day = d.getDate() + '';
  if (day.length == 1) day = '0' + day;
  var month = d.getMonth() + 1 + '';
  if (month.length == 1) month = '0' + month;
  return d.getDate() + '.' + month + '.' + d.getFullYear() + ' ' + d.getHours() + ':' + d.getMinutes();
}
var datestring = formatDate(new Date());
function newQuartalPremium() {
  return {
    id: 0,
    target: null,
    title: '',
    source: 0,
    group_id: 0,
    activity_id: 0,
    sum: 0,
    plan: 1,
    from: null,
    to: null,
    text: '',
    created_at: datestring,
    updated_at: datestring,
    created_by: 'Вы',
    updated_by: 'Вы',
    expanded: false,
    is_active: true
  };
}

// eslint-disable-next-line no-undef
module.exports = {
  fields: fields,
  newQuartalPremium: newQuartalPremium
};

/***/ }),

/***/ "./resources/js/stores/KPI.js":
/*!************************************!*\
  !*** ./resources/js/stores/KPI.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useKPIStore": () => (/* binding */ useKPIStore)
/* harmony export */ });
/* harmony import */ var pinia__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! pinia */ "./node_modules/pinia/dist/pinia.mjs");
/* harmony import */ var _stores_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/stores/api */ "./resources/js/stores/api.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }


function initialState() {
  var now = new Date();
  var currentYear = now.getFullYear();
  // const currentMonth = now.getMonth()
  return {
    statYear: {
      data: [],
      lastPage: 0,
      rows: 0,
      page: 1,
      limit: 10,
      year: currentYear
    }
  };
}
var useKPIStore = (0,pinia__WEBPACK_IMPORTED_MODULE_1__.defineStore)('kpi', {
  state: function state() {
    return _objectSpread({
      isLoading: {}
    }, initialState());
  },
  actions: {
    fetchStatYear: function fetchStatYear() {
      var _arguments = arguments,
        _this = this;
      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var year, page, limit, _yield$fetchKPIStatYe, paginator;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                year = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : _this.statYear.year;
                page = _arguments.length > 1 && _arguments[1] !== undefined ? _arguments[1] : _this.statYear.page;
                limit = _arguments.length > 2 && _arguments[2] !== undefined ? _arguments[2] : _this.statYear.limit;
                _this.isLoading.year = true;
                _context.prev = 4;
                _context.next = 7;
                return (0,_stores_api__WEBPACK_IMPORTED_MODULE_0__.fetchKPIStatYear)({
                  year: year,
                  page: page,
                  limit: limit
                });
              case 7:
                _yield$fetchKPIStatYe = _context.sent;
                paginator = _yield$fetchKPIStatYe.paginator;
                _this.statYear.data = paginator.data;
                _this.statYear.lastPage = paginator.last_page;
                _this.statYear.page = paginator.current_page;
                _this.statYear.rows = paginator.total;
                _context.next = 18;
                break;
              case 15:
                _context.prev = 15;
                _context.t0 = _context["catch"](4);
                console.error('fetchKPIStatYear', _context.t0);
              case 18:
                _this.isLoading.year = false;
              case 19:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[4, 15]]);
      }))();
    },
    setStatYearPage: function setStatYearPage(page) {
      if (this.statYear.page === page) return;
      this.statYear.page = page;
      this.fetchStatYear();
    },
    setStatYearYear: function setStatYearYear(year) {
      if (this.statYear.year === year) return;
      this.statYear.year = year;
      this.fetchStatYear();
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".bonuses-table tbody th, .bonuses-table tbody td {\n  vertical-align: middle;\n}\n.KPIBonuses-icon-info {\n  width: 1.6rem;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=style&index=0&lang=scss&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=style&index=0&lang=scss& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".kpi-tabs {\n  overflow: visible !important;\n}\n.kpi-status-switch {\n  position: relative;\n}\n.kpi-pages .kpi .kpi-status-switch {\n  margin-left: auto;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".child-table[data-v-1724985f] {\n  width: 100%;\n}\n.profile-salary-info .table td[data-v-1724985f], .profile-salary-info .table th[data-v-1724985f], .profile-salary-info .table thead th[data-v-1724985f] {\n  vertical-align: middle;\n  min-width: 42px;\n  font-size: 13px;\n  padding: 5px 12px;\n  text-align: center;\n}\n.profile-salary-info .j-table .table-inner[data-v-1724985f] {\n  background: #e9eef3;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".StatsTableYear {\n  position: relative;\n}\n.StatsTableYear .StatsTableYear-table .first-column {\n  width: 20rem;\n}\n.StatsTableYear-subrow {\n  background-color: #F7FAFC;\n}\n.StatsTableYear-firstCol {\n  display: flex;\n  justify-content: space-between;\n}\n.KPIBacklight-row {\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n  margin-bottom: 1rem;\n}\n.KPIBacklight-input {\n  display: inline-flex;\n  width: auto;\n}\n.KPIBacklight-input[type=color] {\n  padding: 0 !important;\n  min-width: 4rem;\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=style&index=0&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=style&index=0&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.kpi-name-rows{\n\tdisplay: inline-flex;\n\tflex-flow: column;\n}\n.kpi-name-row{\n\tfont-size: 1.2rem;\n\tcolor: #777;\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.search-btn[data-v-032ffa6f] {\n    position: absolute;\n    right: 20px;\n    top: 12px;\n}\n.block[data-v-032ffa6f] {\n  transform: translateY(20px);\n  transition: 1.5s;\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/jw-vue-pagination/lib/JwPagination.js":
/*!************************************************************!*\
  !*** ./node_modules/jw-vue-pagination/lib/JwPagination.js ***!
  \************************************************************/
/***/ ((module) => {

module.exports=function(e){var t={};function s(r){if(t[r])return t[r].exports;var a=t[r]={i:r,l:!1,exports:{}};return e[r].call(a.exports,a,a.exports,s),a.l=!0,a.exports}return s.m=e,s.c=t,s.d=function(e,t,r){s.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:r})},s.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},s.t=function(e,t){if(1&t&&(e=s(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var r=Object.create(null);if(s.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var a in e)s.d(r,a,function(t){return e[t]}.bind(null,a));return r},s.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return s.d(t,"a",t),t},s.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},s.p="",s(s.s=1)}([function(e,t,s){"use strict";e.exports=function(e,t,s,r){void 0===t&&(t=1),void 0===s&&(s=10),void 0===r&&(r=10);var a,n,i=Math.ceil(e/s);if(t<1?t=1:t>i&&(t=i),i<=r)a=1,n=i;else{var l=Math.floor(r/2),o=Math.ceil(r/2)-1;t<=l?(a=1,n=r):t+o>=i?(a=i-r+1,n=i):(a=t-l,n=t+o)}var c=(t-1)*s,u=Math.min(c+s-1,e-1),p=Array.from(Array(n+1-a).keys()).map(function(e){return a+e});return{totalItems:e,currentPage:t,pageSize:s,totalPages:i,startPage:a,endPage:n,startIndex:c,endIndex:u,pages:p}}},function(e,t,s){"use strict";s.r(t);var r=function(){var e=this,t=e.$createElement,s=e._self._c||t;return e.pager.pages&&e.pager.pages.length?s("ul",{staticClass:"pagination",style:e.ulStyles},[s("li",{staticClass:"page-item first",class:{disabled:1===e.pager.currentPage},style:e.liStyles},[s("a",{staticClass:"page-link",style:e.aStyles,on:{click:function(t){return e.setPage(1)}}},[e._v(e._s(e.labels.first))])]),e._v(" "),s("li",{staticClass:"page-item previous",class:{disabled:1===e.pager.currentPage},style:e.liStyles},[s("a",{staticClass:"page-link",style:e.aStyles,on:{click:function(t){return e.setPage(e.pager.currentPage-1)}}},[e._v(e._s(e.labels.previous))])]),e._v(" "),e._l(e.pager.pages,function(t){return s("li",{key:t,staticClass:"page-item page-number",class:{active:e.pager.currentPage===t},style:e.liStyles},[s("a",{staticClass:"page-link",style:e.aStyles,on:{click:function(s){return e.setPage(t)}}},[e._v(e._s(t))])])}),e._v(" "),s("li",{staticClass:"page-item next",class:{disabled:e.pager.currentPage===e.pager.totalPages},style:e.liStyles},[s("a",{staticClass:"page-link",style:e.aStyles,on:{click:function(t){return e.setPage(e.pager.currentPage+1)}}},[e._v(e._s(e.labels.next))])]),e._v(" "),s("li",{staticClass:"page-item last",class:{disabled:e.pager.currentPage===e.pager.totalPages},style:e.liStyles},[s("a",{staticClass:"page-link",style:e.aStyles,on:{click:function(t){return e.setPage(e.pager.totalPages)}}},[e._v(e._s(e.labels.last))])])],2):e._e()};r._withStripped=!0;var a=s(0),n=s.n(a);function i(e,t){var s=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),s.push.apply(s,r)}return s}function l(e){for(var t=1;t<arguments.length;t++){var s=null!=arguments[t]?arguments[t]:{};t%2?i(s,!0).forEach(function(t){o(e,t,s[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(s)):i(s).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(s,t))})}return e}function o(e,t,s){return t in e?Object.defineProperty(e,t,{value:s,enumerable:!0,configurable:!0,writable:!0}):e[t]=s,e}var c={first:"First",last:"Last",previous:"Previous",next:"Next"},u={margin:0,padding:0,display:"inline-block"},p={listStyle:"none",display:"inline",textAlign:"center"},g={cursor:"pointer",padding:"6px 12px",display:"block",float:"left"};var f=function(e,t,s,r,a,n,i,l){var o,c="function"==typeof e?e.options:e;if(t&&(c.render=t,c.staticRenderFns=s,c._compiled=!0),r&&(c.functional=!0),n&&(c._scopeId="data-v-"+n),i?(o=function(e){(e=e||this.$vnode&&this.$vnode.ssrContext||this.parent&&this.parent.$vnode&&this.parent.$vnode.ssrContext)||"undefined"==typeof __VUE_SSR_CONTEXT__||(e=__VUE_SSR_CONTEXT__),a&&a.call(this,e),e&&e._registeredComponents&&e._registeredComponents.add(i)},c._ssrRegister=o):a&&(o=l?function(){a.call(this,this.$root.$options.shadowRoot)}:a),o)if(c.functional){c._injectStyles=o;var u=c.render;c.render=function(e,t){return o.call(t),u(e,t)}}else{var p=c.beforeCreate;c.beforeCreate=p?[].concat(p,o):[o]}return{exports:e,options:c}}({props:{items:{type:Array,required:!0},initialPage:{type:Number,default:1},pageSize:{type:Number,default:10},maxPages:{type:Number,default:10},labels:{type:Object,default:function(){return c}},styles:{type:Object},disableDefaultStyles:{type:Boolean,default:!1}},data:function(){return{pager:{},ulStyles:{},liStyles:{},aStyles:{}}},created:function(){if(!this.$listeners.changePage)throw'Missing required event listener: "changePage"';this.disableDefaultStyles||(this.ulStyles=u,this.liStyles=p,this.aStyles=g),this.styles&&(this.ulStyles=l({},this.ulStyles,{},this.styles.ul),this.liStyles=l({},this.liStyles,{},this.styles.li),this.aStyles=l({},this.aStyles,{},this.styles.a)),this.setPage(this.initialPage)},methods:{setPage:function(e){var t=this.items,s=this.pageSize,r=this.maxPages,a=n()(t.length,e,s,r),i=t.slice(a.startIndex,a.endIndex+1);this.pager=a,this.$emit("changePage",i)}},watch:{items:function(){this.setPage(this.initialPage)}}},r,[],!1,null,null,null);f.options.__file="src/JwPagination.vue";t.default=f.exports}]);

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Bonuses_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Bonuses.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Bonuses_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Bonuses_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiPages_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiPages.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiPages_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiPages_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableV2_vue_vue_type_style_index_0_id_1724985f_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableV2_vue_vue_type_style_index_0_id_1724985f_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableV2_vue_vue_type_style_index_0_id_1724985f_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableYear_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableYear.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=style&index=0&lang=scss&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableYear_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableYear_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=style&index=0&lang=css&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=style&index=0&lang=css& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Kpi_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Kpi.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=style&index=0&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Kpi_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Kpi_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_SuperFilter_vue_vue_type_style_index_0_id_032ffa6f_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_SuperFilter_vue_vue_type_style_index_0_id_032ffa6f_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_SuperFilter_vue_vue_type_style_index_0_id_032ffa6f_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/pages/kpi/Bonuses.vue":
/*!********************************************!*\
  !*** ./resources/js/pages/kpi/Bonuses.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Bonuses_vue_vue_type_template_id_aae91cae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Bonuses.vue?vue&type=template&id=aae91cae& */ "./resources/js/pages/kpi/Bonuses.vue?vue&type=template&id=aae91cae&");
/* harmony import */ var _Bonuses_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Bonuses.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/Bonuses.vue?vue&type=script&lang=js&");
/* harmony import */ var _Bonuses_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Bonuses.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/kpi/Bonuses.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Bonuses_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Bonuses_vue_vue_type_template_id_aae91cae___WEBPACK_IMPORTED_MODULE_0__.render,
  _Bonuses_vue_vue_type_template_id_aae91cae___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/Bonuses.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/Indicators.vue":
/*!***********************************************!*\
  !*** ./resources/js/pages/kpi/Indicators.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Indicators_vue_vue_type_template_id_ac69ec50___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Indicators.vue?vue&type=template&id=ac69ec50& */ "./resources/js/pages/kpi/Indicators.vue?vue&type=template&id=ac69ec50&");
/* harmony import */ var _Indicators_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Indicators.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/Indicators.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Indicators_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Indicators_vue_vue_type_template_id_ac69ec50___WEBPACK_IMPORTED_MODULE_0__.render,
  _Indicators_vue_vue_type_template_id_ac69ec50___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/Indicators.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/Kpi.vue":
/*!****************************************!*\
  !*** ./resources/js/pages/kpi/Kpi.vue ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Kpi_vue_vue_type_template_id_4821a280___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Kpi.vue?vue&type=template&id=4821a280& */ "./resources/js/pages/kpi/Kpi.vue?vue&type=template&id=4821a280&");
/* harmony import */ var _Kpi_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Kpi.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/Kpi.vue?vue&type=script&lang=js&");
/* harmony import */ var _Kpi_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Kpi.vue?vue&type=style&index=0&lang=css& */ "./resources/js/pages/kpi/Kpi.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Kpi_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Kpi_vue_vue_type_template_id_4821a280___WEBPACK_IMPORTED_MODULE_0__.render,
  _Kpi_vue_vue_type_template_id_4821a280___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/Kpi.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/KpiItems.vue":
/*!*********************************************!*\
  !*** ./resources/js/pages/kpi/KpiItems.vue ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _KpiItems_vue_vue_type_template_id_bdb891e0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./KpiItems.vue?vue&type=template&id=bdb891e0& */ "./resources/js/pages/kpi/KpiItems.vue?vue&type=template&id=bdb891e0&");
/* harmony import */ var _KpiItems_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./KpiItems.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/KpiItems.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _KpiItems_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _KpiItems_vue_vue_type_template_id_bdb891e0___WEBPACK_IMPORTED_MODULE_0__.render,
  _KpiItems_vue_vue_type_template_id_bdb891e0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/KpiItems.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/KpiItemsV2.vue":
/*!***********************************************!*\
  !*** ./resources/js/pages/kpi/KpiItemsV2.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./KpiItemsV2.vue?vue&type=template&id=2775d5ac& */ "./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac&");
/* harmony import */ var _KpiItemsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./KpiItemsV2.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _KpiItemsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__.render,
  _KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/KpiItemsV2.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/KpiPages.vue":
/*!*********************************************!*\
  !*** ./resources/js/pages/kpi/KpiPages.vue ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _KpiPages_vue_vue_type_template_id_55721d14___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./KpiPages.vue?vue&type=template&id=55721d14& */ "./resources/js/pages/kpi/KpiPages.vue?vue&type=template&id=55721d14&");
/* harmony import */ var _KpiPages_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./KpiPages.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/KpiPages.vue?vue&type=script&lang=js&");
/* harmony import */ var _KpiPages_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./KpiPages.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/kpi/KpiPages.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _KpiPages_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _KpiPages_vue_vue_type_template_id_55721d14___WEBPACK_IMPORTED_MODULE_0__.render,
  _KpiPages_vue_vue_type_template_id_55721d14___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/KpiPages.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/QuartalPremium.vue":
/*!***************************************************!*\
  !*** ./resources/js/pages/kpi/QuartalPremium.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _QuartalPremium_vue_vue_type_template_id_9794c83e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuartalPremium.vue?vue&type=template&id=9794c83e& */ "./resources/js/pages/kpi/QuartalPremium.vue?vue&type=template&id=9794c83e&");
/* harmony import */ var _QuartalPremium_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuartalPremium.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/QuartalPremium.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuartalPremium_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuartalPremium_vue_vue_type_template_id_9794c83e___WEBPACK_IMPORTED_MODULE_0__.render,
  _QuartalPremium_vue_vue_type_template_id_9794c83e___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/QuartalPremium.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableBonus.vue":
/*!****************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableBonus.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StatsTableBonus_vue_vue_type_template_id_e2d5a3e8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatsTableBonus.vue?vue&type=template&id=e2d5a3e8& */ "./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=template&id=e2d5a3e8&");
/* harmony import */ var _StatsTableBonus_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatsTableBonus.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _StatsTableBonus_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StatsTableBonus_vue_vue_type_template_id_e2d5a3e8___WEBPACK_IMPORTED_MODULE_0__.render,
  _StatsTableBonus_vue_vue_type_template_id_e2d5a3e8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/StatsTableBonus.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableQuartal.vue":
/*!******************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableQuartal.vue ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StatsTableQuartal_vue_vue_type_template_id_7d445157___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatsTableQuartal.vue?vue&type=template&id=7d445157& */ "./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=template&id=7d445157&");
/* harmony import */ var _StatsTableQuartal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatsTableQuartal.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _StatsTableQuartal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StatsTableQuartal_vue_vue_type_template_id_7d445157___WEBPACK_IMPORTED_MODULE_0__.render,
  _StatsTableQuartal_vue_vue_type_template_id_7d445157___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/StatsTableQuartal.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableV2.vue":
/*!*************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableV2.vue ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StatsTableV2_vue_vue_type_template_id_1724985f_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatsTableV2.vue?vue&type=template&id=1724985f&scoped=true& */ "./resources/js/pages/kpi/StatsTableV2.vue?vue&type=template&id=1724985f&scoped=true&");
/* harmony import */ var _StatsTableV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatsTableV2.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/StatsTableV2.vue?vue&type=script&lang=js&");
/* harmony import */ var _StatsTableV2_vue_vue_type_style_index_0_id_1724985f_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss& */ "./resources/js/pages/kpi/StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _StatsTableV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StatsTableV2_vue_vue_type_template_id_1724985f_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _StatsTableV2_vue_vue_type_template_id_1724985f_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "1724985f",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/StatsTableV2.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableYear.vue":
/*!***************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableYear.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StatsTableYear_vue_vue_type_template_id_0edfba40___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatsTableYear.vue?vue&type=template&id=0edfba40& */ "./resources/js/pages/kpi/StatsTableYear.vue?vue&type=template&id=0edfba40&");
/* harmony import */ var _StatsTableYear_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatsTableYear.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/StatsTableYear.vue?vue&type=script&lang=js&");
/* harmony import */ var _StatsTableYear_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./StatsTableYear.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/pages/kpi/StatsTableYear.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _StatsTableYear_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StatsTableYear_vue_vue_type_template_id_0edfba40___WEBPACK_IMPORTED_MODULE_0__.render,
  _StatsTableYear_vue_vue_type_template_id_0edfba40___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/StatsTableYear.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/StatsV2.vue":
/*!********************************************!*\
  !*** ./resources/js/pages/kpi/StatsV2.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StatsV2_vue_vue_type_template_id_46a30d17___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatsV2.vue?vue&type=template&id=46a30d17& */ "./resources/js/pages/kpi/StatsV2.vue?vue&type=template&id=46a30d17&");
/* harmony import */ var _StatsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatsV2.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/StatsV2.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _StatsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StatsV2_vue_vue_type_template_id_46a30d17___WEBPACK_IMPORTED_MODULE_0__.render,
  _StatsV2_vue_vue_type_template_id_46a30d17___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/StatsV2.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/SuperFilter.vue":
/*!************************************************!*\
  !*** ./resources/js/pages/kpi/SuperFilter.vue ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _SuperFilter_vue_vue_type_template_id_032ffa6f_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SuperFilter.vue?vue&type=template&id=032ffa6f&scoped=true& */ "./resources/js/pages/kpi/SuperFilter.vue?vue&type=template&id=032ffa6f&scoped=true&");
/* harmony import */ var _SuperFilter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SuperFilter.vue?vue&type=script&lang=js& */ "./resources/js/pages/kpi/SuperFilter.vue?vue&type=script&lang=js&");
/* harmony import */ var _SuperFilter_vue_vue_type_style_index_0_id_032ffa6f_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css& */ "./resources/js/pages/kpi/SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SuperFilter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SuperFilter_vue_vue_type_template_id_032ffa6f_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _SuperFilter_vue_vue_type_template_id_032ffa6f_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "032ffa6f",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/kpi/SuperFilter.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/kpi/Bonuses.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/pages/kpi/Bonuses.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Bonuses_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Bonuses.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Bonuses_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/Indicators.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/pages/kpi/Indicators.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Indicators_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Indicators.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Indicators.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Indicators_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/Kpi.vue?vue&type=script&lang=js&":
/*!*****************************************************************!*\
  !*** ./resources/js/pages/kpi/Kpi.vue?vue&type=script&lang=js& ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Kpi_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Kpi.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Kpi_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/KpiItems.vue?vue&type=script&lang=js&":
/*!**********************************************************************!*\
  !*** ./resources/js/pages/kpi/KpiItems.vue?vue&type=script&lang=js& ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItems_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiItems.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItems.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItems_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItemsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiItemsV2.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItemsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/KpiPages.vue?vue&type=script&lang=js&":
/*!**********************************************************************!*\
  !*** ./resources/js/pages/kpi/KpiPages.vue?vue&type=script&lang=js& ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiPages_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiPages.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiPages_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/QuartalPremium.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/pages/kpi/QuartalPremium.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuartalPremium_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./QuartalPremium.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/QuartalPremium.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuartalPremium_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableBonus_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableBonus.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableBonus_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableQuartal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableQuartal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableQuartal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableV2.vue?vue&type=script&lang=js&":
/*!**************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableV2.vue?vue&type=script&lang=js& ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableV2.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableYear.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableYear.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableYear_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableYear.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableYear_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/StatsV2.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsV2.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsV2.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsV2.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsV2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/SuperFilter.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./resources/js/pages/kpi/SuperFilter.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SuperFilter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SuperFilter.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SuperFilter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/kpi/Bonuses.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************!*\
  !*** ./resources/js/pages/kpi/Bonuses.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Bonuses_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Bonuses.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/kpi/KpiPages.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************!*\
  !*** ./resources/js/pages/kpi/KpiPages.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiPages_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiPages.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss& ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableV2_vue_vue_type_style_index_0_id_1724985f_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=style&index=0&id=1724985f&scoped=true&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableYear.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableYear.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_12_0_rules_0_use_3_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableYear_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!../../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableYear.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=style&index=0&lang=scss&");


/***/ }),

/***/ "./resources/js/pages/kpi/Kpi.vue?vue&type=style&index=0&lang=css&":
/*!*************************************************************************!*\
  !*** ./resources/js/pages/kpi/Kpi.vue?vue&type=style&index=0&lang=css& ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Kpi_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Kpi.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=style&index=0&lang=css&");


/***/ }),

/***/ "./resources/js/pages/kpi/SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/pages/kpi/SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css& ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_SuperFilter_vue_vue_type_style_index_0_id_032ffa6f_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=style&index=0&id=032ffa6f&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/pages/kpi/Bonuses.vue?vue&type=template&id=aae91cae&":
/*!***************************************************************************!*\
  !*** ./resources/js/pages/kpi/Bonuses.vue?vue&type=template&id=aae91cae& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Bonuses_vue_vue_type_template_id_aae91cae___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Bonuses_vue_vue_type_template_id_aae91cae___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Bonuses_vue_vue_type_template_id_aae91cae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Bonuses.vue?vue&type=template&id=aae91cae& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=template&id=aae91cae&");


/***/ }),

/***/ "./resources/js/pages/kpi/Indicators.vue?vue&type=template&id=ac69ec50&":
/*!******************************************************************************!*\
  !*** ./resources/js/pages/kpi/Indicators.vue?vue&type=template&id=ac69ec50& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Indicators_vue_vue_type_template_id_ac69ec50___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Indicators_vue_vue_type_template_id_ac69ec50___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Indicators_vue_vue_type_template_id_ac69ec50___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Indicators.vue?vue&type=template&id=ac69ec50& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Indicators.vue?vue&type=template&id=ac69ec50&");


/***/ }),

/***/ "./resources/js/pages/kpi/Kpi.vue?vue&type=template&id=4821a280&":
/*!***********************************************************************!*\
  !*** ./resources/js/pages/kpi/Kpi.vue?vue&type=template&id=4821a280& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Kpi_vue_vue_type_template_id_4821a280___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Kpi_vue_vue_type_template_id_4821a280___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Kpi_vue_vue_type_template_id_4821a280___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Kpi.vue?vue&type=template&id=4821a280& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=template&id=4821a280&");


/***/ }),

/***/ "./resources/js/pages/kpi/KpiItems.vue?vue&type=template&id=bdb891e0&":
/*!****************************************************************************!*\
  !*** ./resources/js/pages/kpi/KpiItems.vue?vue&type=template&id=bdb891e0& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItems_vue_vue_type_template_id_bdb891e0___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItems_vue_vue_type_template_id_bdb891e0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItems_vue_vue_type_template_id_bdb891e0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiItems.vue?vue&type=template&id=bdb891e0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItems.vue?vue&type=template&id=bdb891e0&");


/***/ }),

/***/ "./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac&":
/*!******************************************************************************!*\
  !*** ./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiItemsV2_vue_vue_type_template_id_2775d5ac___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiItemsV2.vue?vue&type=template&id=2775d5ac& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac&");


/***/ }),

/***/ "./resources/js/pages/kpi/KpiPages.vue?vue&type=template&id=55721d14&":
/*!****************************************************************************!*\
  !*** ./resources/js/pages/kpi/KpiPages.vue?vue&type=template&id=55721d14& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiPages_vue_vue_type_template_id_55721d14___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiPages_vue_vue_type_template_id_55721d14___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_KpiPages_vue_vue_type_template_id_55721d14___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./KpiPages.vue?vue&type=template&id=55721d14& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=template&id=55721d14&");


/***/ }),

/***/ "./resources/js/pages/kpi/QuartalPremium.vue?vue&type=template&id=9794c83e&":
/*!**********************************************************************************!*\
  !*** ./resources/js/pages/kpi/QuartalPremium.vue?vue&type=template&id=9794c83e& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_QuartalPremium_vue_vue_type_template_id_9794c83e___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_QuartalPremium_vue_vue_type_template_id_9794c83e___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_QuartalPremium_vue_vue_type_template_id_9794c83e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./QuartalPremium.vue?vue&type=template&id=9794c83e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/QuartalPremium.vue?vue&type=template&id=9794c83e&");


/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=template&id=e2d5a3e8&":
/*!***********************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=template&id=e2d5a3e8& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableBonus_vue_vue_type_template_id_e2d5a3e8___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableBonus_vue_vue_type_template_id_e2d5a3e8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableBonus_vue_vue_type_template_id_e2d5a3e8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableBonus.vue?vue&type=template&id=e2d5a3e8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=template&id=e2d5a3e8&");


/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=template&id=7d445157&":
/*!*************************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=template&id=7d445157& ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableQuartal_vue_vue_type_template_id_7d445157___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableQuartal_vue_vue_type_template_id_7d445157___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableQuartal_vue_vue_type_template_id_7d445157___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableQuartal.vue?vue&type=template&id=7d445157& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=template&id=7d445157&");


/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableV2.vue?vue&type=template&id=1724985f&scoped=true&":
/*!********************************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableV2.vue?vue&type=template&id=1724985f&scoped=true& ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableV2_vue_vue_type_template_id_1724985f_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableV2_vue_vue_type_template_id_1724985f_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableV2_vue_vue_type_template_id_1724985f_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableV2.vue?vue&type=template&id=1724985f&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=template&id=1724985f&scoped=true&");


/***/ }),

/***/ "./resources/js/pages/kpi/StatsTableYear.vue?vue&type=template&id=0edfba40&":
/*!**********************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsTableYear.vue?vue&type=template&id=0edfba40& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableYear_vue_vue_type_template_id_0edfba40___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableYear_vue_vue_type_template_id_0edfba40___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsTableYear_vue_vue_type_template_id_0edfba40___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsTableYear.vue?vue&type=template&id=0edfba40& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=template&id=0edfba40&");


/***/ }),

/***/ "./resources/js/pages/kpi/StatsV2.vue?vue&type=template&id=46a30d17&":
/*!***************************************************************************!*\
  !*** ./resources/js/pages/kpi/StatsV2.vue?vue&type=template&id=46a30d17& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsV2_vue_vue_type_template_id_46a30d17___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsV2_vue_vue_type_template_id_46a30d17___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatsV2_vue_vue_type_template_id_46a30d17___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatsV2.vue?vue&type=template&id=46a30d17& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsV2.vue?vue&type=template&id=46a30d17&");


/***/ }),

/***/ "./resources/js/pages/kpi/SuperFilter.vue?vue&type=template&id=032ffa6f&scoped=true&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/pages/kpi/SuperFilter.vue?vue&type=template&id=032ffa6f&scoped=true& ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SuperFilter_vue_vue_type_template_id_032ffa6f_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SuperFilter_vue_vue_type_template_id_032ffa6f_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SuperFilter_vue_vue_type_template_id_032ffa6f_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SuperFilter.vue?vue&type=template&id=032ffa6f&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=template&id=032ffa6f&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=template&id=aae91cae&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Bonuses.vue?vue&type=template&id=aae91cae& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "bonuses px-3 py-1" },
    [
      _c("div", { staticClass: "d-flex my-4 jcsb aifs" }, [
        _c(
          "div",
          { staticClass: "d-flex aic mr-2" },
          [
            _c("div", { staticClass: "d-flex aic mr-2" }, [
              _c("span", [_vm._v("Показывать:")]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.pageSize,
                    expression: "pageSize",
                  },
                ],
                staticClass: "form-control ml-2 input-sm",
                attrs: { type: "number", min: "1", max: "100" },
                domProps: { value: _vm.pageSize },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.pageSize = $event.target.value
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("SuperFilter", {
              ref: "child",
              attrs: { groups: _vm.groups },
              on: { apply: _vm.fetch },
            }),
            _vm._v(" "),
            _c("span", { staticClass: "ml-2" }, [
              _vm._v(
                "\n\t\t\t\t\tНайдено: " +
                  _vm._s(_vm.items.length) +
                  "\n\t\t\t\t"
              ),
            ]),
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "button",
          {
            staticClass: "btn rounded btn-success",
            on: { click: _vm.addItemRow },
          },
          [
            _c("i", { staticClass: "fa fa-plus mr-2" }),
            _vm._v(" "),
            _c("span", [_vm._v("Добавить")]),
          ]
        ),
      ]),
      _vm._v(" "),
      _c(
        "table",
        { staticClass: "j-table mb-3 collapse-table bonuses-table" },
        [
          _c("thead", [
            _c("tr", [
              _c(
                "th",
                {
                  staticClass: "text-center pointer",
                  on: { click: _vm.adjustFields },
                },
                [_c("i", { staticClass: "icon-nd-settings" })]
              ),
              _vm._v(" "),
              _c("th", { staticClass: "text-left w-100" }, [
                _vm._v("\n\t\t\t\t\t\tКому\n\t\t\t\t\t"),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c(
            "tbody",
            [
              _vm.bonus && _vm.newBonusesArray.length > 0
                ? [
                    _c("tr", [
                      _c(
                        "td",
                        {
                          staticClass: "text-center pointer",
                          on: {
                            click: function ($event) {
                              _vm.bonus.expanded = !_vm.bonus.expanded
                            },
                          },
                        },
                        [
                          _vm.bonus.expanded
                            ? _c("i", { staticClass: "fa fa-minus mt-1" })
                            : _c("i", { staticClass: "fa fa-plus mt-1" }),
                        ]
                      ),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-left" }, [
                        _vm.all_fields[0].key == "target"
                          ? _c(
                              "div",
                              { staticClass: "d-flex align-items-center" },
                              [
                                _vm.bonus.id == 0
                                  ? _c("SuperSelect", {
                                      staticStyle: { width: "60%" },
                                      attrs: {
                                        onlytype: 2,
                                        values:
                                          _vm.new_target == null &&
                                          _vm.newBonusesArray.length > 0
                                            ? []
                                            : [_vm.new_target],
                                        single: true,
                                      },
                                      on: {
                                        choose: function (target) {
                                          return (_vm.new_target = target)
                                        },
                                        remove: function () {
                                          return (_vm.new_target = null)
                                        },
                                      },
                                    })
                                  : _c("div", [
                                      _vm.bonus.target.type == 1
                                        ? _c("i", {
                                            staticClass:
                                              "fa fa-user ml-2 color-user",
                                          })
                                        : _vm._e(),
                                      _vm._v(" "),
                                      _vm.bonus.target.type == 2
                                        ? _c("i", {
                                            staticClass:
                                              "fa fa-users ml-2 color-group",
                                          })
                                        : _vm._e(),
                                      _vm._v(" "),
                                      _vm.bonus.target.type == 3
                                        ? _c("i", {
                                            staticClass:
                                              "fa fa-briefcase ml-2 color-position",
                                          })
                                        : _vm._e(),
                                      _vm._v(" "),
                                      _c("span", { staticClass: "ml-2" }, [
                                        _vm._v(_vm._s(_vm.bonus.target.name)),
                                      ]),
                                    ]),
                                _vm._v(" "),
                                _c("i", {
                                  staticClass:
                                    "fa fa-save btn btn-success ml-3",
                                  on: {
                                    click: function ($event) {
                                      return _vm.saveNewBonusArray()
                                    },
                                  },
                                }),
                              ],
                              1
                            )
                          : _vm._e(),
                      ]),
                    ]),
                    _vm._v(" "),
                    _vm.bonus.expanded
                      ? [
                          _c("tr", { staticClass: "collapsable active" }, [
                            _c(
                              "td",
                              { attrs: { colspan: _vm.fields.length + 2 } },
                              [
                                _c("div", { staticClass: "table__wrapper" }, [
                                  _c(
                                    "table",
                                    {
                                      staticClass:
                                        "table table-responsive table-inner",
                                    },
                                    [
                                      _c("thead", [
                                        _c(
                                          "tr",
                                          [
                                            _c("th", {
                                              staticClass: "text-center px-1",
                                            }),
                                            _vm._v(" "),
                                            _vm._l(
                                              _vm.fields,
                                              function (field, f) {
                                                return _c(
                                                  "th",
                                                  {
                                                    key: f,
                                                    staticClass: "text-left",
                                                    class: [
                                                      field.class,
                                                      {
                                                        "b-table-sticky-column l-2 hidden":
                                                          field.key == "target",
                                                      },
                                                    ],
                                                  },
                                                  [
                                                    _vm._v(
                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                        _vm._s(field.name) +
                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                    ),
                                                  ]
                                                )
                                              }
                                            ),
                                            _vm._v(" "),
                                            _c("th"),
                                          ],
                                          2
                                        ),
                                      ]),
                                      _vm._v(" "),
                                      _c(
                                        "tbody",
                                        [
                                          _vm._l(
                                            _vm.newBonusesArray,
                                            function (item, i) {
                                              return _c("tr", { key: i }, [
                                                _c("td"),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c("input", {
                                                    directives: [
                                                      {
                                                        name: "model",
                                                        rawName: "v-model",
                                                        value: item.title,
                                                        expression:
                                                          "item.title",
                                                      },
                                                    ],
                                                    attrs: { type: "text" },
                                                    domProps: {
                                                      value: item.title,
                                                    },
                                                    on: {
                                                      change: function (
                                                        $event
                                                      ) {
                                                        return _vm.validate(
                                                          item[_vm.field.key],
                                                          _vm.field.key
                                                        )
                                                      },
                                                      input: function ($event) {
                                                        if (
                                                          $event.target
                                                            .composing
                                                        ) {
                                                          return
                                                        }
                                                        _vm.$set(
                                                          item,
                                                          "title",
                                                          $event.target.value
                                                        )
                                                      },
                                                    },
                                                  }),
                                                ]),
                                                _vm._v(" "),
                                                _c(
                                                  "td",
                                                  { staticClass: "no-hover" },
                                                  [
                                                    _c(
                                                      "div",
                                                      { staticClass: "d-flex" },
                                                      [
                                                        _c(
                                                          "select",
                                                          {
                                                            directives: [
                                                              {
                                                                name: "model",
                                                                rawName:
                                                                  "v-model",
                                                                value:
                                                                  item.source,
                                                                expression:
                                                                  "item.source",
                                                              },
                                                            ],
                                                            on: {
                                                              change: [
                                                                function (
                                                                  $event
                                                                ) {
                                                                  var $$selectedVal =
                                                                    Array.prototype.filter
                                                                      .call(
                                                                        $event
                                                                          .target
                                                                          .options,
                                                                        function (
                                                                          o
                                                                        ) {
                                                                          return o.selected
                                                                        }
                                                                      )
                                                                      .map(
                                                                        function (
                                                                          o
                                                                        ) {
                                                                          var val =
                                                                            "_value" in
                                                                            o
                                                                              ? o._value
                                                                              : o.value
                                                                          return val
                                                                        }
                                                                      )
                                                                  _vm.$set(
                                                                    item,
                                                                    "source",
                                                                    $event
                                                                      .target
                                                                      .multiple
                                                                      ? $$selectedVal
                                                                      : $$selectedVal[0]
                                                                  )
                                                                },
                                                                function (
                                                                  $event
                                                                ) {
                                                                  ++_vm.source_key
                                                                },
                                                              ],
                                                            },
                                                          },
                                                          _vm._l(
                                                            Object.keys(
                                                              _vm.sources
                                                            ),
                                                            function (key) {
                                                              return _c(
                                                                "option",
                                                                {
                                                                  key: key,
                                                                  domProps: {
                                                                    value: key,
                                                                  },
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        _vm
                                                                          .sources[
                                                                          key
                                                                        ]
                                                                      ) +
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              )
                                                            }
                                                          ),
                                                          0
                                                        ),
                                                        _vm._v(" "),
                                                        Number(item.source) == 1
                                                          ? _c(
                                                              "select",
                                                              {
                                                                directives: [
                                                                  {
                                                                    name: "model",
                                                                    rawName:
                                                                      "v-model",
                                                                    value:
                                                                      item.group_id,
                                                                    expression:
                                                                      "item.group_id",
                                                                  },
                                                                ],
                                                                key:
                                                                  "a" +
                                                                  _vm.source_key,
                                                                on: {
                                                                  change:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      var $$selectedVal =
                                                                        Array.prototype.filter
                                                                          .call(
                                                                            $event
                                                                              .target
                                                                              .options,
                                                                            function (
                                                                              o
                                                                            ) {
                                                                              return o.selected
                                                                            }
                                                                          )
                                                                          .map(
                                                                            function (
                                                                              o
                                                                            ) {
                                                                              var val =
                                                                                "_value" in
                                                                                o
                                                                                  ? o._value
                                                                                  : o.value
                                                                              return val
                                                                            }
                                                                          )
                                                                      _vm.$set(
                                                                        item,
                                                                        "group_id",
                                                                        $event
                                                                          .target
                                                                          .multiple
                                                                          ? $$selectedVal
                                                                          : $$selectedVal[0]
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "option",
                                                                  {
                                                                    attrs: {
                                                                      value:
                                                                        "0",
                                                                      selected:
                                                                        "",
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _vm._l(
                                                                  _vm.groups,
                                                                  function (
                                                                    group,
                                                                    id
                                                                  ) {
                                                                    return _c(
                                                                      "option",
                                                                      {
                                                                        key: id,
                                                                        domProps:
                                                                          {
                                                                            value:
                                                                              id,
                                                                          },
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                            _vm._s(
                                                                              group
                                                                            ) +
                                                                            "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                        ),
                                                                      ]
                                                                    )
                                                                  }
                                                                ),
                                                              ],
                                                              2
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        Number(item.source) == 1
                                                          ? _c(
                                                              "select",
                                                              {
                                                                directives: [
                                                                  {
                                                                    name: "model",
                                                                    rawName:
                                                                      "v-model",
                                                                    value:
                                                                      item.activity_id,
                                                                    expression:
                                                                      "item.activity_id",
                                                                  },
                                                                ],
                                                                key:
                                                                  "b" +
                                                                  _vm.source_key,
                                                                on: {
                                                                  change:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      var $$selectedVal =
                                                                        Array.prototype.filter
                                                                          .call(
                                                                            $event
                                                                              .target
                                                                              .options,
                                                                            function (
                                                                              o
                                                                            ) {
                                                                              return o.selected
                                                                            }
                                                                          )
                                                                          .map(
                                                                            function (
                                                                              o
                                                                            ) {
                                                                              var val =
                                                                                "_value" in
                                                                                o
                                                                                  ? o._value
                                                                                  : o.value
                                                                              return val
                                                                            }
                                                                          )
                                                                      _vm.$set(
                                                                        item,
                                                                        "activity_id",
                                                                        $event
                                                                          .target
                                                                          .multiple
                                                                          ? $$selectedVal
                                                                          : $$selectedVal[0]
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "option",
                                                                  {
                                                                    attrs: {
                                                                      value:
                                                                        "0",
                                                                      selected:
                                                                        "",
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _vm._l(
                                                                  _vm.grouped_activities(
                                                                    item.source,
                                                                    item.group_id
                                                                  ),
                                                                  function (
                                                                    activity
                                                                  ) {
                                                                    return _c(
                                                                      "option",
                                                                      {
                                                                        key: activity.id,
                                                                        domProps:
                                                                          {
                                                                            value:
                                                                              activity.id,
                                                                          },
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                            _vm._s(
                                                                              activity.name
                                                                            ) +
                                                                            "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                        ),
                                                                      ]
                                                                    )
                                                                  }
                                                                ),
                                                              ],
                                                              2
                                                            )
                                                          : _vm._e(),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c(
                                                    "select",
                                                    {
                                                      directives: [
                                                        {
                                                          name: "model",
                                                          rawName: "v-model",
                                                          value: item.unit,
                                                          expression:
                                                            "item.unit",
                                                        },
                                                      ],
                                                      on: {
                                                        change: function (
                                                          $event
                                                        ) {
                                                          var $$selectedVal =
                                                            Array.prototype.filter
                                                              .call(
                                                                $event.target
                                                                  .options,
                                                                function (o) {
                                                                  return o.selected
                                                                }
                                                              )
                                                              .map(function (
                                                                o
                                                              ) {
                                                                var val =
                                                                  "_value" in o
                                                                    ? o._value
                                                                    : o.value
                                                                return val
                                                              })
                                                          _vm.$set(
                                                            item,
                                                            "unit",
                                                            $event.target
                                                              .multiple
                                                              ? $$selectedVal
                                                              : $$selectedVal[0]
                                                          )
                                                        },
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "option",
                                                        {
                                                          attrs: {
                                                            value: "0",
                                                            selected: "",
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                          ),
                                                        ]
                                                      ),
                                                      _vm._v(" "),
                                                      _vm._l(
                                                        Object.keys(_vm.units),
                                                        function (key) {
                                                          return _c(
                                                            "option",
                                                            {
                                                              key: key,
                                                              domProps: {
                                                                value: key,
                                                              },
                                                            },
                                                            [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                  _vm._s(
                                                                    _vm.units[
                                                                      key
                                                                    ]
                                                                  ) +
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                              ),
                                                            ]
                                                          )
                                                        }
                                                      ),
                                                    ],
                                                    2
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c(
                                                  "td",
                                                  { staticClass: "ho-hover" },
                                                  [
                                                    _c(
                                                      "div",
                                                      { staticClass: "d-flex" },
                                                      [
                                                        _c(
                                                          "select",
                                                          {
                                                            directives: [
                                                              {
                                                                name: "model",
                                                                rawName:
                                                                  "v-model",
                                                                value:
                                                                  item.daypart,
                                                                expression:
                                                                  "item.daypart",
                                                              },
                                                            ],
                                                            on: {
                                                              change: function (
                                                                $event
                                                              ) {
                                                                var $$selectedVal =
                                                                  Array.prototype.filter
                                                                    .call(
                                                                      $event
                                                                        .target
                                                                        .options,
                                                                      function (
                                                                        o
                                                                      ) {
                                                                        return o.selected
                                                                      }
                                                                    )
                                                                    .map(
                                                                      function (
                                                                        o
                                                                      ) {
                                                                        var val =
                                                                          "_value" in
                                                                          o
                                                                            ? o._value
                                                                            : o.value
                                                                        return val
                                                                      }
                                                                    )
                                                                _vm.$set(
                                                                  item,
                                                                  "daypart",
                                                                  $event.target
                                                                    .multiple
                                                                    ? $$selectedVal
                                                                    : $$selectedVal[0]
                                                                )
                                                              },
                                                            },
                                                          },
                                                          [
                                                            _vm._l(
                                                              Object.keys(
                                                                _vm.dayparts
                                                              ),
                                                              function (key) {
                                                                return _c(
                                                                  "option",
                                                                  {
                                                                    key: key,
                                                                    domProps: {
                                                                      value:
                                                                        key,
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                        _vm._s(
                                                                          _vm
                                                                            .dayparts[
                                                                            key
                                                                          ]
                                                                        ) +
                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                    ),
                                                                  ]
                                                                )
                                                              }
                                                            ),
                                                            _vm._v(" "),
                                                            item.unit !==
                                                            "percent"
                                                              ? _c(
                                                                  "option",
                                                                  {
                                                                    domProps: {
                                                                      value: 2,
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tМесяц\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                    ),
                                                                  ]
                                                                )
                                                              : _vm._e(),
                                                          ],
                                                          2
                                                        ),
                                                        _vm._v(" "),
                                                        item.daypart == 1
                                                          ? _c("input", {
                                                              directives: [
                                                                {
                                                                  name: "model",
                                                                  rawName:
                                                                    "v-model",
                                                                  value:
                                                                    item.from,
                                                                  expression:
                                                                    "item.from",
                                                                },
                                                              ],
                                                              attrs: {
                                                                type: "time",
                                                              },
                                                              domProps: {
                                                                value:
                                                                  item.from,
                                                              },
                                                              on: {
                                                                input:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    if (
                                                                      $event
                                                                        .target
                                                                        .composing
                                                                    ) {
                                                                      return
                                                                    }
                                                                    _vm.$set(
                                                                      item,
                                                                      "from",
                                                                      $event
                                                                        .target
                                                                        .value
                                                                    )
                                                                  },
                                                              },
                                                            })
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        item.daypart == 1
                                                          ? _c("input", {
                                                              directives: [
                                                                {
                                                                  name: "model",
                                                                  rawName:
                                                                    "v-model",
                                                                  value:
                                                                    item.to,
                                                                  expression:
                                                                    "item.to",
                                                                },
                                                              ],
                                                              attrs: {
                                                                type: "time",
                                                              },
                                                              domProps: {
                                                                value: item.to,
                                                              },
                                                              on: {
                                                                input:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    if (
                                                                      $event
                                                                        .target
                                                                        .composing
                                                                    ) {
                                                                      return
                                                                    }
                                                                    _vm.$set(
                                                                      item,
                                                                      "to",
                                                                      $event
                                                                        .target
                                                                        .value
                                                                    )
                                                                  },
                                                              },
                                                            })
                                                          : _vm._e(),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c("input", {
                                                    directives: [
                                                      {
                                                        name: "model",
                                                        rawName: "v-model",
                                                        value: item.sum,
                                                        expression: "item.sum",
                                                      },
                                                    ],
                                                    attrs: { type: "text" },
                                                    domProps: {
                                                      value: item.sum,
                                                    },
                                                    on: {
                                                      input: function ($event) {
                                                        if (
                                                          $event.target
                                                            .composing
                                                        ) {
                                                          return
                                                        }
                                                        _vm.$set(
                                                          item,
                                                          "sum",
                                                          $event.target.value
                                                        )
                                                      },
                                                    },
                                                  }),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c("input", {
                                                    directives: [
                                                      {
                                                        name: "model",
                                                        rawName: "v-model",
                                                        value: item.quantity,
                                                        expression:
                                                          "item.quantity",
                                                      },
                                                    ],
                                                    attrs: { type: "text" },
                                                    domProps: {
                                                      value: item.quantity,
                                                    },
                                                    on: {
                                                      input: function ($event) {
                                                        if (
                                                          $event.target
                                                            .composing
                                                        ) {
                                                          return
                                                        }
                                                        _vm.$set(
                                                          item,
                                                          "quantity",
                                                          $event.target.value
                                                        )
                                                      },
                                                    },
                                                  }),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c("input", {
                                                    directives: [
                                                      {
                                                        name: "model",
                                                        rawName: "v-model",
                                                        value: item.text,
                                                        expression: "item.text",
                                                      },
                                                    ],
                                                    attrs: { type: "textarea" },
                                                    domProps: {
                                                      value: item.text,
                                                    },
                                                    on: {
                                                      input: function ($event) {
                                                        if (
                                                          $event.target
                                                            .composing
                                                        ) {
                                                          return
                                                        }
                                                        _vm.$set(
                                                          item,
                                                          "text",
                                                          $event.target.value
                                                        )
                                                      },
                                                    },
                                                  }),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _vm._v(
                                                    _vm._s(item.created_at)
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _vm._v(
                                                    _vm._s(item.updated_at)
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _vm._v(
                                                    _vm._s(item.created_by)
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _vm._v(
                                                    _vm._s(item.updated_by)
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c(
                                                  "td",
                                                  { staticClass: "ho-hover" },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "d-flex px-2",
                                                      },
                                                      [
                                                        _c("i", {
                                                          staticClass:
                                                            "fa fa-save btn btn-success btn-icon",
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.saveNewBonus(
                                                                i
                                                              )
                                                            },
                                                          },
                                                        }),
                                                        _vm._v(" "),
                                                        _c("i", {
                                                          staticClass:
                                                            "fa fa-trash btn btn-danger btn-icon",
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.deleteNewBonus(
                                                                i
                                                              )
                                                            },
                                                          },
                                                        }),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ])
                                            }
                                          ),
                                          _vm._v(" "),
                                          _c("tr", [
                                            _c(
                                              "td",
                                              {
                                                staticClass: "plus-item",
                                                attrs: { colspan: "13" },
                                              },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass: "p-4",
                                                    on: {
                                                      click: function ($event) {
                                                        return _vm.addBonus()
                                                      },
                                                    },
                                                  },
                                                  [
                                                    _c("i", {
                                                      staticClass:
                                                        "fa fa-plus mr-2",
                                                    }),
                                                    _vm._v(" "),
                                                    _c("b", [
                                                      _vm._v("Добавить бонус"),
                                                    ]),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]),
                                        ],
                                        2
                                      ),
                                    ]
                                  ),
                                ]),
                              ]
                            ),
                          ]),
                        ]
                      : _vm._e(),
                  ]
                : _vm._e(),
              _vm._v(" "),
              _vm._l(_vm.page_items, function (page_item, p) {
                return [
                  _c("tr", { key: p }, [
                    _c(
                      "td",
                      {
                        staticClass: "pointer b-table-sticky-column",
                        on: {
                          click: function ($event) {
                            return _vm.expand(p)
                          },
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "d-flex align-items-center px-2" },
                          [
                            _c("span", { staticClass: "mr-2" }, [
                              _vm._v(_vm._s(p + 1)),
                            ]),
                            _vm._v(" "),
                            page_item.expanded
                              ? _c("i", { staticClass: "fa fa-minus mt-1" })
                              : _c("i", { staticClass: "fa fa-plus mt-1" }),
                          ]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-left" }, [
                      _c("div", { staticClass: "d-flex aic" }, [
                        page_item.type == 1
                          ? _c("i", {
                              staticClass: "fa fa-user ml-2 color-user",
                            })
                          : _vm._e(),
                        _vm._v(" "),
                        page_item.type == 2
                          ? _c("i", {
                              staticClass: "fa fa-users ml-2 color-group",
                            })
                          : _vm._e(),
                        _vm._v(" "),
                        page_item.type == 3
                          ? _c("i", {
                              staticClass:
                                "fa fa-briefcase ml-2 color-position",
                            })
                          : _vm._e(),
                        _vm._v(" "),
                        _c("span", { staticClass: "ml-2" }, [
                          _vm._v(_vm._s(page_item.name)),
                        ]),
                        _vm._v(" "),
                        _c("i", {
                          staticClass:
                            "fa fa-save btn btn-success btn-icon ml-a",
                          on: {
                            click: function ($event) {
                              return _vm.saveAll(p)
                            },
                          },
                        }),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  page_item.items !== undefined && page_item.items.length > 0
                    ? [
                        _c(
                          "tr",
                          {
                            key: p + "a",
                            staticClass: "collapsable",
                            class: { active: page_item.expanded },
                          },
                          [
                            _c(
                              "td",
                              { attrs: { colspan: _vm.fields.length + 2 } },
                              [
                                _c(
                                  "div",
                                  { staticClass: "table__wrapper w-100" },
                                  [
                                    _c(
                                      "table",
                                      {
                                        staticClass:
                                          "table table-responsive table-inner",
                                      },
                                      [
                                        _c("thead", [
                                          _c(
                                            "tr",
                                            [
                                              _c("th"),
                                              _vm._v(" "),
                                              _vm._l(
                                                _vm.fields,
                                                function (field, f) {
                                                  return _c(
                                                    "th",
                                                    {
                                                      key: f,
                                                      class: [
                                                        field.class,
                                                        {
                                                          "b-table-sticky-column l-2 hidden":
                                                            field.key ==
                                                            "target",
                                                        },
                                                      ],
                                                    },
                                                    [
                                                      _vm._v(
                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                          _vm._s(field.name) +
                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                      ),
                                                      field.key === "sum"
                                                        ? _c("img", {
                                                            directives: [
                                                              {
                                                                name: "b-popover",
                                                                rawName:
                                                                  "v-b-popover.hover.right.html",
                                                                value:
                                                                  "Укажите в количестве<br> или в процентах %",
                                                                expression:
                                                                  "'Укажите в количестве<br> или в процентах %'",
                                                                modifiers: {
                                                                  hover: true,
                                                                  right: true,
                                                                  html: true,
                                                                },
                                                              },
                                                            ],
                                                            staticClass:
                                                              "KPIBonuses-icon-info",
                                                            attrs: {
                                                              src: "/images/dist/profit-info.svg",
                                                              alt: "info icon",
                                                            },
                                                          })
                                                        : _vm._e(),
                                                    ]
                                                  )
                                                }
                                              ),
                                              _vm._v(" "),
                                              _c("th"),
                                            ],
                                            2
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c(
                                          "tbody",
                                          [
                                            _vm._l(
                                              page_item.items,
                                              function (item, i) {
                                                return _c(
                                                  "tr",
                                                  { key: i },
                                                  [
                                                    _c(
                                                      "td",
                                                      {
                                                        staticClass:
                                                          "text-center",
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                            _vm._s(i + 1) +
                                                            "\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _vm._l(
                                                      _vm.fields,
                                                      function (field, f) {
                                                        return _c(
                                                          "td",
                                                          {
                                                            key: f,
                                                            class: [
                                                              field.class,
                                                              {
                                                                "b-table-sticky-column l-2 hidden":
                                                                  field.key ==
                                                                  "target",
                                                              },
                                                              {
                                                                "no-hover":
                                                                  field.key ==
                                                                  "daypart",
                                                              },
                                                              {
                                                                "no-hover":
                                                                  field.key ==
                                                                    "activity_id" &&
                                                                  item.source !=
                                                                    undefined,
                                                              },
                                                            ],
                                                          },
                                                          [
                                                            field.key ==
                                                            "target"
                                                              ? void 0
                                                              : field.key ==
                                                                  "created_by" &&
                                                                item.creator !=
                                                                  null
                                                              ? [
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        item
                                                                          .creator
                                                                          .last_name +
                                                                          " " +
                                                                          item
                                                                            .creator
                                                                            .name
                                                                      ) +
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              : field.key ==
                                                                  "updated_by" &&
                                                                item.updater !=
                                                                  null
                                                              ? [
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        item
                                                                          .updater
                                                                          .last_name +
                                                                          " " +
                                                                          item
                                                                            .updater
                                                                            .name
                                                                      ) +
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              : _vm.non_editable_fields.includes(
                                                                  field.key
                                                                )
                                                              ? [
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ]
                                                                      ) +
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              : field.key ==
                                                                  "activity_id" &&
                                                                item.source !=
                                                                  undefined
                                                              ? [
                                                                  _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "d-flex",
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "select",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item.source,
                                                                                expression:
                                                                                  "item.source",
                                                                              },
                                                                            ],
                                                                          on: {
                                                                            change:
                                                                              [
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  var $$selectedVal =
                                                                                    Array.prototype.filter
                                                                                      .call(
                                                                                        $event
                                                                                          .target
                                                                                          .options,
                                                                                        function (
                                                                                          o
                                                                                        ) {
                                                                                          return o.selected
                                                                                        }
                                                                                      )
                                                                                      .map(
                                                                                        function (
                                                                                          o
                                                                                        ) {
                                                                                          var val =
                                                                                            "_value" in
                                                                                            o
                                                                                              ? o._value
                                                                                              : o.value
                                                                                          return val
                                                                                        }
                                                                                      )
                                                                                  _vm.$set(
                                                                                    item,
                                                                                    "source",
                                                                                    $event
                                                                                      .target
                                                                                      .multiple
                                                                                      ? $$selectedVal
                                                                                      : $$selectedVal[0]
                                                                                  )
                                                                                },
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  ++_vm.source_key
                                                                                },
                                                                              ],
                                                                          },
                                                                        },
                                                                        _vm._l(
                                                                          Object.keys(
                                                                            _vm.sources
                                                                          ),
                                                                          function (
                                                                            key
                                                                          ) {
                                                                            return _c(
                                                                              "option",
                                                                              {
                                                                                key: key,
                                                                                domProps:
                                                                                  {
                                                                                    value:
                                                                                      key,
                                                                                  },
                                                                              },
                                                                              [
                                                                                _vm._v(
                                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                    _vm._s(
                                                                                      _vm
                                                                                        .sources[
                                                                                        key
                                                                                      ]
                                                                                    ) +
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                ),
                                                                              ]
                                                                            )
                                                                          }
                                                                        ),
                                                                        0
                                                                      ),
                                                                      _vm._v(
                                                                        " "
                                                                      ),
                                                                      Number(
                                                                        item.source
                                                                      ) == 1
                                                                        ? _c(
                                                                            "select",
                                                                            {
                                                                              directives:
                                                                                [
                                                                                  {
                                                                                    name: "model",
                                                                                    rawName:
                                                                                      "v-model",
                                                                                    value:
                                                                                      item.group_id,
                                                                                    expression:
                                                                                      "item.group_id",
                                                                                  },
                                                                                ],
                                                                              key:
                                                                                "c" +
                                                                                _vm.source_key,
                                                                              on: {
                                                                                change:
                                                                                  function (
                                                                                    $event
                                                                                  ) {
                                                                                    var $$selectedVal =
                                                                                      Array.prototype.filter
                                                                                        .call(
                                                                                          $event
                                                                                            .target
                                                                                            .options,
                                                                                          function (
                                                                                            o
                                                                                          ) {
                                                                                            return o.selected
                                                                                          }
                                                                                        )
                                                                                        .map(
                                                                                          function (
                                                                                            o
                                                                                          ) {
                                                                                            var val =
                                                                                              "_value" in
                                                                                              o
                                                                                                ? o._value
                                                                                                : o.value
                                                                                            return val
                                                                                          }
                                                                                        )
                                                                                    _vm.$set(
                                                                                      item,
                                                                                      "group_id",
                                                                                      $event
                                                                                        .target
                                                                                        .multiple
                                                                                        ? $$selectedVal
                                                                                        : $$selectedVal[0]
                                                                                    )
                                                                                  },
                                                                              },
                                                                            },
                                                                            [
                                                                              _c(
                                                                                "option",
                                                                                {
                                                                                  attrs:
                                                                                    {
                                                                                      value:
                                                                                        "0",
                                                                                      selected:
                                                                                        "",
                                                                                    },
                                                                                },
                                                                                [
                                                                                  _vm._v(
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                  ),
                                                                                ]
                                                                              ),
                                                                              _vm._v(
                                                                                " "
                                                                              ),
                                                                              _vm._l(
                                                                                _vm.groups,
                                                                                function (
                                                                                  group,
                                                                                  id
                                                                                ) {
                                                                                  return _c(
                                                                                    "option",
                                                                                    {
                                                                                      key: id,
                                                                                      domProps:
                                                                                        {
                                                                                          value:
                                                                                            id,
                                                                                        },
                                                                                    },
                                                                                    [
                                                                                      _vm._v(
                                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                          _vm._s(
                                                                                            group
                                                                                          ) +
                                                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                      ),
                                                                                    ]
                                                                                  )
                                                                                }
                                                                              ),
                                                                            ],
                                                                            2
                                                                          )
                                                                        : _vm._e(),
                                                                      _vm._v(
                                                                        " "
                                                                      ),
                                                                      Number(
                                                                        item.source
                                                                      ) == 1
                                                                        ? _c(
                                                                            "select",
                                                                            {
                                                                              directives:
                                                                                [
                                                                                  {
                                                                                    name: "model",
                                                                                    rawName:
                                                                                      "v-model",
                                                                                    value:
                                                                                      item.activity_id,
                                                                                    expression:
                                                                                      "item.activity_id",
                                                                                  },
                                                                                ],
                                                                              key:
                                                                                "d" +
                                                                                _vm.source_key,
                                                                              on: {
                                                                                change:
                                                                                  function (
                                                                                    $event
                                                                                  ) {
                                                                                    var $$selectedVal =
                                                                                      Array.prototype.filter
                                                                                        .call(
                                                                                          $event
                                                                                            .target
                                                                                            .options,
                                                                                          function (
                                                                                            o
                                                                                          ) {
                                                                                            return o.selected
                                                                                          }
                                                                                        )
                                                                                        .map(
                                                                                          function (
                                                                                            o
                                                                                          ) {
                                                                                            var val =
                                                                                              "_value" in
                                                                                              o
                                                                                                ? o._value
                                                                                                : o.value
                                                                                            return val
                                                                                          }
                                                                                        )
                                                                                    _vm.$set(
                                                                                      item,
                                                                                      "activity_id",
                                                                                      $event
                                                                                        .target
                                                                                        .multiple
                                                                                        ? $$selectedVal
                                                                                        : $$selectedVal[0]
                                                                                    )
                                                                                  },
                                                                              },
                                                                            },
                                                                            [
                                                                              _c(
                                                                                "option",
                                                                                {
                                                                                  attrs:
                                                                                    {
                                                                                      value:
                                                                                        "0",
                                                                                      selected:
                                                                                        "",
                                                                                    },
                                                                                },
                                                                                [
                                                                                  _vm._v(
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                  ),
                                                                                ]
                                                                              ),
                                                                              _vm._v(
                                                                                " "
                                                                              ),
                                                                              _vm._l(
                                                                                _vm.grouped_activities(
                                                                                  item.source,
                                                                                  item.group_id
                                                                                ),
                                                                                function (
                                                                                  activity
                                                                                ) {
                                                                                  return _c(
                                                                                    "option",
                                                                                    {
                                                                                      key: activity.id,
                                                                                      domProps:
                                                                                        {
                                                                                          value:
                                                                                            activity.id,
                                                                                        },
                                                                                    },
                                                                                    [
                                                                                      _vm._v(
                                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                          _vm._s(
                                                                                            activity.name
                                                                                          ) +
                                                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                      ),
                                                                                    ]
                                                                                  )
                                                                                }
                                                                              ),
                                                                            ],
                                                                            2
                                                                          )
                                                                        : _vm._e(),
                                                                    ]
                                                                  ),
                                                                ]
                                                              : field.key ==
                                                                "unit"
                                                              ? [
                                                                  _c(
                                                                    "select",
                                                                    {
                                                                      directives:
                                                                        [
                                                                          {
                                                                            name: "model",
                                                                            rawName:
                                                                              "v-model",
                                                                            value:
                                                                              item.unit,
                                                                            expression:
                                                                              "item.unit",
                                                                          },
                                                                        ],
                                                                      on: {
                                                                        change:
                                                                          [
                                                                            function (
                                                                              $event
                                                                            ) {
                                                                              var $$selectedVal =
                                                                                Array.prototype.filter
                                                                                  .call(
                                                                                    $event
                                                                                      .target
                                                                                      .options,
                                                                                    function (
                                                                                      o
                                                                                    ) {
                                                                                      return o.selected
                                                                                    }
                                                                                  )
                                                                                  .map(
                                                                                    function (
                                                                                      o
                                                                                    ) {
                                                                                      var val =
                                                                                        "_value" in
                                                                                        o
                                                                                          ? o._value
                                                                                          : o.value
                                                                                      return val
                                                                                    }
                                                                                  )
                                                                              _vm.$set(
                                                                                item,
                                                                                "unit",
                                                                                $event
                                                                                  .target
                                                                                  .multiple
                                                                                  ? $$selectedVal
                                                                                  : $$selectedVal[0]
                                                                              )
                                                                            },
                                                                            function (
                                                                              $event
                                                                            ) {
                                                                              return _vm.onChangeUnit(
                                                                                item
                                                                              )
                                                                            },
                                                                          ],
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "option",
                                                                        {
                                                                          attrs:
                                                                            {
                                                                              value:
                                                                                "0",
                                                                              selected:
                                                                                "",
                                                                            },
                                                                        },
                                                                        [
                                                                          _vm._v(
                                                                            "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                          ),
                                                                        ]
                                                                      ),
                                                                      _vm._v(
                                                                        " "
                                                                      ),
                                                                      _vm._l(
                                                                        Object.keys(
                                                                          _vm.units
                                                                        ),
                                                                        function (
                                                                          key
                                                                        ) {
                                                                          return _c(
                                                                            "option",
                                                                            {
                                                                              key: key,
                                                                              domProps:
                                                                                {
                                                                                  value:
                                                                                    key,
                                                                                },
                                                                            },
                                                                            [
                                                                              _vm._v(
                                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                  _vm._s(
                                                                                    _vm
                                                                                      .units[
                                                                                      key
                                                                                    ]
                                                                                  ) +
                                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                              ),
                                                                            ]
                                                                          )
                                                                        }
                                                                      ),
                                                                    ],
                                                                    2
                                                                  ),
                                                                ]
                                                              : field.key ==
                                                                "daypart"
                                                              ? [
                                                                  _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "d-flex",
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "select",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item.daypart,
                                                                                expression:
                                                                                  "item.daypart",
                                                                              },
                                                                            ],
                                                                          on: {
                                                                            change:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                var $$selectedVal =
                                                                                  Array.prototype.filter
                                                                                    .call(
                                                                                      $event
                                                                                        .target
                                                                                        .options,
                                                                                      function (
                                                                                        o
                                                                                      ) {
                                                                                        return o.selected
                                                                                      }
                                                                                    )
                                                                                    .map(
                                                                                      function (
                                                                                        o
                                                                                      ) {
                                                                                        var val =
                                                                                          "_value" in
                                                                                          o
                                                                                            ? o._value
                                                                                            : o.value
                                                                                        return val
                                                                                      }
                                                                                    )
                                                                                _vm.$set(
                                                                                  item,
                                                                                  "daypart",
                                                                                  $event
                                                                                    .target
                                                                                    .multiple
                                                                                    ? $$selectedVal
                                                                                    : $$selectedVal[0]
                                                                                )
                                                                              },
                                                                          },
                                                                        },
                                                                        [
                                                                          _vm._l(
                                                                            Object.keys(
                                                                              _vm.dayparts
                                                                            ),
                                                                            function (
                                                                              key
                                                                            ) {
                                                                              return _c(
                                                                                "option",
                                                                                {
                                                                                  key: key,
                                                                                  domProps:
                                                                                    {
                                                                                      value:
                                                                                        key,
                                                                                    },
                                                                                },
                                                                                [
                                                                                  _vm._v(
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                      _vm._s(
                                                                                        _vm
                                                                                          .dayparts[
                                                                                          key
                                                                                        ]
                                                                                      ) +
                                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                  ),
                                                                                ]
                                                                              )
                                                                            }
                                                                          ),
                                                                          _vm._v(
                                                                            " "
                                                                          ),
                                                                          item.unit !==
                                                                          "percent"
                                                                            ? _c(
                                                                                "option",
                                                                                {
                                                                                  domProps:
                                                                                    {
                                                                                      value: 2,
                                                                                    },
                                                                                },
                                                                                [
                                                                                  _vm._v(
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tМесяц\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                  ),
                                                                                ]
                                                                              )
                                                                            : _vm._e(),
                                                                        ],
                                                                        2
                                                                      ),
                                                                      _vm._v(
                                                                        " "
                                                                      ),
                                                                      item.daypart ==
                                                                      1
                                                                        ? _c(
                                                                            "input",
                                                                            {
                                                                              directives:
                                                                                [
                                                                                  {
                                                                                    name: "model",
                                                                                    rawName:
                                                                                      "v-model",
                                                                                    value:
                                                                                      item.from,
                                                                                    expression:
                                                                                      "item.from",
                                                                                  },
                                                                                ],
                                                                              attrs:
                                                                                {
                                                                                  type: "time",
                                                                                },
                                                                              domProps:
                                                                                {
                                                                                  value:
                                                                                    item.from,
                                                                                },
                                                                              on: {
                                                                                input:
                                                                                  function (
                                                                                    $event
                                                                                  ) {
                                                                                    if (
                                                                                      $event
                                                                                        .target
                                                                                        .composing
                                                                                    ) {
                                                                                      return
                                                                                    }
                                                                                    _vm.$set(
                                                                                      item,
                                                                                      "from",
                                                                                      $event
                                                                                        .target
                                                                                        .value
                                                                                    )
                                                                                  },
                                                                              },
                                                                            }
                                                                          )
                                                                        : _vm._e(),
                                                                      _vm._v(
                                                                        " "
                                                                      ),
                                                                      item.daypart ==
                                                                      1
                                                                        ? _c(
                                                                            "input",
                                                                            {
                                                                              directives:
                                                                                [
                                                                                  {
                                                                                    name: "model",
                                                                                    rawName:
                                                                                      "v-model",
                                                                                    value:
                                                                                      item.to,
                                                                                    expression:
                                                                                      "item.to",
                                                                                  },
                                                                                ],
                                                                              attrs:
                                                                                {
                                                                                  type: "time",
                                                                                },
                                                                              domProps:
                                                                                {
                                                                                  value:
                                                                                    item.to,
                                                                                },
                                                                              on: {
                                                                                input:
                                                                                  function (
                                                                                    $event
                                                                                  ) {
                                                                                    if (
                                                                                      $event
                                                                                        .target
                                                                                        .composing
                                                                                    ) {
                                                                                      return
                                                                                    }
                                                                                    _vm.$set(
                                                                                      item,
                                                                                      "to",
                                                                                      $event
                                                                                        .target
                                                                                        .value
                                                                                    )
                                                                                  },
                                                                              },
                                                                            }
                                                                          )
                                                                        : _vm._e(),
                                                                    ]
                                                                  ),
                                                                ]
                                                              : field.key ===
                                                                "sum"
                                                              ? [
                                                                  field.type ===
                                                                  "checkbox"
                                                                    ? _c(
                                                                        "input",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                expression:
                                                                                  "item[field.key]",
                                                                              },
                                                                            ],
                                                                          attrs:
                                                                            {
                                                                              type: "checkbox",
                                                                            },
                                                                          domProps:
                                                                            {
                                                                              checked:
                                                                                Array.isArray(
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ]
                                                                                )
                                                                                  ? _vm._i(
                                                                                      item[
                                                                                        field
                                                                                          .key
                                                                                      ],
                                                                                      null
                                                                                    ) >
                                                                                    -1
                                                                                  : item[
                                                                                      field
                                                                                        .key
                                                                                    ],
                                                                            },
                                                                          on: {
                                                                            change:
                                                                              [
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  var $$a =
                                                                                      item[
                                                                                        field
                                                                                          .key
                                                                                      ],
                                                                                    $$el =
                                                                                      $event.target,
                                                                                    $$c =
                                                                                      $$el.checked
                                                                                        ? true
                                                                                        : false
                                                                                  if (
                                                                                    Array.isArray(
                                                                                      $$a
                                                                                    )
                                                                                  ) {
                                                                                    var $$v =
                                                                                        null,
                                                                                      $$i =
                                                                                        _vm._i(
                                                                                          $$a,
                                                                                          $$v
                                                                                        )
                                                                                    if (
                                                                                      $$el.checked
                                                                                    ) {
                                                                                      $$i <
                                                                                        0 &&
                                                                                        _vm.$set(
                                                                                          item,
                                                                                          field.key,
                                                                                          $$a.concat(
                                                                                            [
                                                                                              $$v,
                                                                                            ]
                                                                                          )
                                                                                        )
                                                                                    } else {
                                                                                      $$i >
                                                                                        -1 &&
                                                                                        _vm.$set(
                                                                                          item,
                                                                                          field.key,
                                                                                          $$a
                                                                                            .slice(
                                                                                              0,
                                                                                              $$i
                                                                                            )
                                                                                            .concat(
                                                                                              $$a.slice(
                                                                                                $$i +
                                                                                                  1
                                                                                              )
                                                                                            )
                                                                                        )
                                                                                    }
                                                                                  } else {
                                                                                    _vm.$set(
                                                                                      item,
                                                                                      field.key,
                                                                                      $$c
                                                                                    )
                                                                                  }
                                                                                },
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  return _vm.validate(
                                                                                    item[
                                                                                      field
                                                                                        .key
                                                                                    ],
                                                                                    field.key
                                                                                  )
                                                                                },
                                                                              ],
                                                                          },
                                                                        }
                                                                      )
                                                                    : field.type ===
                                                                      "radio"
                                                                    ? _c(
                                                                        "input",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                expression:
                                                                                  "item[field.key]",
                                                                              },
                                                                            ],
                                                                          attrs:
                                                                            {
                                                                              type: "radio",
                                                                            },
                                                                          domProps:
                                                                            {
                                                                              checked:
                                                                                _vm._q(
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                  null
                                                                                ),
                                                                            },
                                                                          on: {
                                                                            change:
                                                                              [
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  return _vm.$set(
                                                                                    item,
                                                                                    field.key,
                                                                                    null
                                                                                  )
                                                                                },
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  return _vm.validate(
                                                                                    item[
                                                                                      field
                                                                                        .key
                                                                                    ],
                                                                                    field.key
                                                                                  )
                                                                                },
                                                                              ],
                                                                          },
                                                                        }
                                                                      )
                                                                    : _c(
                                                                        "input",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                expression:
                                                                                  "item[field.key]",
                                                                              },
                                                                            ],
                                                                          attrs:
                                                                            {
                                                                              type: field.type,
                                                                            },
                                                                          domProps:
                                                                            {
                                                                              value:
                                                                                item[
                                                                                  field
                                                                                    .key
                                                                                ],
                                                                            },
                                                                          on: {
                                                                            change:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return _vm.validate(
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                  field.key
                                                                                )
                                                                              },
                                                                            input:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                if (
                                                                                  $event
                                                                                    .target
                                                                                    .composing
                                                                                ) {
                                                                                  return
                                                                                }
                                                                                _vm.$set(
                                                                                  item,
                                                                                  field.key,
                                                                                  $event
                                                                                    .target
                                                                                    .value
                                                                                )
                                                                              },
                                                                          },
                                                                        }
                                                                      ),
                                                                  _vm._v(
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                      _vm._s(
                                                                        item.unit ===
                                                                          "percent"
                                                                          ? "%"
                                                                          : ""
                                                                      ) +
                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                  ),
                                                                ]
                                                              : field.key ===
                                                                  "quantity" &&
                                                                item.unit ===
                                                                  "percent"
                                                              ? void 0
                                                              : [
                                                                  field.type ===
                                                                  "checkbox"
                                                                    ? _c(
                                                                        "input",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                expression:
                                                                                  "item[field.key]",
                                                                              },
                                                                            ],
                                                                          attrs:
                                                                            {
                                                                              type: "checkbox",
                                                                            },
                                                                          domProps:
                                                                            {
                                                                              checked:
                                                                                Array.isArray(
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ]
                                                                                )
                                                                                  ? _vm._i(
                                                                                      item[
                                                                                        field
                                                                                          .key
                                                                                      ],
                                                                                      null
                                                                                    ) >
                                                                                    -1
                                                                                  : item[
                                                                                      field
                                                                                        .key
                                                                                    ],
                                                                            },
                                                                          on: {
                                                                            change:
                                                                              [
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  var $$a =
                                                                                      item[
                                                                                        field
                                                                                          .key
                                                                                      ],
                                                                                    $$el =
                                                                                      $event.target,
                                                                                    $$c =
                                                                                      $$el.checked
                                                                                        ? true
                                                                                        : false
                                                                                  if (
                                                                                    Array.isArray(
                                                                                      $$a
                                                                                    )
                                                                                  ) {
                                                                                    var $$v =
                                                                                        null,
                                                                                      $$i =
                                                                                        _vm._i(
                                                                                          $$a,
                                                                                          $$v
                                                                                        )
                                                                                    if (
                                                                                      $$el.checked
                                                                                    ) {
                                                                                      $$i <
                                                                                        0 &&
                                                                                        _vm.$set(
                                                                                          item,
                                                                                          field.key,
                                                                                          $$a.concat(
                                                                                            [
                                                                                              $$v,
                                                                                            ]
                                                                                          )
                                                                                        )
                                                                                    } else {
                                                                                      $$i >
                                                                                        -1 &&
                                                                                        _vm.$set(
                                                                                          item,
                                                                                          field.key,
                                                                                          $$a
                                                                                            .slice(
                                                                                              0,
                                                                                              $$i
                                                                                            )
                                                                                            .concat(
                                                                                              $$a.slice(
                                                                                                $$i +
                                                                                                  1
                                                                                              )
                                                                                            )
                                                                                        )
                                                                                    }
                                                                                  } else {
                                                                                    _vm.$set(
                                                                                      item,
                                                                                      field.key,
                                                                                      $$c
                                                                                    )
                                                                                  }
                                                                                },
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  return _vm.validate(
                                                                                    item[
                                                                                      field
                                                                                        .key
                                                                                    ],
                                                                                    field.key
                                                                                  )
                                                                                },
                                                                              ],
                                                                          },
                                                                        }
                                                                      )
                                                                    : field.type ===
                                                                      "radio"
                                                                    ? _c(
                                                                        "input",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                expression:
                                                                                  "item[field.key]",
                                                                              },
                                                                            ],
                                                                          attrs:
                                                                            {
                                                                              type: "radio",
                                                                            },
                                                                          domProps:
                                                                            {
                                                                              checked:
                                                                                _vm._q(
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                  null
                                                                                ),
                                                                            },
                                                                          on: {
                                                                            change:
                                                                              [
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  return _vm.$set(
                                                                                    item,
                                                                                    field.key,
                                                                                    null
                                                                                  )
                                                                                },
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  return _vm.validate(
                                                                                    item[
                                                                                      field
                                                                                        .key
                                                                                    ],
                                                                                    field.key
                                                                                  )
                                                                                },
                                                                              ],
                                                                          },
                                                                        }
                                                                      )
                                                                    : _c(
                                                                        "input",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                expression:
                                                                                  "item[field.key]",
                                                                              },
                                                                            ],
                                                                          attrs:
                                                                            {
                                                                              type: field.type,
                                                                            },
                                                                          domProps:
                                                                            {
                                                                              value:
                                                                                item[
                                                                                  field
                                                                                    .key
                                                                                ],
                                                                            },
                                                                          on: {
                                                                            change:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return _vm.validate(
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                  field.key
                                                                                )
                                                                              },
                                                                            input:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                if (
                                                                                  $event
                                                                                    .target
                                                                                    .composing
                                                                                ) {
                                                                                  return
                                                                                }
                                                                                _vm.$set(
                                                                                  item,
                                                                                  field.key,
                                                                                  $event
                                                                                    .target
                                                                                    .value
                                                                                )
                                                                              },
                                                                          },
                                                                        }
                                                                      ),
                                                                ],
                                                          ],
                                                          2
                                                        )
                                                      }
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "td",
                                                      {
                                                        staticClass: "no-hover",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "d-flex px-2",
                                                          },
                                                          [
                                                            _c(
                                                              "b-form-checkbox",
                                                              {
                                                                staticClass:
                                                                  "kpi-status-switch",
                                                                attrs: {
                                                                  switch: "",
                                                                  checked:
                                                                    !!item.is_active,
                                                                  disabled:
                                                                    _vm.requestInProgress,
                                                                },
                                                                on: {
                                                                  input:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.changeStatus(
                                                                        item,
                                                                        $event
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("i", {
                                                              staticClass:
                                                                "fa fa-save btn btn-success btn-icon",
                                                              on: {
                                                                click:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    return _vm.saveItemFromTable(
                                                                      p,
                                                                      i
                                                                    )
                                                                  },
                                                              },
                                                            }),
                                                            _vm._v(" "),
                                                            _c("i", {
                                                              staticClass:
                                                                "fa fa-trash btn btn-danger btn-icon",
                                                              on: {
                                                                click:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    return _vm.deleteItem(
                                                                      p,
                                                                      i
                                                                    )
                                                                  },
                                                              },
                                                            }),
                                                          ],
                                                          1
                                                        ),
                                                      ]
                                                    ),
                                                  ],
                                                  2
                                                )
                                              }
                                            ),
                                            _vm._v(" "),
                                            _c("tr", [
                                              _c(
                                                "td",
                                                {
                                                  staticClass: "plus-item",
                                                  attrs: { colspan: "13" },
                                                },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass: "px-4 py-3",
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          return _vm.addBonusGroup(
                                                            page_item
                                                          )
                                                        },
                                                      },
                                                    },
                                                    [
                                                      _c("i", {
                                                        staticClass:
                                                          "fa fa-plus mr-2",
                                                      }),
                                                      _vm._v(" "),
                                                      _c("b", [
                                                        _vm._v(
                                                          "Добавить бонус"
                                                        ),
                                                      ]),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                            ]),
                                          ],
                                          2
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    : _vm._e(),
                ]
              }),
            ],
            2
          ),
        ]
      ),
      _vm._v(" "),
      _c("JwPagination", {
        key: _vm.paginationKey,
        attrs: {
          items: _vm.items,
          labels: {
            first: "<<",
            last: ">>",
            previous: "<",
            next: ">",
          },
          "page-size": +_vm.pageSize,
        },
        on: { changePage: _vm.onChangePage },
      }),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            title: "Настройка списка",
            "ok-text": "Закрыть",
            size: "lg",
          },
          on: {
            ok: function ($event) {
              _vm.modalAdjustVisibleFields = !_vm.modalAdjustVisibleFields
            },
          },
          model: {
            value: _vm.modalAdjustVisibleFields,
            callback: function ($$v) {
              _vm.modalAdjustVisibleFields = $$v
            },
            expression: "modalAdjustVisibleFields",
          },
        },
        [
          _c(
            "div",
            { staticClass: "row" },
            _vm._l(_vm.all_fields, function (field, f) {
              return _c(
                "div",
                { key: f, staticClass: "col-md-4 mb-2" },
                [
                  _c(
                    "b-form-checkbox",
                    {
                      attrs: { value: true, "unchecked-value": false },
                      model: {
                        value: _vm.show_fields[field.key],
                        callback: function ($$v) {
                          _vm.$set(_vm.show_fields, field.key, $$v)
                        },
                        expression: "show_fields[field.key]",
                      },
                    },
                    [
                      _vm._v(
                        "\n\t\t\t\t\t\t" + _vm._s(field.name) + "\n\t\t\t\t\t"
                      ),
                    ]
                  ),
                ],
                1
              )
            }),
            0
          ),
        ]
      ),
      _vm._v(" "),
       false
        ? 0
        : _vm._e(),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Indicators.vue?vue&type=template&id=ac69ec50&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Indicators.vue?vue&type=template&id=ac69ec50& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "indicators px-3 py-1" },
    [
      _c("div", { staticClass: "d-flex mb-2 mt-2 jcsb aifs" }, [
        _c("div", { staticClass: "d-flex aic mr-2" }, [
          _c("div", { staticClass: "d-flex aic mr-2" }, [
            _c("span", [_vm._v("Показывать:")]),
            _vm._v(" "),
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.pageSize,
                  expression: "pageSize",
                },
              ],
              staticClass: "form-control ml-2 input-sm",
              attrs: { type: "number", min: "1", max: "100" },
              domProps: { value: _vm.pageSize },
              on: {
                input: function ($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.pageSize = $event.target.value
                },
              },
            }),
          ]),
          _vm._v(" "),
          _c("input", {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.searchText,
                expression: "searchText",
              },
            ],
            staticClass: "searcher mr-2 form-control",
            attrs: { type: "text", placeholder: "Поиск по совпадениям..." },
            domProps: { value: _vm.searchText },
            on: {
              keyup: _vm.onSearch,
              input: function ($event) {
                if ($event.target.composing) {
                  return
                }
                _vm.searchText = $event.target.value
              },
            },
          }),
          _vm._v(" "),
          _c("span", { staticClass: "ml-2 whitespace-no-wrap" }, [
            _vm._v(
              "\n\t\t\t\tНайдено: " + _vm._s(_vm.items.length) + "\n\t\t\t"
            ),
          ]),
        ]),
      ]),
      _vm._v(" "),
      _c(
        "table",
        {
          staticClass: "table table-responsive j-table thead-word-break-normal",
        },
        [
          _c("thead", [
            _c(
              "tr",
              [
                _c("th", { staticClass: "b-table-sticky-column text-center" }, [
                  _c("i", {
                    staticClass: "icon-nd-settings",
                    on: { click: _vm.adjustFields },
                  }),
                ]),
                _vm._v(" "),
                _vm._l(_vm.fields, function (field, i) {
                  return _c(
                    "th",
                    {
                      key: i,
                      class: [
                        field.class,
                        { "b-table-sticky-column l-60": field.key == "name" },
                      ],
                    },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(field.name) + "\n\t\t\t\t")]
                  )
                }),
              ],
              2
            ),
          ]),
          _vm._v(" "),
          _c(
            "tbody",
            [
              _vm._l(_vm.page_items, function (item, i) {
                return [
                  _c(
                    "tr",
                    { key: i },
                    [
                      _c(
                        "td",
                        { staticClass: "b-table-sticky-column text-center" },
                        [
                          _vm._v(
                            "\n\t\t\t\t\t\t" + _vm._s(i + 1) + "\n\t\t\t\t\t"
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _vm._l(_vm.fields, function (field, f) {
                        return _c(
                          "td",
                          {
                            key: f,
                            class: [
                              field.class,
                              {
                                "b-table-sticky-column l-60":
                                  field.key == "name",
                              },
                            ],
                          },
                          [
                            field.key == "created_by" && item.creator != null
                              ? [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(
                                        item.creator.last_name +
                                          " " +
                                          item.creator.name
                                      ) +
                                      "\n\t\t\t\t\t\t"
                                  ),
                                ]
                              : field.key == "updated_by" &&
                                item.updater != null
                              ? [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(
                                        item.updater.last_name +
                                          " " +
                                          item.updater.name
                                      ) +
                                      "\n\t\t\t\t\t\t"
                                  ),
                                ]
                              : _vm.non_editable_fields.includes(field.key)
                              ? [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(item[field.key]) +
                                      "\n\t\t\t\t\t\t"
                                  ),
                                ]
                              : field.key == "source" &&
                                item.source != undefined
                              ? [
                                  _c(
                                    "div",
                                    { staticClass: "d-flex text-left" },
                                    [
                                      _vm.sources[item.source] !== undefined
                                        ? _c("div", { staticClass: "mr-4" }, [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\t\t" +
                                                _vm._s(
                                                  _vm.sources[item.source]
                                                ) +
                                                "\n\t\t\t\t\t\t\t\t"
                                            ),
                                          ])
                                        : _vm._e(),
                                      _vm._v(" "),
                                      Number(item.source) == 1 &&
                                      _vm.groups[item.group_id] !== undefined
                                        ? _c("div", [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\t\t" +
                                                _vm._s(
                                                  _vm.groups[item.group_id]
                                                ) +
                                                "\n\t\t\t\t\t\t\t\t"
                                            ),
                                          ])
                                        : _vm._e(),
                                    ]
                                  ),
                                ]
                              : field.key == "method"
                              ? [
                                  _vm.methods[item.method] !== undefined
                                    ? _c("div", [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t" +
                                            _vm._s(_vm.methods[item.method]) +
                                            "\n\t\t\t\t\t\t\t"
                                        ),
                                      ])
                                    : _vm._e(),
                                ]
                              : field.key == "view"
                              ? [
                                  _vm.views[item.view] !== undefined
                                    ? _c("div", [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t" +
                                            _vm._s(_vm.views[item.method]) +
                                            "\n\t\t\t\t\t\t\t"
                                        ),
                                      ])
                                    : _vm._e(),
                                ]
                              : field.key == "editable"
                              ? [
                                  _c("input", {
                                    attrs: { type: "checkbox", disabled: "" },
                                    domProps: { checked: item[field.key] },
                                  }),
                                ]
                              : [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(item[field.key]) +
                                      "\n\t\t\t\t\t\t"
                                  ),
                                ],
                          ],
                          2
                        )
                      }),
                    ],
                    2
                  ),
                ]
              }),
            ],
            2
          ),
        ]
      ),
      _vm._v(" "),
      _c("JwPagination", {
        key: _vm.paginationKey,
        attrs: {
          items: _vm.items,
          labels: {
            first: "<<",
            last: ">>",
            previous: "<",
            next: ">",
          },
          "page-size": +_vm.pageSize,
        },
        on: { changePage: _vm.onChangePage },
      }),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            title: "Настройка списка",
            "ok-text": "Закрыть",
            size: "lg",
          },
          on: {
            ok: function ($event) {
              _vm.modalAdjustVisibleFields = !_vm.modalAdjustVisibleFields
            },
          },
          model: {
            value: _vm.modalAdjustVisibleFields,
            callback: function ($$v) {
              _vm.modalAdjustVisibleFields = $$v
            },
            expression: "modalAdjustVisibleFields",
          },
        },
        [
          _c(
            "div",
            { staticClass: "row" },
            _vm._l(_vm.all_fields, function (field, f) {
              return _c(
                "div",
                { key: f, staticClass: "col-md-4 mb-2" },
                [
                  _c(
                    "b-form-checkbox",
                    {
                      attrs: { value: true, "unchecked-value": false },
                      model: {
                        value: _vm.show_fields[field.key],
                        callback: function ($$v) {
                          _vm.$set(_vm.show_fields, field.key, $$v)
                        },
                        expression: "show_fields[field.key]",
                      },
                    },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(field.name) + "\n\t\t\t\t")]
                  ),
                ],
                1
              )
            }),
            0
          ),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=template&id=4821a280&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/Kpi.vue?vue&type=template&id=4821a280& ***!
  \**************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "kpi" },
    [
      _c("div", { staticClass: "d-flex my-4 jcsb aifs" }, [
        _c(
          "div",
          { staticClass: "d-flex aic mr-2" },
          [
            _c("div", { staticClass: "d-flex aic mr-2" }, [
              _c("span", [_vm._v("Показывать:")]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.pageSize,
                    expression: "pageSize",
                  },
                ],
                staticClass: "form-control ml-2 input-sm",
                attrs: { type: "number", min: "1", max: "100" },
                domProps: { value: _vm.pageSize },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.pageSize = $event.target.value
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("SuperFilter", {
              ref: "child",
              attrs: { groups: _vm.groups },
              on: { apply: _vm.fetchKPI },
            }),
            _vm._v(" "),
            _c("span", { staticClass: "ml-2" }, [
              _vm._v(
                "\n\t\t\t\t\tНайдено: " +
                  _vm._s(_vm.items.length) +
                  "\n\t\t\t\t"
              ),
            ]),
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "button",
          { staticClass: "btn rounded btn-success", on: { click: _vm.addKpi } },
          [
            _c("i", { staticClass: "fa fa-plus mr-2" }),
            _vm._v(" "),
            _c("span", [_vm._v("Добавить")]),
          ]
        ),
      ]),
      _vm._v(" "),
      _c("table", { staticClass: "j-table" }, [
        _c("thead", [
          _c(
            "tr",
            { staticClass: "table-heading" },
            [
              _c(
                "th",
                {
                  staticClass: "first-column text-center pointer",
                  on: { click: _vm.adjustFields },
                },
                [_c("i", { staticClass: "icon-nd-settings" })]
              ),
              _vm._v(" "),
              _vm._l(_vm.fields, function (field, i) {
                return _c("th", { key: i, class: field.class }, [
                  _vm._v(
                    "\n\t\t\t\t\t\t" + _vm._s(field.name) + "\n\t\t\t\t\t"
                  ),
                ])
              }),
              _vm._v(" "),
              _c("th", [_vm._v("Действия")]),
            ],
            2
          ),
        ]),
        _vm._v(" "),
        _c(
          "tbody",
          [
            _vm._l(_vm.page_items, function (item, i) {
              return [
                _c(
                  "tr",
                  { key: i },
                  [
                    _c(
                      "td",
                      {
                        staticClass: "pointer",
                        on: {
                          click: function ($event) {
                            return _vm.expand(i)
                          },
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "d-flex align-items-center px-2" },
                          [
                            _c("span", { staticClass: "mr-2" }, [
                              _vm._v(_vm._s(i + 1)),
                            ]),
                            _vm._v(" "),
                            item.expanded
                              ? _c("i", { staticClass: "fa fa-minus mt-1" })
                              : _c("i", { staticClass: "fa fa-plus mt-1" }),
                          ]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _vm._l(_vm.fields, function (field, f) {
                      return _c("td", { key: f, class: field.class }, [
                        field.key == "target"
                          ? _c(
                              "div",
                              [
                                item.target == null || item.id == 0
                                  ? _c("SuperSelect", {
                                      key: i,
                                      staticClass: "w-full",
                                      attrs: {
                                        values:
                                          item.target == null
                                            ? []
                                            : [item.target],
                                        single: true,
                                      },
                                      on: {
                                        choose: function (target) {
                                          return (item.target = target)
                                        },
                                        remove: function () {
                                          return (item.target = null)
                                        },
                                      },
                                    })
                                  : _c(
                                      "div",
                                      { staticClass: "d-flex aic" },
                                      [
                                        item.target.type == 1
                                          ? _c("i", {
                                              staticClass: "fa fa-user ml-2",
                                            })
                                          : _vm._e(),
                                        _vm._v(" "),
                                        item.target.type == 2
                                          ? _c("i", {
                                              staticClass: "fa fa-users ml-2",
                                            })
                                          : _vm._e(),
                                        _vm._v(" "),
                                        item.target.type == 3
                                          ? _c("i", {
                                              staticClass:
                                                "fa fa-briefcase ml-2",
                                            })
                                          : _vm._e(),
                                        _vm._v(" "),
                                        _c(
                                          "span",
                                          { staticClass: "ml-2 kpi-name-rows" },
                                          [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\t\t\t" +
                                                _vm._s(item.target.name) +
                                                "\n\t\t\t\t\t\t\t\t\t\t"
                                            ),
                                            item.user
                                              ? _c(
                                                  "span",
                                                  {
                                                    staticClass: "kpi-name-row",
                                                  },
                                                  [
                                                    _vm._v(
                                                      "\n\t\t\t\t\t\t\t\t\t\t\t(" +
                                                        _vm._s(
                                                          _vm.getUserGourpsString(
                                                            item.user
                                                          )
                                                        ) +
                                                        ")\n\t\t\t\t\t\t\t\t\t\t"
                                                    ),
                                                  ]
                                                )
                                              : _vm._e(),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "b-form-checkbox",
                                          {
                                            staticClass: "kpi-status-switch",
                                            attrs: {
                                              switch: "",
                                              checked: !!item.is_active,
                                              disabled: _vm.statusRequest,
                                            },
                                            on: {
                                              input: function ($event) {
                                                return _vm.changeStatus(
                                                  item,
                                                  $event
                                                )
                                              },
                                            },
                                          },
                                          [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\t\t\t \n\t\t\t\t\t\t\t\t\t"
                                            ),
                                          ]
                                        ),
                                      ],
                                      1
                                    ),
                              ],
                              1
                            )
                          : field.key == "stats"
                          ? _c("div", { class: field.class }, [
                              _c(
                                "a",
                                {
                                  staticClass: "btn btn-primary btn-icon",
                                  attrs: {
                                    href:
                                      "/kpi?target=" +
                                      (item.target ? item.target.name : ""),
                                    target: "_blank",
                                  },
                                },
                                [_c("i", { staticClass: "fa fa-chart-bar" })]
                              ),
                            ])
                          : field.key == "created_by" && item.creator != null
                          ? _c("div", [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t\t" +
                                  _vm._s(
                                    item.creator.last_name +
                                      " " +
                                      item.creator.name
                                  ) +
                                  "\n\t\t\t\t\t\t\t"
                              ),
                            ])
                          : field.key == "updated_by" && item.updater != null
                          ? _c("div", [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t\t" +
                                  _vm._s(
                                    item.updater.last_name +
                                      " " +
                                      item.updater.name
                                  ) +
                                  "\n\t\t\t\t\t\t\t"
                              ),
                            ])
                          : _vm.non_editable_fields.includes(field.key)
                          ? _c("div", { class: field.class }, [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t\t" +
                                  _vm._s(item[field.key]) +
                                  "\n\t\t\t\t\t\t\t"
                              ),
                            ])
                          : _c("div", { class: field.class }, [
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: item[field.key],
                                    expression: "item[field.key]",
                                  },
                                ],
                                staticClass: "form-control",
                                attrs: { type: "text" },
                                domProps: { value: item[field.key] },
                                on: {
                                  change: function ($event) {
                                    return _vm.validate(
                                      item[field.key],
                                      field.key
                                    )
                                  },
                                  input: function ($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      item,
                                      field.key,
                                      $event.target.value
                                    )
                                  },
                                },
                              }),
                            ]),
                      ])
                    }),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { staticClass: "d-flex" }, [
                        _c("i", {
                          staticClass:
                            "fa fa-save ml-2 mr-1 btn btn-success btn-icon",
                          on: {
                            click: function ($event) {
                              return _vm.saveKpi(i)
                            },
                          },
                        }),
                        _vm._v(" "),
                        _c("i", {
                          staticClass: "fa fa-trash btn btn-danger btn-icon",
                          on: {
                            click: function ($event) {
                              return _vm.deleteKpi(i)
                            },
                          },
                        }),
                      ]),
                    ]),
                  ],
                  2
                ),
                _vm._v(" "),
                item.items !== undefined
                  ? [
                      _c(
                        "tr",
                        {
                          key: i + "a",
                          staticClass: "collapsable",
                          class: { active: item.expanded },
                        },
                        [
                          _c(
                            "td",
                            { attrs: { colspan: _vm.fields.length + 2 } },
                            [
                              _c(
                                "div",
                                { staticClass: "table__wrapper w-100" },
                                [
                                  _c("KpiItems", {
                                    attrs: {
                                      kpi_id: item.id,
                                      items: item.items,
                                      expanded: item.expanded,
                                      activities: _vm.activities,
                                      groups: _vm.groups,
                                      completed_80: item.completed_80,
                                      completed_100: item.completed_100,
                                      lower_limit: item.lower_limit,
                                      upper_limit: item.upper_limit,
                                      editable: true,
                                      kpi_page: true,
                                    },
                                    on: {
                                      getSum: function ($event) {
                                        item.my_sum = $event
                                      },
                                    },
                                  }),
                                ],
                                1
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  : _vm._e(),
              ]
            }),
          ],
          2
        ),
      ]),
      _vm._v(" "),
      _c("JwPagination", {
        key: _vm.paginationKey,
        staticClass: "mt-3",
        attrs: {
          items: _vm.items,
          labels: {
            first: "<<",
            last: ">>",
            previous: "<",
            next: ">",
          },
          "page-size": +_vm.pageSize,
        },
        on: { changePage: _vm.onChangePage },
      }),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            title: "Настройка списка «KPI»",
            "ok-text": "Закрыть",
            size: "lg",
          },
          on: {
            ok: function ($event) {
              _vm.modalAdjustVisibleFields = !_vm.modalAdjustVisibleFields
            },
          },
          model: {
            value: _vm.modalAdjustVisibleFields,
            callback: function ($$v) {
              _vm.modalAdjustVisibleFields = $$v
            },
            expression: "modalAdjustVisibleFields",
          },
        },
        [
          _c(
            "div",
            { staticClass: "row" },
            _vm._l(_vm.all_fields, function (field, f) {
              return _c(
                "div",
                { key: f, staticClass: "col-md-4 mb-4" },
                [
                  _c(
                    "b-form-checkbox",
                    {
                      attrs: { value: true, "unchecked-value": false },
                      model: {
                        value: _vm.show_fields[field.key],
                        callback: function ($$v) {
                          _vm.$set(_vm.show_fields, field.key, $$v)
                        },
                        expression: "show_fields[field.key]",
                      },
                    },
                    [
                      _vm._v(
                        "\n\t\t\t\t\t\t" + _vm._s(field.name) + "\n\t\t\t\t\t"
                      ),
                    ]
                  ),
                ],
                1
              )
            }),
            0
          ),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItems.vue?vue&type=template&id=bdb891e0&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItems.vue?vue&type=template&id=bdb891e0& ***!
  \*******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "kpi-item" },
    [
      _c("table", { staticClass: "table table-inner" }, [
        _c("thead", [
          _c("tr", [
            _c("th"),
            _vm._v(" "),
            _c("th", [_vm._v("Наименование активности")]),
            _vm._v(" "),
            _c("th", [_vm._v("Вид плана")]),
            _vm._v(" "),
            _vm.kpi_page
              ? _c("th", [
                  _vm._v("\n\t\t\t\t\tПоказатели "),
                  _c("i", {
                    staticClass: "fa fa-info-circle",
                    on: {
                      click: function ($event) {
                        return _vm.showDescription()
                      },
                    },
                  }),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.kpi_page
              ? _c("th", [_vm._v("\n\t\t\t\t\tЕд. изм.\n\t\t\t\t")])
              : _vm._e(),
            _vm._v(" "),
            _c("th", [_vm._v("Целевое значение на месяц")]),
            _vm._v(" "),
            _c("th", [_vm._v("Удельный вес, %")]),
            _vm._v(" "),
            !_vm.kpi_page
              ? _c("th", [_vm._v("\n\t\t\t\t\tФакт\n\t\t\t\t")])
              : _vm._e(),
            _vm._v(" "),
            !_vm.kpi_page
              ? _c("th", [_vm._v("\n\t\t\t\t\t% выполнения\n\t\t\t\t")])
              : _vm._e(),
            _vm._v(" "),
            _c("th", [_vm._v("Сумма премии при выполнении плана, KZT")]),
            _vm._v(" "),
            _c("th", [_vm._v("Заработано")]),
            _vm._v(" "),
            _vm.kpi_page ? _c("th") : _vm._e(),
          ]),
        ]),
        _vm._v(" "),
        _c(
          "tbody",
          { key: _vm.refreshItemsKey },
          [
            _vm.kpi_page
              ? [
                  _vm._l(_vm.items, function (item, i) {
                    return _c(
                      "tr",
                      {
                        key: i,
                        staticClass: "jt-row",
                        class: {
                          "j-hidden": !_vm.expanded,
                          "j-deleted":
                            item.deleted != undefined && item.deleted,
                        },
                      },
                      [
                        _c("td", { staticClass: "first-column text-center" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t" + _vm._s(i + 1) + "\n\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.name,
                                expression: "item.name",
                              },
                            ],
                            attrs: { type: "text" },
                            domProps: { value: item.name },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "name", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _c(
                            "select",
                            {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: item.method,
                                  expression: "item.method",
                                },
                              ],
                              on: {
                                change: function ($event) {
                                  var $$selectedVal = Array.prototype.filter
                                    .call($event.target.options, function (o) {
                                      return o.selected
                                    })
                                    .map(function (o) {
                                      var val =
                                        "_value" in o ? o._value : o.value
                                      return val
                                    })
                                  _vm.$set(
                                    item,
                                    "method",
                                    $event.target.multiple
                                      ? $$selectedVal
                                      : $$selectedVal[0]
                                  )
                                },
                              },
                            },
                            _vm._l(Object.keys(_vm.methods), function (key) {
                              return _c(
                                "option",
                                { key: key, domProps: { value: key } },
                                [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t\t" +
                                      _vm._s(_vm.methods[key]) +
                                      "\n\t\t\t\t\t\t\t"
                                  ),
                                ]
                              )
                            }),
                            0
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center no-hover" }, [
                          _c("div", { staticClass: "d-flex" }, [
                            _c(
                              "select",
                              {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: item.source,
                                    expression: "item.source",
                                  },
                                ],
                                on: {
                                  change: [
                                    function ($event) {
                                      var $$selectedVal = Array.prototype.filter
                                        .call(
                                          $event.target.options,
                                          function (o) {
                                            return o.selected
                                          }
                                        )
                                        .map(function (o) {
                                          var val =
                                            "_value" in o ? o._value : o.value
                                          return val
                                        })
                                      _vm.$set(
                                        item,
                                        "source",
                                        $event.target.multiple
                                          ? $$selectedVal
                                          : $$selectedVal[0]
                                      )
                                    },
                                    function ($event) {
                                      ++_vm.source_key
                                    },
                                  ],
                                },
                              },
                              _vm._l(Object.keys(_vm.sources), function (key) {
                                return _c(
                                  "option",
                                  { key: key, domProps: { value: key } },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\t\t" +
                                        _vm._s(_vm.sources[key]) +
                                        "\n\t\t\t\t\t\t\t\t"
                                    ),
                                  ]
                                )
                              }),
                              0
                            ),
                            _vm._v(" "),
                            item.source == 1
                              ? _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: item.group_id,
                                        expression: "item.group_id",
                                      },
                                    ],
                                    key: "c" + _vm.source_key,
                                    on: {
                                      change: [
                                        function ($event) {
                                          var $$selectedVal =
                                            Array.prototype.filter
                                              .call(
                                                $event.target.options,
                                                function (o) {
                                                  return o.selected
                                                }
                                              )
                                              .map(function (o) {
                                                var val =
                                                  "_value" in o
                                                    ? o._value
                                                    : o.value
                                                return val
                                              })
                                          _vm.$set(
                                            item,
                                            "group_id",
                                            $event.target.multiple
                                              ? $$selectedVal
                                              : $$selectedVal[0]
                                          )
                                        },
                                        function ($event) {
                                          ++_vm.source_key
                                        },
                                      ],
                                    },
                                  },
                                  [
                                    _c(
                                      "option",
                                      { attrs: { value: "0", selected: "" } },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _vm._l(_vm.groups, function (group, id) {
                                      return _c(
                                        "option",
                                        { key: id, domProps: { value: id } },
                                        [
                                          _vm._v(
                                            "\n\t\t\t\t\t\t\t\t\t" +
                                              _vm._s(group) +
                                              "\n\t\t\t\t\t\t\t\t"
                                          ),
                                        ]
                                      )
                                    }),
                                  ],
                                  2
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            _c(
                              "select",
                              {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: item.activity_id,
                                    expression: "item.activity_id",
                                  },
                                ],
                                key: "d" + _vm.source_key,
                                class: { hidden: item.source == 0 },
                                on: {
                                  change: function ($event) {
                                    var $$selectedVal = Array.prototype.filter
                                      .call(
                                        $event.target.options,
                                        function (o) {
                                          return o.selected
                                        }
                                      )
                                      .map(function (o) {
                                        var val =
                                          "_value" in o ? o._value : o.value
                                        return val
                                      })
                                    _vm.$set(
                                      item,
                                      "activity_id",
                                      $event.target.multiple
                                        ? $$selectedVal
                                        : $$selectedVal[0]
                                    )
                                  },
                                },
                              },
                              [
                                _c(
                                  "option",
                                  { attrs: { value: "0", selected: "" } },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _vm._l(
                                  _vm.grouped_activities(
                                    item.source,
                                    item.group_id
                                  ),
                                  function (activity) {
                                    return _c(
                                      "option",
                                      {
                                        key: activity.id,
                                        domProps: { value: activity.id },
                                      },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t" +
                                            _vm._s(activity.name) +
                                            "\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    )
                                  }
                                ),
                              ],
                              2
                            ),
                            _vm._v(" "),
                            item.source == 1 && !_vm.isCell(item.activity_id)
                              ? _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: item.common,
                                        expression: "item.common",
                                      },
                                    ],
                                    on: {
                                      change: function ($event) {
                                        var $$selectedVal =
                                          Array.prototype.filter
                                            .call(
                                              $event.target.options,
                                              function (o) {
                                                return o.selected
                                              }
                                            )
                                            .map(function (o) {
                                              var val =
                                                "_value" in o
                                                  ? o._value
                                                  : o.value
                                              return val
                                            })
                                        _vm.$set(
                                          item,
                                          "common",
                                          $event.target.multiple
                                            ? $$selectedVal
                                            : $$selectedVal[0]
                                        )
                                      },
                                    },
                                  },
                                  [
                                    _c(
                                      "option",
                                      { attrs: { value: "0", selected: "" } },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\tСвой\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c("option", { attrs: { value: "1" } }, [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t\tВсего отдела\n\t\t\t\t\t\t\t\t"
                                      ),
                                    ]),
                                  ]
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            item.source == 1 && _vm.isCell(item.activity_id)
                              ? _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item.cell,
                                      expression: "item.cell",
                                    },
                                  ],
                                  attrs: {
                                    type: "text",
                                    placeholder: "Ячейка: C7",
                                  },
                                  domProps: { value: item.cell },
                                  on: {
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        item,
                                        "cell",
                                        $event.target.value
                                      )
                                    },
                                  },
                                })
                              : _vm._e(),
                          ]),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center w-sm" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.unit,
                                expression: "item.unit",
                              },
                            ],
                            attrs: { type: "text" },
                            domProps: { value: item.unit },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "unit", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.plan,
                                expression: "item.plan",
                              },
                            ],
                            attrs: { type: "number" },
                            domProps: { value: item.plan },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "plan", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.share,
                                expression: "item.share",
                              },
                            ],
                            attrs: { type: "number", min: "0", max: "100" },
                            domProps: { value: item.share },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "share", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t" + _vm._s(item.sum) + "\n\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t" +
                              _vm._s(
                                parseInt(item.sum * (item.percent / 100))
                              ) +
                              "\n\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "no-hover" }, [
                          item.deleted != undefined && item.deleted
                            ? _c("i", {
                                staticClass:
                                  "fa fa-arrow-up mx-3 btn btn-danger btn-icon",
                                on: {
                                  click: function ($event) {
                                    return _vm.restoreItem(i)
                                  },
                                },
                              })
                            : _c("i", {
                                staticClass:
                                  "fa fa-trash mx-3 btn btn-danger btn-icon",
                                on: {
                                  click: function ($event) {
                                    return _vm.deleteItem(i)
                                  },
                                },
                              }),
                        ]),
                      ]
                    )
                  }),
                  _vm._v(" "),
                  _c("tr", [
                    _c(
                      "td",
                      {
                        staticClass: "plus-item",
                        attrs: { colspan: "10" },
                        on: { click: _vm.addItem },
                      },
                      [_vm._m(0)]
                    ),
                  ]),
                ]
              : _vm._l(_vm.items, function (item, i) {
                  return _c(
                    "tr",
                    {
                      key: i,
                      staticClass: "jt-row j-hidden",
                      class: {
                        "j-hidden": !_vm.expanded,
                      },
                    },
                    [
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(i + 1) + "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "px-2" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(item.name) + "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(_vm.methods[item.method]) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _c("b", [
                          _vm._v(_vm._s(item.plan) + " " + _vm._s(item.unit)),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(item.share) + "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _vm.editable
                        ? _c("td", { staticClass: "text-center" }, [
                            [1, 3, 5].includes(item.method)
                              ? _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item.fact,
                                      expression: "item.fact",
                                    },
                                  ],
                                  attrs: { type: "number", min: "0" },
                                  domProps: { value: item.fact },
                                  on: {
                                    change: function ($event) {
                                      return _vm.updateStat(i)
                                    },
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        item,
                                        "fact",
                                        $event.target.value
                                      )
                                    },
                                  },
                                })
                              : _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item.avg,
                                      expression: "item.avg",
                                    },
                                  ],
                                  attrs: { type: "number", min: "0" },
                                  domProps: { value: item.avg },
                                  on: {
                                    change: function ($event) {
                                      return _vm.updateStat(i)
                                    },
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(item, "avg", $event.target.value)
                                    },
                                  },
                                }),
                          ])
                        : _c("td", { staticClass: "text-center" }, [
                            [1, 3, 5].includes(item.method)
                              ? _c("div", [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(item.fact) +
                                      "\n\t\t\t\t\t\t"
                                  ),
                                ])
                              : _c("div", [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(Number(item.avg).toFixed(2)) +
                                      "\n\t\t\t\t\t\t"
                                  ),
                                ]),
                          ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(item.percent) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(_vm.my_sum * (parseInt(item.share) / 100)) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(item.sum) + "\n\t\t\t\t\t"
                        ),
                      ]),
                    ]
                  )
                }),
          ],
          2
        ),
      ]),
      _vm._v(" "),
      _c(
        "sidebar",
        {
          attrs: {
            title: "Показатели",
            open: _vm.show_description,
            width: "70%",
          },
          on: {
            close: function ($event) {
              return _vm.toggle()
            },
          },
        },
        [
          _c("p", [
            _vm._v(
              "Тут указывается какой показатель сотрудника нужно смотреть для выявления процента выполнения."
            ),
          ]),
          _vm._v(" "),
          _c("p", [_vm._v("Первый select источник:")]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- без источникa:")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("руководитель сам будет ставить нужный коэффициент"),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- из показателей отдела: ")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("берем данные из подробных таблиц в Аналитике отдела."),
          ]),
          _vm._v(" "),
          _c("p", [_vm._v("Появляются три selectа:")]),
          _vm._v(" "),
          _c("ul", [
            _c("li", [_vm._v("выбираем отдел")]),
            _vm._v(" "),
            _c("li", [_vm._v("выбираем показатель")]),
            _vm._v(" "),
            _c("li", [
              _vm._v("выбор "),
              _c("em", [_vm._v("Свой")]),
              _vm._v(" или "),
              _c("em", [_vm._v("Всего отдела")]),
              _vm._v(
                ". Свой выберет только показатель пользователя, а Всего отдела - какой показатель сделал отдел."
              ),
            ]),
          ]),
          _vm._v(" "),
          _c("p", [
            _vm._v("Если выбрать "),
            _c("em", [_vm._v("ячейка из сводной")]),
            _vm._v(" нужно будет указать название ячейки как в Excel."),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- из битрикса:")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("Если в интеграции настроен "),
            _c("strong", [_vm._v("Битрикс24")]),
            _vm._v(
              ", будем брать оттуда показатели, при условии, что  ID пользователей из битрикса были связаны с Jobtron."
            ),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- из amocrm:")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("Если в интеграции настроен "),
            _c("strong", [_vm._v("Amocrm")]),
            _vm._v(
              ", будем брать оттуда показатели, при условии, что  ID пользователей из amocrm были связаны с Jobtron."
            ),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- другие :")])]),
          _vm._v(" "),
          _c("p", [_vm._v("разные показатели в Jobtron")]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "p-4" }, [
      _c("i", { staticClass: "fa fa-plus mr-2" }),
      _vm._v(" "),
      _c("b", [_vm._v("Добавить активность")]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiItemsV2.vue?vue&type=template&id=2775d5ac& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "kpi-item" },
    [
      _c("table", { staticClass: "table table-inner" }, [
        _c("thead", [
          _c("tr", [
            _c("th"),
            _vm._v(" "),
            _c("th", [_vm._v("Наименование активности")]),
            _vm._v(" "),
            _c("th", [_vm._v("Вид плана")]),
            _vm._v(" "),
            _vm.kpi_page
              ? _c("th", [
                  _vm._v("\n\t\t\t\t\tПоказатели "),
                  _c("i", {
                    staticClass: "fa fa-info-circle",
                    on: {
                      click: function ($event) {
                        return _vm.showDescription()
                      },
                    },
                  }),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.kpi_page
              ? _c("th", [_vm._v("\n\t\t\t\t\tЕд. изм.\n\t\t\t\t")])
              : _vm._e(),
            _vm._v(" "),
            _c("th", [_vm._v("Целевое значение на месяц")]),
            _vm._v(" "),
            _c("th", [_vm._v("Удельный вес, %")]),
            _vm._v(" "),
            !_vm.kpi_page
              ? _c("th", [_vm._v("\n\t\t\t\t\tФакт\n\t\t\t\t")])
              : _vm._e(),
            _vm._v(" "),
            !_vm.kpi_page
              ? _c("th", [_vm._v("\n\t\t\t\t\t% выполнения\n\t\t\t\t")])
              : _vm._e(),
            _vm._v(" "),
            _c("th", [_vm._v("Сумма премии при выполнении плана, KZT")]),
            _vm._v(" "),
            _c("th", [_vm._v("Заработано")]),
            _vm._v(" "),
            _vm.kpi_page ? _c("th") : _vm._e(),
          ]),
        ]),
        _vm._v(" "),
        _c(
          "tbody",
          { key: _vm.refreshItemsKey },
          [
            _vm.kpi_page
              ? [
                  _vm._l(_vm.items, function (item, i) {
                    return _c(
                      "tr",
                      {
                        key: i,
                        staticClass: "jt-row",
                        class: {
                          "j-hidden": !_vm.expanded,
                          "j-deleted":
                            item.deleted != undefined && item.deleted,
                        },
                      },
                      [
                        _c("td", { staticClass: "first-column text-center" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t" + _vm._s(i + 1) + "\n\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.name,
                                expression: "item.name",
                              },
                            ],
                            attrs: { type: "text" },
                            domProps: { value: item.name },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "name", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _c(
                            "select",
                            {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: item.method,
                                  expression: "item.method",
                                },
                              ],
                              on: {
                                change: function ($event) {
                                  var $$selectedVal = Array.prototype.filter
                                    .call($event.target.options, function (o) {
                                      return o.selected
                                    })
                                    .map(function (o) {
                                      var val =
                                        "_value" in o ? o._value : o.value
                                      return val
                                    })
                                  _vm.$set(
                                    item,
                                    "method",
                                    $event.target.multiple
                                      ? $$selectedVal
                                      : $$selectedVal[0]
                                  )
                                },
                              },
                            },
                            _vm._l(Object.keys(_vm.methods), function (key) {
                              return _c(
                                "option",
                                { key: key, domProps: { value: key } },
                                [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t\t" +
                                      _vm._s(_vm.methods[key]) +
                                      "\n\t\t\t\t\t\t\t"
                                  ),
                                ]
                              )
                            }),
                            0
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center no-hover" }, [
                          _c("div", { staticClass: "d-flex" }, [
                            _c(
                              "select",
                              {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: item.source,
                                    expression: "item.source",
                                  },
                                ],
                                on: {
                                  change: [
                                    function ($event) {
                                      var $$selectedVal = Array.prototype.filter
                                        .call(
                                          $event.target.options,
                                          function (o) {
                                            return o.selected
                                          }
                                        )
                                        .map(function (o) {
                                          var val =
                                            "_value" in o ? o._value : o.value
                                          return val
                                        })
                                      _vm.$set(
                                        item,
                                        "source",
                                        $event.target.multiple
                                          ? $$selectedVal
                                          : $$selectedVal[0]
                                      )
                                    },
                                    function ($event) {
                                      ++_vm.source_key
                                    },
                                  ],
                                },
                              },
                              _vm._l(Object.keys(_vm.sources), function (key) {
                                return _c(
                                  "option",
                                  { key: key, domProps: { value: key } },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\t\t" +
                                        _vm._s(_vm.sources[key]) +
                                        "\n\t\t\t\t\t\t\t\t"
                                    ),
                                  ]
                                )
                              }),
                              0
                            ),
                            _vm._v(" "),
                            item.source == 1
                              ? _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: item.group_id,
                                        expression: "item.group_id",
                                      },
                                    ],
                                    key: "c" + _vm.source_key,
                                    on: {
                                      change: [
                                        function ($event) {
                                          var $$selectedVal =
                                            Array.prototype.filter
                                              .call(
                                                $event.target.options,
                                                function (o) {
                                                  return o.selected
                                                }
                                              )
                                              .map(function (o) {
                                                var val =
                                                  "_value" in o
                                                    ? o._value
                                                    : o.value
                                                return val
                                              })
                                          _vm.$set(
                                            item,
                                            "group_id",
                                            $event.target.multiple
                                              ? $$selectedVal
                                              : $$selectedVal[0]
                                          )
                                        },
                                        function ($event) {
                                          ++_vm.source_key
                                        },
                                      ],
                                    },
                                  },
                                  [
                                    _c(
                                      "option",
                                      { attrs: { value: "0", selected: "" } },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _vm._l(_vm.groups, function (group, id) {
                                      return _c(
                                        "option",
                                        { key: id, domProps: { value: id } },
                                        [
                                          _vm._v(
                                            "\n\t\t\t\t\t\t\t\t\t" +
                                              _vm._s(group) +
                                              "\n\t\t\t\t\t\t\t\t"
                                          ),
                                        ]
                                      )
                                    }),
                                  ],
                                  2
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            _c(
                              "select",
                              {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: item.activity_id,
                                    expression: "item.activity_id",
                                  },
                                ],
                                key: "d" + _vm.source_key,
                                class: { hidden: item.source == 0 },
                                on: {
                                  change: function ($event) {
                                    var $$selectedVal = Array.prototype.filter
                                      .call(
                                        $event.target.options,
                                        function (o) {
                                          return o.selected
                                        }
                                      )
                                      .map(function (o) {
                                        var val =
                                          "_value" in o ? o._value : o.value
                                        return val
                                      })
                                    _vm.$set(
                                      item,
                                      "activity_id",
                                      $event.target.multiple
                                        ? $$selectedVal
                                        : $$selectedVal[0]
                                    )
                                  },
                                },
                              },
                              [
                                _c(
                                  "option",
                                  { attrs: { value: "0", selected: "" } },
                                  [
                                    _vm._v(
                                      "\n\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t"
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _vm._l(
                                  _vm.grouped_activities(
                                    item.source,
                                    item.group_id
                                  ),
                                  function (activity) {
                                    return _c(
                                      "option",
                                      {
                                        key: activity.id,
                                        domProps: { value: activity.id },
                                      },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t" +
                                            _vm._s(activity.name) +
                                            "\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    )
                                  }
                                ),
                              ],
                              2
                            ),
                            _vm._v(" "),
                            item.source == 1 && !_vm.isCell(item.activity_id)
                              ? _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: item.common,
                                        expression: "item.common",
                                      },
                                    ],
                                    on: {
                                      change: function ($event) {
                                        var $$selectedVal =
                                          Array.prototype.filter
                                            .call(
                                              $event.target.options,
                                              function (o) {
                                                return o.selected
                                              }
                                            )
                                            .map(function (o) {
                                              var val =
                                                "_value" in o
                                                  ? o._value
                                                  : o.value
                                              return val
                                            })
                                        _vm.$set(
                                          item,
                                          "common",
                                          $event.target.multiple
                                            ? $$selectedVal
                                            : $$selectedVal[0]
                                        )
                                      },
                                    },
                                  },
                                  [
                                    _c(
                                      "option",
                                      { attrs: { value: "0", selected: "" } },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\tСвой\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c("option", { attrs: { value: "1" } }, [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t\tВсего отдела\n\t\t\t\t\t\t\t\t"
                                      ),
                                    ]),
                                  ]
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            item.source == 1 && _vm.isCell(item.activity_id)
                              ? _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item.cell,
                                      expression: "item.cell",
                                    },
                                  ],
                                  attrs: {
                                    type: "text",
                                    placeholder: "Ячейка: C7",
                                  },
                                  domProps: { value: item.cell },
                                  on: {
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        item,
                                        "cell",
                                        $event.target.value
                                      )
                                    },
                                  },
                                })
                              : _vm._e(),
                          ]),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center w-sm" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.unit,
                                expression: "item.unit",
                              },
                            ],
                            attrs: { type: "text" },
                            domProps: { value: item.unit },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "unit", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.plan,
                                expression: "item.plan",
                              },
                            ],
                            attrs: { type: "number" },
                            domProps: { value: item.plan },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "plan", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: item.share,
                                expression: "item.share",
                              },
                            ],
                            attrs: { type: "number", min: "0", max: "100" },
                            domProps: { value: item.share },
                            on: {
                              input: function ($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(item, "share", $event.target.value)
                              },
                            },
                          }),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t" + _vm._s(item.sum) + "\n\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-center" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t" +
                              _vm._s(
                                parseInt(item.sum * (item.percent / 100))
                              ) +
                              "\n\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", { staticClass: "no-hover" }, [
                          item.deleted != undefined && item.deleted
                            ? _c("i", {
                                staticClass:
                                  "fa fa-arrow-up mx-3 btn btn-danger btn-icon",
                                on: {
                                  click: function ($event) {
                                    return _vm.restoreItem(i)
                                  },
                                },
                              })
                            : _c("i", {
                                staticClass:
                                  "fa fa-trash mx-3 btn btn-danger btn-icon",
                                on: {
                                  click: function ($event) {
                                    return _vm.deleteItem(i)
                                  },
                                },
                              }),
                        ]),
                      ]
                    )
                  }),
                  _vm._v(" "),
                  _c("tr", [
                    _c(
                      "td",
                      {
                        staticClass: "plus-item",
                        attrs: { colspan: "10" },
                        on: { click: _vm.addItem },
                      },
                      [_vm._m(0)]
                    ),
                  ]),
                ]
              : _vm._l(_vm.items, function (item, i) {
                  return _c(
                    "tr",
                    {
                      key: i,
                      staticClass: "jt-row j-hidden",
                      class: {
                        "j-hidden": !_vm.expanded,
                      },
                    },
                    [
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(i + 1) + "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "px-2" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(
                              item.histories_latest
                                ? item.histories_latest.payload.name
                                : item.name
                            ) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(_vm.methods[item.method]) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _c("b", [
                          _vm._v(
                            _vm._s(
                              item.histories_latest
                                ? item.histories_latest.payload.plan
                                : item.plan
                            ) +
                              " " +
                              _vm._s(
                                item.histories_latest
                                  ? item.histories_latest.payload.unit
                                  : item.unit
                              )
                          ),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(
                              item.histories_latest
                                ? item.histories_latest.payload.share
                                : item.share
                            ) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _vm.editable
                        ? _c("td", { staticClass: "text-center" }, [
                            [1, 3, 5].includes(item.method)
                              ? _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item.fact,
                                      expression: "item.fact",
                                    },
                                  ],
                                  attrs: { type: "number", min: "0" },
                                  domProps: { value: item.fact },
                                  on: {
                                    change: function ($event) {
                                      return _vm.updateStat(i)
                                    },
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        item,
                                        "fact",
                                        $event.target.value
                                      )
                                    },
                                  },
                                })
                              : _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: item.avg,
                                      expression: "item.avg",
                                    },
                                  ],
                                  attrs: { type: "number", min: "0" },
                                  domProps: { value: item.avg },
                                  on: {
                                    change: function ($event) {
                                      return _vm.updateStat(i)
                                    },
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(item, "avg", $event.target.value)
                                    },
                                  },
                                }),
                          ])
                        : _c("td", { staticClass: "text-center" }, [
                            [1, 3, 5].includes(item.method)
                              ? _c("div", [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(item.fact) +
                                      "\n\t\t\t\t\t\t"
                                  ),
                                ])
                              : _c("div", [
                                  _vm._v(
                                    "\n\t\t\t\t\t\t\t" +
                                      _vm._s(Number(item.avg).toFixed(2)) +
                                      "\n\t\t\t\t\t\t"
                                  ),
                                ]),
                          ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(item.percent) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(
                              _vm.my_sum *
                                (parseInt(
                                  item.histories_latest
                                    ? item.histories_latest.payload.share
                                    : item.share
                                ) /
                                  100)
                            ) +
                            "\n\t\t\t\t\t"
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(
                          "\n\t\t\t\t\t\t" + _vm._s(item.sum) + "\n\t\t\t\t\t"
                        ),
                      ]),
                    ]
                  )
                }),
          ],
          2
        ),
      ]),
      _vm._v(" "),
      _c(
        "sidebar",
        {
          attrs: {
            title: "Показатели",
            open: _vm.show_description,
            width: "70%",
          },
          on: {
            close: function ($event) {
              return _vm.toggle()
            },
          },
        },
        [
          _c("p", [
            _vm._v(
              "Тут указывается какой показатель сотрудника нужно смотреть для выявления процента выполнения."
            ),
          ]),
          _vm._v(" "),
          _c("p", [_vm._v("Первый select источник:")]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- без источникa:")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("руководитель сам будет ставить нужный коэффициент"),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- из показателей отдела: ")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("берем данные из подробных таблиц в Аналитике отдела."),
          ]),
          _vm._v(" "),
          _c("p", [_vm._v("Появляются три selectа:")]),
          _vm._v(" "),
          _c("ul", [
            _c("li", [_vm._v("выбираем отдел")]),
            _vm._v(" "),
            _c("li", [_vm._v("выбираем показатель")]),
            _vm._v(" "),
            _c("li", [
              _vm._v("выбор "),
              _c("em", [_vm._v("Свой")]),
              _vm._v(" или "),
              _c("em", [_vm._v("Всего отдела")]),
              _vm._v(
                ". Свой выберет только показатель пользователя, а Всего отдела - какой показатель сделал отдел."
              ),
            ]),
          ]),
          _vm._v(" "),
          _c("p", [
            _vm._v("Если выбрать "),
            _c("em", [_vm._v("ячейка из сводной")]),
            _vm._v(" нужно будет указать название ячейки как в Excel."),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- из битрикса:")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("Если в интеграции настроен "),
            _c("strong", [_vm._v("Битрикс24")]),
            _vm._v(
              ", будем брать оттуда показатели, при условии, что  ID пользователей из битрикса были связаны с Jobtron."
            ),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- из amocrm:")])]),
          _vm._v(" "),
          _c("p", [
            _vm._v("Если в интеграции настроен "),
            _c("strong", [_vm._v("Amocrm")]),
            _vm._v(
              ", будем брать оттуда показатели, при условии, что  ID пользователей из amocrm были связаны с Jobtron."
            ),
          ]),
          _vm._v(" "),
          _c("p", [_c("strong", [_vm._v("- другие :")])]),
          _vm._v(" "),
          _c("p", [_vm._v("разные показатели в Jobtron")]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "p-4" }, [
      _c("i", { staticClass: "fa fa-plus mr-2" }),
      _vm._v(" "),
      _c("b", [_vm._v("Добавить активность")]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=template&id=55721d14&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/KpiPages.vue?vue&type=template&id=55721d14& ***!
  \*******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.page
    ? _c("div", { staticClass: "kpi-pages" }, [
        _vm.access == "edit"
          ? _c(
              "div",
              [
                _c(
                  "b-tabs",
                  {
                    staticClass: "mt-4 kpi-tabs",
                    attrs: { type: "card", value: _vm.active },
                    on: {
                      "activate-tab": function (n, p, e) {
                        return (_vm.active = n)
                      },
                    },
                  },
                  [
                    _c(
                      "b-tab",
                      { key: 0, attrs: { title: "KPI", card: "" } },
                      [_vm.active == 0 ? _c("KPI") : _vm._e()],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-tab",
                      { key: 1, attrs: { title: "Бонусы, %", card: "" } },
                      [_vm.active == 1 ? _c("Bonuses") : _vm._e()],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-tab",
                      {
                        key: 2,
                        attrs: { title: "Квартальная премия", card: "" },
                      },
                      [_vm.active == 2 ? _c("QuartalPremium") : _vm._e()],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-tab",
                      { key: 3, attrs: { title: "Статистика", card: "" } },
                      [_vm.active == 3 ? _c("StatsV2") : _vm._e()],
                      1
                    ),
                    _vm._v(" "),
                    _vm.tenant === "bp"
                      ? _c(
                          "b-tab",
                          { key: 4, attrs: { title: "Показатели", card: "" } },
                          [
                            _vm.active == 4 && _vm.tenant === "bp"
                              ? _c("Indicators")
                              : _vm._e(),
                          ],
                          1
                        )
                      : _vm._e(),
                    _vm._v(" "),
                     false
                      ? 0
                      : _vm._e(),
                  ],
                  1
                ),
              ],
              1
            )
          : _c(
              "div",
              [
                _c(
                  "b-tabs",
                  {
                    staticClass: "mt-4",
                    attrs: { type: "card", value: _vm.active },
                    on: {
                      "activate-tab": function (n, p, e) {
                        return (_vm.active = n)
                      },
                    },
                  },
                  [
                    _c(
                      "b-tab",
                      { key: 0, attrs: { title: "Статистика", card: "" } },
                      [_vm.active == 0 ? _c("StatsV2") : _vm._e()],
                      1
                    ),
                    _vm._v(" "),
                    _vm.tenant === "bp"
                      ? _c(
                          "b-tab",
                          { key: 1, attrs: { title: "Показатели", card: "" } },
                          [
                            _vm.active == 1 && _vm.tenant === "bp"
                              ? _c("Indicators")
                              : _vm._e(),
                          ],
                          1
                        )
                      : _vm._e(),
                  ],
                  1
                ),
              ],
              1
            ),
      ])
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/QuartalPremium.vue?vue&type=template&id=9794c83e&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/QuartalPremium.vue?vue&type=template&id=9794c83e& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "quartal-premiums px-3 py-1" },
    [
      _c("div", { staticClass: "d-flex my-4 jcsb aifs" }, [
        _c(
          "div",
          { staticClass: "d-flex aic mr-2" },
          [
            _c("div", { staticClass: "d-flex aic mr-2" }, [
              _c("span", [_vm._v("Показывать:")]),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.pageSize,
                    expression: "pageSize",
                  },
                ],
                staticClass: "form-control ml-2 input-sm",
                attrs: { type: "number", min: "1", max: "100" },
                domProps: { value: _vm.pageSize },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.pageSize = $event.target.value
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("SuperFilter", {
              ref: "child",
              attrs: { groups: _vm.groups },
              on: { apply: _vm.fetch },
            }),
            _vm._v(" "),
            _c("span", { staticClass: "ml-2" }, [
              _vm._v(
                "\n\t\t\t\t\tНайдено: " +
                  _vm._s(_vm.items.length) +
                  "\n\t\t\t\t"
              ),
            ]),
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "button",
          {
            staticClass: "btn rounded btn-success",
            on: { click: _vm.addRowItem },
          },
          [
            _c("i", { staticClass: "fa fa-plus mr-2" }),
            _vm._v(" "),
            _c("span", [_vm._v("Добавить")]),
          ]
        ),
      ]),
      _vm._v(" "),
      _c("table", { staticClass: "j-table collapse-table" }, [
        _c("thead", [
          _c("tr", [
            _c("th", { staticClass: "text-center pointer" }, [
              _c("i", {
                staticClass: "icon-nd-settings",
                on: { click: _vm.adjustFields },
              }),
            ]),
            _vm._v(" "),
            _c("th", { staticClass: "text-left w-100" }, [
              _vm._v("\n\t\t\t\t\t\tКому\n\t\t\t\t\t"),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _c(
          "tbody",
          [
            _vm.premium && _vm.newPremiumArray.length > 0
              ? [
                  _c("tr", [
                    _c(
                      "td",
                      {
                        staticClass: "text-center",
                        on: {
                          click: function ($event) {
                            _vm.premium.expanded = !_vm.premium.expanded
                          },
                        },
                      },
                      [
                        _vm.premium.expanded
                          ? _c("i", { staticClass: "fa fa-minus mt-1" })
                          : _c("i", { staticClass: "fa fa-plus mt-1" }),
                      ]
                    ),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-left" }, [
                      _vm.all_fields[0].key == "target"
                        ? _c(
                            "div",
                            { staticClass: "mr-5" },
                            [
                              _vm.newPremiumArray[0].id == 0
                                ? _c("SuperSelect", {
                                    staticStyle: { width: "60%" },
                                    attrs: {
                                      values:
                                        _vm.new_target == null &&
                                        _vm.newPremiumArray.length > 0
                                          ? []
                                          : [_vm.new_target],
                                      single: true,
                                    },
                                    on: {
                                      choose: function (target) {
                                        return (_vm.new_target = target)
                                      },
                                      remove: function () {
                                        return (_vm.new_target = null)
                                      },
                                    },
                                  })
                                : _c("div", { staticClass: "d-flex aic" }, [
                                    _vm.newPremiumArray[0].target.type == 1
                                      ? _c("i", {
                                          staticClass:
                                            "fa fa-user ml-2 color-user",
                                        })
                                      : _vm._e(),
                                    _vm._v(" "),
                                    _vm.newPremiumArray[0].target.type == 2
                                      ? _c("i", {
                                          staticClass:
                                            "fa fa-users ml-2 color-group",
                                        })
                                      : _vm._e(),
                                    _vm._v(" "),
                                    _vm.newPremiumArray[0].target.type == 3
                                      ? _c("i", {
                                          staticClass:
                                            "fa fa-briefcase ml-2 color-position",
                                        })
                                      : _vm._e(),
                                    _vm._v(" "),
                                    _c("span", { staticClass: "ml-2" }, [
                                      _vm._v(
                                        _vm._s(
                                          _vm.newPremiumArray[0].target.name
                                        )
                                      ),
                                    ]),
                                  ]),
                            ],
                            1
                          )
                        : _vm._e(),
                    ]),
                  ]),
                  _vm._v(" "),
                  _vm.premium.expanded
                    ? [
                        _c("tr", { staticClass: "collapsable active" }, [
                          _c(
                            "td",
                            { attrs: { colspan: _vm.fields.length + 2 } },
                            [
                              _c("div", { staticClass: "table__wrapper" }, [
                                _c(
                                  "table",
                                  {
                                    staticClass:
                                      "table table-responsive table-inner",
                                  },
                                  [
                                    _c("thead", [
                                      _c(
                                        "tr",
                                        [
                                          _c("th"),
                                          _vm._v(" "),
                                          _vm._l(
                                            _vm.fields,
                                            function (field, f) {
                                              return _c(
                                                "th",
                                                {
                                                  key: f,
                                                  staticClass: "text-left",
                                                  class: [
                                                    field.class,
                                                    {
                                                      "b-table-sticky-column l-2 hidden":
                                                        field.key == "target",
                                                    },
                                                  ],
                                                },
                                                [
                                                  _vm._v(
                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                      _vm._s(field.name) +
                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                  ),
                                                ]
                                              )
                                            }
                                          ),
                                          _vm._v(" "),
                                          _c("th"),
                                        ],
                                        2
                                      ),
                                    ]),
                                    _vm._v(" "),
                                    _c(
                                      "tbody",
                                      [
                                        _vm._l(
                                          _vm.newPremiumArray,
                                          function (item, i) {
                                            return _c(
                                              "tr",
                                              { key: i },
                                              [
                                                _c("td"),
                                                _vm._v(" "),
                                                _vm._l(
                                                  _vm.fields,
                                                  function (field, f) {
                                                    return _c(
                                                      "td",
                                                      {
                                                        key: f,
                                                        class: [
                                                          field.class,
                                                          {
                                                            "b-table-sticky-column l-2 hidden":
                                                              field.key ==
                                                              "target",
                                                          },
                                                          {
                                                            "no-hover":
                                                              field.key ==
                                                                "activity_id" &&
                                                              item.source !=
                                                                undefined,
                                                          },
                                                        ],
                                                      },
                                                      [
                                                        field.key ==
                                                          "created_by" &&
                                                        item.creator != null
                                                          ? [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                  _vm._s(
                                                                    item.creator
                                                                      .last_name +
                                                                      " " +
                                                                      item
                                                                        .creator
                                                                        .name
                                                                  ) +
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                              ),
                                                            ]
                                                          : field.key ==
                                                              "updated_by" &&
                                                            item.updater != null
                                                          ? [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                  _vm._s(
                                                                    item.updater
                                                                      .last_name +
                                                                      " " +
                                                                      item
                                                                        .updater
                                                                        .name
                                                                  ) +
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                              ),
                                                            ]
                                                          : _vm.non_editable_fields.includes(
                                                              field.key
                                                            )
                                                          ? [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                  _vm._s(
                                                                    item[
                                                                      field.key
                                                                    ]
                                                                  ) +
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                              ),
                                                            ]
                                                          : field.key ==
                                                              "activity_id" &&
                                                            item.source !=
                                                              undefined
                                                          ? [
                                                              _c(
                                                                "div",
                                                                {
                                                                  staticClass:
                                                                    "d-flex",
                                                                },
                                                                [
                                                                  _c(
                                                                    "select",
                                                                    {
                                                                      directives:
                                                                        [
                                                                          {
                                                                            name: "model",
                                                                            rawName:
                                                                              "v-model",
                                                                            value:
                                                                              item.source,
                                                                            expression:
                                                                              "item.source",
                                                                          },
                                                                        ],
                                                                      on: {
                                                                        change:
                                                                          [
                                                                            function (
                                                                              $event
                                                                            ) {
                                                                              var $$selectedVal =
                                                                                Array.prototype.filter
                                                                                  .call(
                                                                                    $event
                                                                                      .target
                                                                                      .options,
                                                                                    function (
                                                                                      o
                                                                                    ) {
                                                                                      return o.selected
                                                                                    }
                                                                                  )
                                                                                  .map(
                                                                                    function (
                                                                                      o
                                                                                    ) {
                                                                                      var val =
                                                                                        "_value" in
                                                                                        o
                                                                                          ? o._value
                                                                                          : o.value
                                                                                      return val
                                                                                    }
                                                                                  )
                                                                              _vm.$set(
                                                                                item,
                                                                                "source",
                                                                                $event
                                                                                  .target
                                                                                  .multiple
                                                                                  ? $$selectedVal
                                                                                  : $$selectedVal[0]
                                                                              )
                                                                            },
                                                                            function (
                                                                              $event
                                                                            ) {
                                                                              ++_vm.source_key
                                                                            },
                                                                          ],
                                                                      },
                                                                    },
                                                                    _vm._l(
                                                                      Object.keys(
                                                                        _vm.sources
                                                                      ),
                                                                      function (
                                                                        key
                                                                      ) {
                                                                        return _c(
                                                                          "option",
                                                                          {
                                                                            key: key,
                                                                            domProps:
                                                                              {
                                                                                value:
                                                                                  key,
                                                                              },
                                                                          },
                                                                          [
                                                                            _vm._v(
                                                                              "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                _vm._s(
                                                                                  _vm
                                                                                    .sources[
                                                                                    key
                                                                                  ]
                                                                                ) +
                                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                            ),
                                                                          ]
                                                                        )
                                                                      }
                                                                    ),
                                                                    0
                                                                  ),
                                                                  _vm._v(" "),
                                                                  Number(
                                                                    item.source
                                                                  ) == 1
                                                                    ? _c(
                                                                        "select",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item.group_id,
                                                                                expression:
                                                                                  "item.group_id",
                                                                              },
                                                                            ],
                                                                          key:
                                                                            "a" +
                                                                            _vm.source_key,
                                                                          on: {
                                                                            change:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                var $$selectedVal =
                                                                                  Array.prototype.filter
                                                                                    .call(
                                                                                      $event
                                                                                        .target
                                                                                        .options,
                                                                                      function (
                                                                                        o
                                                                                      ) {
                                                                                        return o.selected
                                                                                      }
                                                                                    )
                                                                                    .map(
                                                                                      function (
                                                                                        o
                                                                                      ) {
                                                                                        var val =
                                                                                          "_value" in
                                                                                          o
                                                                                            ? o._value
                                                                                            : o.value
                                                                                        return val
                                                                                      }
                                                                                    )
                                                                                _vm.$set(
                                                                                  item,
                                                                                  "group_id",
                                                                                  $event
                                                                                    .target
                                                                                    .multiple
                                                                                    ? $$selectedVal
                                                                                    : $$selectedVal[0]
                                                                                )
                                                                              },
                                                                          },
                                                                        },
                                                                        [
                                                                          _c(
                                                                            "option",
                                                                            {
                                                                              attrs:
                                                                                {
                                                                                  value:
                                                                                    "0",
                                                                                  selected:
                                                                                    "",
                                                                                },
                                                                            },
                                                                            [
                                                                              _vm._v(
                                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                              ),
                                                                            ]
                                                                          ),
                                                                          _vm._v(
                                                                            " "
                                                                          ),
                                                                          _vm._l(
                                                                            _vm.groups,
                                                                            function (
                                                                              group,
                                                                              id
                                                                            ) {
                                                                              return _c(
                                                                                "option",
                                                                                {
                                                                                  key: id,
                                                                                  domProps:
                                                                                    {
                                                                                      value:
                                                                                        id,
                                                                                    },
                                                                                },
                                                                                [
                                                                                  _vm._v(
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                      _vm._s(
                                                                                        group
                                                                                      ) +
                                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                  ),
                                                                                ]
                                                                              )
                                                                            }
                                                                          ),
                                                                        ],
                                                                        2
                                                                      )
                                                                    : _vm._e(),
                                                                  _vm._v(" "),
                                                                  Number(
                                                                    item.source
                                                                  ) == 1
                                                                    ? _c(
                                                                        "select",
                                                                        {
                                                                          directives:
                                                                            [
                                                                              {
                                                                                name: "model",
                                                                                rawName:
                                                                                  "v-model",
                                                                                value:
                                                                                  item.activity_id,
                                                                                expression:
                                                                                  "item.activity_id",
                                                                              },
                                                                            ],
                                                                          key:
                                                                            "b" +
                                                                            _vm.source_key,
                                                                          on: {
                                                                            change:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                var $$selectedVal =
                                                                                  Array.prototype.filter
                                                                                    .call(
                                                                                      $event
                                                                                        .target
                                                                                        .options,
                                                                                      function (
                                                                                        o
                                                                                      ) {
                                                                                        return o.selected
                                                                                      }
                                                                                    )
                                                                                    .map(
                                                                                      function (
                                                                                        o
                                                                                      ) {
                                                                                        var val =
                                                                                          "_value" in
                                                                                          o
                                                                                            ? o._value
                                                                                            : o.value
                                                                                        return val
                                                                                      }
                                                                                    )
                                                                                _vm.$set(
                                                                                  item,
                                                                                  "activity_id",
                                                                                  $event
                                                                                    .target
                                                                                    .multiple
                                                                                    ? $$selectedVal
                                                                                    : $$selectedVal[0]
                                                                                )
                                                                              },
                                                                          },
                                                                        },
                                                                        [
                                                                          _c(
                                                                            "option",
                                                                            {
                                                                              attrs:
                                                                                {
                                                                                  value:
                                                                                    "0",
                                                                                  selected:
                                                                                    "",
                                                                                },
                                                                            },
                                                                            [
                                                                              _vm._v(
                                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                              ),
                                                                            ]
                                                                          ),
                                                                          _vm._v(
                                                                            " "
                                                                          ),
                                                                          _vm._l(
                                                                            _vm.grouped_activities(
                                                                              item.source,
                                                                              item.group_id
                                                                            ),
                                                                            function (
                                                                              activity
                                                                            ) {
                                                                              return _c(
                                                                                "option",
                                                                                {
                                                                                  key: activity.id,
                                                                                  domProps:
                                                                                    {
                                                                                      value:
                                                                                        activity.id,
                                                                                    },
                                                                                },
                                                                                [
                                                                                  _vm._v(
                                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                      _vm._s(
                                                                                        activity.name
                                                                                      ) +
                                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                  ),
                                                                                ]
                                                                              )
                                                                            }
                                                                          ),
                                                                        ],
                                                                        2
                                                                      )
                                                                    : _vm._e(),
                                                                ]
                                                              ),
                                                            ]
                                                          : field.key == "unit"
                                                          ? [
                                                              _c(
                                                                "select",
                                                                {
                                                                  directives: [
                                                                    {
                                                                      name: "model",
                                                                      rawName:
                                                                        "v-model",
                                                                      value:
                                                                        item.unit,
                                                                      expression:
                                                                        "item.unit",
                                                                    },
                                                                  ],
                                                                  on: {
                                                                    change:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        var $$selectedVal =
                                                                          Array.prototype.filter
                                                                            .call(
                                                                              $event
                                                                                .target
                                                                                .options,
                                                                              function (
                                                                                o
                                                                              ) {
                                                                                return o.selected
                                                                              }
                                                                            )
                                                                            .map(
                                                                              function (
                                                                                o
                                                                              ) {
                                                                                var val =
                                                                                  "_value" in
                                                                                  o
                                                                                    ? o._value
                                                                                    : o.value
                                                                                return val
                                                                              }
                                                                            )
                                                                        _vm.$set(
                                                                          item,
                                                                          "unit",
                                                                          $event
                                                                            .target
                                                                            .multiple
                                                                            ? $$selectedVal
                                                                            : $$selectedVal[0]
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _c(
                                                                    "option",
                                                                    {
                                                                      attrs: {
                                                                        value:
                                                                          "0",
                                                                        selected:
                                                                          "",
                                                                      },
                                                                    },
                                                                    [
                                                                      _vm._v(
                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                      ),
                                                                    ]
                                                                  ),
                                                                  _vm._v(" "),
                                                                  _vm._l(
                                                                    Object.keys(
                                                                      _vm.units
                                                                    ),
                                                                    function (
                                                                      key
                                                                    ) {
                                                                      return _c(
                                                                        "option",
                                                                        {
                                                                          key: key,
                                                                          domProps:
                                                                            {
                                                                              value:
                                                                                key,
                                                                            },
                                                                        },
                                                                        [
                                                                          _vm._v(
                                                                            "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                              _vm._s(
                                                                                _vm
                                                                                  .units[
                                                                                  key
                                                                                ]
                                                                              ) +
                                                                              "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                          ),
                                                                        ]
                                                                      )
                                                                    }
                                                                  ),
                                                                ],
                                                                2
                                                              ),
                                                            ]
                                                          : field.key ==
                                                            "daypart"
                                                          ? [
                                                              _c(
                                                                "select",
                                                                {
                                                                  directives: [
                                                                    {
                                                                      name: "model",
                                                                      rawName:
                                                                        "v-model",
                                                                      value:
                                                                        item.daypart,
                                                                      expression:
                                                                        "item.daypart",
                                                                    },
                                                                  ],
                                                                  on: {
                                                                    change:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        var $$selectedVal =
                                                                          Array.prototype.filter
                                                                            .call(
                                                                              $event
                                                                                .target
                                                                                .options,
                                                                              function (
                                                                                o
                                                                              ) {
                                                                                return o.selected
                                                                              }
                                                                            )
                                                                            .map(
                                                                              function (
                                                                                o
                                                                              ) {
                                                                                var val =
                                                                                  "_value" in
                                                                                  o
                                                                                    ? o._value
                                                                                    : o.value
                                                                                return val
                                                                              }
                                                                            )
                                                                        _vm.$set(
                                                                          item,
                                                                          "daypart",
                                                                          $event
                                                                            .target
                                                                            .multiple
                                                                            ? $$selectedVal
                                                                            : $$selectedVal[0]
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                _vm._l(
                                                                  Object.keys(
                                                                    _vm.dayparts
                                                                  ),
                                                                  function (
                                                                    key
                                                                  ) {
                                                                    return _c(
                                                                      "option",
                                                                      {
                                                                        key: key,
                                                                        domProps:
                                                                          {
                                                                            value:
                                                                              key,
                                                                          },
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                            _vm._s(
                                                                              _vm
                                                                                .dayparts[
                                                                                key
                                                                              ]
                                                                            ) +
                                                                            "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                        ),
                                                                      ]
                                                                    )
                                                                  }
                                                                ),
                                                                0
                                                              ),
                                                            ]
                                                          : field.key == "text"
                                                          ? [
                                                              _c("textarea", {
                                                                directives: [
                                                                  {
                                                                    name: "model",
                                                                    rawName:
                                                                      "v-model",
                                                                    value:
                                                                      item[
                                                                        field
                                                                          .key
                                                                      ],
                                                                    expression:
                                                                      "item[field.key]",
                                                                  },
                                                                ],
                                                                domProps: {
                                                                  value:
                                                                    item[
                                                                      field.key
                                                                    ],
                                                                },
                                                                on: {
                                                                  input:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      if (
                                                                        $event
                                                                          .target
                                                                          .composing
                                                                      ) {
                                                                        return
                                                                      }
                                                                      _vm.$set(
                                                                        item,
                                                                        field.key,
                                                                        $event
                                                                          .target
                                                                          .value
                                                                      )
                                                                    },
                                                                },
                                                              }),
                                                            ]
                                                          : [
                                                              field.type ===
                                                              "checkbox"
                                                                ? _c("input", {
                                                                    directives:
                                                                      [
                                                                        {
                                                                          name: "model",
                                                                          rawName:
                                                                            "v-model",
                                                                          value:
                                                                            item[
                                                                              field
                                                                                .key
                                                                            ],
                                                                          expression:
                                                                            "item[field.key]",
                                                                        },
                                                                      ],
                                                                    attrs: {
                                                                      type: "checkbox",
                                                                    },
                                                                    domProps: {
                                                                      checked:
                                                                        Array.isArray(
                                                                          item[
                                                                            field
                                                                              .key
                                                                          ]
                                                                        )
                                                                          ? _vm._i(
                                                                              item[
                                                                                field
                                                                                  .key
                                                                              ],
                                                                              null
                                                                            ) >
                                                                            -1
                                                                          : item[
                                                                              field
                                                                                .key
                                                                            ],
                                                                    },
                                                                    on: {
                                                                      change: [
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          var $$a =
                                                                              item[
                                                                                field
                                                                                  .key
                                                                              ],
                                                                            $$el =
                                                                              $event.target,
                                                                            $$c =
                                                                              $$el.checked
                                                                                ? true
                                                                                : false
                                                                          if (
                                                                            Array.isArray(
                                                                              $$a
                                                                            )
                                                                          ) {
                                                                            var $$v =
                                                                                null,
                                                                              $$i =
                                                                                _vm._i(
                                                                                  $$a,
                                                                                  $$v
                                                                                )
                                                                            if (
                                                                              $$el.checked
                                                                            ) {
                                                                              $$i <
                                                                                0 &&
                                                                                _vm.$set(
                                                                                  item,
                                                                                  field.key,
                                                                                  $$a.concat(
                                                                                    [
                                                                                      $$v,
                                                                                    ]
                                                                                  )
                                                                                )
                                                                            } else {
                                                                              $$i >
                                                                                -1 &&
                                                                                _vm.$set(
                                                                                  item,
                                                                                  field.key,
                                                                                  $$a
                                                                                    .slice(
                                                                                      0,
                                                                                      $$i
                                                                                    )
                                                                                    .concat(
                                                                                      $$a.slice(
                                                                                        $$i +
                                                                                          1
                                                                                      )
                                                                                    )
                                                                                )
                                                                            }
                                                                          } else {
                                                                            _vm.$set(
                                                                              item,
                                                                              field.key,
                                                                              $$c
                                                                            )
                                                                          }
                                                                        },
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          return _vm.validate(
                                                                            item[
                                                                              field
                                                                                .key
                                                                            ],
                                                                            field.key
                                                                          )
                                                                        },
                                                                      ],
                                                                    },
                                                                  })
                                                                : field.type ===
                                                                  "radio"
                                                                ? _c("input", {
                                                                    directives:
                                                                      [
                                                                        {
                                                                          name: "model",
                                                                          rawName:
                                                                            "v-model",
                                                                          value:
                                                                            item[
                                                                              field
                                                                                .key
                                                                            ],
                                                                          expression:
                                                                            "item[field.key]",
                                                                        },
                                                                      ],
                                                                    attrs: {
                                                                      type: "radio",
                                                                    },
                                                                    domProps: {
                                                                      checked:
                                                                        _vm._q(
                                                                          item[
                                                                            field
                                                                              .key
                                                                          ],
                                                                          null
                                                                        ),
                                                                    },
                                                                    on: {
                                                                      change: [
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          return _vm.$set(
                                                                            item,
                                                                            field.key,
                                                                            null
                                                                          )
                                                                        },
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          return _vm.validate(
                                                                            item[
                                                                              field
                                                                                .key
                                                                            ],
                                                                            field.key
                                                                          )
                                                                        },
                                                                      ],
                                                                    },
                                                                  })
                                                                : _c("input", {
                                                                    directives:
                                                                      [
                                                                        {
                                                                          name: "model",
                                                                          rawName:
                                                                            "v-model",
                                                                          value:
                                                                            item[
                                                                              field
                                                                                .key
                                                                            ],
                                                                          expression:
                                                                            "item[field.key]",
                                                                        },
                                                                      ],
                                                                    attrs: {
                                                                      type: field.type,
                                                                    },
                                                                    domProps: {
                                                                      value:
                                                                        item[
                                                                          field
                                                                            .key
                                                                        ],
                                                                    },
                                                                    on: {
                                                                      change:
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          return _vm.validate(
                                                                            item[
                                                                              field
                                                                                .key
                                                                            ],
                                                                            field.key
                                                                          )
                                                                        },
                                                                      input:
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          if (
                                                                            $event
                                                                              .target
                                                                              .composing
                                                                          ) {
                                                                            return
                                                                          }
                                                                          _vm.$set(
                                                                            item,
                                                                            field.key,
                                                                            $event
                                                                              .target
                                                                              .value
                                                                          )
                                                                        },
                                                                    },
                                                                  }),
                                                            ],
                                                      ],
                                                      2
                                                    )
                                                  }
                                                ),
                                                _vm._v(" "),
                                                _c(
                                                  "td",
                                                  { staticClass: "no-hover" },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "d-flex px-2",
                                                      },
                                                      [
                                                        _c("i", {
                                                          staticClass:
                                                            "fa fa-save btn btn-success btn-icon",
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.saveNewQuartal(
                                                                i
                                                              )
                                                            },
                                                          },
                                                        }),
                                                        _vm._v(" "),
                                                        _c("i", {
                                                          staticClass:
                                                            "fa fa-trash btn btn-danger btn-icon",
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.deleteNewQuartal(
                                                                i
                                                              )
                                                            },
                                                          },
                                                        }),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ],
                                              2
                                            )
                                          }
                                        ),
                                        _vm._v(" "),
                                        _c("tr", [
                                          _c(
                                            "td",
                                            {
                                              staticClass: "plus-item",
                                              attrs: { colspan: "13" },
                                            },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass: "p-4",
                                                  on: {
                                                    click: function ($event) {
                                                      return _vm.addPremium()
                                                    },
                                                  },
                                                },
                                                [
                                                  _c("i", {
                                                    staticClass:
                                                      "fa fa-plus mr-2",
                                                  }),
                                                  _vm._v(" "),
                                                  _c("b", [
                                                    _vm._v("Добавить премию"),
                                                  ]),
                                                ]
                                              ),
                                            ]
                                          ),
                                        ]),
                                      ],
                                      2
                                    ),
                                  ]
                                ),
                              ]),
                            ]
                          ),
                        ]),
                      ]
                    : _vm._e(),
                ]
              : _vm._e(),
            _vm._v(" "),
            _vm._l(_vm.page_items, function (page_item, p) {
              return [
                _c("tr", { key: p }, [
                  _c(
                    "td",
                    {
                      staticClass: "pointer",
                      on: {
                        click: function ($event) {
                          return _vm.expand(p)
                        },
                      },
                    },
                    [
                      _c(
                        "div",
                        { staticClass: "d-flex align-items-center px-2" },
                        [
                          _c("span", { staticClass: "mr-2" }, [
                            _vm._v(_vm._s(p + 1)),
                          ]),
                          _vm._v(" "),
                          page_item.expanded
                            ? _c("i", { staticClass: "fa fa-minus mt-1" })
                            : _c("i", { staticClass: "fa fa-plus mt-1" }),
                        ]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c("td", { staticClass: "text-left" }, [
                    _c("div", { staticClass: "d-flex aic" }, [
                      page_item.type == 1
                        ? _c("i", { staticClass: "fa fa-user ml-2 color-user" })
                        : _vm._e(),
                      _vm._v(" "),
                      page_item.type == 2
                        ? _c("i", {
                            staticClass: "fa fa-users ml-2 color-group",
                          })
                        : _vm._e(),
                      _vm._v(" "),
                      page_item.type == 3
                        ? _c("i", {
                            staticClass: "fa fa-briefcase ml-2 color-position",
                          })
                        : _vm._e(),
                      _vm._v(" "),
                      _c("span", { staticClass: "ml-2" }, [
                        _vm._v(_vm._s(page_item.name)),
                      ]),
                      _vm._v(" "),
                      _c("i", {
                        staticClass: "fa fa-save btn btn-success btn-icon ml-a",
                        on: {
                          click: function ($event) {
                            return _vm.saveAll(p)
                          },
                        },
                      }),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                page_item.items !== undefined && page_item.items.length > 0
                  ? [
                      _c(
                        "tr",
                        {
                          key: p + "a",
                          staticClass: "collapsable",
                          class: { active: page_item.expanded },
                        },
                        [
                          _c(
                            "td",
                            { attrs: { colspan: _vm.fields.length + 2 } },
                            [
                              _c(
                                "div",
                                { staticClass: "table__wrapper w-100" },
                                [
                                  _c(
                                    "table",
                                    {
                                      staticClass:
                                        "table table-responsive table-inner",
                                    },
                                    [
                                      _c("thead", [
                                        _c(
                                          "tr",
                                          [
                                            _c("th"),
                                            _vm._v(" "),
                                            _vm._l(
                                              _vm.fields,
                                              function (field, f) {
                                                return _c(
                                                  "th",
                                                  {
                                                    key: f,
                                                    staticClass: "text-left",
                                                    class: [
                                                      field.class,
                                                      {
                                                        "b-table-sticky-column l-2 hidden":
                                                          field.key == "target",
                                                      },
                                                    ],
                                                  },
                                                  [
                                                    _vm._v(
                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                        _vm._s(field.name) +
                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                    ),
                                                  ]
                                                )
                                              }
                                            ),
                                            _vm._v(" "),
                                            _c("th"),
                                          ],
                                          2
                                        ),
                                      ]),
                                      _vm._v(" "),
                                      _c(
                                        "tbody",
                                        [
                                          _vm._l(
                                            page_item.items,
                                            function (item, i) {
                                              return _c(
                                                "tr",
                                                { key: i },
                                                [
                                                  _c(
                                                    "td",
                                                    {
                                                      staticClass:
                                                        "text-center",
                                                    },
                                                    [
                                                      _c("div", [
                                                        _vm._v(_vm._s(i + 1)),
                                                      ]),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _vm._l(
                                                    _vm.fields,
                                                    function (field, f) {
                                                      return _c(
                                                        "td",
                                                        {
                                                          key: f,
                                                          class: [
                                                            field.class,
                                                            {
                                                              "b-table-sticky-column l-2 hidden":
                                                                field.key ==
                                                                "target",
                                                            },
                                                            {
                                                              "no-hover":
                                                                field.key ==
                                                                  "activity_id" &&
                                                                item.source !=
                                                                  undefined,
                                                            },
                                                          ],
                                                        },
                                                        [
                                                          field.key == "target"
                                                            ? void 0
                                                            : field.key ==
                                                                "created_by" &&
                                                              item.creator !=
                                                                null
                                                            ? [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                    _vm._s(
                                                                      item
                                                                        .creator
                                                                        .last_name +
                                                                        " " +
                                                                        item
                                                                          .creator
                                                                          .name
                                                                    ) +
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            : field.key ==
                                                                "updated_by" &&
                                                              item.updater !=
                                                                null
                                                            ? [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                    _vm._s(
                                                                      item
                                                                        .updater
                                                                        .last_name +
                                                                        " " +
                                                                        item
                                                                          .updater
                                                                          .name
                                                                    ) +
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            : _vm.non_editable_fields.includes(
                                                                field.key
                                                              )
                                                            ? [
                                                                _vm._v(
                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                    _vm._s(
                                                                      item[
                                                                        field
                                                                          .key
                                                                      ]
                                                                    ) +
                                                                    "\n\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                ),
                                                              ]
                                                            : field.key ==
                                                                "activity_id" &&
                                                              item.source !=
                                                                undefined
                                                            ? [
                                                                _c(
                                                                  "div",
                                                                  {
                                                                    staticClass:
                                                                      "d-flex",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "select",
                                                                      {
                                                                        directives:
                                                                          [
                                                                            {
                                                                              name: "model",
                                                                              rawName:
                                                                                "v-model",
                                                                              value:
                                                                                item.source,
                                                                              expression:
                                                                                "item.source",
                                                                            },
                                                                          ],
                                                                        on: {
                                                                          change:
                                                                            [
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                var $$selectedVal =
                                                                                  Array.prototype.filter
                                                                                    .call(
                                                                                      $event
                                                                                        .target
                                                                                        .options,
                                                                                      function (
                                                                                        o
                                                                                      ) {
                                                                                        return o.selected
                                                                                      }
                                                                                    )
                                                                                    .map(
                                                                                      function (
                                                                                        o
                                                                                      ) {
                                                                                        var val =
                                                                                          "_value" in
                                                                                          o
                                                                                            ? o._value
                                                                                            : o.value
                                                                                        return val
                                                                                      }
                                                                                    )
                                                                                _vm.$set(
                                                                                  item,
                                                                                  "source",
                                                                                  $event
                                                                                    .target
                                                                                    .multiple
                                                                                    ? $$selectedVal
                                                                                    : $$selectedVal[0]
                                                                                )
                                                                              },
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                ++_vm.source_key
                                                                              },
                                                                            ],
                                                                        },
                                                                      },
                                                                      _vm._l(
                                                                        Object.keys(
                                                                          _vm.sources
                                                                        ),
                                                                        function (
                                                                          key
                                                                        ) {
                                                                          return _c(
                                                                            "option",
                                                                            {
                                                                              key: key,
                                                                              domProps:
                                                                                {
                                                                                  value:
                                                                                    key,
                                                                                },
                                                                            },
                                                                            [
                                                                              _vm._v(
                                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                  _vm._s(
                                                                                    _vm
                                                                                      .sources[
                                                                                      key
                                                                                    ]
                                                                                  ) +
                                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                              ),
                                                                            ]
                                                                          )
                                                                        }
                                                                      ),
                                                                      0
                                                                    ),
                                                                    _vm._v(" "),
                                                                    Number(
                                                                      item.source
                                                                    ) == 1
                                                                      ? _c(
                                                                          "select",
                                                                          {
                                                                            directives:
                                                                              [
                                                                                {
                                                                                  name: "model",
                                                                                  rawName:
                                                                                    "v-model",
                                                                                  value:
                                                                                    item.group_id,
                                                                                  expression:
                                                                                    "item.group_id",
                                                                                },
                                                                              ],
                                                                            key:
                                                                              "c" +
                                                                              _vm.source_key,
                                                                            on: {
                                                                              change:
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  var $$selectedVal =
                                                                                    Array.prototype.filter
                                                                                      .call(
                                                                                        $event
                                                                                          .target
                                                                                          .options,
                                                                                        function (
                                                                                          o
                                                                                        ) {
                                                                                          return o.selected
                                                                                        }
                                                                                      )
                                                                                      .map(
                                                                                        function (
                                                                                          o
                                                                                        ) {
                                                                                          var val =
                                                                                            "_value" in
                                                                                            o
                                                                                              ? o._value
                                                                                              : o.value
                                                                                          return val
                                                                                        }
                                                                                      )
                                                                                  _vm.$set(
                                                                                    item,
                                                                                    "group_id",
                                                                                    $event
                                                                                      .target
                                                                                      .multiple
                                                                                      ? $$selectedVal
                                                                                      : $$selectedVal[0]
                                                                                  )
                                                                                },
                                                                            },
                                                                          },
                                                                          [
                                                                            _c(
                                                                              "option",
                                                                              {
                                                                                attrs:
                                                                                  {
                                                                                    value:
                                                                                      "0",
                                                                                    selected:
                                                                                      "",
                                                                                  },
                                                                              },
                                                                              [
                                                                                _vm._v(
                                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                ),
                                                                              ]
                                                                            ),
                                                                            _vm._v(
                                                                              " "
                                                                            ),
                                                                            _vm._l(
                                                                              _vm.groups,
                                                                              function (
                                                                                group,
                                                                                id
                                                                              ) {
                                                                                return _c(
                                                                                  "option",
                                                                                  {
                                                                                    key: id,
                                                                                    domProps:
                                                                                      {
                                                                                        value:
                                                                                          id,
                                                                                      },
                                                                                  },
                                                                                  [
                                                                                    _vm._v(
                                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                        _vm._s(
                                                                                          group
                                                                                        ) +
                                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                    ),
                                                                                  ]
                                                                                )
                                                                              }
                                                                            ),
                                                                          ],
                                                                          2
                                                                        )
                                                                      : _vm._e(),
                                                                    _vm._v(" "),
                                                                    Number(
                                                                      item.source
                                                                    ) == 1
                                                                      ? _c(
                                                                          "select",
                                                                          {
                                                                            directives:
                                                                              [
                                                                                {
                                                                                  name: "model",
                                                                                  rawName:
                                                                                    "v-model",
                                                                                  value:
                                                                                    item.activity_id,
                                                                                  expression:
                                                                                    "item.activity_id",
                                                                                },
                                                                              ],
                                                                            key:
                                                                              "d" +
                                                                              _vm.source_key,
                                                                            on: {
                                                                              change:
                                                                                function (
                                                                                  $event
                                                                                ) {
                                                                                  var $$selectedVal =
                                                                                    Array.prototype.filter
                                                                                      .call(
                                                                                        $event
                                                                                          .target
                                                                                          .options,
                                                                                        function (
                                                                                          o
                                                                                        ) {
                                                                                          return o.selected
                                                                                        }
                                                                                      )
                                                                                      .map(
                                                                                        function (
                                                                                          o
                                                                                        ) {
                                                                                          var val =
                                                                                            "_value" in
                                                                                            o
                                                                                              ? o._value
                                                                                              : o.value
                                                                                          return val
                                                                                        }
                                                                                      )
                                                                                  _vm.$set(
                                                                                    item,
                                                                                    "activity_id",
                                                                                    $event
                                                                                      .target
                                                                                      .multiple
                                                                                      ? $$selectedVal
                                                                                      : $$selectedVal[0]
                                                                                  )
                                                                                },
                                                                            },
                                                                          },
                                                                          [
                                                                            _c(
                                                                              "option",
                                                                              {
                                                                                attrs:
                                                                                  {
                                                                                    value:
                                                                                      "0",
                                                                                    selected:
                                                                                      "",
                                                                                  },
                                                                              },
                                                                              [
                                                                                _vm._v(
                                                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                ),
                                                                              ]
                                                                            ),
                                                                            _vm._v(
                                                                              " "
                                                                            ),
                                                                            _vm._l(
                                                                              _vm.grouped_activities(
                                                                                item.source,
                                                                                item.group_id
                                                                              ),
                                                                              function (
                                                                                activity
                                                                              ) {
                                                                                return _c(
                                                                                  "option",
                                                                                  {
                                                                                    key: activity.id,
                                                                                    domProps:
                                                                                      {
                                                                                        value:
                                                                                          activity.id,
                                                                                      },
                                                                                  },
                                                                                  [
                                                                                    _vm._v(
                                                                                      "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                        _vm._s(
                                                                                          activity.name
                                                                                        ) +
                                                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                                    ),
                                                                                  ]
                                                                                )
                                                                              }
                                                                            ),
                                                                          ],
                                                                          2
                                                                        )
                                                                      : _vm._e(),
                                                                  ]
                                                                ),
                                                              ]
                                                            : field.key ==
                                                              "unit"
                                                            ? [
                                                                _c(
                                                                  "select",
                                                                  {
                                                                    directives:
                                                                      [
                                                                        {
                                                                          name: "model",
                                                                          rawName:
                                                                            "v-model",
                                                                          value:
                                                                            item.unit,
                                                                          expression:
                                                                            "item.unit",
                                                                        },
                                                                      ],
                                                                    on: {
                                                                      change:
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          var $$selectedVal =
                                                                            Array.prototype.filter
                                                                              .call(
                                                                                $event
                                                                                  .target
                                                                                  .options,
                                                                                function (
                                                                                  o
                                                                                ) {
                                                                                  return o.selected
                                                                                }
                                                                              )
                                                                              .map(
                                                                                function (
                                                                                  o
                                                                                ) {
                                                                                  var val =
                                                                                    "_value" in
                                                                                    o
                                                                                      ? o._value
                                                                                      : o.value
                                                                                  return val
                                                                                }
                                                                              )
                                                                          _vm.$set(
                                                                            item,
                                                                            "unit",
                                                                            $event
                                                                              .target
                                                                              .multiple
                                                                              ? $$selectedVal
                                                                              : $$selectedVal[0]
                                                                          )
                                                                        },
                                                                    },
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "option",
                                                                      {
                                                                        attrs: {
                                                                          value:
                                                                            "0",
                                                                          selected:
                                                                            "",
                                                                        },
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                        ),
                                                                      ]
                                                                    ),
                                                                    _vm._v(" "),
                                                                    _vm._l(
                                                                      Object.keys(
                                                                        _vm.units
                                                                      ),
                                                                      function (
                                                                        key
                                                                      ) {
                                                                        return _c(
                                                                          "option",
                                                                          {
                                                                            key: key,
                                                                            domProps:
                                                                              {
                                                                                value:
                                                                                  key,
                                                                              },
                                                                          },
                                                                          [
                                                                            _vm._v(
                                                                              "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                                _vm._s(
                                                                                  _vm
                                                                                    .units[
                                                                                    key
                                                                                  ]
                                                                                ) +
                                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                            ),
                                                                          ]
                                                                        )
                                                                      }
                                                                    ),
                                                                  ],
                                                                  2
                                                                ),
                                                              ]
                                                            : field.key ==
                                                              "daypart"
                                                            ? [
                                                                _c(
                                                                  "select",
                                                                  {
                                                                    directives:
                                                                      [
                                                                        {
                                                                          name: "model",
                                                                          rawName:
                                                                            "v-model",
                                                                          value:
                                                                            item.daypart,
                                                                          expression:
                                                                            "item.daypart",
                                                                        },
                                                                      ],
                                                                    on: {
                                                                      change:
                                                                        function (
                                                                          $event
                                                                        ) {
                                                                          var $$selectedVal =
                                                                            Array.prototype.filter
                                                                              .call(
                                                                                $event
                                                                                  .target
                                                                                  .options,
                                                                                function (
                                                                                  o
                                                                                ) {
                                                                                  return o.selected
                                                                                }
                                                                              )
                                                                              .map(
                                                                                function (
                                                                                  o
                                                                                ) {
                                                                                  var val =
                                                                                    "_value" in
                                                                                    o
                                                                                      ? o._value
                                                                                      : o.value
                                                                                  return val
                                                                                }
                                                                              )
                                                                          _vm.$set(
                                                                            item,
                                                                            "daypart",
                                                                            $event
                                                                              .target
                                                                              .multiple
                                                                              ? $$selectedVal
                                                                              : $$selectedVal[0]
                                                                          )
                                                                        },
                                                                    },
                                                                  },
                                                                  _vm._l(
                                                                    Object.keys(
                                                                      _vm.dayparts
                                                                    ),
                                                                    function (
                                                                      key
                                                                    ) {
                                                                      return _c(
                                                                        "option",
                                                                        {
                                                                          key: key,
                                                                          domProps:
                                                                            {
                                                                              value:
                                                                                key,
                                                                            },
                                                                        },
                                                                        [
                                                                          _vm._v(
                                                                            "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                              _vm._s(
                                                                                _vm
                                                                                  .dayparts[
                                                                                  key
                                                                                ]
                                                                              ) +
                                                                              "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                                          ),
                                                                        ]
                                                                      )
                                                                    }
                                                                  ),
                                                                  0
                                                                ),
                                                              ]
                                                            : [
                                                                field.type ===
                                                                "checkbox"
                                                                  ? _c(
                                                                      "input",
                                                                      {
                                                                        directives:
                                                                          [
                                                                            {
                                                                              name: "model",
                                                                              rawName:
                                                                                "v-model",
                                                                              value:
                                                                                item[
                                                                                  field
                                                                                    .key
                                                                                ],
                                                                              expression:
                                                                                "item[field.key]",
                                                                            },
                                                                          ],
                                                                        attrs: {
                                                                          type: "checkbox",
                                                                        },
                                                                        domProps:
                                                                          {
                                                                            checked:
                                                                              Array.isArray(
                                                                                item[
                                                                                  field
                                                                                    .key
                                                                                ]
                                                                              )
                                                                                ? _vm._i(
                                                                                    item[
                                                                                      field
                                                                                        .key
                                                                                    ],
                                                                                    null
                                                                                  ) >
                                                                                  -1
                                                                                : item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                          },
                                                                        on: {
                                                                          change:
                                                                            [
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                var $$a =
                                                                                    item[
                                                                                      field
                                                                                        .key
                                                                                    ],
                                                                                  $$el =
                                                                                    $event.target,
                                                                                  $$c =
                                                                                    $$el.checked
                                                                                      ? true
                                                                                      : false
                                                                                if (
                                                                                  Array.isArray(
                                                                                    $$a
                                                                                  )
                                                                                ) {
                                                                                  var $$v =
                                                                                      null,
                                                                                    $$i =
                                                                                      _vm._i(
                                                                                        $$a,
                                                                                        $$v
                                                                                      )
                                                                                  if (
                                                                                    $$el.checked
                                                                                  ) {
                                                                                    $$i <
                                                                                      0 &&
                                                                                      _vm.$set(
                                                                                        item,
                                                                                        field.key,
                                                                                        $$a.concat(
                                                                                          [
                                                                                            $$v,
                                                                                          ]
                                                                                        )
                                                                                      )
                                                                                  } else {
                                                                                    $$i >
                                                                                      -1 &&
                                                                                      _vm.$set(
                                                                                        item,
                                                                                        field.key,
                                                                                        $$a
                                                                                          .slice(
                                                                                            0,
                                                                                            $$i
                                                                                          )
                                                                                          .concat(
                                                                                            $$a.slice(
                                                                                              $$i +
                                                                                                1
                                                                                            )
                                                                                          )
                                                                                      )
                                                                                  }
                                                                                } else {
                                                                                  _vm.$set(
                                                                                    item,
                                                                                    field.key,
                                                                                    $$c
                                                                                  )
                                                                                }
                                                                              },
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return _vm.validate(
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                  field.key
                                                                                )
                                                                              },
                                                                            ],
                                                                        },
                                                                      }
                                                                    )
                                                                  : field.type ===
                                                                    "radio"
                                                                  ? _c(
                                                                      "input",
                                                                      {
                                                                        directives:
                                                                          [
                                                                            {
                                                                              name: "model",
                                                                              rawName:
                                                                                "v-model",
                                                                              value:
                                                                                item[
                                                                                  field
                                                                                    .key
                                                                                ],
                                                                              expression:
                                                                                "item[field.key]",
                                                                            },
                                                                          ],
                                                                        attrs: {
                                                                          type: "radio",
                                                                        },
                                                                        domProps:
                                                                          {
                                                                            checked:
                                                                              _vm._q(
                                                                                item[
                                                                                  field
                                                                                    .key
                                                                                ],
                                                                                null
                                                                              ),
                                                                          },
                                                                        on: {
                                                                          change:
                                                                            [
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return _vm.$set(
                                                                                  item,
                                                                                  field.key,
                                                                                  null
                                                                                )
                                                                              },
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return _vm.validate(
                                                                                  item[
                                                                                    field
                                                                                      .key
                                                                                  ],
                                                                                  field.key
                                                                                )
                                                                              },
                                                                            ],
                                                                        },
                                                                      }
                                                                    )
                                                                  : _c(
                                                                      "input",
                                                                      {
                                                                        directives:
                                                                          [
                                                                            {
                                                                              name: "model",
                                                                              rawName:
                                                                                "v-model",
                                                                              value:
                                                                                item[
                                                                                  field
                                                                                    .key
                                                                                ],
                                                                              expression:
                                                                                "item[field.key]",
                                                                            },
                                                                          ],
                                                                        attrs: {
                                                                          type: field.type,
                                                                        },
                                                                        domProps:
                                                                          {
                                                                            value:
                                                                              item[
                                                                                field
                                                                                  .key
                                                                              ],
                                                                          },
                                                                        on: {
                                                                          change:
                                                                            function (
                                                                              $event
                                                                            ) {
                                                                              return _vm.validate(
                                                                                item[
                                                                                  field
                                                                                    .key
                                                                                ],
                                                                                field.key
                                                                              )
                                                                            },
                                                                          input:
                                                                            function (
                                                                              $event
                                                                            ) {
                                                                              if (
                                                                                $event
                                                                                  .target
                                                                                  .composing
                                                                              ) {
                                                                                return
                                                                              }
                                                                              _vm.$set(
                                                                                item,
                                                                                field.key,
                                                                                $event
                                                                                  .target
                                                                                  .value
                                                                              )
                                                                            },
                                                                        },
                                                                      }
                                                                    ),
                                                              ],
                                                        ],
                                                        2
                                                      )
                                                    }
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "td",
                                                    { staticClass: "no-hover" },
                                                    [
                                                      _c(
                                                        "div",
                                                        {
                                                          staticClass:
                                                            "d-flex px-2",
                                                        },
                                                        [
                                                          _c(
                                                            "b-form-checkbox",
                                                            {
                                                              staticClass:
                                                                "kpi-status-switch",
                                                              attrs: {
                                                                switch: "",
                                                                checked:
                                                                  !!item.is_active,
                                                                disabled:
                                                                  _vm.statusRequest,
                                                              },
                                                              on: {
                                                                input:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    return _vm.changeStatus(
                                                                      item,
                                                                      $event
                                                                    )
                                                                  },
                                                              },
                                                            },
                                                            [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                                                              ),
                                                            ]
                                                          ),
                                                          _vm._v(" "),
                                                          _c("i", {
                                                            staticClass:
                                                              "fa fa-save btn btn-success btn-icon",
                                                            on: {
                                                              click: function (
                                                                $event
                                                              ) {
                                                                return _vm.saveItemFromTable(
                                                                  p,
                                                                  i
                                                                )
                                                              },
                                                            },
                                                          }),
                                                          _vm._v(" "),
                                                          _c("i", {
                                                            staticClass:
                                                              "fa fa-trash btn btn-danger btn-icon",
                                                            on: {
                                                              click: function (
                                                                $event
                                                              ) {
                                                                return _vm.deleteItem(
                                                                  p,
                                                                  i
                                                                )
                                                              },
                                                            },
                                                          }),
                                                        ],
                                                        1
                                                      ),
                                                    ]
                                                  ),
                                                ],
                                                2
                                              )
                                            }
                                          ),
                                          _vm._v(" "),
                                          _c("tr", [
                                            _c(
                                              "td",
                                              {
                                                staticClass: "plus-item",
                                                attrs: { colspan: "13" },
                                              },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass: "px-4 py-3",
                                                    on: {
                                                      click: function ($event) {
                                                        return _vm.addPremiumGroup(
                                                          page_item
                                                        )
                                                      },
                                                    },
                                                  },
                                                  [
                                                    _c("i", {
                                                      staticClass:
                                                        "fa fa-plus mr-2",
                                                    }),
                                                    _vm._v(" "),
                                                    _c("b", [
                                                      _vm._v("Добавить премию"),
                                                    ]),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]),
                                        ],
                                        2
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  : _vm._e(),
              ]
            }),
          ],
          2
        ),
      ]),
      _vm._v(" "),
      _c("JwPagination", {
        key: _vm.paginationKey,
        staticClass: "mt-3",
        attrs: {
          items: _vm.items,
          labels: {
            first: "<<",
            last: ">>",
            previous: "<",
            next: ">",
          },
          "page-size": +_vm.pageSize,
        },
        on: { changePage: _vm.onChangePage },
      }),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          attrs: {
            title: "Настройка списка",
            "ok-text": "Закрыть",
            size: "lg",
          },
          on: {
            ok: function ($event) {
              _vm.modalAdjustVisibleFields = !_vm.modalAdjustVisibleFields
            },
          },
          model: {
            value: _vm.modalAdjustVisibleFields,
            callback: function ($$v) {
              _vm.modalAdjustVisibleFields = $$v
            },
            expression: "modalAdjustVisibleFields",
          },
        },
        [
          _c(
            "div",
            { staticClass: "row" },
            _vm._l(_vm.all_fields, function (field, f) {
              return _c(
                "div",
                { key: f, staticClass: "col-md-4 mb-2" },
                [
                  _c(
                    "b-form-checkbox",
                    {
                      attrs: { value: true, "unchecked-value": false },
                      model: {
                        value: _vm.show_fields[field.key],
                        callback: function ($$v) {
                          _vm.$set(_vm.show_fields, field.key, $$v)
                        },
                        expression: "show_fields[field.key]",
                      },
                    },
                    [
                      _vm._v(
                        "\n\t\t\t\t\t\t" + _vm._s(field.name) + "\n\t\t\t\t\t"
                      ),
                    ]
                  ),
                ],
                1
              )
            }),
            0
          ),
        ]
      ),
      _vm._v(" "),
      _vm.activeItem != null
        ? _c(
            "Sidebar",
            {
              attrs: {
                title: "Настроить премию",
                open: _vm.showSidebar,
                width: "40%",
              },
              on: { close: _vm.closeSidebar },
            },
            [
              _c(
                "div",
                { staticClass: "row m-0" },
                [
                  _vm._l(_vm.all_fields, function (field, f) {
                    return _c(
                      "div",
                      { key: f, staticClass: "mb-3", class: field.alter_class },
                      [
                        _c("div", { staticClass: "mb-2 mt-2 field" }, [
                          _vm._v(
                            "\n\t\t\t\t\t\t" +
                              _vm._s(field.name) +
                              "\n\t\t\t\t\t"
                          ),
                        ]),
                        _vm._v(" "),
                        field.key == "target"
                          ? _c(
                              "div",
                              { staticClass: "mr-5" },
                              [
                                _vm.activeItem.id == 0
                                  ? _c("SuperSelect", {
                                      staticClass: "w-full",
                                      attrs: {
                                        values:
                                          _vm.activeItem.target == null
                                            ? []
                                            : [_vm.activeItem.target],
                                        single: true,
                                      },
                                      on: {
                                        choose: function (target) {
                                          return (_vm.activeItem.target =
                                            target)
                                        },
                                      },
                                    })
                                  : _c("div", { staticClass: "d-flex aic" }, [
                                      _vm.activeItem.target.type == 1
                                        ? _c("i", {
                                            staticClass:
                                              "fa fa-user ml-2 color-user",
                                          })
                                        : _vm._e(),
                                      _vm._v(" "),
                                      _vm.activeItem.target.type == 2
                                        ? _c("i", {
                                            staticClass:
                                              "fa fa-users ml-2 color-group",
                                          })
                                        : _vm._e(),
                                      _vm._v(" "),
                                      _vm.activeItem.target.type == 3
                                        ? _c("i", {
                                            staticClass:
                                              "fa fa-briefcase ml-2 color-position",
                                          })
                                        : _vm._e(),
                                      _vm._v(" "),
                                      _c("span", { staticClass: "ml-2" }, [
                                        _vm._v(
                                          _vm._s(_vm.activeItem.target.name)
                                        ),
                                      ]),
                                    ]),
                              ],
                              1
                            )
                          : field.key == "created_by" &&
                            _vm.activeItem.creator != null
                          ? _c("div", [
                              _vm._v(
                                "\n\t\t\t\t\t\t" +
                                  _vm._s(
                                    _vm.activeItem.creator.last_name +
                                      " " +
                                      _vm.activeItem.creator.name
                                  ) +
                                  "\n\t\t\t\t\t"
                              ),
                            ])
                          : field.key == "updated_by" &&
                            _vm.activeItem.updater != null
                          ? _c("div", [
                              _vm._v(
                                "\n\t\t\t\t\t\t" +
                                  _vm._s(
                                    _vm.activeItem.updater.last_name +
                                      " " +
                                      _vm.activeItem.updater.name
                                  ) +
                                  "\n\t\t\t\t\t"
                              ),
                            ])
                          : _vm.non_editable_fields.includes(field.key)
                          ? _c("div", [
                              _vm._v(
                                "\n\t\t\t\t\t\t" +
                                  _vm._s(_vm.activeItem[field.key]) +
                                  "\n\t\t\t\t\t"
                              ),
                            ])
                          : field.key == "activity_id" &&
                            _vm.activeItem.source != undefined
                          ? _c("div", [
                              _c("div", { staticClass: "d-flex" }, [
                                _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.activeItem.source,
                                        expression: "activeItem.source",
                                      },
                                    ],
                                    on: {
                                      change: [
                                        function ($event) {
                                          var $$selectedVal =
                                            Array.prototype.filter
                                              .call(
                                                $event.target.options,
                                                function (o) {
                                                  return o.selected
                                                }
                                              )
                                              .map(function (o) {
                                                var val =
                                                  "_value" in o
                                                    ? o._value
                                                    : o.value
                                                return val
                                              })
                                          _vm.$set(
                                            _vm.activeItem,
                                            "source",
                                            $event.target.multiple
                                              ? $$selectedVal
                                              : $$selectedVal[0]
                                          )
                                        },
                                        function ($event) {
                                          ++_vm.source_key
                                        },
                                      ],
                                    },
                                  },
                                  _vm._l(
                                    Object.keys(_vm.sources),
                                    function (key) {
                                      return _c(
                                        "option",
                                        { key: key, domProps: { value: key } },
                                        [
                                          _vm._v(
                                            "\n\t\t\t\t\t\t\t\t\t" +
                                              _vm._s(_vm.sources[key]) +
                                              "\n\t\t\t\t\t\t\t\t"
                                          ),
                                        ]
                                      )
                                    }
                                  ),
                                  0
                                ),
                                _vm._v(" "),
                                Number(_vm.activeItem.source) == 1
                                  ? _c(
                                      "select",
                                      {
                                        directives: [
                                          {
                                            name: "model",
                                            rawName: "v-model",
                                            value: _vm.activeItem.group_id,
                                            expression: "activeItem.group_id",
                                          },
                                        ],
                                        key: "a" + _vm.source_key,
                                        on: {
                                          change: function ($event) {
                                            var $$selectedVal =
                                              Array.prototype.filter
                                                .call(
                                                  $event.target.options,
                                                  function (o) {
                                                    return o.selected
                                                  }
                                                )
                                                .map(function (o) {
                                                  var val =
                                                    "_value" in o
                                                      ? o._value
                                                      : o.value
                                                  return val
                                                })
                                            _vm.$set(
                                              _vm.activeItem,
                                              "group_id",
                                              $event.target.multiple
                                                ? $$selectedVal
                                                : $$selectedVal[0]
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "option",
                                          {
                                            attrs: { value: "0", selected: "" },
                                          },
                                          [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t"
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _vm._l(
                                          _vm.groups,
                                          function (group, id) {
                                            return _c(
                                              "option",
                                              {
                                                key: id,
                                                domProps: { value: id },
                                              },
                                              [
                                                _vm._v(
                                                  "\n\t\t\t\t\t\t\t\t\t" +
                                                    _vm._s(group) +
                                                    "\n\t\t\t\t\t\t\t\t"
                                                ),
                                              ]
                                            )
                                          }
                                        ),
                                      ],
                                      2
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.activeItem.activity_id,
                                        expression: "activeItem.activity_id",
                                      },
                                    ],
                                    key: "b" + _vm.source_key,
                                    on: {
                                      change: function ($event) {
                                        var $$selectedVal =
                                          Array.prototype.filter
                                            .call(
                                              $event.target.options,
                                              function (o) {
                                                return o.selected
                                              }
                                            )
                                            .map(function (o) {
                                              var val =
                                                "_value" in o
                                                  ? o._value
                                                  : o.value
                                              return val
                                            })
                                        _vm.$set(
                                          _vm.activeItem,
                                          "activity_id",
                                          $event.target.multiple
                                            ? $$selectedVal
                                            : $$selectedVal[0]
                                        )
                                      },
                                    },
                                  },
                                  [
                                    _c(
                                      "option",
                                      { attrs: { value: "0", selected: "" } },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _vm._l(
                                      _vm.grouped_activities(
                                        _vm.activeItem.source,
                                        _vm.activeItem.group_id
                                      ),
                                      function (activity) {
                                        return _c(
                                          "option",
                                          {
                                            key: activity.id,
                                            domProps: { value: activity.id },
                                          },
                                          [
                                            _vm._v(
                                              "\n\t\t\t\t\t\t\t\t\t" +
                                                _vm._s(activity.name) +
                                                "\n\t\t\t\t\t\t\t\t"
                                            ),
                                          ]
                                        )
                                      }
                                    ),
                                  ],
                                  2
                                ),
                              ]),
                            ])
                          : field.key == "unit"
                          ? _c("div", [
                              _c(
                                "select",
                                {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.activeItem.unit,
                                      expression: "activeItem.unit",
                                    },
                                  ],
                                  on: {
                                    change: function ($event) {
                                      var $$selectedVal = Array.prototype.filter
                                        .call(
                                          $event.target.options,
                                          function (o) {
                                            return o.selected
                                          }
                                        )
                                        .map(function (o) {
                                          var val =
                                            "_value" in o ? o._value : o.value
                                          return val
                                        })
                                      _vm.$set(
                                        _vm.activeItem,
                                        "unit",
                                        $event.target.multiple
                                          ? $$selectedVal
                                          : $$selectedVal[0]
                                      )
                                    },
                                  },
                                },
                                [
                                  _c(
                                    "option",
                                    { attrs: { value: "0", selected: "" } },
                                    [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t-\n\t\t\t\t\t\t\t"
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _vm._l(
                                    Object.keys(_vm.units),
                                    function (key) {
                                      return _c(
                                        "option",
                                        { key: key, domProps: { value: key } },
                                        [
                                          _vm._v(
                                            "\n\t\t\t\t\t\t\t\t" +
                                              _vm._s(_vm.units[key]) +
                                              "\n\t\t\t\t\t\t\t"
                                          ),
                                        ]
                                      )
                                    }
                                  ),
                                ],
                                2
                              ),
                            ])
                          : field.key == "daypart"
                          ? _c("div", [
                              _c(
                                "select",
                                {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.activeItem.daypart,
                                      expression: "activeItem.daypart",
                                    },
                                  ],
                                  on: {
                                    change: function ($event) {
                                      var $$selectedVal = Array.prototype.filter
                                        .call(
                                          $event.target.options,
                                          function (o) {
                                            return o.selected
                                          }
                                        )
                                        .map(function (o) {
                                          var val =
                                            "_value" in o ? o._value : o.value
                                          return val
                                        })
                                      _vm.$set(
                                        _vm.activeItem,
                                        "daypart",
                                        $event.target.multiple
                                          ? $$selectedVal
                                          : $$selectedVal[0]
                                      )
                                    },
                                  },
                                },
                                _vm._l(
                                  Object.keys(_vm.dayparts),
                                  function (key) {
                                    return _c(
                                      "option",
                                      { key: key, domProps: { value: key } },
                                      [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t" +
                                            _vm._s(_vm.dayparts[key]) +
                                            "\n\t\t\t\t\t\t\t"
                                        ),
                                      ]
                                    )
                                  }
                                ),
                                0
                              ),
                            ])
                          : field.key == "text"
                          ? _c("div", [
                              _c("textarea", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.activeItem[field.key],
                                    expression: "activeItem[field.key]",
                                  },
                                ],
                                domProps: { value: _vm.activeItem[field.key] },
                                on: {
                                  input: function ($event) {
                                    if ($event.target.composing) {
                                      return
                                    }
                                    _vm.$set(
                                      _vm.activeItem,
                                      field.key,
                                      $event.target.value
                                    )
                                  },
                                },
                              }),
                            ])
                          : _c("div", [
                              field.type === "checkbox"
                                ? _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.activeItem[field.key],
                                        expression: "activeItem[field.key]",
                                      },
                                    ],
                                    attrs: { type: "checkbox" },
                                    domProps: {
                                      checked: Array.isArray(
                                        _vm.activeItem[field.key]
                                      )
                                        ? _vm._i(
                                            _vm.activeItem[field.key],
                                            null
                                          ) > -1
                                        : _vm.activeItem[field.key],
                                    },
                                    on: {
                                      change: [
                                        function ($event) {
                                          var $$a = _vm.activeItem[field.key],
                                            $$el = $event.target,
                                            $$c = $$el.checked ? true : false
                                          if (Array.isArray($$a)) {
                                            var $$v = null,
                                              $$i = _vm._i($$a, $$v)
                                            if ($$el.checked) {
                                              $$i < 0 &&
                                                _vm.$set(
                                                  _vm.activeItem,
                                                  field.key,
                                                  $$a.concat([$$v])
                                                )
                                            } else {
                                              $$i > -1 &&
                                                _vm.$set(
                                                  _vm.activeItem,
                                                  field.key,
                                                  $$a
                                                    .slice(0, $$i)
                                                    .concat($$a.slice($$i + 1))
                                                )
                                            }
                                          } else {
                                            _vm.$set(
                                              _vm.activeItem,
                                              field.key,
                                              $$c
                                            )
                                          }
                                        },
                                        function ($event) {
                                          return _vm.validate(
                                            _vm.activeItem[field.key],
                                            field.key
                                          )
                                        },
                                      ],
                                    },
                                  })
                                : field.type === "radio"
                                ? _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.activeItem[field.key],
                                        expression: "activeItem[field.key]",
                                      },
                                    ],
                                    attrs: { type: "radio" },
                                    domProps: {
                                      checked: _vm._q(
                                        _vm.activeItem[field.key],
                                        null
                                      ),
                                    },
                                    on: {
                                      change: [
                                        function ($event) {
                                          return _vm.$set(
                                            _vm.activeItem,
                                            field.key,
                                            null
                                          )
                                        },
                                        function ($event) {
                                          return _vm.validate(
                                            _vm.activeItem[field.key],
                                            field.key
                                          )
                                        },
                                      ],
                                    },
                                  })
                                : _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.activeItem[field.key],
                                        expression: "activeItem[field.key]",
                                      },
                                    ],
                                    attrs: { type: field.type },
                                    domProps: {
                                      value: _vm.activeItem[field.key],
                                    },
                                    on: {
                                      change: function ($event) {
                                        return _vm.validate(
                                          _vm.activeItem[field.key],
                                          field.key
                                        )
                                      },
                                      input: function ($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.activeItem,
                                          field.key,
                                          $event.target.value
                                        )
                                      },
                                    },
                                  }),
                            ]),
                      ]
                    )
                  }),
                  _vm._v(" "),
                  _c("div", [
                    _c(
                      "button",
                      {
                        staticClass: "d-flex aic  btn btn-success ml-3",
                        on: { click: _vm.saveItem },
                      },
                      [
                        _c("i", { staticClass: "fa fa-save" }),
                        _vm._v(" "),
                        _c("span", { staticClass: "ml-2" }, [
                          _vm._v("Сохранить"),
                        ]),
                      ]
                    ),
                  ]),
                ],
                2
              ),
            ]
          )
        : _vm._e(),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=template&id=e2d5a3e8&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableBonus.vue?vue&type=template&id=e2d5a3e8& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "bonuses 1" }, [
    _c(
      "table",
      {
        staticClass:
          "table j-table table-bordered table-sm mb-3 collapse-table",
      },
      [
        _c("tr", [
          _c("th", { staticClass: "b-table-sticky-column text-center px-1" }, [
            _c("i", {
              staticClass: "fa fa-cog",
              on: { click: _vm.adjustFields },
            }),
          ]),
          _vm._v(" "),
          _c("th", { staticClass: "text-left" }, [
            _vm._v("\n\t\t\t\t\tКому\n\t\t\t\t"),
          ]),
        ]),
        _vm._v(" "),
        _c("tr"),
        _vm._v(" "),
        _vm._l(_vm.items, function (page_item, index) {
          return [
            _c("tr", { key: index }, [
              _c(
                "td",
                {
                  staticClass: "pointer b-table-sticky-column",
                  on: {
                    click: function ($event) {
                      page_item.expanded = !page_item.expanded
                    },
                  },
                },
                [
                  _c("div", { staticClass: "d-flex px-2" }, [
                    page_item.expanded
                      ? _c("i", { staticClass: "fa fa-minus mt-1" })
                      : _c("i", { staticClass: "fa fa-plus mt-1" }),
                    _vm._v(" "),
                    _c("span", { staticClass: "ml-2" }, [
                      _vm._v(_vm._s(index + 1)),
                    ]),
                  ]),
                ]
              ),
              _vm._v(" "),
              _c("td", { staticClass: "text-left" }, [
                _c("div", { staticClass: "d-flex aic p-1" }, [
                  _c("span", { staticClass: "ml-2" }, [
                    _vm._v(_vm._s(page_item.name)),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            page_item.expanded
              ? [
                  _c(
                    "tr",
                    {
                      key: "tr" + index,
                      staticClass: "collapsable",
                      class: { active: page_item.expanded },
                    },
                    [
                      _c("td", { attrs: { colspan: _vm.fields.length + 2 } }, [
                        _c(
                          "div",
                          { staticClass: "table__wrapper" },
                          _vm._l(page_item.users, function (user, userIndex) {
                            return _c(
                              "table",
                              {
                                key: userIndex,
                                staticClass:
                                  "table b-table table-bordered table-sm table-responsive mb-0 table-inner",
                              },
                              [
                                _c(
                                  "tr",
                                  [
                                    _c(
                                      "th",
                                      {
                                        staticClass:
                                          "b-table-sticky-column text-center px-1 pointer",
                                        on: {
                                          click: function ($event) {
                                            user.expanded = !user.expanded
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          { staticClass: "d-flex px-2 " },
                                          [
                                            user.expanded
                                              ? _c("i", {
                                                  staticClass:
                                                    "fa fa-minus mt-1",
                                                })
                                              : _c("i", {
                                                  staticClass:
                                                    "fa fa-plus mt-1",
                                                }),
                                            _vm._v(" "),
                                            _c(
                                              "span",
                                              {
                                                staticClass:
                                                  "ml-2 bg-transparent ",
                                              },
                                              [_vm._v(_vm._s(user.id))]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c("th", { staticClass: "text-left" }, [
                                      _vm._v(
                                        "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                          _vm._s(user.name) +
                                          "\n\t\t\t\t\t\t\t\t\t\t"
                                      ),
                                    ]),
                                    _vm._v(" "),
                                    _vm._l(_vm.bonuses, function (bonus) {
                                      return [
                                        bonus.targetable_id == page_item.id
                                          ? _c("th", { key: bonus.id }, [
                                              _vm._v(
                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                  _vm._s(bonus.title) +
                                                  " "
                                              ),
                                              user.bonus_totals.filter(
                                                function (total) {
                                                  return (
                                                    total.bonus_id === bonus.id
                                                  )
                                                }
                                              )[0]
                                                ? _c("b", [
                                                    _vm._v(
                                                      _vm._s(
                                                        user.bonus_totals.filter(
                                                          function (total) {
                                                            return (
                                                              total.bonus_id ===
                                                              bonus.id
                                                            )
                                                          }
                                                        )[0].sum
                                                      ) + " тг"
                                                    ),
                                                  ])
                                                : _c("b", [_vm._v(" 0 тг")]),
                                            ])
                                          : _vm._e(),
                                      ]
                                    }),
                                  ],
                                  2
                                ),
                                _vm._v(" "),
                                user.expanded
                                  ? [
                                      _c(
                                        "table",
                                        {
                                          staticClass:
                                            "table b-table table-bordered table-sm table-responsive mb-0 table-inner",
                                        },
                                        [
                                          _vm._m(0, true),
                                          _vm._v(" "),
                                          _vm._l(
                                            _vm.filteredBonuses,
                                            function (bonus, bonusIndex) {
                                              return _c(
                                                "tr",
                                                { key: bonusIndex },
                                                [
                                                  _c(
                                                    "td",
                                                    {
                                                      staticClass:
                                                        "text-white text-center",
                                                    },
                                                    [
                                                      _vm._v(
                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                          _vm._s(
                                                            bonusIndex + 1
                                                          ) +
                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                      ),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(bonus.comment)
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(
                                                        bonus.comment.substring(
                                                          bonus.comment.indexOf(
                                                            ":"
                                                          ) + 1,
                                                          bonus.comment.lastIndexOf(
                                                            ";"
                                                          )
                                                        )
                                                      )
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(bonus.amount)
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(_vm._s(bonus.date)),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(
                                                        bonus.amount *
                                                          parseInt(
                                                            bonus.comment.substring(
                                                              bonus.comment.indexOf(
                                                                ":"
                                                              ) + 1,
                                                              bonus.comment.lastIndexOf(
                                                                ";"
                                                              )
                                                            )
                                                          )
                                                      )
                                                    ),
                                                  ]),
                                                ]
                                              )
                                            }
                                          ),
                                        ],
                                        2
                                      ),
                                    ]
                                  : _vm._e(),
                              ],
                              2
                            )
                          }),
                          0
                        ),
                      ]),
                    ]
                  ),
                ]
              : _vm._e(),
          ]
        }),
        _vm._v(" "),
        _c("tr"),
      ],
      2
    ),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th"),
      _vm._v(" "),
      _c("th", [_vm._v("Наименование активности")]),
      _vm._v(" "),
      _c("th", [_vm._v("За")]),
      _vm._v(" "),
      _c("th", [_vm._v("Кол-во")]),
      _vm._v(" "),
      _c("th", [_vm._v("Вознаграждение")]),
      _vm._v(" "),
      _c("th", [_vm._v("Период")]),
      _vm._v(" "),
      _c("th", [_vm._v("Заработано")]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=template&id=7d445157&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableQuartal.vue?vue&type=template&id=7d445157& ***!
  \****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "bonuses" }, [
    _c(
      "table",
      {
        staticClass:
          "table j-table table-bordered table-sm mb-3 collapse-table",
      },
      [
        _vm._m(0),
        _vm._v(" "),
        _c("tr"),
        _vm._v(" "),
        _vm._l(_vm.users, function (page_item, p) {
          return [
            page_item.name.includes(_vm.searchText) ||
            _vm.searchText.length == 0
              ? [
                  _c("tr", { key: p }, [
                    _c(
                      "td",
                      {
                        staticClass: "pointer b-table-sticky-column",
                        on: {
                          click: function ($event) {
                            return _vm.expandUser(p)
                          },
                        },
                      },
                      [
                        _c("div", { staticClass: "d-flex px-2" }, [
                          page_item.expanded
                            ? _c("i", { staticClass: "fa fa-minus mt-1" })
                            : _c("i", { staticClass: "fa fa-plus mt-1" }),
                          _vm._v(" "),
                          _c("span", { staticClass: "ml-2" }, [
                            _vm._v(_vm._s(p + 1)),
                          ]),
                        ]),
                      ]
                    ),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-left" }, [
                      _c("div", { staticClass: "d-flex aic p-1" }, [
                        _c("i", { staticClass: "fa fa-user ml-2 color-user" }),
                        _vm._v(" "),
                        _c("span", { staticClass: "ml-2" }, [
                          _vm._v(_vm._s(page_item.name)),
                        ]),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  page_item.expanded
                    ? [
                        _c("tr", { key: "tr" + p }, [
                          _c("td", { attrs: { colspan: "2" } }, [
                            _c(
                              "table",
                              {
                                staticClass:
                                  "table b-table table-bordered table-sm table-responsive mb-0 table-inner",
                              },
                              [
                                _vm._m(1, true),
                                _vm._v(" "),
                                _c("tr", [
                                  _c("td"),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(_vm._s(page_item.items.title)),
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(_vm._s(page_item.items.plan)),
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(_vm._s(page_item.items.fact)),
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(_vm._s(page_item.items.sum)),
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(_vm._s(page_item.items.from)),
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(_vm._s(page_item.items.to)),
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(_vm._s(page_item.items.text)),
                                  ]),
                                  _vm._v(" "),
                                  page_item.items.plan <= page_item.items.fact
                                    ? _c("td", [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t\t\tВыполнено\n\t\t\t\t\t\t\t\t\t\t"
                                        ),
                                      ])
                                    : _c("td", [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t\t\tНе выполнено\n\t\t\t\t\t\t\t\t\t\t"
                                        ),
                                      ]),
                                  _vm._v(" "),
                                  page_item.items.plan <= page_item.items.fact
                                    ? _c("td", [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t\t\t" +
                                            _vm._s(page_item.items.sum) +
                                            "\n\t\t\t\t\t\t\t\t\t\t"
                                        ),
                                      ])
                                    : _c("td", [
                                        _vm._v(
                                          "\n\t\t\t\t\t\t\t\t\t\t\t0\n\t\t\t\t\t\t\t\t\t\t"
                                        ),
                                      ]),
                                ]),
                              ]
                            ),
                          ]),
                        ]),
                      ]
                    : _vm._e(),
                ]
              : _vm._e(),
          ]
        }),
        _vm._v(" "),
        _vm._l(_vm.groups, function (page_item, p) {
          return [
            page_item[0].name.includes(_vm.searchText) ||
            _vm.searchText.length == 0
              ? [
                  _c("tr", { key: p }, [
                    _c(
                      "td",
                      {
                        staticClass: "pointer b-table-sticky-column",
                        on: {
                          click: function ($event) {
                            return _vm.expandGroup(p)
                          },
                        },
                      },
                      [
                        _c("div", { staticClass: "d-flex px-2" }, [
                          page_item.expanded
                            ? _c("i", { staticClass: "fa fa-minus mt-1" })
                            : _c("i", { staticClass: "fa fa-plus mt-1" }),
                          _vm._v(" "),
                          _c("span", { staticClass: "ml-2" }, [
                            _vm._v(_vm._s(p + 1 + _vm.users.length)),
                          ]),
                        ]),
                      ]
                    ),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-left" }, [
                      _c("div", { staticClass: "d-flex aic p-1" }, [
                        _c("i", {
                          staticClass: "fa fa-users ml-2 color-group",
                        }),
                        _vm._v(" "),
                        _c("span", { staticClass: "ml-2" }, [
                          _vm._v(_vm._s(page_item[0].name)),
                        ]),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  page_item.expanded
                    ? [
                        _c("tr", { key: "tr" + p }, [
                          _c(
                            "td",
                            { attrs: { colspan: "2" } },
                            [
                              _vm._l(page_item, function (user, i) {
                                return [
                                  i != "expanded"
                                    ? _c(
                                        "table",
                                        {
                                          key: i,
                                          staticClass:
                                            "table b-table table-bordered table-sm table-responsive mb-0 table-inner",
                                        },
                                        [
                                          _c("tr", [
                                            _c(
                                              "th",
                                              {
                                                staticClass:
                                                  "pointer b-table-sticky-column",
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.expandGroupUser(
                                                      i,
                                                      p
                                                    )
                                                  },
                                                },
                                              },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass: "d-flex px-2",
                                                  },
                                                  [
                                                    user.expended
                                                      ? _c("i", {
                                                          staticClass:
                                                            "fa fa-minus mt-1",
                                                        })
                                                      : _c("i", {
                                                          staticClass:
                                                            "fa fa-plus mt-1",
                                                        }),
                                                    _vm._v(" "),
                                                    _c(
                                                      "span",
                                                      { staticClass: "ml-2" },
                                                      [
                                                        _vm._v(
                                                          _vm._s(
                                                            parseInt(i) + 1
                                                          )
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                            _vm._v(" "),
                                            _c(
                                              "th",
                                              { attrs: { colspan: "9" } },
                                              [
                                                _vm._v(
                                                  "\n\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                    _vm._s(user.full_name) +
                                                    "\n\t\t\t\t\t\t\t\t\t\t\t"
                                                ),
                                              ]
                                            ),
                                          ]),
                                          _vm._v(" "),
                                          user.expended
                                            ? [
                                                _vm._m(2, true),
                                                _vm._v(" "),
                                                _c("tr", [
                                                  _c("td"),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(
                                                        user.quartalPremiums
                                                          .title
                                                      )
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(
                                                        user.quartalPremiums
                                                          .plan
                                                      )
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(_vm._s(user.fact)),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(
                                                        user.quartalPremiums.sum
                                                      )
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(
                                                        user.quartalPremiums
                                                          .from
                                                      )
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(
                                                        user.quartalPremiums.to
                                                      )
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(
                                                        user.quartalPremiums
                                                          .text
                                                      )
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  user.quartalPremiums.plan <=
                                                  user.quartalPremiums.fact
                                                    ? _c("td", [
                                                        _vm._v(
                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\tВыполнено\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                        ),
                                                      ])
                                                    : _c("td", [
                                                        _vm._v(
                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\tНе выполнено\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                        ),
                                                      ]),
                                                  _vm._v(" "),
                                                  user.quartalPremiums.plan <=
                                                  user.quartalPremiums.fact
                                                    ? _c("td", [
                                                        _vm._v(
                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                            _vm._s(
                                                              page_item
                                                                .quartalPremiums
                                                                .sum
                                                            ) +
                                                            "\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                        ),
                                                      ])
                                                    : _c("td", [
                                                        _vm._v(
                                                          "\n\t\t\t\t\t\t\t\t\t\t\t\t\t0\n\t\t\t\t\t\t\t\t\t\t\t\t"
                                                        ),
                                                      ]),
                                                ]),
                                              ]
                                            : _vm._e(),
                                        ],
                                        2
                                      )
                                    : _vm._e(),
                                ]
                              }),
                            ],
                            2
                          ),
                        ]),
                      ]
                    : _vm._e(),
                ]
              : _vm._e(),
          ]
        }),
      ],
      2
    ),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th", { staticClass: "b-table-sticky-column text-center px-1" }, [
        _c("i", { staticClass: "fa fa-cog" }),
      ]),
      _vm._v(" "),
      _c("th", { staticClass: "text-left" }, [
        _vm._v("\n\t\t\t\t\tКвартальные премии\n\t\t\t\t"),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th"),
      _vm._v(" "),
      _c("th", [_vm._v("Название")]),
      _vm._v(" "),
      _c("th", [_vm._v("План")]),
      _vm._v(" "),
      _c("th", [_vm._v("Факт")]),
      _vm._v(" "),
      _c("th", [_vm._v("Вознаграждение")]),
      _vm._v(" "),
      _c("th", [_vm._v("Период с")]),
      _vm._v(" "),
      _c("th", [_vm._v("Период по")]),
      _vm._v(" "),
      _c("th", [_vm._v("Текст")]),
      _vm._v(" "),
      _c("th", [_vm._v("Вып/Невып")]),
      _vm._v(" "),
      _c("th", [_vm._v("Заработанная сумма")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("tr", [
      _c("th"),
      _vm._v(" "),
      _c("th", [_vm._v("Название")]),
      _vm._v(" "),
      _c("th", [_vm._v("План")]),
      _vm._v(" "),
      _c("th", [_vm._v("Факт")]),
      _vm._v(" "),
      _c("th", [_vm._v("Вознаграждение")]),
      _vm._v(" "),
      _c("th", [_vm._v("Период с")]),
      _vm._v(" "),
      _c("th", [_vm._v("Период по")]),
      _vm._v(" "),
      _c("th", [_vm._v("Текст")]),
      _vm._v(" "),
      _c("th", [_vm._v("Вып/Невып")]),
      _vm._v(" "),
      _c("th", [_vm._v("Заработанная сумма")]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=template&id=1724985f&scoped=true&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableV2.vue?vue&type=template&id=1724985f&scoped=true& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "t-stats" }, [
    _c("table", { staticClass: "j-table" }, [
      _c("thead", [
        _c("tr", { staticClass: "table-heading" }, [
          _c("th", { staticClass: "first-column" }),
          _vm._v(" "),
          _c("th", { staticClass: "w" }, [_vm._v("\n\t\t\t\t\tKPI\n\t\t\t\t")]),
          _vm._v(" "),
          _vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tСредний %\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          !_vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tНижний порог отсчета\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          !_vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tВерхний порог отсчета\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          !_vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tПри выполнении на 80-99%\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          !_vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tПри выполнении на 100%\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          !_vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tЗаработано\n\t\t\t\t"),
              ])
            : _vm._e(),
          _vm._v(" "),
          _vm.editable
            ? _c("th", { staticClass: "px-2" }, [
                _vm._v("\n\t\t\t\t\tСредний %\n\t\t\t\t"),
              ])
            : _vm._e(),
        ]),
      ]),
      _vm._v(" "),
      _c(
        "tbody",
        [
          _vm._l(_vm.reversedItems, function (wrap_item, w) {
            return [
              _c("tr", { key: w, staticClass: "main-row" }, [
                _c(
                  "td",
                  {
                    staticClass: "pointer p-2 text-center",
                    on: {
                      click: function ($event) {
                        _vm.kpis[_vm.types[wrap_item.targetable_type]][
                          wrap_item.targetable_id
                        ]
                          ? _vm.closeKPI(
                              wrap_item.targetable_id,
                              wrap_item.targetable_type
                            )
                          : _vm.fetchKPI(
                              wrap_item.targetable_id,
                              wrap_item.targetable_type
                            )
                      },
                    },
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "d-flex align-items-center justify-content-center px-2",
                      },
                      [
                        _c("span", { staticClass: "mr-2" }, [
                          _vm._v(_vm._s(w + 1)),
                        ]),
                        _vm._v(" "),
                        _vm.kpis[_vm.types[wrap_item.targetable_type]][
                          wrap_item.targetable_id
                        ]
                          ? _c("i", { staticClass: "fa fa-minus mt-1" })
                          : _vm.loading[_vm.types[wrap_item.targetable_type]][
                              wrap_item.targetable_id
                            ]
                          ? _c("i", {
                              staticClass: "fa fa-circle-notch fa-spin mt-1",
                            })
                          : _c("i", { staticClass: "fa fa-plus mt-1" }),
                      ]
                    ),
                  ]
                ),
                _vm._v(" "),
                _c("td", { staticClass: "p-4" }, [
                  _vm.types[wrap_item.targetable_type] === 1
                    ? _c("i", { staticClass: "fa fa-user mt-1 mr-1" })
                    : _vm.types[wrap_item.targetable_type] === 2
                    ? _c("i", { staticClass: "fa fa-users mt-1 mr-1" })
                    : _c("i", { staticClass: "fa fa-briefcase mt-1 mr-1" }),
                  _vm._v(" "),
                  wrap_item.target != null
                    ? _c("span", [_vm._v(_vm._s(wrap_item.target.name))])
                    : _c("span", [_vm._v("---")]),
                ]),
                _vm._v(" "),
                _vm.editable
                  ? _c(
                      "td",
                      {
                        staticClass: "p-4",
                        style:
                          "background-color: " +
                          _vm.getBacklightForValue(wrap_item.avg),
                      },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(wrap_item.avg) +
                            "%\n\t\t\t\t\t"
                        ),
                      ]
                    )
                  : _vm._e(),
                _vm._v(" "),
                !_vm.editable
                  ? _c("td", { staticClass: "p-4" }, [
                      _vm._v(
                        "\n\t\t\t\t\t\t" +
                          _vm._s(wrap_item.lower_limit) +
                          "%\n\t\t\t\t\t"
                      ),
                    ])
                  : _vm._e(),
                _vm._v(" "),
                !_vm.editable
                  ? _c("td", { staticClass: "p-4" }, [
                      _vm._v(
                        "\n\t\t\t\t\t\t" +
                          _vm._s(wrap_item.upper_limit) +
                          "%\n\t\t\t\t\t"
                      ),
                    ])
                  : _vm._e(),
                _vm._v(" "),
                !_vm.editable
                  ? _c("td", { staticClass: "p-4" }, [
                      _vm._v(
                        "\n\t\t\t\t\t\t" +
                          _vm._s(
                            wrap_item.users.length > 0 &&
                              wrap_item.users[0].full_time == 1
                              ? wrap_item.completed_80
                              : wrap_item.completed_80 / 2
                          ) +
                          "\n\t\t\t\t\t"
                      ),
                    ])
                  : _vm._e(),
                _vm._v(" "),
                !_vm.editable
                  ? _c("td", { staticClass: "p-4" }, [
                      _vm._v(
                        "\n\t\t\t\t\t\t" +
                          _vm._s(
                            wrap_item.users.length > 0 &&
                              wrap_item.users[0].full_time == 1
                              ? wrap_item.completed_100
                              : wrap_item.completed_100 / 2
                          ) +
                          "\n\t\t\t\t\t"
                      ),
                    ])
                  : _vm._e(),
                _vm._v(" "),
                !_vm.editable
                  ? _c("td", { staticClass: "p-4" }, [
                      _vm._v(
                        "\n\t\t\t\t\t\t" +
                          _vm._s(wrap_item.my_sum) +
                          "\n\t\t\t\t\t"
                      ),
                    ])
                  : _vm._e(),
                _vm._v(" "),
                _vm.editable ? _c("td") : _vm._e(),
              ]),
              _vm._v(" "),
              wrap_item.users != undefined && wrap_item.users.length > 0
                ? [
                    _c(
                      "tr",
                      {
                        key: w + "a",
                        staticClass: "collapsable",
                        class: {
                          active:
                            _vm.kpis[_vm.types[wrap_item.targetable_type]][
                              wrap_item.targetable_id
                            ] || !_vm.editable,
                        },
                      },
                      [
                        _c("td", { attrs: { colspan: _vm.editable ? 4 : 7 } }, [
                          _c("div", { staticClass: "table__wrapper w-100" }, [
                            _vm.kpis[_vm.types[wrap_item.targetable_type]][
                              wrap_item.targetable_id
                            ]
                              ? _c(
                                  "table",
                                  { staticClass: "child-table" },
                                  [
                                    _vm._l(
                                      _vm.kpis[
                                        _vm.types[wrap_item.targetable_type]
                                      ][wrap_item.targetable_id].users,
                                      function (user, i) {
                                        return [
                                          _vm.editable
                                            ? _c(
                                                "tr",
                                                {
                                                  key: i,
                                                  staticClass: "child-row",
                                                },
                                                [
                                                  _c(
                                                    "td",
                                                    {
                                                      staticClass:
                                                        "pointer p-2 text-center",
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          user.expanded =
                                                            !user.expanded
                                                        },
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "div",
                                                        {
                                                          staticClass:
                                                            "d-flex align-center justify-content-center px-2",
                                                        },
                                                        [
                                                          _c(
                                                            "span",
                                                            {
                                                              staticClass:
                                                                "mr-2 bg-transparent",
                                                            },
                                                            [
                                                              _vm._v(
                                                                _vm._s(i + 1)
                                                              ),
                                                            ]
                                                          ),
                                                          _vm._v(" "),
                                                          user.expanded
                                                            ? _c("i", {
                                                                staticClass:
                                                                  "fa fa-minus mt-1",
                                                              })
                                                            : _c("i", {
                                                                staticClass:
                                                                  "fa fa-plus mt-1",
                                                              }),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "td",
                                                    { staticClass: "p-4" },
                                                    [
                                                      _vm._v(
                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                          _vm._s(user.name) +
                                                          "\n\t\t\t\t\t\t\t\t\t\t\t"
                                                      ),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "td",
                                                    { staticClass: "p-4" },
                                                    [
                                                      _vm._v(
                                                        "\n\t\t\t\t\t\t\t\t\t\t\t\tСредний % "
                                                      ),
                                                      _c("b", [
                                                        _vm._v(
                                                          _vm._s(
                                                            parseFloat(
                                                              user.avg_percent
                                                            ).toFixed(2)
                                                          ) + "%"
                                                        ),
                                                      ]),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  user.items !== undefined
                                                    ? _vm._l(
                                                        user.items,
                                                        function (
                                                          kpi_item,
                                                          index
                                                        ) {
                                                          return _c(
                                                            "td",
                                                            {
                                                              key: index,
                                                              staticClass:
                                                                "px-2",
                                                            },
                                                            [
                                                              _vm._v(
                                                                "\n\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                                                                  _vm._s(
                                                                    kpi_item.name
                                                                  ) +
                                                                  " "
                                                              ),
                                                              _c("b", [
                                                                _vm._v(
                                                                  _vm._s(
                                                                    kpi_item.percent
                                                                  ) + "%"
                                                                ),
                                                              ]),
                                                            ]
                                                          )
                                                        }
                                                      )
                                                    : _vm._e(),
                                                ],
                                                2
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          user.expanded
                                            ? _c("tr", { key: i + "a" }, [
                                                _c(
                                                  "td",
                                                  {
                                                    attrs: {
                                                      colspan:
                                                        _vm.fields.length + 2,
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "table__wrapper__second w-100",
                                                      },
                                                      [
                                                        _c("KpiItemsV2", {
                                                          attrs: {
                                                            my_sum:
                                                              user.full_time ==
                                                              1
                                                                ? wrap_item.completed_100
                                                                : wrap_item.completed_100 /
                                                                  2,
                                                            kpi_id: user.id,
                                                            items: user.items,
                                                            expanded: true,
                                                            activities:
                                                              _vm.activities,
                                                            groups: _vm.groups,
                                                            completed_80:
                                                              wrap_item.completed_80,
                                                            completed_100:
                                                              wrap_item.completed_100,
                                                            lower_limit:
                                                              wrap_item.lower_limit,
                                                            upper_limit:
                                                              wrap_item.upper_limit,
                                                            editable:
                                                              _vm.editable,
                                                            kpi_page: false,
                                                            date: _vm.date,
                                                          },
                                                          on: {
                                                            getSum: function (
                                                              $event
                                                            ) {
                                                              wrap_item.my_sum =
                                                                $event
                                                            },
                                                            recalced:
                                                              _vm.countAvg,
                                                          },
                                                        }),
                                                      ],
                                                      1
                                                    ),
                                                  ]
                                                ),
                                              ])
                                            : _vm._e(),
                                        ]
                                      }
                                    ),
                                  ],
                                  2
                                )
                              : _vm._e(),
                          ]),
                        ]),
                      ]
                    ),
                  ]
                : _vm._e(),
            ]
          }),
        ],
        2
      ),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=template&id=0edfba40&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsTableYear.vue?vue&type=template&id=0edfba40& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "StatsTableYear",
      class: {
        "v-loading": _vm.isLoading.year,
      },
    },
    [
      _c("table", { staticClass: "StatsTableYear-table j-table mt-4" }, [
        _c("thead", [
          _c(
            "tr",
            { staticClass: "table-heading" },
            [
              _c("th"),
              _vm._v(" "),
              _c("th", { staticClass: "first-column" }, [
                _vm._v("\n\t\t\t\t\tСотрудник\\Отдел\n\t\t\t\t"),
              ]),
              _vm._v(" "),
              _c("th", { staticClass: "text-center" }, [
                _vm._v("\n\t\t\t\t\tСредний по году\n\t\t\t\t"),
              ]),
              _vm._v(" "),
              _vm._l(_vm.$moment.months(), function (month) {
                return _c("th", { key: month, staticClass: "text-center" }, [
                  _vm._v("\n\t\t\t\t\t" + _vm._s(month) + "\n\t\t\t\t"),
                ])
              }),
            ],
            2
          ),
        ]),
        _vm._v(" "),
        _c(
          "tbody",
          [
            _vm._l(_vm.stats, function (kpi, index) {
              return [
                _c(
                  "tr",
                  { key: kpi.id },
                  [
                    _c(
                      "td",
                      {
                        staticClass: "p-3 pointer",
                        on: {
                          click: function ($event) {
                            return _vm.toggleKPI(kpi)
                          },
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "StatsTableYear-firstCol" },
                          [
                            _c("span", [_vm._v(_vm._s(index + 1))]),
                            _vm._v(" "),
                            kpi.type !== 1 && kpi.users.length
                              ? [
                                  kpi.expanded
                                    ? _c("i", {
                                        staticClass: "fa fa-minus mt-1",
                                      })
                                    : _c("i", {
                                        staticClass: "fa fa-plus mt-1",
                                      }),
                                ]
                              : _vm._e(),
                          ],
                          2
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c("td", { staticClass: "p-3" }, [
                      kpi.type === 1
                        ? _c("i", { staticClass: "fa fa-user mt-1 mr-1" })
                        : kpi.type === 2
                        ? _c("i", { staticClass: "fa fa-users mt-1 mr-1" })
                        : _c("i", { staticClass: "fa fa-briefcase mt-1 mr-1" }),
                      _vm._v(
                        "\n\t\t\t\t\t\t" + _vm._s(kpi.title) + "\n\t\t\t\t\t"
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "td",
                      {
                        staticClass: "text-center p-3",
                        style:
                          "background-color: " +
                          _vm.getBacklightForValue(kpi.avg),
                      },
                      [
                        _vm._v(
                          "\n\t\t\t\t\t\t" +
                            _vm._s(_vm._f("nonFixedFloat")(kpi.avg))
                        ),
                        typeof kpi.avg !== "undefined"
                          ? _c("sub", [_vm._v("%")])
                          : _vm._e(),
                      ]
                    ),
                    _vm._v(" "),
                    _vm._l(_vm.$moment.months(), function (month, key) {
                      return _c(
                        "td",
                        {
                          key: key,
                          staticClass: "text-center p-3",
                          style:
                            "background-color: " +
                            _vm.getBacklightForValue(kpi[key + 1]),
                        },
                        [
                          _vm._v(
                            "\n\t\t\t\t\t\t" +
                              _vm._s(_vm._f("nonFixedFloat")(kpi[key + 1]))
                          ),
                          typeof kpi[key + 1] !== "undefined"
                            ? _c("sub", [_vm._v("%")])
                            : _vm._e(),
                        ]
                      )
                    }),
                  ],
                  2
                ),
                _vm._v(" "),
                kpi.expanded
                  ? _vm._l(kpi.users, function (user) {
                      return _c(
                        "tr",
                        {
                          key: kpi.id + "-" + user.id,
                          staticClass: "StatsTableYear-subrow",
                        },
                        [
                          _c("td"),
                          _vm._v(" "),
                          _c("td", { staticClass: "p-3" }, [
                            _c("i", { staticClass: "fa fa-user mt-1 mr-1" }),
                            _vm._v(
                              "\n\t\t\t\t\t\t\t" +
                                _vm._s(user.name) +
                                "\n\t\t\t\t\t\t"
                            ),
                          ]),
                          _vm._v(" "),
                          _c(
                            "td",
                            {
                              staticClass: "text-center p-3",
                              style:
                                "background-color: " +
                                _vm.getBacklightForValue(user.avg),
                            },
                            [
                              _vm._v(
                                "\n\t\t\t\t\t\t\t" +
                                  _vm._s(_vm._f("nonFixedFloat")(user.avg))
                              ),
                              typeof user[_vm.key + 1] !== "undefined"
                                ? _c("sub", [_vm._v("%")])
                                : _vm._e(),
                            ]
                          ),
                          _vm._v(" "),
                          _vm._l(_vm.$moment.months(), function (month, key) {
                            return _c(
                              "td",
                              {
                                key: key,
                                staticClass: "text-center p-3",
                                style:
                                  "background-color: " +
                                  _vm.getBacklightForValue(user[key + 1]),
                              },
                              [
                                _vm._v(
                                  "\n\t\t\t\t\t\t\t" +
                                    _vm._s(
                                      _vm._f("nonFixedFloat")(user[key + 1])
                                    )
                                ),
                                typeof user[key + 1] !== "undefined"
                                  ? _c("sub", [_vm._v("%")])
                                  : _vm._e(),
                              ]
                            )
                          }),
                        ],
                        2
                      )
                    })
                  : _vm._e(),
              ]
            }),
          ],
          2
        ),
      ]),
      _vm._v(" "),
      _c(
        "b-col",
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { staticClass: "d-flex aic" },
                [
                  _c("b-pagination", {
                    staticClass: "mt-4",
                    attrs: {
                      "total-rows": _vm.statYear.rows,
                      "per-page": _vm.statYear.limit,
                      size: "sm",
                    },
                    model: {
                      value: _vm.page,
                      callback: function ($$v) {
                        _vm.page = $$v
                      },
                      expression: "page",
                    },
                  }),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { staticClass: "d-flex aic", attrs: { cols: "3" } },
                [
                  _c("b-form-select", {
                    attrs: { options: [10, 20, 50, 100] },
                    model: {
                      value: _vm.statYear.limit,
                      callback: function ($$v) {
                        _vm.$set(_vm.statYear, "limit", $$v)
                      },
                      expression: "statYear.limit",
                    },
                  }),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsV2.vue?vue&type=template&id=46a30d17&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/StatsV2.vue?vue&type=template&id=46a30d17& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "stats px-3 py-1" },
    [
      _c("div", { staticClass: "d-flex my-4 jcsb aifs" }, [
        _c(
          "div",
          { staticClass: "d-flex aic mr-2" },
          [
            _c("SuperFilter", {
              ref: "child",
              attrs: { groups: _vm.groups },
              on: { apply: _vm.fetchData },
            }),
            _vm._v(" "),
            _vm.items
              ? _c("span", { staticClass: "ml-2" }, [
                  _vm._v(
                    "\n\t\t\t\tНайдено: " + _vm._s(_vm.totalRows) + "\n\t\t\t"
                  ),
                ])
              : _c("span", { staticClass: "ml-2" }, [
                  _vm._v("\n\t\t\t\tНайдено: 0\n\t\t\t"),
                ]),
          ],
          1
        ),
        _vm._v(" "),
        _vm.isAdmin
          ? _c("i", {
              staticClass: "fa fa-cog btn ml-a",
              on: {
                click: function ($event) {
                  _vm.isSettingsOpen = true
                },
              },
            })
          : _vm._e(),
      ]),
      _vm._v(" "),
      _vm.s_type_main == 1
        ? [
            _c(
              "b-tabs",
              [
                _c(
                  "b-tab",
                  { attrs: { title: "Месяц" } },
                  [
                    _c("StatsTableV2", {
                      staticClass: "mt-4",
                      attrs: {
                        activities: _vm.activities,
                        groups: _vm.groups,
                        items: _vm.page_items,
                        editable: true,
                        "search-text": _vm.searchText,
                        date: _vm.date,
                        filters: _vm.filters,
                      },
                    }),
                    _vm._v(" "),
                    _c(
                      "b-col",
                      [
                        _c(
                          "b-row",
                          [
                            _c(
                              "b-col",
                              { staticClass: "d-flex aic" },
                              [
                                _c("b-pagination", {
                                  staticClass: "mt-4",
                                  attrs: {
                                    "total-rows": _vm.totalRows,
                                    "per-page": _vm.perPage,
                                    size: "sm",
                                  },
                                  model: {
                                    value: _vm.currentPage,
                                    callback: function ($$v) {
                                      _vm.currentPage = $$v
                                    },
                                    expression: "currentPage",
                                  },
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              {
                                staticClass: "d-flex aic",
                                attrs: { cols: "3" },
                              },
                              [
                                _c("b-form-select", {
                                  attrs: { options: [10, 20, 50, 100] },
                                  model: {
                                    value: _vm.perPage,
                                    callback: function ($$v) {
                                      _vm.perPage = $$v
                                    },
                                    expression: "perPage",
                                  },
                                }),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "b-tab",
                  { attrs: { title: "Годовая" } },
                  [
                    _c("StatsTableYear", {
                      staticClass: "mt-4",
                      attrs: {
                        year: _vm.filters.data_from
                          ? _vm.filters.data_from.year
                          : new Date().getFullYear(),
                      },
                    }),
                  ],
                  1
                ),
              ],
              1
            ),
          ]
        : _vm._e(),
      _vm._v(" "),
      _vm.s_type_main == 2
        ? _c("StatsTableBonus", {
            key: _vm.bonus_groups,
            attrs: {
              groups: _vm.bonus_groups,
              group_names: _vm.groups,
              month: _vm.month,
            },
          })
        : _vm._e(),
      _vm._v(" "),
      _vm.s_type_main == 3
        ? _c("StatsTableQuartal", {
            key: _vm.quartal_users,
            attrs: {
              users: _vm.quartal_users,
              groups: _vm.quartal_groups,
              "search-text": _vm.searchText,
            },
          })
        : _vm._e(),
      _vm._v(" "),
      _c(
        "SideBar",
        {
          attrs: {
            open: _vm.isSettingsOpen,
            width: "50vw",
            title: "Настройки",
          },
          on: {
            close: function ($event) {
              _vm.isSettingsOpen = false
            },
          },
        },
        [
          _c("h3", [_vm._v("Подсветка ячеек")]),
          _vm._v(" "),
          _vm._l(_vm.kpiBacklight, function (item, index) {
            return _c("div", { key: index, staticClass: "KPIBacklight-row" }, [
              _vm._v("\n\t\t\tот:\n\t\t\t"),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: item.startValue,
                    expression: "item.startValue",
                  },
                ],
                staticClass: "form-control input-surv KPIBacklight-input",
                attrs: { type: "number", min: item.prevMax, max: 99 },
                domProps: { value: item.startValue },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(item, "startValue", $event.target.value)
                  },
                },
              }),
              _vm._v("\n\t\t\tдо:\n\t\t\t"),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: item.endValue,
                    expression: "item.endValue",
                  },
                ],
                staticClass: "form-control input-surv KPIBacklight-input",
                attrs: { type: "number", min: item.prevMax + 1, max: 100 },
                domProps: { value: item.endValue },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(item, "endValue", $event.target.value)
                  },
                },
              }),
              _vm._v("\n\t\t\tцвет:\n\t\t\t"),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: item.color,
                    expression: "item.color",
                  },
                ],
                staticClass: "form-control input-surv KPIBacklight-input",
                attrs: { type: "color" },
                domProps: { value: item.color },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(item, "color", $event.target.value)
                  },
                },
              }),
              _vm._v(" "),
              _c("i", {
                staticClass: "fa fa-trash btn btn-danger btn-icon",
                on: {
                  click: function ($event) {
                    return _vm.deleteBacklightColor(index)
                  },
                },
              }),
            ])
          }),
          _vm._v(" "),
          _c(
            "button",
            {
              staticClass: "btn btn-primary",
              on: {
                click: function ($event) {
                  return _vm.addBacklightColor(
                    _vm.kpiBacklight[_vm.kpiBacklight.length - 1]
                  )
                },
              },
            },
            [_vm._v("\n\t\t\tДобавить\n\t\t")]
          ),
          _vm._v(" "),
          _c("hr"),
          _vm._v(" "),
          _c(
            "button",
            {
              staticClass: "btn btn-success",
              on: {
                click: function ($event) {
                  _vm.updateBacklightColors().then(function () {
                    _vm.isSettingsOpen = false
                  })
                },
              },
            },
            [_vm._v("\n\t\t\tСохранить\n\t\t")]
          ),
        ],
        2
      ),
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=template&id=032ffa6f&scoped=true&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/kpi/SuperFilter.vue?vue&type=template&id=032ffa6f&scoped=true& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      directives: [
        {
          name: "click-outside",
          rawName: "v-click-outside",
          value: _vm.close,
          expression: "close",
        },
      ],
      staticClass: "super-filter",
    },
    [
      _c("div", { staticClass: "d-flex relative" }, [
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.searchText,
              expression: "searchText",
            },
          ],
          staticClass: "searcher form-control mr-2 pr-3",
          attrs: { type: "text", placeholder: "Поиск по совпадениям..." },
          domProps: { value: _vm.searchText },
          on: {
            click: function ($event) {
              _vm.show = true
            },
            keyup: function ($event) {
              return _vm.$emit("search-text-changed", _vm.searchText)
            },
            input: function ($event) {
              if ($event.target.composing) {
                return
              }
              _vm.searchText = $event.target.value
            },
          },
        }),
        _vm._v(" "),
        _c("i", {
          staticClass: "fa fa-search search-btn",
          on: {
            click: function ($event) {
              return _vm.applyFilter()
            },
          },
        }),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "block _active", class: { show: _vm.show } }, [
        _c("div", { staticClass: "item" }, [
          _c("div", { staticClass: "label" }, [
            _vm._v("\n\t\t\t\tОтдел\n\t\t\t"),
          ]),
          _vm._v(" "),
          _c(
            "select",
            {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.group_id,
                  expression: "group_id",
                },
              ],
              staticClass: "form-control ",
              on: {
                change: [
                  function ($event) {
                    var $$selectedVal = Array.prototype.filter
                      .call($event.target.options, function (o) {
                        return o.selected
                      })
                      .map(function (o) {
                        var val = "_value" in o ? o._value : o.value
                        return val
                      })
                    _vm.group_id = $event.target.multiple
                      ? $$selectedVal
                      : $$selectedVal[0]
                  },
                  function ($event) {
                    return _vm.change("group_id")
                  },
                ],
              },
            },
            _vm._l(Object.keys(_vm.groups), function (key) {
              return _c("option", { key: key, domProps: { value: key } }, [
                _vm._v("\n\t\t\t\t\t" + _vm._s(_vm.groups[key]) + "\n\t\t\t\t"),
              ])
            }),
            0
          ),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "item" }, [
          _c("div", { staticClass: "label" }, [
            _vm._v("\n\t\t\t\tЧто ищем\n\t\t\t"),
          ]),
          _vm._v(" "),
          _c(
            "select",
            {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.s_type,
                  expression: "s_type",
                },
              ],
              staticClass: "form-control ",
              on: {
                change: [
                  function ($event) {
                    var $$selectedVal = Array.prototype.filter
                      .call($event.target.options, function (o) {
                        return o.selected
                      })
                      .map(function (o) {
                        var val = "_value" in o ? o._value : o.value
                        return val
                      })
                    _vm.s_type = $event.target.multiple
                      ? $$selectedVal
                      : $$selectedVal[0]
                  },
                  function ($event) {
                    return _vm.change(_vm.s_type)
                  },
                ],
              },
            },
            _vm._l(Object.keys(_vm.s_types), function (key) {
              return _c("option", { key: key, domProps: { value: key } }, [
                _vm._v(
                  "\n\t\t\t\t\t" + _vm._s(_vm.s_types[key]) + "\n\t\t\t\t"
                ),
              ])
            }),
            0
          ),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "item d-flex" }, [
          _c("div", { staticClass: "label" }, [
            _vm._v("\n\t\t\t\tДанные за\n\t\t\t"),
          ]),
          _vm._v(" "),
          _c(
            "select",
            {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.data_from.month,
                  expression: "data_from.month",
                },
              ],
              staticClass: "form-control mr-2",
              on: {
                change: [
                  function ($event) {
                    var $$selectedVal = Array.prototype.filter
                      .call($event.target.options, function (o) {
                        return o.selected
                      })
                      .map(function (o) {
                        var val = "_value" in o ? o._value : o.value
                        return val
                      })
                    _vm.$set(
                      _vm.data_from,
                      "month",
                      $event.target.multiple ? $$selectedVal : $$selectedVal[0]
                    )
                  },
                  function ($event) {
                    return _vm.changeDate("data_from", "month")
                  },
                ],
              },
            },
            _vm._l(_vm.$moment.months(), function (month, i) {
              return _c("option", { key: month, domProps: { value: i + 1 } }, [
                _vm._v("\n\t\t\t\t\t" + _vm._s(month) + "\n\t\t\t\t"),
              ])
            }),
            0
          ),
          _vm._v(" "),
          _c(
            "select",
            {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.data_from.year,
                  expression: "data_from.year",
                },
              ],
              staticClass: "form-control",
              on: {
                change: [
                  function ($event) {
                    var $$selectedVal = Array.prototype.filter
                      .call($event.target.options, function (o) {
                        return o.selected
                      })
                      .map(function (o) {
                        var val = "_value" in o ? o._value : o.value
                        return val
                      })
                    _vm.$set(
                      _vm.data_from,
                      "year",
                      $event.target.multiple ? $$selectedVal : $$selectedVal[0]
                    )
                  },
                  function ($event) {
                    return _vm.changeDate("data_from", "year")
                  },
                ],
              },
            },
            _vm._l(_vm.years, function (year) {
              return _c("option", { key: year, domProps: { value: year } }, [
                _vm._v("\n\t\t\t\t\t" + _vm._s(year) + "\n\t\t\t\t"),
              ])
            }),
            0
          ),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "item d-flex" }, [
          _c("div", { staticClass: "label" }, [
            _vm._v("\n\t\t\t\tДата создания\n\t\t\t"),
          ]),
          _vm._v(" "),
          _c(
            "select",
            {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.created_at.variant,
                  expression: "created_at.variant",
                },
              ],
              staticClass: "form-control mr-2",
              on: {
                change: [
                  function ($event) {
                    var $$selectedVal = Array.prototype.filter
                      .call($event.target.options, function (o) {
                        return o.selected
                      })
                      .map(function (o) {
                        var val = "_value" in o ? o._value : o.value
                        return val
                      })
                    _vm.$set(
                      _vm.created_at,
                      "variant",
                      $event.target.multiple ? $$selectedVal : $$selectedVal[0]
                    )
                  },
                  function ($event) {
                    return _vm.changeDate("created_at", "variant")
                  },
                ],
              },
            },
            _vm._l(Object.keys(_vm.dates), function (key) {
              return _c("option", { key: key, domProps: { value: key } }, [
                _vm._v("\n\t\t\t\t\t" + _vm._s(_vm.dates[key]) + "\n\t\t\t\t"),
              ])
            }),
            0
          ),
          _vm._v(" "),
          _vm.created_at.variant == 5
            ? _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.created_at.month,
                      expression: "created_at.month",
                    },
                  ],
                  staticClass: "form-control mr-2",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.created_at,
                          "month",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      function ($event) {
                        return _vm.changeDate("created_at", "month")
                      },
                    ],
                  },
                },
                _vm._l(_vm.$moment.months(), function (month, i) {
                  return _c(
                    "option",
                    { key: month, domProps: { value: i + 1 } },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(month) + "\n\t\t\t\t")]
                  )
                }),
                0
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.created_at.variant == 5
            ? _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.created_at.year,
                      expression: "created_at.year",
                    },
                  ],
                  staticClass: "form-control",
                  on: {
                    change: [
                      function ($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function (o) {
                            return o.selected
                          })
                          .map(function (o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.created_at,
                          "year",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      function ($event) {
                        return _vm.changeDate("created_at", "year")
                      },
                    ],
                  },
                },
                _vm._l(_vm.years, function (year) {
                  return _c(
                    "option",
                    { key: year, domProps: { value: year } },
                    [_vm._v("\n\t\t\t\t\t" + _vm._s(year) + "\n\t\t\t\t")]
                  )
                }),
                0
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.created_at.variant == 6
            ? _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.created_at.from,
                    expression: "created_at.from",
                  },
                ],
                staticClass: "form-control form-control-sm mr-2",
                attrs: { type: "date" },
                domProps: { value: _vm.created_at.from },
                on: {
                  change: function ($event) {
                    return _vm.changeDate("created_at", "from")
                  },
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.created_at, "from", $event.target.value)
                  },
                },
              })
            : _vm._e(),
          _vm._v(" "),
          _vm.created_at.variant == 6
            ? _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.created_at.to,
                    expression: "created_at.to",
                  },
                ],
                staticClass: "form-control form-control-sm",
                attrs: { type: "date" },
                domProps: { value: _vm.created_at.to },
                on: {
                  change: function ($event) {
                    return _vm.changeDate("created_at", "to")
                  },
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.created_at, "to", $event.target.value)
                  },
                },
              })
            : _vm._e(),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "mt-3" }, [
          _c(
            "button",
            { staticClass: "btn btn-primary", on: { click: _vm.applyFilter } },
            [
              _c("i", { staticClass: "fa fa-search mr-2" }),
              _vm._v(" "),
              _c("span", [_vm._v("Найти")]),
            ]
          ),
        ]),
      ]),
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);