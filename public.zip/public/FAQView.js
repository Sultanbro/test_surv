"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["FAQView"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _layouts_DefaultLayout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/layouts/DefaultLayout */ "./resources/js/layouts/DefaultLayout.vue");

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'FAQView',
  components: {
    DefaultLayout: _layouts_DefaultLayout__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      page: ''
    };
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.text-black p strong[data-v-aca12ce8]{color:#383838}\nul[data-v-aca12ce8],\nol[data-v-aca12ce8] {\n    padding-left: 30px;\n}\n.content h3[data-v-aca12ce8] {\n  font-weight: 700;\n}\n.content p[data-v-aca12ce8] {\n    color: #000;\n}\n.content a[data-v-aca12ce8] {\n    color: #007bff;\n    -webkit-text-decoration: dashed;\n            text-decoration: dashed;\n}\n#right-panel.show-sidebar .content[data-v-aca12ce8] {\n  padding-left: 15px;\n}\nbody[data-v-aca12ce8] {\n    background: #f1f2f7;\n}\n.card[data-v-aca12ce8] {\n    border: 1px solid #ccc;\n    margin-bottom: 15px;\n}\n.header__profile[data-v-aca12ce8] {\n    display:none !important;\n}\n@media (min-width: 1360px) {\n.container.container-left-padding[data-v-aca12ce8] {\n    padding-left: 7rem !important;\n}\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQView_vue_vue_type_style_index_0_id_aca12ce8_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQView_vue_vue_type_style_index_0_id_aca12ce8_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQView_vue_vue_type_style_index_0_id_aca12ce8_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/views/FAQView.vue":
/*!****************************************!*\
  !*** ./resources/js/views/FAQView.vue ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _FAQView_vue_vue_type_template_id_aca12ce8_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FAQView.vue?vue&type=template&id=aca12ce8&scoped=true& */ "./resources/js/views/FAQView.vue?vue&type=template&id=aca12ce8&scoped=true&");
/* harmony import */ var _FAQView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FAQView.vue?vue&type=script&lang=js& */ "./resources/js/views/FAQView.vue?vue&type=script&lang=js&");
/* harmony import */ var _FAQView_vue_vue_type_style_index_0_id_aca12ce8_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css& */ "./resources/js/views/FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _FAQView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FAQView_vue_vue_type_template_id_aca12ce8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _FAQView_vue_vue_type_template_id_aca12ce8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "aca12ce8",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/views/FAQView.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/views/FAQView.vue?vue&type=script&lang=js&":
/*!*****************************************************************!*\
  !*** ./resources/js/views/FAQView.vue?vue&type=script&lang=js& ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./FAQView.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/views/FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/views/FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css& ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQView_vue_vue_type_style_index_0_id_aca12ce8_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/style-loader/dist/cjs.js!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=style&index=0&id=aca12ce8&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/views/FAQView.vue?vue&type=template&id=aca12ce8&scoped=true&":
/*!***********************************************************************************!*\
  !*** ./resources/js/views/FAQView.vue?vue&type=template&id=aca12ce8&scoped=true& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQView_vue_vue_type_template_id_aca12ce8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQView_vue_vue_type_template_id_aca12ce8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FAQView_vue_vue_type_template_id_aca12ce8_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./FAQView.vue?vue&type=template&id=aca12ce8&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=template&id=aca12ce8&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=template&id=aca12ce8&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/FAQView.vue?vue&type=template&id=aca12ce8&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("DefaultLayout", [
    _c("div", { staticClass: "old__content" }, [
      _c("div", { staticClass: "old__content" }, [
        _c("div", {}, [
          _c("div", { staticClass: "card p-3", attrs: { id: "card1" } }, [
            _c("h3", [_vm._v("Учет времени")]),
            _vm._v(" "),
            _c("p", [_c("strong", [_vm._v("Кнопка «Начать день»")])]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Данная функция фиксирует время начала рабочего дня у удаленных работников:"
              ),
            ]),
            _vm._v(" "),
            _c("ol", [
              _c("li", [
                _vm._v(
                  "У удаленных операторов он фиксируется по нажатию на кнопку «Начать рабочий день» в панели Учета времени, при этом нажать на кнопку можно не ранее 08:30. Время фиксации учитывается в соответствии с временем интернета. "
                ),
              ]),
              _vm._v(" "),
              _c("li", [
                _vm._v(
                  "У штатных операторов данный показатель фиксируется по нажатии на сканер отпечатков Anviz W1 PRO у входа в колл-центр."
                ),
              ]),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Если у вас нет ни кнопки начать день, ни завершить день, значит вы работаете в системе U-calls. При нажатии на Готов в панели оператора начало дня фиксируется автоматически."
              ),
            ]),
            _vm._v(" "),
            _c("p", [_c("strong", [_vm._v("Кнопка «Завершить день»")])]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Данная функция фиксирует время завершения рабочего дня у штатных и удаленных работников:"
              ),
            ]),
            _vm._v(" "),
            _c("ol", [
              _c("li", [
                _vm._v(
                  "Для того чтобы вручную завершить свой рабочий день по какой-либо из причин, будь то это завершенный полностью рабочий день, или вынужденное прерывание рабочего дня по причине надобности ухода с работы в этот день, или же из-за Вашего рабочего графика, Вам требуется нажать на кнопку «Завершить день»."
                ),
              ]),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "После того как Вы нажмете на эту кнопку оплата за работу начисляться не будет."
              ),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Так же эта кнопка может автоматически нажаться/завершить Ваш рабочий день, в этих случаях:"
              ),
            ]),
            _vm._v(" "),
            _c("ol", [
              _c("li", [
                _vm._v(
                  "По установленному рабочему времени группы, в которой Вы работаете. Например, Время работы Вашей группы до 18:00, значит система автоматически завершит Ваш рабочий день в это время. Если же Вы работаете в 2х или более отделах, то система завершит Ваш рабочий день в то время которое указано максимально, например, в одной группе 18:00 а в другой 19:00, значит система завершит в 19:00"
                ),
              ]),
              _vm._v(" "),
              _c("li", [
                _vm._v(
                  "Если Вы находитесь более 10 минут в любом из статусов кроме «ГОТОВ» в панели оператора сервиса обзвона U-Calls "
                ),
                _c("a", { attrs: { href: "http://joxi.ru/1A5wKYktG1J49m" } }, [
                  _vm._v("http://joxi.ru/1A5wKYktG1J49m"),
                ]),
                _vm._v(
                  ", то система автоматически завершит Ваш рабочий день и не будет начислять Вам оплату. Если же Вы вернетесь в статус «ГОТОВ» в течени 10 минут, то система автоматически вернет Вас в рабочее время в панели Учета времени. "
                ),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "bp-text" }, [
              _c("p", [_vm._v(" ")]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      "font-family": "arial, helvetica, sans-serif",
                      "font-size": "12pt",
                    },
                  },
                  [
                    _c(
                      "span",
                      {
                        staticStyle: { "font-size": "13pt", color: "#0065aa" },
                      },
                      [_c("strong", [_vm._v("Корпоративный  портал Jobtron")])]
                    ),
                    _vm._v(
                      " разработан с целью облегчить понимание сотрудника о том сколько он заработал на текущий момент времени и как заработать больше, а также чтобы коммуницировать с коллегами и обучаться новым навыкам. А также портал помогает руководителям анализировать показатели продуктивности своего отдела на основе ежедневных автоматических отчетов.\n\t\t\t\t\t\t\t\t"
                    ),
                  ]
                ),
              ]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      "font-family": "arial, helvetica, sans-serif",
                      "font-size": "12pt",
                    },
                  },
                  [
                    _vm._v(
                      "Каждый сотрудник может ежедневно видеть, сколько он заработал денег на текущий момент времени."
                    ),
                  ]
                ),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("img", {
                  attrs: {
                    src: "/bpartners/1653044718.png",
                    alt: "картинка",
                    width: "947",
                    height: "382",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("p", [_vm._v(" ")]),
              _vm._v(" "),
              _c("p", [_vm._v(" ")]),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(" "),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-size": "13pt",
                        "font-family": "arial, helvetica, sans-serif",
                        color: "#000000",
                      },
                    },
                    [_c("strong", [_vm._v("Кнопка «Начать день»")])]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(
                          "Данная функция фиксирует время начала рабочего дня у удаленных работников:"
                        ),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v("У"),
                      ]),
                      _vm._v(" "),
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(
                          ' удаленных сотрудников начало работы фиксируется по нажатию на кнопку «Начать рабочий день» на странице "Мой профиль", при этом нажать на кнопку можно не ранее 08:30 и не позднее начала Вашего рабочего времени, которое указано на странице "мой профиль" (время фиксации учитывается в соответствии с временем в интернете)'
                        ),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(
                          "У сотрудников которые работают в офисе компании показатель прихода на работу, фиксируется по нажатию на сканер отпечатков пальца у входа в колл-центр."
                        ),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(
                          "Если у вас нет ни кнопки начать день, ни завершить день, значит вы работаете в системе обзвона U-calls. При нажатии на Готов в панели оператора начало дня фиксируется автоматически."
                        ),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(" "),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-size": "13pt",
                        color: "#000000",
                        "font-family": "arial, helvetica, sans-serif",
                      },
                    },
                    [_c("strong", [_vm._v("Кнопка «Завершить день»")])]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(
                          "Данная функция фиксирует время завершения рабочего дня у штатных и удаленных работников:"
                        ),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(
                          "Для того чтобы вручную завершить свой рабочий день по какой-либо из причин, будь то это завершенный полностью рабочий день, или вынужденное прерывание рабочего дня по причине надобности ухода с работы в этот день, или же из-за Вашего рабочего графика, Вам требуется нажать на кнопку «Завершить день». "
                        ),
                      ]),
                      _vm._v(" "),
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(
                          "После того как Вы нажмете на эту кнопку оплата за работу начисляться не будет."
                        ),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(" "),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(
                          "Так же эта кнопка может автоматически нажаться/завершить Ваш рабочий день, в этих случаях:"
                        ),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(
                          "По установленному рабочему времени группы, в которой Вы работаете. Например, Время работы Вашей группы до 18:00, значит система автоматически завершит Ваш рабочий день в это время. Если же Вы работаете в 2х или более отделах, то система завершит Ваш рабочий день в то время которое указано максимально, например, в одной группе 18:00 а в другой 19:00, значит система завершит в 19:00"
                        ),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "h3",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    margin: "0px 0px 0.5em",
                    "line-height": "1.2",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                        "font-size": "12pt",
                      },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "500" } }, [
                        _vm._v(
                          "Если Вы находитесь более 10 минут в любом из статусов кроме «ГОТОВ» в панели оператора сервиса обзвона U-Calls, то система автоматически завершит Ваш рабочий день и не будет начислять Вам оплату. Если же Вы вернетесь в статус «ГОТОВ» в течении 10 минут, то система автоматически вернет Вас в рабочее время в панели Учета времени."
                        ),
                      ]),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c("p", [_vm._v(" ")]),
              _vm._v(" "),
              _c("p", [_vm._v(" ")]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      color: "#000000",
                      "font-family": "arial, helvetica, sans-serif",
                      "font-size": "13pt",
                    },
                  },
                  [_c("strong", [_vm._v("Важно!!!")])]
                ),
              ]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      color: "#000000",
                      "font-family": "arial, helvetica, sans-serif",
                      "font-size": "12pt",
                    },
                  },
                  [
                    _vm._v(
                      'В случае, если при начале рабочего дня Вы нажали статус "Готов" или кнопку "Начать рабочий день" позже 8:45, то Вам будет автоматически начислено депримирование, согласно Системы депремирования.'
                    ),
                  ]
                ),
              ]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      color: "#000000",
                      "font-family": "arial, helvetica, sans-serif",
                      "font-size": "12pt",
                    },
                  },
                  [
                    _vm._v(
                      "Если Вы вообще не отметитесь в системе, то этот день Вам не будет засчитан, как отработанный, и соответственно не будет оплачен."
                    ),
                  ]
                ),
              ]),
              _vm._v(" "),
              _c("p", [_vm._v(" ")]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      color: "#000000",
                      "font-family": "arial, helvetica, sans-serif",
                      "font-size": "13pt",
                    },
                  },
                  [_c("strong", [_vm._v("Как войти в личный кабинет:")])]
                ),
              ]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      "font-family": "arial, helvetica, sans-serif",
                      "font-size": "12pt",
                    },
                  },
                  [
                    _vm._v("1. Переходим по ссылке  "),
                    _c("a", { attrs: { href: "../login", target: "_blank" } }, [
                      _vm._v("http://joytron.org/"),
                    ]),
                  ]
                ),
              ]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      "font-family": "arial, helvetica, sans-serif",
                      "font-size": "12pt",
                    },
                  },
                  [_vm._v("2. Заходите используя свой логин и пароль")]
                ),
              ]),
              _vm._v(" "),
              _c("p", [_vm._v(" ")]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "card p-3", attrs: { id: "card2" } }, [
            _c("h3", [_vm._v("Показатели в таблицах аналитики")]),
            _vm._v(" "),
            _c("p", [
              _c("strong", [_vm._v("Оклад – ")]),
              _vm._v(
                "эта строка показывает фактические начисления за каждый отработанный Вами день. Так же тут показаны суммы депримирований, если таковые имелись, например, опоздания, выговоры, прогулы. Вам начисляется ежедневно сумма в строку «Оклад» по простой формуле: Ваш оклад, поделенный на кол-во рабочих дней в месяце (это кол-во дней минус кол-во воскресений) далее поделенный на количество рабочих часов и умноженных на фактически отработанные часы, которые отражаются в строке «часы работы»\n\t\t\t\t\t\t"
              ),
            ]),
            _vm._v(" "),
            _c("p", [
              _c("strong", [_vm._v("Время прихода – ")]),
              _vm._v(
                "в данной строке указано время начала рабочего дня, это тогда, когда Вы нажали на кнопки «Начать день» если Вы штатный сотрудник или «Готов» если Вы работаете удаленно.\n\t\t\t\t\t\t"
              ),
            ]),
            _vm._v(" "),
            _c("p", [
              _c("strong", [_vm._v("Часы работы – ")]),
              _vm._v(
                "это показатель количества отработанных часов за день.\n\t\t\t\t\t\t"
              ),
            ]),
            _vm._v(" "),
            _c("p", [_c("strong", [_vm._v("Оплата труда")])]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Она делится на 2 показателя + внутренняя валюта. Первая часть — это оклад, и вторая это KPI (выполнение определённых показателей в работе)"
              ),
            ]),
            _vm._v(" "),
            _c("p", [_c("strong", [_vm._v("Показатель «Баланс Оклада»")])]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Вы можете каждый час наблюдать как увеличивается окладная сумма, которую Вы заработали за каждый час работы. Если нажать на сумму, то Вы попадете на страницу где указаны данные начислений за каждый Ваш отработанный день. "
              ),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Стандартный оклад оператора составляет 80 000 тенге в месяц, из этого расчёта считается баланс оклада."
              ),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "При этом если оператор не сдал запланированный экзамен по прочитанной книге, и не получил положительную оценку от экзаменатора, то расчёт оклада за месяц будет автоматически перерассчитан из суммы 70 000 тенге."
              ),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Если же оператор и на второй месяц не сдал запланированный экзамен по прочитанной книге, то оплата будет рассчитываться автоматически из суммы оклада 60 000 тенге в месяц."
              ),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v("\n\t\t\t\t\t\t\tПлан книг указан на странице "),
              _c(
                "a",
                { attrs: { href: "/timetracking/books", target: "_blank" } },
                [_vm._v("плана чтения книг")]
              ),
              _vm._v(".\n\t\t\t\t\t\t"),
            ]),
            _vm._v(" "),
            _c("p", [
              _c("strong", [_vm._v("Показатель «")]),
              _vm._v(" "),
              _c("strong", [_vm._v("KPI»")]),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Это показатель выполнения определённых дополнительных показателей в работе, например, таких как:"
              ),
            ]),
            _vm._v(" "),
            _c("ul", [
              _c("li", [_vm._v("Минуты разговора")]),
              _vm._v(" "),
              _c("li", [_vm._v("Средний рейтинг оператора")]),
              _vm._v(" "),
              _c("li", [_vm._v("Переданные клиенты")]),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Ниже с показателя «Баланс оклада» находится состояние баланса «KPI», данный показатель рассчитывается по формуле и делает дополнительные начисления к Вашей оплате труда."
              ),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Кликнув на сумму KPI Вам будет показано подробное состояние начислений KPI на сегодняшний день."
              ),
            ]),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "Показатели KPI могут меняться каждый месяц, и устанавливаются они руководителями групп."
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "bp-text" }, [
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                      },
                    },
                    [
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "font-size": "12pt",
                            color: "#000000",
                          },
                        },
                        [
                          _c(
                            "span",
                            {
                              staticStyle: {
                                "box-sizing": "border-box",
                                "font-weight": "bolder",
                              },
                            },
                            [_vm._v("1. Баланс оклада – ")]
                          ),
                          _vm._v(
                            "это показатель фактически начисленных денег за каждый отработанный Вами день. Так же тут показаны суммы депримирований, если они были, например, опоздания, нарушения правил, прогулы. Вам начисляется ежедневно сумма в строку «Оклад» по простой формуле: Ваш оклад, поделенный на кол-во рабочих дней в месяце (это кол-во дней минус кол-во воскресений) далее поделенный на количество рабочих часов и умноженных на фактически отработанные часы, которые отражаются в строке «часы работы».  "
                          ),
                        ]
                      ),
                      _vm._v(
                        "Вы можете каждый час наблюдать как увеличивается окладная сумма, которую Вы заработали за каждый час работы.  "
                      ),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-size": "12pt",
                        color: "#000000",
                        "font-family": "arial, helvetica, sans-serif",
                      },
                    },
                    [
                      _c(
                        "span",
                        { staticStyle: { "box-sizing": "border-box" } },
                        [_vm._v("Время прихода – ")]
                      ),
                      _vm._v(
                        "в данной строке указано время начала рабочего дня, это тогда, когда Вы нажали на кнопки «Начать день» если Вы штатный сотрудник или «Готов» если Вы работаете удаленно. "
                      ),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-size": "12pt",
                        color: "#000000",
                        "font-family": "arial, helvetica, sans-serif",
                      },
                    },
                    [
                      _c(
                        "span",
                        { staticStyle: { "box-sizing": "border-box" } },
                        [_vm._v("Часы работы – ")]
                      ),
                      _vm._v(
                        "это показатель количества отработанных часов за день. "
                      ),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [_vm._v("\n \n\t\t\t\t\t\t\t")]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                      },
                    },
                    [
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "font-size": "12pt",
                            color: "#000000",
                          },
                        },
                        [
                          _c(
                            "span",
                            {
                              staticStyle: {
                                "box-sizing": "border-box",
                                "font-weight": "bolder",
                              },
                            },
                            [_vm._v("2. Показатель «")]
                          ),
                          _vm._v(" "),
                          _c(
                            "span",
                            {
                              staticStyle: {
                                "box-sizing": "border-box",
                                "font-weight": "bolder",
                              },
                            },
                            [_vm._v("KPI», ")]
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "font-size": "12pt",
                            color: "#000000",
                          },
                        },
                        [
                          _vm._v(
                            "это показатель выполнения определённых дополнительных активностей в работе, например, таких как:"
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "ul",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "padding-left": "30px",
                    "list-style": "none",
                    color: "rgba(0, 0, 0, 0.65)",
                    "font-size": "14px",
                  },
                },
                [
                  _c("li", { staticStyle: { "box-sizing": "border-box" } }, [
                    _c(
                      "span",
                      {
                        staticStyle: {
                          "font-size": "12pt",
                          color: "#000000",
                          "font-family": "arial, helvetica, sans-serif",
                        },
                      },
                      [_vm._v("Минуты разговора")]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", { staticStyle: { "box-sizing": "border-box" } }, [
                    _c(
                      "span",
                      {
                        staticStyle: {
                          "font-size": "12pt",
                          color: "#000000",
                          "font-family": "arial, helvetica, sans-serif",
                        },
                      },
                      [_vm._v("Средний рейтинг оператора")]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", { staticStyle: { "box-sizing": "border-box" } }, [
                    _c(
                      "span",
                      {
                        staticStyle: {
                          "font-size": "12pt",
                          color: "#000000",
                          "font-family": "arial, helvetica, sans-serif",
                        },
                      },
                      [_vm._v("Переданные клиенты")]
                    ),
                  ]),
                ]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                      },
                    },
                    [
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "font-size": "12pt",
                            color: "#000000",
                          },
                        },
                        [
                          _vm._v(
                            "Кликнув на сумму KPI Вам будет показано подробное состояние выполнения назначенных Вам активностей и заработанная сумма денег на сегодняшний день. "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "font-size": "12pt",
                            color: "#000000",
                          },
                        },
                        [
                          _vm._v(
                            "Показатели KPI могут меняться каждый месяц, и устанавливаются они руководителями отделов."
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [_vm._v("\n \n\t\t\t\t\t\t\t")]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                      },
                    },
                    [
                      _c("strong", [
                        _c(
                          "span",
                          {
                            staticStyle: {
                              "font-size": "12pt",
                              color: "#000000",
                            },
                          },
                          [_vm._v("3. Бонусы: ")]
                        ),
                      ]),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "font-size": "12pt",
                            color: "#000000",
                          },
                        },
                        [
                          _vm._v(
                            'это деньги которые Вы можете зарабатывать дополнительно каждый день, и Ваша сумма к выплате за месяц будет выше, чем просто оклад. Например бонусы могут начисляться за то, что Вы первый в отделе сделаете больше какой то активности, например больше согласий до обеда, или за день, или больше минут проговорите и тому подобное. Кликните на иконку "Бонусы" и там будет написано, как Вам заработать больше бонусов.'
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [_vm._v("\n \n\t\t\t\t\t\t\t")]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                      },
                    },
                    [
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "font-size": "12pt",
                            color: "#000000",
                          },
                        },
                        [
                          _c("strong", [_vm._v("4. Квартальная премия. ")]),
                          _vm._v(
                            "Чем Выше Вы по должности, тем больше вероятность, что у Вас есть заработать квартальную премию. Она назначается Директорами компании. Поэтому обучатся курсам которые Вам назначены и расти по карьерной лестнице Вам очень выгодно и с финансовой точки зрения. "
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [_vm._v("\n \n\t\t\t\t\t\t\t")]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "font-family": "arial, helvetica, sans-serif",
                      },
                    },
                    [
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "font-size": "12pt",
                            color: "#000000",
                          },
                        },
                        [
                          _c("strong", [_vm._v("5. Награды: ")]),
                          _vm._v(
                            "это нематериальная мотивация, хотя в этом разделе есть и материальные поощрения, обязательно изучите этот раздел. Тут есть и сертификаты и грамоты, и возможность заработать внутреннюю валюту, которую потом можно обменять на физические, ценные вещи.  "
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [_vm._v("\n \n\t\t\t\t\t\t\t")]
              ),
            ]),
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "card p-3 text-black", attrs: { id: "card3" } },
            [
              _c("h3", [_vm._v("Правила выдачи оплаты")]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [_vm._v(" 1. Какой график? ")]
                ),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(
                  " Есть 3 разных графика работы на полный день и 3 графика на пол дня: "
                ),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" на полный день "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" с 08:45 - 19:00 "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" с 13:00 - 23:00 "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v("с 18:00 - 02:00 "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v("на пол дня "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v("c 08:45 - 13:00 "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v("c 14:00 - 19:00 "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v("c 19:00 - 23:00\n\t\t\t\t\t\t"),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [_vm._v("2. Сколько дней обучения для стажера?")]
                ),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(
                  "Обучение длится в среднем 5-7 дней, все зависит от усваиваемости материала и способности обучаться. Чем раньше Вы готовы будете рассказать нам о продукте с которым Вы будете работать, тем раньше начнете официально работать.\n\t\t\t\t\t\t"
                ),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [
                    _vm._v(
                      "3. Как я могу заработать больше проходя обучающие курсы ?"
                    ),
                  ]
                ),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(
                  "Обучающие курсы проходить нужно обязательно, они у Вас указаны на странице Вашего профиля, и Вам за это начисляются баллы, а баллы это деньги которые мы прибавим к Вашей выплате за отработанный месяц.\n\t\t\t\t\t\t"
                ),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [_vm._v("4.Можно ли самому выбирать выходной день?")]
                ),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(
                  "Выходные дни в разных отделах, в разные дни и о них Вам сообщит Вам руководитель отдела. "
                ),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
              ]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [_vm._v("5. Как можно получить аванс?")]
                ),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(
                  "Аванс Вы можете запросить при достижении определенных активностей (показателей) в Вашей группе, установленных Вашим руководителем.\n\t\t\t\t\t\t"
                ),
              ]),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [_vm._v("\n \n\t\t\t\t\t\t")]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "box-sizing": "border-box",
                        "font-weight": "bolder",
                        color: "#383838",
                      },
                    },
                    [_vm._v("6. Вопросы по оплате")]
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "p",
                {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "font-family": "'Open Sans', sans-serif",
                    "margin-top": "0px",
                    "margin-bottom": "1em",
                    "font-size": "16px",
                    "line-height": "24px",
                    color: "#333333",
                  },
                },
                [
                  _c(
                    "span",
                    {
                      staticStyle: {
                        "box-sizing": "border-box",
                        "font-weight": "bolder",
                        color: "#383838",
                      },
                    },
                    [
                      _c(
                        "span",
                        {
                          staticStyle: {
                            "background-color": "#ffffff",
                            "font-family": "sans-serif",
                          },
                        },
                        [_vm._v("Вопрос:")]
                      ),
                      _vm._v(" "),
                      _c("span", {
                        staticStyle: {
                          "background-color": "#ffffff",
                          "font-family": "sans-serif",
                        },
                      }),
                      _vm._v("Сколько составляет оклад? "),
                    ]
                  ),
                  _vm._v(" "),
                  _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                  _vm._v(" "),
                  _c(
                    "span",
                    {
                      staticStyle: {
                        color: "#000000",
                        "font-family": "sans-serif",
                        "font-size": "medium",
                        "background-color": "#ffffff",
                      },
                    },
                    [_vm._v("Ответ: ")]
                  ),
                  _vm._v(
                    "Окладная часть оператора зависит от количества отработанных часов в месяце. Работая полный день окладная часть достигает 80 000 тенге + Kpi в размере до 60 000 тенге в зависимости от отдела (проект) в котором Вы работаете.\n\t\t\t\t\t\t"
                  ),
                ]
              ),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "background-color": "#ffffff",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [_vm._v("Вопрос: Когда будет ЗП?")]
                ),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c("span", { staticStyle: { "background-color": "#ffffff" } }, [
                  _vm._v(
                    "Ответ: начисления по договору выплачивается до 25 числа "
                  ),
                ]),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticClass: "bx-messenger-ajax bx-messenger-ajax-black",
                    staticStyle: {
                      "box-sizing": "border-box",
                      "background-color": "#ffffff",
                    },
                    attrs: {
                      "data-entity": "date",
                      "data-messageid": "8136640",
                      "data-ts": "1630422000",
                    },
                  },
                  [_vm._v("следующего месяца")]
                ),
                _vm._v(" "),
                _c("span", { staticStyle: { "background-color": "#ffffff" } }, [
                  _vm._v(". Но обычно ЗП начинают выдавать в районе 10 числа "),
                ]),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticClass: "bx-messenger-ajax bx-messenger-ajax-black",
                    staticStyle: {
                      "box-sizing": "border-box",
                      "background-color": "#ffffff",
                    },
                    attrs: {
                      "data-entity": "date",
                      "data-messageid": "8136640",
                      "data-ts": "1630422000",
                    },
                  },
                  [_vm._v("следующего месяца")]
                ),
                _vm._v(" "),
                _c("span", { staticStyle: { "background-color": "#ffffff" } }, [
                  _vm._v("."),
                ]),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "background-color": "#ffffff",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [_vm._v("Вопрос: Почему кто-то получил ЗП а я еще нет?")]
                ),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c("span", { staticStyle: { "background-color": "#ffffff" } }, [
                  _vm._v(
                    "Ответ: Это может произойти по нескольким причинам. Во-первых, потому что выплаты начинаются по мере готовности ведомости Вашим руководителем. Во-вторых, потому что на банковских картах есть лимит в сутки на перечисление."
                  ),
                ]),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "background-color": "#ffffff",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [
                    _vm._v(
                      "Вопрос: Мне начислили неправильную сумму – что мне делать?"
                    ),
                  ]
                ),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c("span", { staticStyle: { "background-color": "#ffffff" } }, [
                  _vm._v(
                    "Ответ: Вам нужно обратиться к Вашему руководителю. Перед этим проверить начисление в системе учета рабочего времени."
                  ),
                ]),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "background-color": "#ffffff",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [_vm._v("Вопрос: Кому первому выдают ЗП?")]
                ),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c("span", { staticStyle: { "background-color": "#ffffff" } }, [
                  _vm._v(
                    "Ответ: Очередность выдачи ЗП осуществляется в случайном порядке."
                  ),
                ]),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "background-color": "#ffffff",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [_vm._v("Вопрос: Когда будет повышение ЗП?")]
                ),
                _vm._v(" "),
                _c("br", {
                  staticStyle: {
                    "box-sizing": "border-box",
                    "background-color": "#ffffff",
                  },
                }),
                _vm._v(" "),
                _c("span", { staticStyle: { "background-color": "#ffffff" } }, [
                  _vm._v("Ответ: Каждые 3 "),
                ]),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticClass: "bx-messenger-ajax bx-messenger-ajax-black",
                    staticStyle: {
                      "box-sizing": "border-box",
                      "background-color": "#ffffff",
                    },
                    attrs: {
                      "data-entity": "date",
                      "data-messageid": "8136640",
                      "data-ts": "1627743600",
                    },
                  },
                  [_vm._v("месяца")]
                ),
                _vm._v(" "),
                _c("span", { staticStyle: { "background-color": "#ffffff" } }, [
                  _vm._v(
                    " для операторов происходит индексация ЗП, то есть повышение ЗП оператора колл-центра на 5 000 тенге."
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [
                    _c(
                      "span",
                      { staticStyle: { "background-color": "#ffffff" } },
                      [_vm._v("Вопрос:")]
                    ),
                    _vm._v(" "),
                    _c("span", {
                      staticStyle: { "background-color": "#ffffff" },
                    }),
                    _vm._v("От чего зависит бонусная часть? "),
                  ]
                ),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c("span", { staticStyle: { "background-color": "#ffffff" } }, [
                  _vm._v("Ответ: "),
                ]),
                _vm._v(
                  "В каждой группе колл центра, есть KPI - это показатели по разным активностям оператора, например звонки и минуты. KPI в разных отделах от 20 000 - 60 000 тысяч тенге, и чем активнее Вы работаете, тем больше по итогу  "
                ),
                _c(
                  "span",
                  {
                    staticClass: "bx-messenger-ajax bx-messenger-ajax-black",
                    staticStyle: { "box-sizing": "border-box" },
                    attrs: {
                      "data-entity": "date",
                      "data-messageid": "8433466",
                      "data-ts": "1630422000",
                    },
                  },
                  [_vm._v("месяца")]
                ),
                _vm._v(
                  " получите оплату. Так же есть и другие виды материальной мотивации которые описаны в базе знаний. "
                ),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticStyle: {
                      "box-sizing": "border-box",
                      "font-weight": "bolder",
                      color: "#383838",
                    },
                  },
                  [
                    _c(
                      "span",
                      { staticStyle: { "background-color": "#ffffff" } },
                      [_vm._v("Вопрос: ")]
                    ),
                    _vm._v(
                      "З/П в договоре указана уже с вычетом налогового обложения 10%? "
                    ),
                  ]
                ),
                _vm._v(" "),
                _c("br", { staticStyle: { "box-sizing": "border-box" } }),
                _vm._v(" "),
                _c("span", { staticStyle: { "background-color": "#ffffff" } }, [
                  _vm._v("Ответ: "),
                ]),
                _vm._v("В договоре указана сумма без вычета.\n\t\t\t\t\t\t"),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("strong", [_vm._v("Вопрос: Когда будет ЗП?")]),
                _vm._v(" "),
                _c("br"),
                _vm._v("Ответ: ЗП по договору выплачивается до 25 числа  "),
                _c(
                  "span",
                  {
                    staticClass: "bx-messenger-ajax bx-messenger-ajax-black",
                    attrs: {
                      "data-entity": "date",
                      "data-messageid": "8136640",
                      "data-ts": "1630422000",
                    },
                  },
                  [_vm._v("следующего месяца")]
                ),
                _vm._v(". Но обычно ЗП начинают выдавать в районе 10 числа  "),
                _c(
                  "span",
                  {
                    staticClass: "bx-messenger-ajax bx-messenger-ajax-black",
                    attrs: {
                      "data-entity": "date",
                      "data-messageid": "8136640",
                      "data-ts": "1630422000",
                    },
                  },
                  [_vm._v("следующего месяца")]
                ),
                _vm._v(". "),
                _c("br"),
                _vm._v(" "),
                _c("br"),
                _vm._v(" "),
                _c("strong", [
                  _vm._v("Вопрос: Почему кто-то получил ЗП а я еще нет?"),
                ]),
                _vm._v(" "),
                _c("br"),
                _vm._v(
                  "Ответ: Это может произойти по нескольким причинам. Во-первых, потому что выплаты начинаются по мере готовности ведомости. Во-вторых, потому что на банковских картах есть лимит в сутки на перечисление. "
                ),
                _c("br"),
                _vm._v(" "),
                _c("br"),
                _vm._v(" "),
                _c("strong", [
                  _vm._v(
                    "Вопрос: Мне начислили неправильную сумму – что мне делать?"
                  ),
                ]),
                _vm._v(" "),
                _c("br"),
                _vm._v(
                  "Ответ: Вам нужно обратиться к Вашему руководителю. Перед этим проверить начисление в системе учета рабочего времени. "
                ),
                _c("br"),
                _vm._v(" "),
                _c("br"),
                _vm._v(" "),
                _c("strong", [_vm._v("Вопрос: Кому первому выдают ЗП?")]),
                _vm._v(" "),
                _c("br"),
                _vm._v(
                  "Ответ: Очередность выдачи ЗП осуществляется в случайном порядке. "
                ),
                _c("br"),
                _vm._v(" "),
                _c("br"),
                _vm._v(" "),
                _c("strong", [_vm._v("Вопрос: Когда будет повышение ЗП?")]),
                _vm._v(" "),
                _c("br"),
                _vm._v("Ответ: Каждые 3  "),
                _c(
                  "span",
                  {
                    staticClass: "bx-messenger-ajax bx-messenger-ajax-black",
                    attrs: {
                      "data-entity": "date",
                      "data-messageid": "8136640",
                      "data-ts": "1627743600",
                    },
                  },
                  [_vm._v("месяца")]
                ),
                _vm._v(
                  " происходит индексация ЗП, то есть повышение ЗП оператора колл-центра на 5 000 тенге.\n\t\t\t\t\t\t"
                ),
              ]),
            ]
          ),
        ]),
      ]),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);